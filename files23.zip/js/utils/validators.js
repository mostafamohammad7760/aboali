/**
 * وحدة التحقق من صحة البيانات للضرائب والزكاة
 * @module validators
 */

/**
 * التحقق من صحة رقم الإقرار الضريبي
 * @param {string} returnNumber - رقم الإقرار
 * @returns {boolean} نتيجة التحقق
 */
export function validateTaxReturnNumber(returnNumber) {
    const pattern = /^TAX-\d{6}$/;
    return pattern.test(returnNumber);
}

/**
 * التحقق من صحة إقرار ضريبة القيمة المضافة
 * @param {Object} vatReturn - بيانات إقرار ضريبة القيمة المضافة
 * @throws {Error} خطأ في حالة عدم صحة البيانات
 */
export function validateVATReturn(vatReturn) {
    const requiredFields = [
        'period_start',
        'period_end',
        'sales_amount',
        'purchases_amount',
        'vat_on_sales',
        'vat_on_purchases'
    ];

    // التحقق من وجود الحقول المطلوبة
    validateRequiredFields(vatReturn, requiredFields);

    // التحقق من صحة التواريخ
    validateDateRange(vatReturn.period_start, vatReturn.period_end);

    // التحقق من صحة المبالغ
    validateAmounts([
        { value: vatReturn.sales_amount, name: 'مبلغ المبيعات' },
        { value: vatReturn.purchases_amount, name: 'مبلغ المشتريات' },
        { value: vatReturn.vat_on_sales, name: 'ضريبة المبيعات' },
        { value: vatReturn.vat_on_purchases, name: 'ضريبة المشتريات' }
    ]);

    // التحقق من صحة احتساب الضريبة
    validateVATCalculation(vatReturn);
}

/**
 * التحقق من صحة بيانات وعاء الزكاة
 * @param {Object} zakatBase - بيانات وعاء الزكاة
 * @throws {Error} خطأ في حالة عدم صحة البيانات
 */
export function validateZakatBase(zakatBase) {
    const requiredFields = [
        'year',
        'period_start',
        'period_end',
        'capital',
        'reserves',
        'retained_earnings'
    ];

    // التحقق من وجود الحقول المطلوبة
    validateRequiredFields(zakatBase, requiredFields);

    // التحقق من صحة السنة المالية
    validateFiscalYear(zakatBase.year);

    // التحقق من صحة التواريخ
    validateDateRange(zakatBase.period_start, zakatBase.period_end);

    // التحقق من صحة المبالغ
    validateAmounts([
        { value: zakatBase.capital, name: 'رأس المال' },
        { value: zakatBase.reserves, name: 'الاحتياطيات' },
        { value: zakatBase.retained_earnings, name: 'الأرباح المحتجزة' }
    ]);
}

/**
 * التحقق من صحة بيانات المستند
 * @param {Object} document - بيانات المستند
 * @throws {Error} خطأ في حالة عدم صحة البيانات
 */
export function validateDocument(document) {
    const requiredFields = [
        'document_type',
        'reference_type',
        'reference_id',
        'file'
    ];

    // التحقق من وجود الحقول المطلوبة
    validateRequiredFields(document, requiredFields);

    // التحقق من نوع المستند
    validateDocumentType(document.document_type);

    // التحقق من الملف
    validateFile(document.file);
}

/**
 * التحقق من وجود الحقول المطلوبة
 * @param {Object} data - البيانات المراد التحقق منها
 * @param {Array<string>} requiredFields - قائمة الحقول المطلوبة
 * @throws {Error} خطأ في حالة عدم وجود حقل مطلوب
 */
export function validateRequiredFields(data, requiredFields) {
    const missingFields = requiredFields.filter(field => !data[field]);
    if (missingFields.length > 0) {
        throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
    }
}

/**
 * التحقق من صحة نطاق التواريخ
 * @param {string|Date} startDate - تاريخ البداية
 * @param {string|Date} endDate - تاريخ النهاية
 * @throws {Error} خطأ في حالة عدم صحة التواريخ
 */
export function validateDateRange(startDate, endDate) {
    const start = new Date(startDate);
    const end = new Date(endDate);

    if (isNaN(start.getTime())) {
        throw new Error('تاريخ البداية غير صالح');
    }

    if (isNaN(end.getTime())) {
        throw new Error('تاريخ النهاية غير صالح');
    }

    if (start > end) {
        throw new Error('تاريخ البداية يجب أن يكون قبل تاريخ النهاية');
    }
}

/**
 * التحقق من صحة المبالغ
 * @param {Array<{value: number, name: string}>} amounts - قائمة المبالغ
 * @throws {Error} خطأ في حالة عدم صحة المبالغ
 */
export function validateAmounts(amounts) {
    amounts.forEach(({ value, name }) => {
        if (typeof value !== 'number') {
            throw new Error(`${name} يجب أن يكون رقماً`);
        }
        if (value < 0) {
            throw new Error(`${name} لا يمكن أن يكون سالباً`);
        }
    });
}

/**
 * التحقق من صحة احتساب ضريبة القيمة المضافة
 * @param {Object} vatReturn - بيانات إقرار ضريبة القيمة المضافة
 * @throws {Error} خطأ في حالة عدم صحة الاحتساب
 */
export function validateVATCalculation(vatReturn) {
    const STANDARD_VAT_RATE = 0.15; // 15%
    
    const expectedVATOnSales = vatReturn.sales_amount * STANDARD_VAT_RATE;
    const expectedVATOnPurchases = vatReturn.purchases_amount * STANDARD_VAT_RATE;
    
    const tolerance = 0.01; // للتعامل مع فروقات التقريب

    if (Math.abs(vatReturn.vat_on_sales - expectedVATOnSales) > tolerance) {
        throw new Error('قيمة ضريبة المبيعات غير صحيحة');
    }

    if (Math.abs(vatReturn.vat_on_purchases - expectedVATOnPurchases) > tolerance) {
        throw new Error('قيمة ضريبة المشتريات غير صحيحة');
    }
}

/**
 * التحقق من صحة السنة المالية
 * @param {number} year - السنة المالية
 * @throws {Error} خطأ في حالة عدم صحة السنة
 */
export function validateFiscalYear(year) {
    const currentYear = new Date().getFullYear();
    
    if (!Number.isInteger(year)) {
        throw new Error('السنة المالية يجب أن تكون رقماً صحيحاً');
    }

    if (year < 2000 || year > currentYear + 1) {
        throw new Error('السنة المالية غير صالحة');
    }
}

/**
 * التحقق من نوع المستند
 * @param {string} documentType - نوع المستند
 * @throws {Error} خطأ في حالة عدم صحة نوع المستند
 */
export function validateDocumentType(documentType) {
    const validTypes = [
        'vat_return',
        'zakat_declaration',
        'financial_statement',
        'supporting_document',
        'official_letter'
    ];

    if (!validTypes.includes(documentType)) {
        throw new Error('نوع المستند غير صالح');
    }
}

/**
 * التحقق من الملف
 * @param {File} file - الملف المراد التحقق منه
 * @throws {Error} خطأ في حالة عدم صحة الملف
 */
export function validateFile(file) {
    const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 ميجابايت
    const ALLOWED_TYPES = [
        'application/pdf',
        'image/jpeg',
        'image/png',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    ];

    if (!file) {
        throw new Error('الملف مطلوب');
    }

    if (file.size > MAX_FILE_SIZE) {
        throw new Error('حجم الملف يتجاوز الحد المسموح به (10 ميجابايت)');
    }

    if (!ALLOWED_TYPES.includes(file.type)) {
        throw new Error('نوع الملف غير مدعوم');
    }
}