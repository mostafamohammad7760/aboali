export class FinancialReportsAPI {
    constructor() {
        this.baseUrl = '/api/v1/financial-reports';
        this.defaultHeaders = {
            'Content-Type': 'application/json',
            'X-User-Id': 'mostafamohammad7760',
            'X-Timestamp': new Date().toISOString()
        };
    }

    async request(endpoint, options = {}) {
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                ...options,
                headers: {
                    ...this.defaultHeaders,
                    ...options.headers
                }
            });

            if (!response.ok) {
                throw await this.handleErrorResponse(response);
            }

            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            throw this.createUserFriendlyError(error);
        }
    }

    // طلبات لوحة المعلومات
    async getReportStats() {
        return this.request('/dashboard/report-stats');
    }

    async getRatioStats() {
        return this.request('/dashboard/ratio-stats');
    }

    async getNoteStats() {
        return this.request('/dashboard/note-stats');
    }

    async getAdjustmentStats() {
        return this.request('/dashboard/adjustment-stats');
    }

    async getRatiosAnalysis(period = 'month') {
        return this.request(`/dashboard/ratios-analysis?period=${period}`);
    }

    async getItemsAnalysis(period = 'month') {
        return this.request(`/dashboard/items-analysis?period=${period}`);
    }

    async getLatestReports() {
        return this.request('/dashboard/latest-reports');
    }

    // طلبات الفترات المالية
    async getFinancialPeriods(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/periods?${queryString}`);
    }

    async getFinancialPeriod(periodId) {
        return this.request(`/periods/${periodId}`);
    }

    async createFinancialPeriod(periodData) {
        this.validatePeriodData(periodData);
        return this.request('/periods', {
            method: 'POST',
            body: JSON.stringify(periodData)
        });
    }

    async updateFinancialPeriod(periodId, periodData) {
        this.validatePeriodData(periodData);
        return this.request(`/periods/${periodId}`, {
            method: 'PUT',
            body: JSON.stringify(periodData)
        });
    }

    async closePeriod(periodId) {
        return this.request(`/periods/${periodId}/close`, {
            method: 'PUT'
        });
    }

    // طلبات التقارير المالية
    async getFinancialReports(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports?${queryString}`);
    }

    async getFinancialReport(reportId) {
        return this.request(`/reports/${reportId}`);
    }

    async createFinancialReport(reportData) {
        this.validateReportData(reportData);
        return this.request('/reports', {
            method: 'POST',
            body: JSON.stringify(reportData)
        });
    }

    async updateFinancialReport(reportId, reportData) {
        this.validateReportData(reportData);
        return this.request(`/reports/${reportId}`, {
            method: 'PUT',
            body: JSON.stringify(reportData)
        });
    }

    async submitForReview(reportId) {
        return this.request(`/reports/${reportId}/submit`, {
            method: 'PUT'
        });
    }

    async approveReport(reportId) {
        return this.request(`/reports/${reportId}/approve`, {
            method: 'PUT'
        });
    }

    async publishReport(reportId) {
        return this.request(`/reports/${reportId}/publish`, {
            method: 'PUT'
        });
    }

    async exportReport(reportId, format = 'pdf') {
        return this.request(`/reports/${reportId}/export?format=${format}`, {
            headers: {
                'Accept': 'application/octet-stream'
            }
        });
    }

    // طلبات الإيضاحات المتممة
    async getFinancialNotes(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/notes?${queryString}`);
    }

    async getFinancialNote(noteId) {
        return this.request(`/notes/${noteId}`);
    }

    async createFinancialNote(noteData) {
        this.validateNoteData(noteData);
        return this.request('/notes', {
            method: 'POST',
            body: JSON.stringify(noteData)
        });
    }

    async updateFinancialNote(noteId, noteData) {
        this.validateNoteData(noteData);
        return this.request(`/notes/${noteId}`, {
            method: 'PUT',
            body: JSON.stringify(noteData)
        });
    }

    async submitNoteForReview(noteId) {
        return this.request(`/notes/${noteId}/submit`, {
            method: 'PUT'
        });
    }

    async approveNote(noteId) {
        return this.request(`/notes/${noteId}/approve`, {
            method: 'PUT'
        });
    }

    // طلبات التسويات المالية
    async getFinancialAdjustments(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/adjustments?${queryString}`);
    }

    async getFinancialAdjustment(adjustmentId) {
        return this.request(`/adjustments/${adjustmentId}`);
    }

    async createFinancialAdjustment(adjustmentData) {
        this.validateAdjustmentData(adjustmentData);
        return this.request('/adjustments', {
            method: 'POST',
            body: JSON.stringify(adjustmentData)
        });
    }

    async updateFinancialAdjustment(adjustmentId, adjustmentData) {
        this.validateAdjustmentData(adjustmentData);
        return this.request(`/adjustments/${adjustmentId}`, {
            method: 'PUT',
            body: JSON.stringify(adjustmentData)
        });
    }

    async approveAdjustment(adjustmentId) {
        return this.request(`/adjustments/${adjustmentId}/approve`, {
            method: 'PUT'
        });
    }

    async rejectAdjustment(adjustmentId, reason) {
        return this.request(`/adjustments/${adjustmentId}/reject`, {
            method: 'PUT',
            body: JSON.stringify({ reason })
        });
    }

    // طلبات المؤشرات المالية
    async getFinancialRatios(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/ratios?${queryString}`);
    }

    async getFinancialRatio(ratioId) {
        return this.request(`/ratios/${ratioId}`);
    }

    async updateFinancialRatio(ratioId, ratioData) {
        this.validateRatioData(ratioData);
        return this.request(`/ratios/${ratioId}`, {
            method: 'PUT',
            body: JSON.stringify(ratioData)
        });
    }

    async calculateAllRatios(reportId) {
        return this.request(`/ratios/calculate/${reportId}`, {
            method: 'POST'
        });
    }

    // طلبات معايير IFRS
    async getIFRSStandards(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/standards?${queryString}`);
    }

    async getIFRSStandard(standardId) {
        return this.request(`/standards/${standardId}`);
    }

    // توابع التحقق من صحة البيانات
    validatePeriodData(periodData) {
        const requiredFields = ['code', 'name', 'startDate', 'endDate'];
        
        const missingFields = requiredFields.filter(field => !periodData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        if (new Date(periodData.endDate) <= new Date(periodData.startDate)) {
            throw new Error('تاريخ النهاية يجب أن يكون بعد تاريخ البداية');
        }

        return true;
    }

    validateReportData(reportData) {
        const requiredFields = ['periodId', 'templateId', 'reportDate'];
        
        const missingFields = requiredFields.filter(field => !reportData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        return true;
    }

    validateNoteData(noteData) {
        if (!noteData.reportId || !noteData.title || !noteData.content) {
            throw new Error('التقرير والعنوان والمحتوى مطلوبة');
        }

        return true;
    }

    validateAdjustmentData(adjustmentData) {
        const requiredFields = ['reportId', 'accountId', 'amount', 'description'];
        
        const missingFields = requiredFields.filter(field => !adjustmentData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        if (adjustmentData.amount === 0) {
            throw new Error('مبلغ التسوية يجب أن يكون غير صفري');
        }

        return true;
    }

    validateRatioData(ratioData) {
        const requiredFields = ['formula', 'benchmark'];
        
        const missingFields = requiredFields.filter(field => !ratioData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        return true;
    }

    // توابع معالجة الأخطاء
    async handleErrorResponse(response) {
        let error;
        try {
            const errorData = await response.json();
            error = new Error(errorData.message || 'حدث خطأ غير معروف');
            error.code = errorData.code;
            error.details = errorData.details;
        } catch {
            error = new Error(`خطأ في الطلب: ${response.status}`);
        }
        error.status = response.status;
        return error;
    }

    createUserFriendlyError(error) {
        const errorMessages = {
            400: 'البيانات المدخلة غير صحيحة',
            401: 'يرجى تسجيل الدخول مرة أخرى',
            403: 'ليس لديك صلاحية للقيام بهذا الإجراء',
            404: 'لم يتم العثور على البيانات المطلوبة',
            409: 'تعارض في البيانات',
            422: 'البيانات المدخلة غير صالحة',
            500: 'حدث خطأ في النظام'
        };

        return new Error(
            errorMessages[error.status] || 
            error.message || 
            'حدث خطأ غير متوقع'
        );
    }
}