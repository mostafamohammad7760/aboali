/**
 * تحكم نقاط البيع API
 * التاريخ: 2025-05-09 04:26:01
 * المستخدم: mostafamohammad7760
 */

import { Request, Response } from 'express';
import { POSService } from '../../services/POSService';
import { validateRequest } from '../middleware/validation';
import { authorize } from '../middleware/auth';

export class POSController {
  private posService: POSService;

  constructor() {
    this.posService = new POSService();
  }

  /**
   * فتح وردية جديدة
   */
  @authorize(['pos.manage_shifts'])
  public async openShift(req: Request, res: Response): Promise<void> {
    try {
      validateRequest(req.body, {
        branchId: 'required|numeric',
        startBalance: 'required|numeric|min:0',
        notes: 'string'
      });

      const shift = await this.posService.openShift({
        userId: req.user.id,
        branchId: req.body.branchId,
        startBalance: req.body.startBalance,
        notes: req.body.notes
      });

      res.status(201).json({
        success: true,
        data: shift
      });

    } catch (error) {
      res.status(400).json({
        success: false,
        message: error.message
      });
    }
  }

  /**
   * إغلاق الوردية
   */
  @authorize(['pos.manage_shifts'])
  public async closeShift(req: Request, res: Response): Promise<void> {
    try {
      validateRequest(req.body, {
        shiftId: 'required|numeric',
        actualBalance: 'required|numeric|min:0',
        notes: 'string'
      });

      const shift = await this.posService.closeShift({
        shiftId: req.body.shiftId,
        actualBalance: req.body.actualBalance,
        notes: req.body.notes
      });

      res.status(200).json({
        success: true,
        data: shift
      });

    } catch (error) {
      res.status(400).json({
        success: false,
        message: error.message
      });
    }
  }

  /**
   * إنشاء عملية بيع جديدة
   */
  @authorize(['pos.create_sale'])
  public async createSale(req: Request, res: Response): Promise<void> {
    try {
      validateRequest(req.body, {
        shiftId: 'required|numeric',
        customerId: 'numeric',
        items: 'required|array',
        'items.*.productId': 'required|numeric',
        'items.*.quantity': 'required|numeric|min:0.01',
        'items.*.price': 'required|numeric|min:0',
        payments: 'required|array',
        'payments.*.type': 'required|in:cash,card,bank,points',
        'payments.*.amount': 'required|numeric|min:0',
        usePoints: 'boolean',
        notes: 'string'
      });

      const sale = await this.posService.createSale(req.body);

      res.status(201).json({
        success: true,
        data: sale
      });

    } catch (error) {
      res.status(400).json({
        success: false,
        message: error.message
      });
    }
  }
}