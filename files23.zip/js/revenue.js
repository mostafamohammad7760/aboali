import { RevenueAPI } from './api/revenue_api.js';
import { ChartManager } from './chart_manager.js';
import { formatCurrency, formatNumber, formatDate, formatPercentage } from './utils/formatters.js';
import { validateContract, validateObligation, validatePrice } from './utils/validators.js';

class Revenue {
    constructor() {
        this.api = new RevenueAPI();
        this.charts = new ChartManager();
        this.currentUser = 'mostafamohammad7760';
        
        // تهيئة المكونات والبيانات
        this.initializeComponents();
        this.attachEventListeners();
        this.loadDashboardData();
        
        // تحديث الوقت كل ثانية
        this.updateDateTime();
        setInterval(() => this.updateDateTime(), 1000);
    }

    initializeComponents() {
        // عناصر لوحة المعلومات
        this.dashboardElements = {
            // إحصائيات العقود
            activeContracts: document.getElementById('activeContracts'),
            completedContracts: document.getElementById('completedContracts'),
            totalContractValue: document.getElementById('totalContractValue'),
            
            // إحصائيات الإيرادات
            recognizedRevenue: document.getElementById('recognizedRevenue'),
            deferredRevenue: document.getElementById('deferredRevenue'),
            variableRevenue: document.getElementById('variableRevenue'),
            
            // أرصدة العقود
            contractAssets: document.getElementById('contractAssets'),
            contractLiabilities: document.getElementById('contractLiabilities'),
            contractCosts: document.getElementById('contractCosts'),
            
            // التزامات الأداء
            pendingObligations: document.getElementById('pendingObligations'),
            inProgressObligations: document.getElementById('inProgressObligations'),
            completedObligations: document.getElementById('completedObligations'),
            
            // الجداول
            latestContractsTable: document.getElementById('latestContractsTable')
        };

        // عناصر الفلترة
        this.filterElements = {
            revenuePeriod: document.getElementById('revenuePeriod'),
            contractPeriod: document.getElementById('contractPeriod')
        };

        // تهيئة الرسوم البيانية
        this.initializeCharts();
        
        // تهيئة القوالب
        this.contractRowTemplate = document.getElementById('contractRowTemplate');
    }

    async loadDashboardData() {
        try {
            this.showLoading();

            const [
                contractStats,
                revenueStats,
                balanceStats,
                obligationStats,
                revenueData,
                contractData,
                latestContracts
            ] = await Promise.all([
                this.api.getContractStats(),
                this.api.getRevenueStats(),
                this.api.getBalanceStats(),
                this.api.getObligationStats(),
                this.api.getRevenueAnalysis(this.filterElements.revenuePeriod.value),
                this.api.getContractAnalysis(this.filterElements.contractPeriod.value),
                this.api.getLatestContracts()
            ]);

            this.updateContractStats(contractStats);
            this.updateRevenueStats(revenueStats);
            this.updateBalanceStats(balanceStats);
            this.updateObligationStats(obligationStats);
            this.updateCharts(revenueData, contractData);
            this.renderLatestContracts(latestContracts);

            this.hideLoading();
        } catch (error) {
            this.hideLoading();
            this.showError('حدث خطأ أثناء تحميل البيانات');
            console.error('Dashboard loading error:', error);
        }
    }

    initializeCharts() {
        // تهيئة رسم تحليل الإيرادات
        this.charts.initializeLineChart('revenueChart', {
            labels: [],
            datasets: [
                {
                    label: 'الإيرادات المعترف بها',
                    data: [],
                    borderColor: '#27ae60',
                    backgroundColor: 'rgba(39, 174, 96, 0.1)',
                    fill: true
                },
                {
                    label: 'الإيرادات المؤجلة',
                    data: [],
                    borderColor: '#f39c12',
                    backgroundColor: 'rgba(243, 156, 18, 0.1)',
                    fill: true
                },
                {
                    label: 'المقابل المتغير',
                    data: [],
                    borderColor: '#3498db',
                    backgroundColor: 'rgba(52, 152, 219, 0.1)',
                    fill: true
                }
            ],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => formatCurrency(value)
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: context => formatCurrency(context.parsed.y)
                        }
                    }
                }
            }
        });

        // تهيئة رسم تحليل العقود
        this.charts.initializeBarChart('contractChart', {
            labels: [],
            datasets: [{
                data: [],
                backgroundColor: [
                    '#2ecc71',
                    '#3498db',
                    '#f1c40f',
                    '#e67e22',
                    '#e74c3c',
                    '#9b59b6'
                ]
            }],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => formatCurrency(value)
                        }
                    }
                },
                plugins: {
                    legend: {
                        position: 'right'
                    },
                    tooltip: {
                        callbacks: {
                            label: context => 
                                `${context.label}: ${formatCurrency(context.parsed.y)}`
                        }
                    }
                }
            }
        });
    }

    updateContractStats(stats) {
        this.dashboardElements.activeContracts.textContent = stats.active;
        this.dashboardElements.completedContracts.textContent = stats.completed;
        this.dashboardElements.totalContractValue.textContent = 
            formatCurrency(stats.totalValue);
    }

    updateRevenueStats(stats) {
        this.dashboardElements.recognizedRevenue.textContent = 
            formatCurrency(stats.recognized);
        this.dashboardElements.deferredRevenue.textContent = 
            formatCurrency(stats.deferred);
        this.dashboardElements.variableRevenue.textContent = 
            formatCurrency(stats.variable);
    }

    updateBalanceStats(stats) {
        this.dashboardElements.contractAssets.textContent = 
            formatCurrency(stats.assets);
        this.dashboardElements.contractLiabilities.textContent = 
            formatCurrency(stats.liabilities);
        this.dashboardElements.contractCosts.textContent = 
            formatCurrency(stats.costs);
    }

    updateObligationStats(stats) {
        this.dashboardElements.pendingObligations.textContent = stats.pending;
        this.dashboardElements.inProgressObligations.textContent = stats.inProgress;
        this.dashboardElements.completedObligations.textContent = stats.completed;
    }

    updateCharts(revenueData, contractData) {
        // تحديث رسم تحليل الإيرادات
        this.charts.updateLineChart('revenueChart', {
            labels: revenueData.labels,
            datasets: [
                {
                    data: revenueData.recognized,
                    label: 'الإيرادات المعترف بها'
                },
                {
                    data: revenueData.deferred,
                    label: 'الإيرادات المؤجلة'
                },
                {
                    data: revenueData.variable,
                    label: 'المقابل المتغير'
                }
            ]
        });

        // تحديث رسم تحليل العقود
        this.charts.updateBarChart('contractChart', {
            labels: contractData.labels,
            data: contractData.values
        });
    }

    renderLatestContracts(contracts) {
        const tbody = this.dashboardElements.latestContractsTable;
        tbody.innerHTML = '';

        contracts.forEach(contract => {
            const tr = this.createContractRow(contract);
            tbody.appendChild(tr);
        });
    }

    createContractRow(contract) {
        const template = this.contractRowTemplate.content.cloneNode(true);
        const tr = template.querySelector('tr');
        
        tr.querySelector('.contract-code').textContent = contract.code;
        tr.querySelector('.customer-name').textContent = contract.customerName;
        tr.querySelector('.contract-type').textContent = 
            this.translateContractType(contract.type);
        tr.querySelector('.start-date').textContent = 
            formatDate(contract.startDate);
        tr.querySelector('.contract-value').textContent = 
            formatCurrency(contract.value);
        
        const completionCell = tr.querySelector('.completion-percentage');
        completionCell.style.setProperty(
            '--completion', 
            `${contract.completionPercentage}%`
        );
        completionCell.textContent = 
            formatPercentage(contract.completionPercentage);
        
        const statusCell = tr.querySelector('.contract-status');
        statusCell.textContent = this.translateContractStatus(contract.status);
        statusCell.classList.add(contract.status.toLowerCase());

        // إضافة مستمعات الأحداث للأزرار
        tr.querySelector('.view-contract').addEventListener('click', 
            () => this.viewContract(contract.id));
        
        const editButton = tr.querySelector('.edit-contract');
        const completeButton = tr.querySelector('.complete-contract');
        
        if (contract.status === 'active') {
            editButton.addEventListener('click', 
                () => this.editContract(contract.id));
            completeButton.addEventListener('click', 
                () => this.completeContract(contract.id));
        } else {
            editButton.style.display = 'none';
            completeButton.style.display = 'none';
        }

        return tr;
    }

    attachEventListeners() {
        // مستمعات أحداث الإجراءات السريعة
        document.getElementById('createContract')?.addEventListener('click', 
            () => this.showContractModal());
        document.getElementById('createObligation')?.addEventListener('click', 
            () => this.showObligationModal());
        document.getElementById('recognizeRevenue')?.addEventListener('click', 
            () => this.showRevenueRecognitionModal());
        document.getElementById('adjustPrice')?.addEventListener('click', 
            () => this.showPriceAdjustmentModal());

        // مستمعات أحداث الفلترة
        this.filterElements.revenuePeriod.addEventListener('change', 
            () => this.loadRevenueAnalysis());
        this.filterElements.contractPeriod.addEventListener('change', 
            () => this.loadContractAnalysis());

        // مستمعات أحداث التصدير
        document.getElementById('exportRevenueChart')?.addEventListener('click', 
            () => this.exportChart('revenueChart'));
        document.getElementById('exportContractChart')?.addEventListener('click', 
            () => this.exportChart('contractChart'));

        // مستمعات أحداث عرض الكل
        document.getElementById('viewAllContracts')?.addEventListener('click', 
            () => this.navigateToContracts());
    }

    // توابع مساعدة
    translateContractType(type) {
        const typeMap = {
            goods: 'بضائع',
            services: 'خدمات',
            mixed: 'مختلط'
        };
        return typeMap[type] || type;
    }

    translateContractStatus(status) {
        const statusMap = {
            draft: 'مسودة',
            active: 'نشط',
            completed: 'مكتمل',
            terminated: 'منتهي'
        };
        return statusMap[status] || status;
    }

    updateDateTime() {
        document.getElementById('currentDateTime').textContent = 
            new Date().toISOString().slice(0, 19).replace('T', ' ');
    }

    showLoading() {
        const loader = document.createElement('div');
        loader.className = 'loading-overlay';
        loader.innerHTML = '<div class="loading-spinner"></div>';
        document.body.appendChild(loader);
    }

    hideLoading() {
        document.querySelector('.loading-overlay')?.remove();
    }

    showError(message) {
        console.error(message);
        // يمكن تحسين هذه الدالة لعرض رسائل خطأ أكثر جاذبية
        alert(message);
    }

    showSuccess(message) {
        // يمكن تحسين هذه الدالة لعرض رسائل نجاح أكثر جاذبية
        alert(message);
    }
}

// تهيئة التطبيق عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    new Revenue();
});