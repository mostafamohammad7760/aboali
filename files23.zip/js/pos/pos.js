/**
 * نظام نقاط البيع - المنطق الرئيسي
 * @module POS
 * التاريخ: 2025-05-09 02:51:57
 * المستخدم: mostafamohammad7760
 */

import { POSDatabase } from './POSDatabase.js';
import { POSPrinter } from './POSPrinter.js';
import { CartManager } from './CartManager.js';
import { PaymentManager } from './PaymentManager.js';

class POSSystem {
    constructor() {
        // تهيئة المكونات الأساسية
        this.db = new POSDatabase();
        this.printer = new POSPrinter();
        this.cart = new CartManager();
        this.payment = new PaymentManager();

        // حالة النظام
        this.currentUser = 'mostafamohammad7760';
        this.currentCustomer = null;
        this.isRegisterOpen = false;
        this.selectedCategory = null;
        
        // العناصر في DOM
        this.elements = {
            productSearch: document.getElementById('productSearch'),
            productsGrid: document.getElementById('productsGrid'),
            cartItems: document.getElementById('cartItems'),
            subtotal: document.getElementById('subtotal'),
            tax: document.getElementById('tax'),
            total: document.getElementById('total'),
            discountAmount: document.getElementById('discountAmount'),
            discountType: document.getElementById('discountType'),
            customerModal: document.getElementById('customerModal'),
            paymentModal: document.getElementById('paymentModal'),
            registerStatus: document.getElementById('registerStatus')
        };

        this.init();
    }

    /**
     * تهيئة النظام
     */
    async init() {
        try {
            // التحقق من حالة الخزينة
            await this.checkRegisterStatus();
            
            // تحميل البيانات الأولية
            await this.loadInitialData();
            
            // إضافة مستمعات الأحداث
            this.attachEventListeners();
            
            // تحديث معلومات المستخدم والوقت
            this.updateDateTime();
            setInterval(() => this.updateDateTime(), 1000);
            
        } catch (error) {
            console.error('Error initializing POS system:', error);
            this.showError('حدث خطأ أثناء تهيئة النظام');
        }
    }

    /**
     * التحقق من حالة الخزينة
     */
    async checkRegisterStatus() {
        try {
            const status = await this.db.getRegisterStatus();
            this.isRegisterOpen = status.isOpen;
            this.updateRegisterStatus();

            if (!this.isRegisterOpen) {
                this.showOpenRegisterDialog();
            }
        } catch (error) {
            console.error('Error checking register status:', error);
            this.showError('تعذر التحقق من حالة الخزينة');
        }
    }

    /**
     * تحميل البيانات الأولية
     */
    async loadInitialData() {
        try {
            // تحميل الفئات
            const categories = await this.db.getCategories();
            this.renderCategories(categories);

            // تحميل المنتجات
            const products = await this.db.getProducts();
            this.renderProducts(products);

        } catch (error) {
            console.error('Error loading initial data:', error);
            this.showError('تعذر تحميل البيانات');
        }
    }

    /**
     * إضافة مستمعات الأحداث
     */
    attachEventListeners() {
        // البحث عن المنتجات
        this.elements.productSearch.addEventListener('input', 
            debounce((e) => this.handleProductSearch(e.target.value), 300)
        );

        // أحداث السلة
        this.elements.discountAmount.addEventListener('change', 
            () => this.updateCartTotals()
        );
        this.elements.discountType.addEventListener('change', 
            () => this.updateCartTotals()
        );

        // أزرار العمليات
        document.getElementById('newSaleBtn').addEventListener('click', 
            () => this.startNewSale()
        );
        document.getElementById('holdSalesBtn').addEventListener('click', 
            () => this.showHeldSales()
        );
        document.getElementById('cancelSale').addEventListener('click', 
            () => this.cancelCurrentSale()
        );
        document.getElementById('holdSale').addEventListener('click', 
            () => this.holdCurrentSale()
        );
        document.getElementById('completeSale').addEventListener('click', 
            () => this.showPaymentModal()
        );

        // أحداث نافذة الدفع
        document.getElementById('confirmPayment').addEventListener('click', 
            () => this.processPayment()
        );

        // مستمع لمسح الباركود
        document.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && document.activeElement === this.elements.productSearch) {
                this.handleBarcodeScanned(this.elements.productSearch.value);
            }
        });
    }

    /**
     * معالجة البحث عن المنتجات
     */
    async handleProductSearch(query) {
        if (!query) {
            const products = await this.db.getProducts(this.selectedCategory);
            this.renderProducts(products);
            return;
        }

        try {
            const results = await this.db.searchProducts(query);
            this.renderProducts(results);
        } catch (error) {
            console.error('Error searching products:', error);
            this.showError('حدث خطأ أثناء البحث');
        }
    }

    /**
     * معالجة مسح الباركود
     */
    async handleBarcodeScanned(barcode) {
        try {
            const product = await this.db.getProductByBarcode(barcode);
            if (product) {
                this.addToCart(product);
                this.elements.productSearch.value = '';
            } else {
                this.showError('المنتج غير موجود');
            }
        } catch (error) {
            console.error('Error processing barcode:', error);
            this.showError('حدث خطأ أثناء معالجة الباركود');
        }
    }

    /**
     * إضافة منتج للسلة
     */
    addToCart(product) {
        this.cart.addItem({
            id: product.id,
            name: product.name_ar,
            price: product.selling_price,
            quantity: 1,
            vat_rate: product.vat_rate
        });

        this.renderCart();
        this.updateCartTotals();
    }

    /**
     * تحديث إجماليات السلة
     */
    updateCartTotals() {
        const totals = this.cart.calculateTotals({
            discountAmount: parseFloat(this.elements.discountAmount.value) || 0,
            discountType: this.elements.discountType.value
        });

        this.elements.subtotal.textContent = this.formatCurrency(totals.subtotal);
        this.elements.tax.textContent = this.formatCurrency(totals.tax);
        this.elements.total.textContent = this.formatCurrency(totals.total);
    }

    /**
     * معالجة عملية الدفع
     */
    async processPayment() {
        try {
            const paymentDetails = this.payment.getPaymentDetails();
            const saleData = {
                items: this.cart.getItems(),
                totals: this.cart.calculateTotals(),
                payment: paymentDetails,
                customer: this.currentCustomer
            };

            // حفظ عملية البيع
            const sale = await this.db.saveSale(saleData);
            
            // طباعة الفاتورة
            await this.printer.printReceipt(sale);
            
            // تحديث المخزون
            await this.db.updateInventory(sale.items);
            
            // إنهاء عملية البيع
            this.completeSale();
            
            this.showSuccess('تم إتمام عملية البيع بنجاح');
        } catch (error) {
            console.error('Error processing payment:', error);
            this.showError('حدث خطأ أثناء معالجة الدفع');
        }
    }

    /**
     * توابع مساعدة
     */
    formatCurrency(amount) {
        return `${amount.toFixed(2)} ريال`;
    }

    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    showError(message) {
        // يمكن استخدام مكتبة للإشعارات
        alert(message);
    }

    showSuccess(message) {
        // يمكن استخدام مكتبة للإشعارات
        alert(message);
    }

    updateDateTime() {
        const now = new Date();
        document.getElementById('currentDateTime').textContent = 
            now.toISOString().slice(0, 19).replace('T', ' ');
    }
}

// تهيئة النظام عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    window.pos = new POSSystem();
});