-- إنشاء جداول الحسابات المالية

-- جدول دليل الحسابات
CREATE TABLE chart_of_accounts (
    account_id VARCHAR(20) PRIMARY KEY,
    parent_id VARCHAR(20),
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    type ENUM('asset', 'liability', 'equity', 'revenue', 'expense') NOT NULL,
    level INT NOT NULL,
    is_parent BOOLEAN DEFAULT FALSE,
    is_posting BOOLEAN DEFAULT TRUE,
    description TEXT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (parent_id) REFERENCES chart_of_accounts(account_id)
);

-- جدول السنوات المالية
CREATE TABLE fiscal_years (
    year_id VARCHAR(20) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    status ENUM('pending', 'active', 'closed') DEFAULT 'pending',
    is_adjustment_allowed BOOLEAN DEFAULT TRUE,
    closing_date DATE,
    closing_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    UNIQUE KEY unique_year_dates (start_date, end_date)
);

-- جدول الفترات المحاسبية
CREATE TABLE accounting_periods (
    period_id VARCHAR(20) PRIMARY KEY,
    year_id VARCHAR(20) NOT NULL,
    name VARCHAR(100) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    status ENUM('pending', 'active', 'closed') DEFAULT 'pending',
    is_adjustment_allowed BOOLEAN DEFAULT TRUE,
    closing_date DATE,
    closing_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (year_id) REFERENCES fiscal_years(year_id),
    UNIQUE KEY unique_period_dates (year_id, start_date, end_date)
);

-- جدول القيود اليومية
CREATE TABLE journal_entries (
    entry_id VARCHAR(20) PRIMARY KEY,
    entry_number VARCHAR(20) UNIQUE NOT NULL,
    entry_date DATE NOT NULL,
    period_id VARCHAR(20) NOT NULL,
    type ENUM('manual', 'automatic', 'adjustment') NOT NULL,
    reference_type VARCHAR(50),
    reference_id VARCHAR(20),
    description TEXT,
    total_debit DECIMAL(18,2) NOT NULL DEFAULT 0,
    total_credit DECIMAL(18,2) NOT NULL DEFAULT 0,
    status ENUM('draft', 'posted', 'cancelled') DEFAULT 'draft',
    posting_date DATETIME,
    cancellation_date DATETIME,
    cancellation_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (period_id) REFERENCES accounting_periods(period_id)
);

-- جدول تفاصيل القيود اليومية
CREATE TABLE journal_entry_details (
    detail_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    entry_id VARCHAR(20) NOT NULL,
    account_id VARCHAR(20) NOT NULL,
    description TEXT,
    debit DECIMAL(18,2) NOT NULL DEFAULT 0,
    credit DECIMAL(18,2) NOT NULL DEFAULT 0,
    reference_type VARCHAR(50),
    reference_id VARCHAR(20),
    cost_center_id VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (entry_id) REFERENCES journal_entries(entry_id),
    FOREIGN KEY (account_id) REFERENCES chart_of_accounts(account_id)
);

-- جدول مراكز التكلفة
CREATE TABLE cost_centers (
    center_id VARCHAR(20) PRIMARY KEY,
    parent_id VARCHAR(20),
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (parent_id) REFERENCES cost_centers(center_id)
);

-- جدول الأرصدة الافتتاحية
CREATE TABLE opening_balances (
    balance_id VARCHAR(20) PRIMARY KEY,
    year_id VARCHAR(20) NOT NULL,
    account_id VARCHAR(20) NOT NULL,
    debit DECIMAL(18,2) NOT NULL DEFAULT 0,
    credit DECIMAL(18,2) NOT NULL DEFAULT 0,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (year_id) REFERENCES fiscal_years(year_id),
    FOREIGN KEY (account_id) REFERENCES chart_of_accounts(account_id),
    UNIQUE KEY unique_account_year (year_id, account_id)
);

-- جدول القوالب المحاسبية
CREATE TABLE accounting_templates (
    template_id VARCHAR(20) PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    transaction_type VARCHAR(50) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50)
);

-- جدول تفاصيل القوالب المحاسبية
CREATE TABLE accounting_template_details (
    detail_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    template_id VARCHAR(20) NOT NULL,
    account_id VARCHAR(20) NOT NULL,
    description TEXT,
    is_debit BOOLEAN NOT NULL,
    amount_type ENUM('fixed', 'percentage', 'calculated') NOT NULL,
    amount_value DECIMAL(18,2),
    calculation_formula TEXT,
    sequence INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (template_id) REFERENCES accounting_templates(template_id),
    FOREIGN KEY (account_id) REFERENCES chart_of_accounts(account_id)
);

-- إجراءات مخزنة

DELIMITER //

-- إجراء إنشاء قيد يومية
CREATE PROCEDURE create_journal_entry(
    IN p_entry_date DATE,
    IN p_period_id VARCHAR(20),
    IN p_type VARCHAR(20),
    IN p_description TEXT,
    IN p_reference_type VARCHAR(50),
    IN p_reference_id VARCHAR(20),
    IN p_created_by VARCHAR(50),
    OUT p_entry_id VARCHAR(20)
)
BEGIN
    DECLARE v_entry_number VARCHAR(20);
    DECLARE v_year INT;
    
    -- الحصول على السنة من تاريخ القيد
    SET v_year = YEAR(p_entry_date);
    
    -- إنشاء رقم القيد
    SET v_entry_number = CONCAT(
        'JE', 
        v_year,
        LPAD((
            SELECT COUNT(*) + 1 
            FROM journal_entries 
            WHERE YEAR(entry_date) = v_year
        ), 6, '0')
    );
    
    -- إنشاء معرف القيد
    SET p_entry_id = UUID();
    
    -- إدخال القيد
    INSERT INTO journal_entries (
        entry_id,
        entry_number,
        entry_date,
        period_id,
        type,
        description,
        reference_type,
        reference_id,
        created_by
    ) VALUES (
        p_entry_id,
        v_entry_number,
        p_entry_date,
        p_period_id,
        p_type,
        p_description,
        p_reference_type,
        p_reference_id,
        p_created_by
    );
END //

-- إجراء ترحيل قيد يومية
CREATE PROCEDURE post_journal_entry(
    IN p_entry_id VARCHAR(20),
    IN p_posted_by VARCHAR(50)
)
BEGIN
    DECLARE v_total_debit DECIMAL(18,2);
    DECLARE v_total_credit DECIMAL(18,2);
    
    -- حساب إجماليات القيد
    SELECT 
        COALESCE(SUM(debit), 0),
        COALESCE(SUM(credit), 0)
    INTO 
        v_total_debit,
        v_total_credit
    FROM journal_entry_details
    WHERE entry_id = p_entry_id;
    
    -- التحقق من توازن القيد
    IF v_total_debit != v_total_credit THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'القيد غير متوازن';
    END IF;
    
    -- ترحيل القيد
    UPDATE journal_entries
    SET 
        status = 'posted',
        posting_date = NOW(),
        total_debit = v_total_debit,
        total_credit = v_total_credit,
        updated_by = p_posted_by,
        updated_at = NOW()
    WHERE 
        entry_id = p_entry_id
        AND status = 'draft';
        
    IF ROW_COUNT() = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'لا يمكن ترحيل القيد';
    END IF;
END //

-- إجراء إقفال فترة محاسبية
CREATE PROCEDURE close_accounting_period(
    IN p_period_id VARCHAR(20),
    IN p_closing_notes TEXT,
    IN p_closed_by VARCHAR(50)
)
BEGIN
    DECLARE v_unposted_entries INT;
    
    -- التحقق من وجود قيود غير مرحلة
    SELECT COUNT(*)
    INTO v_unposted_entries
    FROM journal_entries
    WHERE 
        period_id = p_period_id
        AND status = 'draft';
        
    IF v_unposted_entries > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'توجد قيود غير مرحلة في هذه الفترة';
    END IF;
    
    -- إقفال الفترة
    UPDATE accounting_periods
    SET 
        status = 'closed',
        closing_date = NOW(),
        closing_notes = p_closing_notes,
        is_adjustment_allowed = FALSE,
        updated_by = p_closed_by,
        updated_at = NOW()
    WHERE 
        period_id = p_period_id
        AND status = 'active';
        
    IF ROW_COUNT() = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'لا يمكن إقفال الفترة';
    END IF;
END //

DELIMITER ;

-- المؤشرات
CREATE INDEX idx_journal_entries_date ON journal_entries(entry_date);
CREATE INDEX idx_journal_entries_period ON journal_entries(period_id);
CREATE INDEX idx_journal_entries_status ON journal_entries(status);
CREATE INDEX idx_journal_details_account ON journal_entry_details(account_id);
CREATE INDEX idx_accounting_periods_dates ON accounting_periods(start_date, end_date);
CREATE INDEX idx_fiscal_years_dates ON fiscal_years(start_date, end_date);
CREATE INDEX idx_chart_accounts_parent ON chart_of_accounts(parent_id);
CREATE INDEX idx_chart_accounts_type ON chart_of_accounts(type);
CREATE INDEX idx_cost_centers_parent ON cost_centers(parent_id);