/**
 * إعدادات الأمان للنظام
 * @module SecurityConfig
 * التاريخ: 2025-05-09 02:45:59
 * المستخدم: mostafamohammad7760
 */

export class SecurityConfig {
    constructor() {
        // القيم الافتراضية للإعدادات
        this.defaultConfig = {
            // إعدادات كلمة المرور
            password: {
                minLength: 8,
                maxLength: 128,
                requireUppercase: true,
                requireLowercase: true,
                requireNumbers: true,
                requireSpecial: true,
                expiryDays: 90,
                preventReuse: 5, // عدد كلمات المرور السابقة التي لا يمكن إعادة استخدامها
                maxAttempts: 5, // عدد محاولات تسجيل الدخول قبل قفل الحساب
                lockoutDuration: 30 // مدة القفل بالدقائق
            },

            // إعدادات الجلسة
            session: {
                timeout: 30, // مدة الجلسة بالدقائق
                extendOnActivity: true,
                maxConcurrentSessions: 3,
                rememberMeDuration: 30 // مدة "تذكرني" بالأيام
            },

            // إعدادات التحقق الثنائي
            twoFactor: {
                enabled: true,
                methods: ['sms', 'email', 'authenticator'],
                defaultMethod: 'authenticator',
                codeLength: 6,
                codeExpiry: 5, // مدة صلاحية الرمز بالدقائق
                backupCodesCount: 10
            },

            // إعدادات التوكن
            token: {
                accessTokenExpiry: '1h',
                refreshTokenExpiry: '7d',
                algorithm: 'HS256',
                issuer: 'accounting-system'
            },

            // إعدادات النسخ الاحتياطي
            backup: {
                automaticBackup: true,
                frequency: 'daily', // daily, weekly, monthly
                retentionPeriod: 30, // عدد الأيام للاحتفاظ بالنسخ
                encryptBackups: true,
                compressionEnabled: true
            },

            // إعدادات السجلات
            logging: {
                enabled: true,
                level: 'info', // debug, info, warning, error, critical
                retentionPeriod: 90, // فترة الاحتفاظ بالسجلات بالأيام
                sensitiveFields: ['password', 'token', 'ssn', 'creditCard']
            },

            // إعدادات الحماية
            protection: {
                rateLimiting: {
                    enabled: true,
                    maxRequests: 100,
                    windowMs: 900000 // 15 دقيقة
                },
                cors: {
                    enabled: true,
                    allowedOrigins: ['https://domain.com'],
                    allowedMethods: ['GET', 'POST', 'PUT', 'DELETE'],
                    allowedHeaders: ['Content-Type', 'Authorization']
                },
                csrf: {
                    enabled: true,
                    tokenExpiry: '1h'
                }
            }
        };

        // تحميل الإعدادات المخصصة
        this.loadCustomConfig();
    }

    /**
     * تحميل الإعدادات المخصصة من التخزين
     */
    loadCustomConfig() {
        try {
            const savedConfig = localStorage.getItem('security_config');
            if (savedConfig) {
                this.config = this.mergeConfigs(
                    this.defaultConfig,
                    JSON.parse(savedConfig)
                );
            } else {
                this.config = { ...this.defaultConfig };
            }
        } catch (error) {
            console.error('Error loading security config:', error);
            this.config = { ...this.defaultConfig };
        }
    }

    /**
     * دمج الإعدادات الافتراضية مع المخصصة
     */
    mergeConfigs(defaultConfig, customConfig) {
        const merged = { ...defaultConfig };
        for (const [key, value] of Object.entries(customConfig)) {
            if (value && typeof value === 'object') {
                merged[key] = this.mergeConfigs(defaultConfig[key], value);
            } else {
                merged[key] = value;
            }
        }
        return merged;
    }

    /**
     * حفظ الإعدادات المخصصة
     */
    async saveConfig(newConfig) {
        try {
            // التحقق من صحة الإعدادات الجديدة
            this.validateConfig(newConfig);

            // دمج الإعدادات الجديدة مع الحالية
            this.config = this.mergeConfigs(this.config, newConfig);

            // حفظ الإعدادات
            localStorage.setItem('security_config', JSON.stringify(this.config));

            // تسجيل التغيير
            await this.logConfigChange(newConfig);

            return true;
        } catch (error) {
            console.error('Error saving security config:', error);
            throw error;
        }
    }

    /**
     * التحقق من صحة الإعدادات
     */
    validateConfig(config) {
        // التحقق من قيم كلمة المرور
        if (config.password) {
            if (config.password.minLength < 8) {
                throw new Error('الحد الأدنى لطول كلمة المرور يجب أن يكون 8 أحرف');
            }
            if (config.password.maxLength > 128) {
                throw new Error('الحد الأقصى لطول كلمة المرور لا يجب أن يتجاوز 128 حرف');
            }
        }

        // التحقق من إعدادات الجلسة
        if (config.session) {
            if (config.session.timeout < 5) {
                throw new Error('مهلة الجلسة يجب أن تكون 5 دقائق على الأقل');
            }
        }

        // التحقق من إعدادات التحقق الثنائي
        if (config.twoFactor) {
            if (config.twoFactor.codeLength < 6) {
                throw new Error('طول رمز التحقق يجب أن يكون 6 أرقام على الأقل');
            }
        }
    }

    /**
     * تسجيل تغييرات الإعدادات
     */
    async logConfigChange(changes) {
        const logEntry = {
            timestamp: new Date().toISOString(),
            user: 'mostafamohammad7760',
            changes: changes,
            type: 'security_config_change'
        };

        try {
            await fetch('/api/v1/security/logs', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(logEntry)
            });
        } catch (error) {
            console.error('Error logging config change:', error);
        }
    }

    /**
     * الحصول على إعداد محدد
     */
    get(path) {
        return path.split('.').reduce((obj, key) => obj?.[key], this.config);
    }

    /**
     * تعيين إعداد محدد
     */
    async set(path, value) {
        const keys = path.split('.');
        const lastKey = keys.pop();
        const target = keys.reduce((obj, key) => obj[key] = obj[key] || {}, this.config);
        target[lastKey] = value;
        await this.saveConfig(this.config);
    }

    /**
     * إعادة تعيين الإعدادات إلى القيم الافتراضية
     */
    async resetToDefault() {
        this.config = { ...this.defaultConfig };
        await this.saveConfig(this.config);
    }
}

// تصدير نسخة واحدة من الإعدادات
export const securityConfig = new SecurityConfig();