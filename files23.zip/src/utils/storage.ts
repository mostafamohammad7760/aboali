/**
 * وظائف التعامل مع التخزين المحلي
 * التاريخ: 2025-05-09 03:48:20
 * المستخدم: mostafamohammad7760
 */

// أنواع وسائط التخزين
type StorageType = 'localStorage' | 'sessionStorage';

// خيارات التخزين
interface StorageOptions {
  storage?: StorageType;
  expires?: number; // بالثواني
  encrypt?: boolean;
  prefix?: string;
}

// واجهة البيانات المخزنة
interface StoredData<T> {
  value: T;
  timestamp: number;
  expires?: number;
}

// مفتاح التشفير - يجب تغييره في الإنتاج
const ENCRYPTION_KEY = process.env.VUE_APP_STORAGE_ENCRYPTION_KEY || 'your-secure-key';

class StorageService {
  private defaultOptions: StorageOptions = {
    storage: 'localStorage',
    encrypt: false,
    prefix: 'pos_'
  };

  // الحصول على وسيط التخزين
  private getStorage(type: StorageType): Storage {
    return type === 'localStorage' ? localStorage : sessionStorage;
  }

  // تشفير البيانات
  private encrypt(data: string): string {
    if (typeof window === 'undefined') return data;

    try {
      const textEncoder = new TextEncoder();
      const encodedData = textEncoder.encode(data);
      // في الإنتاج، استخدم خوارزمية تشفير أقوى
      return btoa(String.fromCharCode.apply(null, Array.from(encodedData)));
    } catch (error) {
      console.error('خطأ في تشفير البيانات:', error);
      return data;
    }
  }

  // فك تشفير البيانات
  private decrypt(data: string): string {
    if (typeof window === 'undefined') return data;

    try {
      const decodedData = atob(data);
      const textDecoder = new TextDecoder();
      return textDecoder.decode(Uint8Array.from(decodedData.split('').map(c => c.charCodeAt(0))));
    } catch (error) {
      console.error('خطأ في فك تشفير البيانات:', error);
      return data;
    }
  }

  // تخزين البيانات
  public set<T>(
    key: string,
    value: T,
    options: StorageOptions = {}
  ): void {
    const opts = { ...this.defaultOptions, ...options };
    const storage = this.getStorage(opts.storage!);
    const prefixedKey = opts.prefix + key;

    const data: StoredData<T> = {
      value,
      timestamp: Date.now(),
      expires: opts.expires ? Date.now() + (opts.expires * 1000) : undefined
    };

    let serializedData = JSON.stringify(data);

    if (opts.encrypt) {
      serializedData = this.encrypt(serializedData);
    }

    try {
      storage.setItem(prefixedKey, serializedData);
    } catch (error) {
      if (error.name === 'QuotaExceededError') {
        // إذا كانت الذاكرة ممتلئة، نحاول تنظيف البيانات القديمة
        this.cleanup(opts.storage!);
        try {
          storage.setItem(prefixedKey, serializedData);
        } catch (e) {
          console.error('فشل تخزين البيانات حتى بعد التنظيف:', e);
        }
      } else {
        console.error('خطأ في تخزين البيانات:', error);
      }
    }
  }

  // استرجاع البيانات
  public get<T>(
    key: string,
    options: StorageOptions = {}
  ): T | null {
    const opts = { ...this.defaultOptions, ...options };
    const storage = this.getStorage(opts.storage!);
    const prefixedKey = opts.prefix + key;

    const serializedData = storage.getItem(prefixedKey);
    if (!serializedData) return null;

    try {
      let dataString = serializedData;
      if (opts.encrypt) {
        dataString = this.decrypt(dataString);
      }

      const data: StoredData<T> = JSON.parse(dataString);

      // التحقق من انتهاء الصلاحية
      if (data.expires && Date.now() > data.expires) {
        this.remove(key, opts);
        return null;
      }

      return data.value;
    } catch (error) {
      console.error('خطأ في استرجاع البيانات:', error);
      return null;
    }
  }

  // حذف البيانات
  public remove(
    key: string,
    options: StorageOptions = {}
  ): void {
    const opts = { ...this.defaultOptions, ...options };
    const storage = this.getStorage(opts.storage!);
    const prefixedKey = opts.prefix + key;

    try {
      storage.removeItem(prefixedKey);
    } catch (error) {
      console.error('خطأ في حذف البيانات:', error);
    }
  }

  // مسح كل البيانات
  public clear(
    options: StorageOptions = {}
  ): void {
    const opts = { ...this.defaultOptions, ...options };
    const storage = this.getStorage(opts.storage!);

    try {
      if (opts.prefix) {
        // حذف فقط البيانات التي تبدأ بالبادئة المحددة
        const keys = Object.keys(storage);
        keys.forEach(key => {
          if (key.startsWith(opts.prefix!)) {
            storage.removeItem(key);
          }
        });
      } else {
        // حذف كل البيانات
        storage.clear();
      }
    } catch (error) {
      console.error('خطأ في مسح البيانات:', error);
    }
  }

  // تنظيف البيانات منتهية الصلاحية
  public cleanup(storageType: StorageType = 'localStorage'): void {
    const storage = this.getStorage(storageType);
    const keys = Object.keys(storage);

    keys.forEach(key => {
      try {
        const serializedData = storage.getItem(key);
        if (!serializedData) return;

        const data: StoredData<any> = JSON.parse(serializedData);

        if (data.expires && Date.now() > data.expires) {
          storage.removeItem(key);
        }
      } catch (error) {
        // تجاهل الأخطاء للعناصر التي لا تتبع التنسيق المتوقع
      }
    });
  }

  // الحصول على حجم البيانات المخزنة
  public getSize(
    options: StorageOptions = {}
  ): number {
    const opts = { ...this.defaultOptions, ...options };
    const storage = this.getStorage(opts.storage!);
    let totalSize = 0;

    try {
      Object.keys(storage).forEach(key => {
        if (!opts.prefix || key.startsWith(opts.prefix)) {
          totalSize += (key.length + (storage.getItem(key)?.length || 0)) * 2; // بالبايت
        }
      });
    } catch (error) {
      console.error('خطأ في حساب حجم البيانات:', error);
    }

    return totalSize;
  }

  // التحقق من دعم التخزين
  public isSupported(type: StorageType = 'localStorage'): boolean {
    try {
      const storage = this.getStorage(type);
      const testKey = '__storage_test__';
      storage.setItem(testKey, testKey);
      storage.removeItem(testKey);
      return true;
    } catch (error) {
      return false;
    }
  }
}

// تصدير نسخة واحدة من الخدمة
export const storage = new StorageService();