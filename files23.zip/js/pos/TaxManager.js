/**
 * مدير الضرائب - إدارة الضرائب والقيمة المضافة في نظام نقاط البيع
 * @module TaxManager
 * التاريخ: 2025-05-09 03:08:56
 * المستخدم: mostafamohammad7760
 */

export class TaxManager {
    constructor(database) {
        this.db = database;
        
        // معدل الضريبة الافتراضي (15%)
        this.defaultVatRate = 15;
        
        // أنواع الضرائب
        this.taxTypes = {
            VAT: 'vat',           // ضريبة القيمة المضافة
            ZERO_RATED: 'zero',    // معفى من الضريبة
            EXEMPT: 'exempt'       // خاضع لضريبة صفرية
        };
    }

    /**
     * حساب الضريبة للسلة
     * @param {Array} cartItems - عناصر السلة
     * @param {Object} customer - بيانات العميل
     */
    async calculateTax(cartItems, customer = null) {
        try {
            let totalBeforeTax = 0;
            let totalTax = 0;
            let totalExempt = 0;
            let totalZeroRated = 0;
            const taxDetails = [];

            for (const item of cartItems) {
                const itemTax = await this.calculateItemTax(item);
                taxDetails.push(itemTax);

                switch (itemTax.taxType) {
                    case this.taxTypes.VAT:
                        totalBeforeTax += itemTax.amountBeforeTax;
                        totalTax += itemTax.taxAmount;
                        break;
                    case this.taxTypes.ZERO_RATED:
                        totalZeroRated += itemTax.amountBeforeTax;
                        break;
                    case this.taxTypes.EXEMPT:
                        totalExempt += itemTax.amountBeforeTax;
                        break;
                }
            }

            return {
                totalBeforeTax,
                totalTax,
                totalExempt,
                totalZeroRated,
                totalWithTax: totalBeforeTax + totalTax + totalExempt + totalZeroRated,
                taxDetails,
                vatRate: this.defaultVatRate,
                customer: customer ? {
                    taxNumber: customer.tax_number,
                    isRegistered: this.isCustomerVatRegistered(customer)
                } : null
            };
        } catch (error) {
            console.error('Error calculating tax:', error);
            throw new Error('فشل حساب الضريبة');
        }
    }

    /**
     * حساب ضريبة منتج واحد
     * @param {Object} item - المنتج
     */
    async calculateItemTax(item) {
        const product = await this.getProductTaxInfo(item.product_id);
        const quantity = item.quantity || 1;
        const price = item.price;
        const discount = item.discount || 0;

        const amountBeforeDiscount = price * quantity;
        const amountAfterDiscount = amountBeforeDiscount - discount;

        let taxAmount = 0;
        let taxableAmount = 0;
        let effectiveRate = 0;

        switch (product.tax_type) {
            case this.taxTypes.VAT:
                taxableAmount = amountAfterDiscount;
                effectiveRate = this.defaultVatRate;
                taxAmount = this.calculateVatAmount(taxableAmount, effectiveRate);
                break;

            case this.taxTypes.ZERO_RATED:
                taxableAmount = amountAfterDiscount;
                effectiveRate = 0;
                break;

            case this.taxTypes.EXEMPT:
                taxableAmount = 0;
                effectiveRate = 0;
                break;
        }

        return {
            product_id: item.product_id,
            name: item.name,
            quantity,
            price,
            discount,
            amountBeforeTax: taxableAmount,
            taxType: product.tax_type,
            taxRate: effectiveRate,
            taxAmount,
            totalAmount: taxableAmount + taxAmount
        };
    }

    /**
     * حساب مبلغ ضريبة القيمة المضافة
     * @param {number} amount - المبلغ قبل الضريبة
     * @param {number} rate - نسبة الضريبة
     */
    calculateVatAmount(amount, rate) {
        return Math.round((amount * (rate / 100)) * 100) / 100;
    }

    /**
     * استخراج الضريبة من المبلغ الإجمالي
     * @param {number} totalAmount - المبلغ الإجمالي
     * @param {number} rate - نسبة الضريبة
     */
    extractVatFromTotal(totalAmount, rate = this.defaultVatRate) {
        const vatFactor = rate / 100;
        const amountBeforeTax = totalAmount / (1 + vatFactor);
        const vatAmount = totalAmount - amountBeforeTax;
        
        return {
            amountBeforeTax: Math.round(amountBeforeTax * 100) / 100,
            vatAmount: Math.round(vatAmount * 100) / 100
        };
    }

    /**
     * الحصول على معلومات الضريبة للمنتج
     * @param {string} productId - معرف المنتج
     */
    async getProductTaxInfo(productId) {
        const [product] = await this.db.executeQuery(`
            SELECT 
                p.product_id,
                p.name_ar,
                p.tax_type,
                p.tax_category_id,
                tc.name as tax_category_name,
                tc.rate as category_rate
            FROM products p
            LEFT JOIN tax_categories tc ON p.tax_category_id = tc.category_id
            WHERE p.product_id = ?
        `, [productId]);

        if (!product) {
            throw new Error('المنتج غير موجود');
        }

        return product;
    }

    /**
     * التحقق من تسجيل العميل في نظام الضريبة
     * @param {Object} customer - بيانات العميل
     */
    isCustomerVatRegistered(customer) {
        return customer && customer.tax_number && 
               this.isValidVatNumber(customer.tax_number);
    }

    /**
     * التحقق من صحة الرقم الضريبي
     * @param {string} vatNumber - الرقم الضريبي
     */
    isValidVatNumber(vatNumber) {
        // التحقق من تنسيق الرقم الضريبي السعودي
        if (!/^\d{15}$/.test(vatNumber)) {
            return false;
        }

        // خوارزمية التحقق من صحة الرقم الضريبي
        let sum = 0;
        const digits = vatNumber.split('').map(Number);
        
        for (let i = 0; i < 14; i++) {
            if (i % 2 === 0) {
                const doubled = digits[i] * 2;
                sum += Math.floor(doubled / 10) + (doubled % 10);
            } else {
                sum += digits[i];
            }
        }

        const checkDigit = (10 - (sum % 10)) % 10;
        return checkDigit === digits[14];
    }

    /**
     * إنشاء ملخص ضريبي للفاتورة
     * @param {Object} invoice - بيانات الفاتورة
     */
    generateTaxSummary(invoice) {
        return {
            invoice_number: invoice.invoice_number,
            date: invoice.sale_date,
            seller: {
                name: process.env.COMPANY_NAME,
                address: process.env.COMPANY_ADDRESS,
                vatNumber: process.env.COMPANY_VAT_NUMBER
            },
            customer: invoice.customer ? {
                name: invoice.customer.name,
                vatNumber: invoice.customer.tax_number,
                address: invoice.customer.address
            } : null,
            totals: {
                totalBeforeTax: invoice.totals.subtotal,
                totalTax: invoice.totals.tax,
                totalWithTax: invoice.totals.total
            },
            taxBreakdown: invoice.taxDetails,
            qrCode: this.generateTaxQRCode(invoice)
        };
    }

    /**
     * إنشاء رمز QR للفاتورة الضريبية
     * @param {Object} invoice - بيانات الفاتورة
     */
    generateTaxQRCode(invoice) {
        // بيانات QR Code حسب متطلبات هيئة الزكاة والضريبة والجمارك
        const qrData = {
            sellerName: process.env.COMPANY_NAME,
            vatNumber: process.env.COMPANY_VAT_NUMBER,
            timestamp: invoice.sale_date,
            totalWithVat: invoice.totals.total,
            vatAmount: invoice.totals.tax
        };

        // تحويل البيانات إلى سلسلة Base64
        return Buffer.from(JSON.stringify(qrData)).toString('base64');
    }
}