/**
 * مكون زر الراديو الأساسي
 * التاريخ: 2025-05-09 03:57:33
 * المستخدم: mostafamohammad7760
 */

<template>
  <label
    :class="[
      'base-radio',
      size,
      {
        'is-checked': isChecked,
        'is-disabled': disabled,
        'has-error': error
      }
    ]"
  >
    <!-- زر الراديو الأصلي (مخفي) -->
    <input
      type="radio"
      :name="name"
      :value="value"
      :checked="isChecked"
      :disabled="disabled"
      :required="required"
      class="radio-input"
      @change="handleChange"
    >

    <!-- زر الراديو المخصص -->
    <span class="radio-custom">
      <span class="radio-dot"></span>
    </span>

    <!-- التسمية -->
    <span class="radio-label" v-if="$slots.default">
      <slot></slot>
    </span>
  </label>

  <!-- رسالة الخطأ -->
  <div v-if="error" class="error-message">
    {{ error }}
  </div>
</template>

<script lang="ts">
import { defineComponent, computed } from 'vue';

export default defineComponent({
  name: 'BaseRadio',

  props: {
    // القيمة المحددة (modelValue)
    modelValue: {
      type: [String, Number, Boolean, Object],
      required: true
    },
    // القيمة الخاصة بهذا الزر
    value: {
      type: [String, Number, Boolean, Object],
      required: true
    },
    // الاسم (لتجميع الأزرار)
    name: {
      type: String,
      required: true
    },
    // الحجم
    size: {
      type: String,
      default: 'md',
      validator: (value: string) => ['sm', 'md', 'lg'].includes(value)
    },
    // معطل
    disabled: {
      type: Boolean,
      default: false
    },
    // إلزامي
    required: {
      type: Boolean,
      default: false
    },
    // رسالة الخطأ
    error: {
      type: String,
      default: ''
    }
  },

  emits: ['update:modelValue', 'change'],

  setup(props, { emit }) {
    // التحقق من حالة التحديد
    const isChecked = computed(() => {
      return props.modelValue === props.value;
    });

    // معالجة التغيير
    const handleChange = (event: Event) => {
      const target = event.target as HTMLInputElement;
      if (target.checked) {
        emit('update:modelValue', props.value);
        emit('change', props.value);
      }
    };

    return {
      isChecked,
      handleChange
    };
  }
});
</script>

<style lang="scss" scoped>
.base-radio {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  cursor: pointer;
  user-select: none;

  // إخفاء زر الراديو الأصلي
  .radio-input {
    position: absolute;
    opacity: 0;
    width: 0;
    height: 0;
  }

  // زر الراديو المخصص
  .radio-custom {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 1.25rem;
    height: 1.25rem;
    background: var(--input-bg);
    border: 2px solid var(--border-color);
    border-radius: 50%;
    transition: all 0.2s ease;

    // النقطة الداخلية
    .radio-dot {
      width: 0.625rem;
      height: 0.625rem;
      background: currentColor;
      border-radius: 50%;
      opacity: 0;
      transform: scale(0);
      transition: all 0.2s ease;
    }
  }

  // التسمية
  .radio-label {
    font-size: 1rem;
    color: var(--text-color);
  }

  // الأحجام
  &.sm {
    .radio-custom {
      width: 1rem;
      height: 1rem;

      .radio-dot {
        width: 0.5rem;
        height: 0.5rem;
      }
    }

    .radio-label {
      font-size: 0.875rem;
    }
  }

  &.lg {
    .radio-custom {
      width: 1.5rem;
      height: 1.5rem;

      .radio-dot {
        width: 0.75rem;
        height: 0.75rem;
      }
    }

    .radio-label {
      font-size: 1.125rem;
    }
  }

  // الحالة المحددة
  &.is-checked {
    .radio-custom {
      border-color: var(--primary-color);
      color: var(--primary-color);

      .radio-dot {
        opacity: 1;
        transform: scale(1);
      }
    }
  }

  // الحالة المعطلة
  &.is-disabled {
    cursor: not-allowed;
    opacity: 0.6;

    .radio-custom {
      background: var(--disabled-bg);
    }
  }

  // حالة الخطأ
  &.has-error {
    .radio-custom {
      border-color: var(--danger-color);
    }
  }

  // التفاعلات
  &:hover:not(.is-disabled) {
    .radio-custom {
      border-color: var(--primary-color);
    }
  }

  .radio-input:focus-visible + .radio-custom {
    box-shadow: 0 0 0 3px rgba(var(--primary-color-rgb), 0.1);
  }
}

// رسالة الخطأ
.error-message {
  margin-top: 0.25rem;
  font-size: 0.75rem;
  color: var(--danger-color);
}

// مجموعة أزرار الراديو
.radio-group {
  display: flex;
  gap: 1rem;

  &.vertical {
    flex-direction: column;
  }
}
</style>