export class InventoryAPI {
    constructor() {
        this.baseUrl = '/api/v1/inventory';
        this.defaultHeaders = {
            'Content-Type': 'application/json',
            'X-User-Id': 'mostafamohammad7760',
            'X-Timestamp': new Date().toISOString()
        };
    }

    async request(endpoint, options = {}) {
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                ...options,
                headers: {
                    ...this.defaultHeaders,
                    ...options.headers
                }
            });

            if (!response.ok) {
                throw await this.handleErrorResponse(response);
            }

            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            throw this.createUserFriendlyError(error);
        }
    }

    // طلبات لوحة المعلومات
    async getInventoryValue() {
        return this.request('/dashboard/inventory-value');
    }

    async getInventoryMovement() {
        return this.request('/dashboard/inventory-movement');
    }

    async getItemsStats() {
        return this.request('/dashboard/items-stats');
    }

    async getCountInfo() {
        return this.request('/dashboard/count-info');
    }

    async getInventoryAnalysis(period = 'month') {
        return this.request(`/dashboard/inventory-analysis?period=${period}`);
    }

    async getWarehousesAnalysis(period = 'month') {
        return this.request(`/dashboard/warehouses-analysis?period=${period}`);
    }

    async getLatestTransactions() {
        return this.request('/dashboard/latest-transactions');
    }

    // طلبات المستودعات
    async getWarehouses(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/warehouses?${queryString}`);
    }

    async getWarehouse(warehouseId) {
        return this.request(`/warehouses/${warehouseId}`);
    }

    async createWarehouse(warehouseData) {
        this.validateWarehouseData(warehouseData);
        return this.request('/warehouses', {
            method: 'POST',
            body: JSON.stringify(warehouseData)
        });
    }

    async updateWarehouse(warehouseId, warehouseData) {
        this.validateWarehouseData(warehouseData);
        return this.request(`/warehouses/${warehouseId}`, {
            method: 'PUT',
            body: JSON.stringify(warehouseData)
        });
    }

    async deleteWarehouse(warehouseId) {
        return this.request(`/warehouses/${warehouseId}`, {
            method: 'DELETE'
        });
    }

    // طلبات الأصناف
    async getItems(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/items?${queryString}`);
    }

    async getItem(itemId) {
        return this.request(`/items/${itemId}`);
    }

    async createItem(itemData) {
        this.validateItemData(itemData);
        return this.request('/items', {
            method: 'POST',
            body: JSON.stringify(itemData)
        });
    }

    async updateItem(itemId, itemData) {
        this.validateItemData(itemData);
        return this.request(`/items/${itemId}`, {
            method: 'PUT',
            body: JSON.stringify(itemData)
        });
    }

    async deleteItem(itemId) {
        return this.request(`/items/${itemId}`, {
            method: 'DELETE'
        });
    }

    // طلبات مجموعات الأصناف
    async getCategories(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/categories?${queryString}`);
    }

    async getCategory(categoryId) {
        return this.request(`/categories/${categoryId}`);
    }

    async createCategory(categoryData) {
        this.validateCategoryData(categoryData);
        return this.request('/categories', {
            method: 'POST',
            body: JSON.stringify(categoryData)
        });
    }

    async updateCategory(categoryId, categoryData) {
        this.validateCategoryData(categoryData);
        return this.request(`/categories/${categoryId}`, {
            method: 'PUT',
            body: JSON.stringify(categoryData)
        });
    }

    async deleteCategory(categoryId) {
        return this.request(`/categories/${categoryId}`, {
            method: 'DELETE'
        });
    }

    // طلبات الوحدات
    async getUnits(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/units?${queryString}`);
    }

    async getUnit(unitId) {
        return this.request(`/units/${unitId}`);
    }

    async createUnit(unitData) {
        this.validateUnitData(unitData);
        return this.request('/units', {
            method: 'POST',
            body: JSON.stringify(unitData)
        });
    }

    async updateUnit(unitId, unitData) {
        this.validateUnitData(unitData);
        return this.request(`/units/${unitId}`, {
            method: 'PUT',
            body: JSON.stringify(unitData)
        });
    }

    async deleteUnit(unitId) {
        return this.request(`/units/${unitId}`, {
            method: 'DELETE'
        });
    }

    // طلبات الحركات المخزنية
    async getTransactions(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/transactions?${queryString}`);
    }

    async getTransaction(transactionId) {
        return this.request(`/transactions/${transactionId}`);
    }

    async createTransaction(transactionData) {
        this.validateTransactionData(transactionData);
        return this.request('/transactions', {
            method: 'POST',
            body: JSON.stringify(transactionData)
        });
    }

    async postTransaction(transactionId) {
        return this.request(`/transactions/${transactionId}/post`, {
            method: 'PUT'
        });
    }

    async cancelTransaction(transactionId, reason) {
        return this.request(`/transactions/${transactionId}/cancel`, {
            method: 'PUT',
            body: JSON.stringify({ reason })
        });
    }

    // طلبات التحويلات بين المستودعات
    async getTransfers(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/transfers?${queryString}`);
    }

    async getTransfer(transferId) {
        return this.request(`/transfers/${transferId}`);
    }

    async createTransfer(transferData) {
        this.validateTransferData(transferData);
        return this.request('/transfers', {
            method: 'POST',
            body: JSON.stringify(transferData)
        });
    }

    async shipTransfer(transferId) {
        return this.request(`/transfers/${transferId}/ship`, {
            method: 'PUT'
        });
    }

    async receiveTransfer(transferId, receivedItems) {
        return this.request(`/transfers/${transferId}/receive`, {
            method: 'PUT',
            body: JSON.stringify({ receivedItems })
        });
    }

    async cancelTransfer(transferId, reason) {
        return this.request(`/transfers/${transferId}/cancel`, {
            method: 'PUT',
            body: JSON.stringify({ reason })
        });
    }

    // طلبات الجرد
    async getInventoryCounts(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/counts?${queryString}`);
    }

    async getInventoryCount(countId) {
        return this.request(`/counts/${countId}`);
    }

    async createInventoryCount(countData) {
        this.validateCountData(countData);
        return this.request('/counts', {
            method: 'POST',
            body: JSON.stringify(countData)
        });
    }

    async updateInventoryCount(countId, countData) {
        return this.request(`/counts/${countId}`, {
            method: 'PUT',
            body: JSON.stringify(countData)
        });
    }

    async completeInventoryCount(countId) {
        return this.request(`/counts/${countId}/complete`, {
            method: 'PUT'
        });
    }

    async cancelInventoryCount(countId, reason) {
        return this.request(`/counts/${countId}/cancel`, {
            method: 'PUT',
            body: JSON.stringify({ reason })
        });
    }

    // طلبات التقارير
    async getItemBalances(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/item-balances?${queryString}`);
    }

    async getItemMovement(itemId, params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/item-movement/${itemId}?${queryString}`);
    }

    async getWarehouseBalances(warehouseId, params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/warehouse-balances/${warehouseId}?${queryString}`);
    }

    async getTransactionReport(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/transactions?${queryString}`);
    }

    // توابع التحقق من صحة البيانات
    validateWarehouseData(warehouseData) {
        const requiredFields = ['code', 'name', 'location'];
        
        const missingFields = requiredFields.filter(field => !warehouseData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        return true;
    }

    validateItemData(itemData) {
        const requiredFields = ['code', 'name', 'categoryId', 'baseUnitId'];
        
        const missingFields = requiredFields.filter(field => !itemData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        return true;
    }

    validateCategoryData(categoryData) {
        if (!categoryData.name) {
            throw new Error('اسم المجموعة مطلوب');
        }

        return true;
    }

    validateUnitData(unitData) {
        const requiredFields = ['code', 'name'];
        
        const missingFields = requiredFields.filter(field => !unitData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        return true;
    }

    validateTransactionData(transactionData) {
        if (!transactionData.warehouseId) {
            throw new Error('المستودع مطلوب');
        }

        if (!Array.isArray(transactionData.items) || transactionData.items.length === 0) {
            throw new Error('يجب إضافة صنف واحد على الأقل');
        }

        transactionData.items.forEach((item, index) => {
            if (!item.itemId || !item.quantity || !item.unitId) {
                throw new Error(`الصنف رقم ${index + 1} يحتوي على بيانات ناقصة`);
            }
        });

        return true;
    }

    validateTransferData(transferData) {
        if (!transferData.fromWarehouseId || !transferData.toWarehouseId) {
            throw new Error('المستودع المصدر والمستودع الهدف مطلوبان');
        }

        if (transferData.fromWarehouseId === transferData.toWarehouseId) {
            throw new Error('لا يمكن التحويل لنفس المستودع');
        }

        if (!Array.isArray(transferData.items) || transferData.items.length === 0) {
            throw new Error('يجب إضافة صنف واحد على الأقل');
        }

        transferData.items.forEach((item, index) => {
            if (!item.itemId || !item.quantity || !item.unitId) {
                throw new Error(`الصنف رقم ${index + 1} يحتوي على بيانات ناقصة`);
            }
        });

        return true;
    }

    validateCountData(countData) {
        if (!countData.warehouseId) {
            throw new Error('المستودع مطلوب');
        }

        return true;
    }

    // توابع معالجة الأخطاء
    async handleErrorResponse(response) {
        let error;
        try {
            const errorData = await response.json();
            error = new Error(errorData.message || 'حدث خطأ غير معروف');
            error.code = errorData.code;
            error.details = errorData.details;
        } catch {
            error = new Error(`خطأ في الطلب: ${response.status}`);
        }
        error.status = response.status;
        return error;
    }

    createUserFriendlyError(error) {
        const errorMessages = {
            400: 'البيانات المدخلة غير صحيحة',
            401: 'يرجى تسجيل الدخول مرة أخرى',
            403: 'ليس لديك صلاحية للقيام بهذا الإجراء',
            404: 'لم يتم العثور على البيانات المطلوبة',
            409: 'تعارض في البيانات',
            422: 'البيانات المدخلة غير صالحة',
            500: 'حدث خطأ في النظام'
        };

        return new Error(
            errorMessages[error.status] || 
            error.message || 
            'حدث خطأ غير متوقع'
        );
    }
}