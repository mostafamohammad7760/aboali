import { TaxAPI } from './api/tax_api.js';
import { ChartManager } from './utils/chart_manager.js';
import { 
    formatCurrency, 
    formatDate, 
    formatPercentage 
} from './utils/formatters.js';
import { 
    validateTaxReturn, 
    validateZakatBase 
} from './utils/validators.js';

class TaxZakatManager {
    constructor() {
        // تهيئة الخدمات
        this.api = new TaxAPI();
        this.charts = new ChartManager();
        this.currentUser = 'mostafamohammad7760';
        
        // تهيئة المكونات والبيانات
        this.initializeComponents();
        this.attachEventListeners();
        this.loadDashboardData();
        
        // تحديث الوقت كل ثانية
        this.updateDateTime();
        setInterval(() => this.updateDateTime(), 1000);
    }

    // تهيئة مكونات الواجهة
    initializeComponents() {
        // عناصر ملخص ضريبة القيمة المضافة
        this.vatElements = {
            payable: document.getElementById('vatPayable'),
            paid: document.getElementById('vatPaid'),
            status: document.getElementById('vatStatus'),
            dueDate: document.getElementById('vatDueDate'),
            period: document.getElementById('vatPeriod')
        };

        // عناصر ملخص الزكاة
        this.zakatElements = {
            base: document.getElementById('zakatBase'),
            amount: document.getElementById('zakatAmount'),
            status: document.getElementById('zakatStatus'),
            dueDate: document.getElementById('zakatDueDate'),
            period: document.getElementById('zakatPeriod')
        };

        // عناصر التحليل
        this.analysisElements = {
            taxPeriod: document.getElementById('taxAnalysisPeriod'),
            zakatYears: document.getElementById('zakatComparisonYears')
        };

        // تهيئة الرسوم البيانية
        this.initializeCharts();
    }

    // تهيئة الرسوم البيانية
    initializeCharts() {
        // رسم تحليل الضرائب
        this.charts.initializeLineChart('taxAnalysisChart', {
            labels: [],
            datasets: [{
                label: 'ضريبة القيمة المضافة',
                data: [],
                borderColor: '#2c4d76',
                tension: 0.4
            }],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => formatCurrency(value)
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: context => formatCurrency(context.parsed.y)
                        }
                    }
                }
            }
        });

        // رسم مقارنة الزكاة
        this.charts.initializeBarChart('zakatComparisonChart', {
            labels: [],
            datasets: [{
                label: 'وعاء الزكاة',
                data: [],
                backgroundColor: '#27ae60'
            }],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => formatCurrency(value)
                        }
                    }
                }
            }
        });
    }

    // تحميل بيانات لوحة المعلومات
    async loadDashboardData() {
        try {
            this.showLoading();

            const [
                vatSummary,
                zakatSummary,
                upcomingReturns,
                taxAnalysis,
                zakatComparison
            ] = await Promise.all([
                this.api.getVATSummary(this.vatElements.period.value),
                this.api.getZakatSummary(this.zakatElements.period.value),
                this.api.getUpcomingReturns(),
                this.api.getTaxAnalysis(this.analysisElements.taxPeriod.value),
                this.api.getZakatComparison(this.analysisElements.zakatYears.value)
            ]);

            this.updateVATSummary(vatSummary);
            this.updateZakatSummary(zakatSummary);
            this.renderUpcomingReturns(upcomingReturns);
            this.updateAnalysisCharts(taxAnalysis, zakatComparison);

            this.hideLoading();
        } catch (error) {
            this.hideLoading();
            this.showError('حدث خطأ أثناء تحميل البيانات');
            console.error('Dashboard loading error:', error);
        }
    }

    // تحديث ملخص ضريبة القيمة المضافة
    updateVATSummary(summary) {
        this.vatElements.payable.textContent = formatCurrency(summary.payableAmount);
        this.vatElements.paid.textContent = formatCurrency(summary.paidAmount);
        this.vatElements.dueDate.textContent = formatDate(summary.dueDate);
        
        const statusBadge = this.vatElements.status;
        statusBadge.className = `status-badge ${summary.status}`;
        statusBadge.textContent = this.getStatusText(summary.status);
    }

    // تحديث ملخص الزكاة
    updateZakatSummary(summary) {
        this.zakatElements.base.textContent = formatCurrency(summary.baseAmount);
        this.zakatElements.amount.textContent = formatCurrency(summary.zakatAmount);
        this.zakatElements.dueDate.textContent = formatDate(summary.dueDate);
        
        const statusBadge = this.zakatElements.status;
        statusBadge.className = `status-badge ${summary.status}`;
        statusBadge.textContent = this.getStatusText(summary.status);
    }

    // تحديث الرسوم البيانية
    updateAnalysisCharts(taxAnalysis, zakatComparison) {
        // تحديث رسم تحليل الضرائب
        this.charts.updateLineChart('taxAnalysisChart', {
            labels: taxAnalysis.periods,
            datasets: [{
                data: taxAnalysis.values
            }]
        });

        // تحديث رسم مقارنة الزكاة
        this.charts.updateBarChart('zakatComparisonChart', {
            labels: zakatComparison.years,
            datasets: [{
                data: zakatComparison.values
            }]
        });
    }

    // عرض الإقرارات القادمة
    renderUpcomingReturns(returns) {
        const tbody = document.getElementById('upcomingReturnsTable');
        tbody.innerHTML = '';

        returns.forEach(returnData => {
            const tr = this.createReturnRow(returnData);
            tbody.appendChild(tr);
        });
    }

    // إنشاء صف إقرار
    createReturnRow(returnData) {
        const template = document.getElementById('returnRowTemplate');
        const tr = template.content.cloneNode(true);

        tr.querySelector('.return-type').textContent = returnData.type;
        tr.querySelector('.return-number').textContent = returnData.number;
        tr.querySelector('.period').textContent = returnData.period;
        tr.querySelector('.due-date').textContent = formatDate(returnData.dueDate);
        tr.querySelector('.expected-amount').textContent = formatCurrency(returnData.expectedAmount);

        const statusBadge = tr.querySelector('.status-badge');
        statusBadge.className = `status-badge ${returnData.status}`;
        statusBadge.textContent = this.getStatusText(returnData.status);

        // إضافة مستمعات الأحداث للأزرار
        tr.querySelector('.prepare-return').addEventListener('click', 
            () => this.showReturnPreparationModal(returnData));
        tr.querySelector('.view-details').addEventListener('click', 
            () => this.viewReturnDetails(returnData));

        return tr;
    }

    // إضافة مستمعات الأحداث
    attachEventListeners() {
        // مستمعات أحداث الفلترة
        this.vatElements.period.addEventListener('change', 
            () => this.loadDashboardData());
        this.zakatElements.period.addEventListener('change', 
            () => this.loadDashboardData());
        this.analysisElements.taxPeriod.addEventListener('change', 
            () => this.loadDashboardData());
        this.analysisElements.zakatYears.addEventListener('change', 
            () => this.loadDashboardData());

        // مستمعات أحداث الإجراءات السريعة
        document.getElementById('newTaxReturn')?.addEventListener('click', 
            () => this.showNewReturnModal());
        document.getElementById('calculateZakat')?.addEventListener('click', 
            () => this.showZakatCalculatorModal());
        document.getElementById('generateReport')?.addEventListener('click', 
            () => this.showReportGeneratorModal());
        document.getElementById('uploadDocuments')?.addEventListener('click', 
            () => this.showDocumentUploadModal());

        // مستمع حدث تصدير الإقرارات
        document.getElementById('exportReturns')?.addEventListener('click', 
            () => this.exportReturns());
    }

    // تحديث التاريخ والوقت
    updateDateTime() {
        const now = new Date();
        document.getElementById('currentDateTime').textContent = 
            now.toISOString().slice(0, 19).replace('T', ' ');
    }

    // ترجمة حالات الإقرارات
    getStatusText(status) {
        const statusMap = {
            'pending': 'قيد الإعداد',
            'submitted': 'تم التقديم',
            'approved': 'معتمد',
            'rejected': 'مرفوض',
            'overdue': 'متأخر'
        };
        return statusMap[status] || status;
    }

    // إظهار/إخفاء مؤشر التحميل
    showLoading() {
        const loader = document.createElement('div');
        loader.className = 'loading-overlay';
        loader.innerHTML = '<div class="loading-spinner"></div>';
        document.body.appendChild(loader);
    }

    hideLoading() {
        document.querySelector('.loading-overlay')?.remove();
    }

    // عرض رسائل الخطأ والنجاح
    showError(message) {
        // يمكن تحسين هذه الدالة لعرض رسائل خطأ أكثر جاذبية
        console.error(message);
        alert(message);
    }

    showSuccess(message) {
        // يمكن تحسين هذه الدالة لعرض رسائل نجاح أكثر جاذبية
        alert(message);
    }
}

// تهيئة التطبيق عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    new TaxZakatManager();
});