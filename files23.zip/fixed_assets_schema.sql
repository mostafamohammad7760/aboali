-- إنشاء جداول الأصول الثابتة

-- جدول مجموعات الأصول
CREATE TABLE asset_groups (
    group_id VARCHAR(20) PRIMARY KEY,
    group_name_ar VARCHAR(100) NOT NULL,
    group_name_en VARCHAR(100),
    depreciation_method ENUM('straight_line', 'declining_balance', 'units_of_production') NOT NULL,
    depreciation_rate DECIMAL(5,2) NOT NULL,
    useful_life_years INT NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50)
);

-- جدول الأصول
CREATE TABLE assets (
    asset_id VARCHAR(20) PRIMARY KEY,
    group_id VARCHAR(20) NOT NULL,
    asset_name_ar VARCHAR(200) NOT NULL,
    asset_name_en VARCHAR(200),
    acquisition_date DATE NOT NULL,
    acquisition_cost DECIMAL(18,2) NOT NULL,
    salvage_value DECIMAL(18,2) DEFAULT 0,
    current_value DECIMAL(18,2) NOT NULL,
    location VARCHAR(100),
    serial_number VARCHAR(50),
    warranty_expiry DATE,
    status ENUM('active', 'inactive', 'maintenance', 'disposed') DEFAULT 'active',
    disposal_date DATE,
    disposal_value DECIMAL(18,2),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (group_id) REFERENCES asset_groups(group_id)
);

-- جدول مكونات الأصول
CREATE TABLE asset_components (
    component_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    asset_id VARCHAR(20) NOT NULL,
    component_name VARCHAR(100) NOT NULL,
    description TEXT,
    quantity INT DEFAULT 1,
    unit_cost DECIMAL(18,2),
    installation_date DATE,
    warranty_expiry DATE,
    status ENUM('active', 'inactive', 'replaced') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    FOREIGN KEY (asset_id) REFERENCES assets(asset_id)
);

-- جدول الإهلاك
CREATE TABLE depreciation (
    depreciation_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    asset_id VARCHAR(20) NOT NULL,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    depreciation_amount DECIMAL(18,2) NOT NULL,
    accumulated_depreciation DECIMAL(18,2) NOT NULL,
    book_value DECIMAL(18,2) NOT NULL,
    fiscal_year INT NOT NULL,
    period_number INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    FOREIGN KEY (asset_id) REFERENCES assets(asset_id)
);

-- جدول الصيانة
CREATE TABLE maintenance (
    maintenance_id VARCHAR(20) PRIMARY KEY,
    asset_id VARCHAR(20) NOT NULL,
    maintenance_type ENUM('preventive', 'corrective', 'scheduled') NOT NULL,
    maintenance_date DATE NOT NULL,
    completion_date DATE,
    cost DECIMAL(18,2) NOT NULL,
    provider VARCHAR(100),
    description TEXT,
    status ENUM('planned', 'in_progress', 'completed', 'cancelled') DEFAULT 'planned',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    FOREIGN KEY (asset_id) REFERENCES assets(asset_id)
);

-- جدول قطع الغيار
CREATE TABLE spare_parts (
    part_id VARCHAR(20) PRIMARY KEY,
    part_name VARCHAR(100) NOT NULL,
    description TEXT,
    unit_cost DECIMAL(18,2) NOT NULL,
    quantity_in_stock INT DEFAULT 0,
    minimum_quantity INT DEFAULT 1,
    location VARCHAR(100),
    supplier VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50)
);

-- جدول العلاقة بين الأصول وقطع الغيار
CREATE TABLE asset_spare_parts (
    asset_id VARCHAR(20) NOT NULL,
    part_id VARCHAR(20) NOT NULL,
    quantity_required INT DEFAULT 1,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    PRIMARY KEY (asset_id, part_id),
    FOREIGN KEY (asset_id) REFERENCES assets(asset_id),
    FOREIGN KEY (part_id) REFERENCES spare_parts(part_id)
);

-- جدول استخدام قطع الغيار في الصيانة
CREATE TABLE maintenance_parts_usage (
    usage_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    maintenance_id VARCHAR(20) NOT NULL,
    part_id VARCHAR(20) NOT NULL,
    quantity_used INT NOT NULL,
    unit_cost DECIMAL(18,2) NOT NULL,
    total_cost DECIMAL(18,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    FOREIGN KEY (maintenance_id) REFERENCES maintenance(maintenance_id),
    FOREIGN KEY (part_id) REFERENCES spare_parts(part_id)
);

-- جدول إعادة التقييم
CREATE TABLE asset_revaluation (
    revaluation_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    asset_id VARCHAR(20) NOT NULL,
    revaluation_date DATE NOT NULL,
    previous_value DECIMAL(18,2) NOT NULL,
    new_value DECIMAL(18,2) NOT NULL,
    adjustment_amount DECIMAL(18,2) NOT NULL,
    reason TEXT,
    approved_by VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    FOREIGN KEY (asset_id) REFERENCES assets(asset_id)
);

-- جدول حركات الأصول
CREATE TABLE asset_transfers (
    transfer_id VARCHAR(20) PRIMARY KEY,
    asset_id VARCHAR(20) NOT NULL,
    from_location VARCHAR(100) NOT NULL,
    to_location VARCHAR(100) NOT NULL,
    transfer_date DATE NOT NULL,
    reason TEXT,
    status ENUM('pending', 'completed', 'cancelled') DEFAULT 'pending',
    completed_at TIMESTAMP NULL,
    completed_by VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    FOREIGN KEY (asset_id) REFERENCES assets(asset_id)
);

-- إجراءات مخزنة

DELIMITER //

-- إجراء حساب الإهلاك الشهري
CREATE PROCEDURE calculate_monthly_depreciation(
    IN p_year INT,
    IN p_month INT
)
BEGIN
    DECLARE v_start_date DATE;
    DECLARE v_end_date DATE;
    
    -- تحديد فترة الإهلاك
    SET v_start_date = DATE(CONCAT(p_year, '-', LPAD(p_month, 2, '0'), '-01'));
    SET v_end_date = LAST_DAY(v_start_date);
    
    -- إدراج سجلات الإهلاك
    INSERT INTO depreciation (
        asset_id,
        period_start,
        period_end,
        depreciation_amount,
        accumulated_depreciation,
        book_value,
        fiscal_year,
        period_number,
        created_by
    )
    SELECT 
        a.asset_id,
        v_start_date,
        v_end_date,
        CASE ag.depreciation_method
            WHEN 'straight_line' THEN 
                (a.acquisition_cost - a.salvage_value) / (ag.useful_life_years * 12)
            WHEN 'declining_balance' THEN
                (a.current_value * (ag.depreciation_rate / 100)) / 12
            ELSE 0
        END as depreciation_amount,
        COALESCE(
            (SELECT SUM(depreciation_amount) 
             FROM depreciation d2 
             WHERE d2.asset_id = a.asset_id
            ), 0
        ) + CASE ag.depreciation_method
            WHEN 'straight_line' THEN 
                (a.acquisition_cost - a.salvage_value) / (ag.useful_life_years * 12)
            WHEN 'declining_balance' THEN
                (a.current_value * (ag.depreciation_rate / 100)) / 12
            ELSE 0
        END as accumulated_depreciation,
        a.current_value - CASE ag.depreciation_method
            WHEN 'straight_line' THEN 
                (a.acquisition_cost - a.salvage_value) / (ag.useful_life_years * 12)
            WHEN 'declining_balance' THEN
                (a.current_value * (ag.depreciation_rate / 100)) / 12
            ELSE 0
        END as book_value,
        p_year,
        p_month,
        'system'
    FROM assets a
    JOIN asset_groups ag ON a.group_id = ag.group_id
    WHERE a.status = 'active'
    AND a.acquisition_date <= v_end_date
    AND (a.disposal_date IS NULL OR a.disposal_date > v_start_date);
    
    -- تحديث القيمة الحالية للأصول
    UPDATE assets a
    JOIN (
        SELECT 
            asset_id,
            book_value
        FROM depreciation
        WHERE period_end = v_end_date
    ) d ON a.asset_id = d.asset_id
    SET a.current_value = d.book_value,
        a.updated_at = CURRENT_TIMESTAMP,
        a.updated_by = 'system';
END //

DELIMITER ;