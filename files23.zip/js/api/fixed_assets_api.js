export class FixedAssetsAPI {
    constructor() {
        this.baseUrl = '/api/v1/fixed-assets';
        this.defaultHeaders = {
            'Content-Type': 'application/json',
            'X-User-Id': 'mostafamohammad7760',
            'X-Timestamp': new Date().toISOString()
        };
    }

    async request(endpoint, options = {}) {
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                ...options,
                headers: {
                    ...this.defaultHeaders,
                    ...options.headers
                }
            });

            if (!response.ok) {
                throw await this.handleErrorResponse(response);
            }

            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            throw this.createUserFriendlyError(error);
        }
    }

    // طلبات لوحة المعلومات
    async getDashboardSummary() {
        return this.request('/dashboard/summary');
    }

    async getAssetsDistribution() {
        return this.request('/dashboard/assets-distribution');
    }

    async getMonthlyDepreciation(year = new Date().getFullYear()) {
        return this.request(`/dashboard/monthly-depreciation/${year}`);
    }

    async getLatestMaintenance(limit = 10) {
        return this.request(`/dashboard/latest-maintenance?limit=${limit}`);
    }

    async getExpiringAssets(days = 90) {
        return this.request(`/dashboard/expiring-assets?days=${days}`);
    }

    // طلبات الأصول
    async getAssets(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/assets?${queryString}`);
    }

    async getAsset(assetId) {
        return this.request(`/assets/${assetId}`);
    }

    async createAsset(assetData) {
        this.validateAssetData(assetData);
        return this.request('/assets', {
            method: 'POST',
            body: JSON.stringify(assetData)
        });
    }

    async updateAsset(assetId, assetData) {
        this.validateAssetData(assetData);
        return this.request(`/assets/${assetId}`, {
            method: 'PUT',
            body: JSON.stringify(assetData)
        });
    }

    async disposeAsset(assetId, disposalData) {
        return this.request(`/assets/${assetId}/dispose`, {
            method: 'POST',
            body: JSON.stringify(disposalData)
        });
    }

    // طلبات مجموعات الأصول
    async getAssetGroups() {
        return this.request('/asset-groups');
    }

    async createAssetGroup(groupData) {
        return this.request('/asset-groups', {
            method: 'POST',
            body: JSON.stringify(groupData)
        });
    }

    async updateAssetGroup(groupId, groupData) {
        return this.request(`/asset-groups/${groupId}`, {
            method: 'PUT',
            body: JSON.stringify(groupData)
        });
    }

    // طلبات الصيانة
    async getMaintenanceRecords(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/maintenance?${queryString}`);
    }

    async createMaintenanceRecord(maintenanceData) {
        return this.request('/maintenance', {
            method: 'POST',
            body: JSON.stringify(maintenanceData)
        });
    }

    async updateMaintenanceStatus(maintenanceId, statusData) {
        return this.request(`/maintenance/${maintenanceId}/status`, {
            method: 'PUT',
            body: JSON.stringify(statusData)
        });
    }

    // طلبات قطع الغيار
    async getSpareParts(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/spare-parts?${queryString}`);
    }

    async createSparePart(partData) {
        return this.request('/spare-parts', {
            method: 'POST',
            body: JSON.stringify(partData)
        });
    }

    async updateSparePartStock(partId, stockData) {
        return this.request(`/spare-parts/${partId}/stock`, {
            method: 'PUT',
            body: JSON.stringify(stockData)
        });
    }

    // طلبات الإهلاك
    async calculateDepreciation(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/depreciation/calculate?${queryString}`);
    }

    async getDepreciationHistory(assetId) {
        return this.request(`/depreciation/history/${assetId}`);
    }

    // طلبات إعادة التقييم
    async revaluateAsset(assetId, revaluationData) {
        return this.request(`/assets/${assetId}/revaluate`, {
            method: 'POST',
            body: JSON.stringify(revaluationData)
        });
    }

    // طلبات التقارير
    async generateReport(reportType, params = {}) {
        const queryString = new URLSearchParams(params).toString();
        const response = await fetch(
            `${this.baseUrl}/reports/${reportType}?${queryString}`,
            {
                headers: this.defaultHeaders
            }
        );

        if (!response.ok) {
            throw await this.handleErrorResponse(response);
        }

        return await this.handleReportResponse(response);
    }

    // توابع مساعدة للتحقق من صحة البيانات
    validateAssetData(assetData) {
        const requiredFields = [
            'assetNameAr',
            'groupId',
            'acquisitionDate',
            'acquisitionCost'
        ];

        const missingFields = requiredFields.filter(field => !assetData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        if (assetData.acquisitionCost <= 0) {
            throw new Error('يجب أن تكون تكلفة الاقتناء أكبر من صفر');
        }

        if (new Date(assetData.acquisitionDate) > new Date()) {
            throw new Error('تاريخ الاقتناء لا يمكن أن يكون في المستقبل');
        }

        return true;
    }

    // معالجة الأخطاء
    async handleErrorResponse(response) {
        let error;
        try {
            const errorData = await response.json();
            error = new Error(errorData.message || 'حدث خطأ غير معروف');
            error.code = errorData.code;
            error.details = errorData.details;
        } catch {
            error = new Error(`خطأ في الطلب: ${response.status}`);
        }
        error.status = response.status;
        return error;
    }

    createUserFriendlyError(error) {
        const errorMessages = {
            400: 'البيانات المدخلة غير صحيحة',
            401: 'يرجى تسجيل الدخول مرة أخرى',
            403: 'ليس لديك صلاحية للقيام بهذا الإجراء',
            404: 'لم يتم العثور على البيانات المطلوبة',
            409: 'تعارض في البيانات',
            500: 'حدث خطأ في النظام'
        };

        return new Error(
            errorMessages[error.status] || 
            error.message || 
            'حدث خطأ غير متوقع'
        );
    }

    // معالجة التقارير
    async handleReportResponse(response) {
        const contentType = response.headers.get('Content-Type');
        const filename = this.getFilenameFromResponse(response);

        if (contentType.includes('application/json')) {
            return await response.json();
        }

        const blob = await response.blob();
        return {
            blob,
            filename,
            contentType
        };
    }

    getFilenameFromResponse(response) {
        const contentDisposition = response.headers.get('Content-Disposition');
        if (!contentDisposition) return `report-${Date.now()}.xlsx`;

        const filenameMatch = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
        return filenameMatch && filenameMatch[1] ? 
            filenameMatch[1].replace(/['"]/g, '') : 
            `report-${Date.now()}.xlsx`;
    }
}