/**
 * مكون مساعد لإدارة الإشعارات
 * التاريخ: 2025-05-09 03:41:00
 * المستخدم: mostafamohammad7760
 */

import { ref, onMounted, onUnmounted } from 'vue';

interface Notification {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  message: string;
  duration?: number;
  isPersistent?: boolean;
}

export function useNotifications() {
  const notifications = ref<Notification[]>([]);
  const timeouts = new Map<string, number>();

  // إضافة إشعار جديد
  const showNotification = ({
    type = 'info',
    message,
    duration = 5000,
    isPersistent = false
  }: Omit<Notification, 'id'>) => {
    const id = Date.now().toString();
    
    notifications.value.push({
      id,
      type,
      message,
      duration,
      isPersistent
    });

    // إذا لم يكن الإشعار دائماً، نضيف مؤقت لإزالته
    if (!isPersistent) {
      const timeout = window.setTimeout(() => {
        removeNotification(id);
        timeouts.delete(id);
      }, duration);
      
      timeouts.set(id, timeout);
    }

    return id;
  };

  // إزالة إشعار
  const removeNotification = (id: string) => {
    const index = notifications.value.findIndex(n => n.id === id);
    if (index > -1) {
      notifications.value.splice(index, 1);
    }

    // إزالة المؤقت إذا وجد
    if (timeouts.has(id)) {
      clearTimeout(timeouts.get(id));
      timeouts.delete(id);
    }
  };

  // إزالة جميع الإشعارات
  const clearAllNotifications = () => {
    notifications.value = [];
    timeouts.forEach(timeout => clearTimeout(timeout));
    timeouts.clear();
  };

  // تحديث مدة إشعار
  const updateNotificationDuration = (id: string, newDuration: number) => {
    const notification = notifications.value.find(n => n.id === id);
    if (!notification || notification.isPersistent) return;

    // إزالة المؤقت القديم
    if (timeouts.has(id)) {
      clearTimeout(timeouts.get(id));
    }

    // إضافة مؤقت جديد
    const timeout = window.setTimeout(() => {
      removeNotification(id);
      timeouts.delete(id);
    }, newDuration);

    timeouts.set(id, timeout);
  };

  // إيقاف مؤقت إشعار مؤقتاً
  const pauseNotification = (id: string) => {
    if (timeouts.has(id)) {
      clearTimeout(timeouts.get(id));
      timeouts.delete(id);
    }
  };

  // استئناف مؤقت إشعار
  const resumeNotification = (id: string) => {
    const notification = notifications.value.find(n => n.id === id);
    if (!notification || notification.isPersistent || timeouts.has(id)) return;

    const timeout = window.setTimeout(() => {
      removeNotification(id);
      timeouts.delete(id);
    }, notification.duration);

    timeouts.set(id, timeout);
  };

  // تنظيف المؤقتات عند إزالة المكون
  onUnmounted(() => {
    timeouts.forEach(timeout => clearTimeout(timeout));
    timeouts.clear();
  });

  return {
    notifications,
    showNotification,
    removeNotification,
    clearAllNotifications,
    updateNotificationDuration,
    pauseNotification,
    resumeNotification
  };
}