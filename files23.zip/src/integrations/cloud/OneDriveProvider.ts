/**
 * مزود خدمة OneDrive للتخزين السحابي
 * التاريخ: 2025-05-09 04:40:56
 * المستخدم: mostafamohammad7760
 */

import { Client } from '@microsoft/microsoft-graph-client';
import { CloudStorageBase, CloudFile, CloudUploadOptions } from './CloudStorageBase';
import { CloudStorageError } from '../errors/CloudStorageError';

export class OneDriveProvider extends CloudStorageBase {
  private client: Client;
  private driveId: string;

  constructor(config: {
    accessToken: string;
    driveId?: string;
  }) {
    super();
    this.client = Client.init({
      authProvider: (done) => {
        done(null, config.accessToken);
      }
    });
    this.driveId = config.driveId || 'me';
  }

  public async upload(path: string, data: Buffer, options?: CloudUploadOptions): Promise<void> {
    try {
      // تحميل الملف في قطع صغيرة للملفات الكبيرة
      if (data.length > 4 * 1024 * 1024) {
        await this.uploadLargeFile(path, data);
      } else {
        await this.uploadSmallFile(path, data);
      }

      if (options?.metadata) {
        await this.updateMetadata(path, options.metadata);
      }
    } catch (error) {
      throw new CloudStorageError('فشل رفع الملف إلى OneDrive', error);
    }
  }

  public async download(path: string): Promise<CloudFile> {
    try {
      const item = await this.client
        .api(`/drives/${this.driveId}/root:/${path}`)
        .get();

      const content = await this.client
        .api(`/drives/${this.driveId}/items/${item.id}/content`)
        .get();

      return {
        data: Buffer.from(await content.arrayBuffer()),
        metadata: item.file.metadata || {}
      };
    } catch (error) {
      throw new CloudStorageError('فشل تحميل الملف من OneDrive', error);
    }
  }

  public async delete(path: string): Promise<void> {
    try {
      await this.client
        .api(`/drives/${this.driveId}/root:/${path}`)
        .delete();
    } catch (error) {
      throw new CloudStorageError('فشل حذف الملف من OneDrive', error);
    }
  }

  public async list(prefix: string): Promise<CloudFile[]> {
    try {
      const response = await this.client
        .api(`/drives/${this.driveId}/root:/${prefix}:/children`)
        .get();

      return response.value
        .filter((item: any) => item.file)
        .map((item: any) => ({
          path: item.name,
          size: item.size,
          metadata: item.file.metadata || {}
        }));
    } catch (error) {
      throw new CloudStorageError('فشل قراءة محتويات المجلد من OneDrive', error);
    }
  }

  private async uploadSmallFile(path: string, data: Buffer): Promise<void> {
    await this.client
      .api(`/drives/${this.driveId}/root:/${path}:/content`)
      .put(data);
  }

  private async uploadLargeFile(path: string, data: Buffer): Promise<void> {
    // إنشاء جلسة تحميل
    const uploadSession = await this.client
      .api(`/drives/${this.driveId}/root:/${path}:/createUploadSession`)
      .post({});

    const maxChunkSize = 4 * 1024 * 1024; // 4MB
    const totalSize = data.length;

    for (let i = 0; i < totalSize; i += maxChunkSize) {
      const chunk = data.slice(i, Math.min(i + maxChunkSize, totalSize));
      const contentRange = `bytes ${i}-${i + chunk.length - 1}/${totalSize}`;

      await fetch(uploadSession.uploadUrl, {
        method: 'PUT',
        headers: {
          'Content-Length': chunk.length.toString(),
          'Content-Range': contentRange
        },
        body: chunk
      });
    }
  }

  private async updateMetadata(path: string, metadata: Record<string, any>): Promise<void> {
    await this.client
      .api(`/drives/${this.driveId}/root:/${path}`)
      .patch({
        file: { metadata }
      });
  }
}