import { PaymentsAPI } from './api/payments_api.js';
import { ChartManager } from './chart_manager.js';
import { formatCurrency, formatNumber, formatDate } from './utils/formatters.js';
import { validateReceipt, validatePayment, validateCheck } from './utils/validators.js';

class Payments {
    constructor() {
        this.api = new PaymentsAPI();
        this.charts = new ChartManager();
        this.currentUser = 'mostafamohammad7760';
        
        // تهيئة المكونات والبيانات
        this.initializeComponents();
        this.attachEventListeners();
        this.loadDashboardData();
        
        // تحديث الوقت كل ثانية
        this.updateDateTime();
        setInterval(() => this.updateDateTime(), 1000);
    }

    initializeComponents() {
        // عناصر لوحة المعلومات
        this.dashboardElements = {
            // الصندوق
            cashBalance: document.getElementById('cashBalance'),
            cashReceipts: document.getElementById('cashReceipts'),
            cashPayments: document.getElementById('cashPayments'),
            
            // البنوك
            totalBankBalance: document.getElementById('totalBankBalance'),
            incomingTransfers: document.getElementById('incomingTransfers'),
            outgoingTransfers: document.getElementById('outgoingTransfers'),
            
            // الشيكات
            pendingChecksReceivable: document.getElementById('pendingChecksReceivable'),
            pendingChecksPayable: document.getElementById('pendingChecksPayable'),
            bouncedChecks: document.getElementById('bouncedChecks'),
            
            // التحصيلات والمدفوعات
            totalReceivables: document.getElementById('totalReceivables'),
            totalPayables: document.getElementById('totalPayables'),
            collectionRate: document.getElementById('collectionRate'),
            
            // الجداول
            upcomingChecksTable: document.getElementById('upcomingChecksTable')
        };

        // عناصر الفلترة
        this.filterElements = {
            cashFlowPeriod: document.getElementById('cashFlowPeriod'),
            distributionPeriod: document.getElementById('distributionPeriod')
        };

        // تهيئة الرسوم البيانية
        this.initializeCharts();
        
        // تهيئة القوالب
        this.checkRowTemplate = document.getElementById('checkRowTemplate');
    }

    async loadDashboardData() {
        try {
            this.showLoading();

            const [
                cashStats,
                bankStats,
                checkStats,
                collectionStats,
                cashFlowData,
                distributionData,
                upcomingChecks
            ] = await Promise.all([
                this.api.getCashStats(),
                this.api.getBankStats(),
                this.api.getCheckStats(),
                this.api.getCollectionStats(),
                this.api.getCashFlowAnalysis(this.filterElements.cashFlowPeriod.value),
                this.api.getDistributionAnalysis(this.filterElements.distributionPeriod.value),
                this.api.getUpcomingChecks()
            ]);

            this.updateCashStats(cashStats);
            this.updateBankStats(bankStats);
            this.updateCheckStats(checkStats);
            this.updateCollectionStats(collectionStats);
            this.updateCharts(cashFlowData, distributionData);
            this.renderUpcomingChecks(upcomingChecks);

            this.hideLoading();
        } catch (error) {
            this.hideLoading();
            this.showError('حدث خطأ أثناء تحميل البيانات');
            console.error('Dashboard loading error:', error);
        }
    }

    initializeCharts() {
        // تهيئة رسم التدفقات النقدية
        this.charts.initializeLineChart('cashFlowChart', {
            labels: [],
            datasets: [
                {
                    label: 'المقبوضات',
                    data: [],
                    borderColor: '#27ae60',
                    backgroundColor: 'rgba(39, 174, 96, 0.1)',
                    fill: true
                },
                {
                    label: 'المدفوعات',
                    data: [],
                    borderColor: '#e74c3c',
                    backgroundColor: 'rgba(231, 76, 60, 0.1)',
                    fill: true
                },
                {
                    label: 'صافي التدفق',
                    data: [],
                    borderColor: '#3498db',
                    backgroundColor: 'rgba(52, 152, 219, 0.1)',
                    fill: true
                }
            ],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => formatCurrency(value)
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: context => formatCurrency(context.parsed.y)
                        }
                    }
                }
            }
        });

        // تهيئة رسم توزيع المدفوعات والمقبوضات
        this.charts.initializeDoughnutChart('distributionChart', {
            labels: [],
            datasets: [{
                data: [],
                backgroundColor: [
                    '#2ecc71',
                    '#3498db',
                    '#f1c40f',
                    '#e67e22',
                    '#e74c3c',
                    '#9b59b6',
                    '#34495e',
                    '#16a085',
                    '#2980b9',
                    '#8e44ad'
                ]
            }],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right'
                    },
                    tooltip: {
                        callbacks: {
                            label: context => 
                                `${context.label}: ${formatCurrency(context.parsed)}`
                        }
                    }
                }
            }
        });
    }

    updateCashStats(stats) {
        this.dashboardElements.cashBalance.textContent = 
            formatCurrency(stats.balance);
        this.dashboardElements.cashReceipts.textContent = 
            formatCurrency(stats.receipts);
        this.dashboardElements.cashPayments.textContent = 
            formatCurrency(stats.payments);
    }

    updateBankStats(stats) {
        this.dashboardElements.totalBankBalance.textContent = 
            formatCurrency(stats.totalBalance);
        this.dashboardElements.incomingTransfers.textContent = 
            formatCurrency(stats.incomingTransfers);
        this.dashboardElements.outgoingTransfers.textContent = 
            formatCurrency(stats.outgoingTransfers);
    }

    updateCheckStats(stats) {
        this.dashboardElements.pendingChecksReceivable.textContent = 
            formatCurrency(stats.pendingReceivable);
        this.dashboardElements.pendingChecksPayable.textContent = 
            formatCurrency(stats.pendingPayable);
        this.dashboardElements.bouncedChecks.textContent = 
            formatCurrency(stats.bounced);
    }

    updateCollectionStats(stats) {
        this.dashboardElements.totalReceivables.textContent = 
            formatCurrency(stats.totalReceivables);
        this.dashboardElements.totalPayables.textContent = 
            formatCurrency(stats.totalPayables);
        this.dashboardElements.collectionRate.textContent = 
            `${stats.collectionRate.toFixed(1)}%`;
    }

    updateCharts(cashFlowData, distributionData) {
        // تحديث رسم التدفقات النقدية
        this.charts.updateLineChart('cashFlowChart', {
            labels: cashFlowData.labels,
            datasets: [
                {
                    data: cashFlowData.receipts,
                    label: 'المقبوضات'
                },
                {
                    data: cashFlowData.payments,
                    label: 'المدفوعات'
                },
                {
                    data: cashFlowData.netFlow,
                    label: 'صافي التدفق'
                }
            ]
        });

        // تحديث رسم توزيع المدفوعات والمقبوضات
        this.charts.updateDoughnutChart('distributionChart', {
            labels: distributionData.labels,
            data: distributionData.values
        });
    }

    renderUpcomingChecks(checks) {
        const tbody = this.dashboardElements.upcomingChecksTable;
        tbody.innerHTML = '';

        checks.forEach(check => {
            const tr = this.createCheckRow(check);
            tbody.appendChild(tr);
        });
    }

    createCheckRow(check) {
        const template = this.checkRowTemplate.content.cloneNode(true);
        const tr = template.querySelector('tr');
        
        tr.querySelector('.check-date').textContent = formatDate(check.date);
        tr.querySelector('.check-number').textContent = check.number;
        tr.querySelector('.check-type').textContent = this.translateCheckType(check.type);
        tr.querySelector('.party-name').textContent = check.partyName;
        tr.querySelector('.bank-name').textContent = check.bankName;
        tr.querySelector('.amount').textContent = formatCurrency(check.amount);
        
        const statusCell = tr.querySelector('.check-status');
        statusCell.textContent = this.translateCheckStatus(check.status);
        statusCell.classList.add(check.status.toLowerCase());

        // إضافة مستمعات الأحداث للأزرار
        tr.querySelector('.view-check').addEventListener('click', 
            () => this.viewCheck(check.id));
        
        const collectButton = tr.querySelector('.collect-check');
        const bounceButton = tr.querySelector('.bounce-check');
        
        if (check.status === 'pending') {
            collectButton.addEventListener('click', 
                () => this.collectCheck(check.id));
            bounceButton.addEventListener('click', 
                () => this.bounceCheck(check.id));
        } else {
            collectButton.style.display = 'none';
            bounceButton.style.display = 'none';
        }

        return tr;
    }

    attachEventListeners() {
        // مستمعات أحداث الإجراءات السريعة
        document.getElementById('createReceipt')?.addEventListener('click', 
            () => this.showReceiptModal());
        document.getElementById('createPayment')?.addEventListener('click', 
            () => this.showPaymentModal());
        document.getElementById('bankTransfer')?.addEventListener('click', 
            () => this.showBankTransferModal());
        document.getElementById('cashTransfer')?.addEventListener('click', 
            () => this.showCashTransferModal());

        // مستمعات أحداث الفلترة
        this.filterElements.cashFlowPeriod.addEventListener('change', 
            () => this.loadCashFlowAnalysis());
        this.filterElements.distributionPeriod.addEventListener('change', 
            () => this.loadDistributionAnalysis());

        // مستمعات أحداث التصدير
        document.getElementById('exportCashFlowChart')?.addEventListener('click', 
            () => this.exportChart('cashFlowChart'));
        document.getElementById('exportDistributionChart')?.addEventListener('click', 
            () => this.exportChart('distributionChart'));

        // مستمعات أحداث عرض الكل
        document.getElementById('viewAllChecks')?.addEventListener('click', 
            () => this.navigateToChecks());
    }

    // توابع مساعدة
    translateCheckType(type) {
        const typeMap = {
            receivable: 'برسم التحصيل',
            payable: 'برسم الدفع'
        };
        return typeMap[type] || type;
    }

    translateCheckStatus(status) {
        const statusMap = {
            pending: 'معلق',
            collected: 'محصل',
            bounced: 'مرتجع',
            cancelled: 'ملغى'
        };
        return statusMap[status] || status;
    }

    updateDateTime() {
        document.getElementById('currentDateTime').textContent = 
            new Date().toISOString().slice(0, 19).replace('T', ' ');
    }

    showLoading() {
        const loader = document.createElement('div');
        loader.className = 'loading-overlay';
        loader.innerHTML = '<div class="loading-spinner"></div>';
        document.body.appendChild(loader);
    }

    hideLoading() {
        document.querySelector('.loading-overlay')?.remove();
    }

    showError(message) {
        console.error(message);
        // يمكن تحسين هذه الدالة لعرض رسائل خطأ أكثر جاذبية
        alert(message);
    }

    showSuccess(message) {
        // يمكن تحسين هذه الدالة لعرض رسائل نجاح أكثر جاذبية
        alert(message);
    }
}

// تهيئة التطبيق عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    new Payments();
});