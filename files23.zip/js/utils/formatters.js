/**
 * وحدة تنسيق البيانات للضرائب والزكاة
 * @module formatters
 * التاريخ: 2025-05-09 02:27:44
 * المستخدم: mostafamohammad7760
 */

/**
 * تنسيق المبالغ المالية
 * @param {number} amount - المبلغ المراد تنسيقه
 * @param {string} currency - رمز العملة (الافتراضي: ريال)
 * @param {string} locale - اللغة والمنطقة (الافتراضي: ar-SA)
 * @returns {string} المبلغ منسقاً
 */
export function formatCurrency(amount, currency = 'SAR', locale = 'ar-SA') {
    try {
        return new Intl.NumberFormat(locale, {
            style: 'currency',
            currency: currency,
            maximumFractionDigits: 2,
            minimumFractionDigits: 2
        }).format(amount);
    } catch (error) {
        console.error('Currency formatting error:', error);
        return `${amount.toFixed(2)} ${currency}`;
    }
}

/**
 * تنسيق النسب المئوية
 * @param {number} value - القيمة المراد تنسيقها
 * @param {number} decimals - عدد المنازل العشرية
 * @param {string} locale - اللغة والمنطقة
 * @returns {string} النسبة المئوية منسقة
 */
export function formatPercentage(value, decimals = 2, locale = 'ar-SA') {
    try {
        return new Intl.NumberFormat(locale, {
            style: 'percent',
            minimumFractionDigits: decimals,
            maximumFractionDigits: decimals
        }).format(value / 100);
    } catch (error) {
        console.error('Percentage formatting error:', error);
        return `${value.toFixed(decimals)}%`;
    }
}

/**
 * تنسيق التواريخ
 * @param {string|Date} date - التاريخ المراد تنسيقه
 * @param {string} format - نمط التنسيق المطلوب
 * @param {string} locale - اللغة والمنطقة
 * @returns {string} التاريخ منسقاً
 */
export function formatDate(date, format = 'full', locale = 'ar-SA') {
    try {
        const dateObj = date instanceof Date ? date : new Date(date);
        
        const options = {
            full: {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            },
            short: {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            },
            monthYear: {
                year: 'numeric',
                month: 'long'
            },
            yearOnly: {
                year: 'numeric'
            }
        };

        return new Intl.DateTimeFormat(locale, options[format] || options.full)
            .format(dateObj);
    } catch (error) {
        console.error('Date formatting error:', error);
        return date.toString();
    }
}

/**
 * تنسيق الفترات الزمنية
 * @param {Date} startDate - تاريخ البداية
 * @param {Date} endDate - تاريخ النهاية
 * @param {string} locale - اللغة والمنطقة
 * @returns {string} الفترة منسقة
 */
export function formatPeriod(startDate, endDate, locale = 'ar-SA') {
    try {
        const start = formatDate(startDate, 'short', locale);
        const end = formatDate(endDate, 'short', locale);
        return `${start} - ${end}`;
    } catch (error) {
        console.error('Period formatting error:', error);
        return `${startDate} - ${endDate}`;
    }
}

/**
 * تنسيق الأرقام
 * @param {number} number - الرقم المراد تنسيقه
 * @param {number} decimals - عدد المنازل العشرية
 * @param {string} locale - اللغة والمنطقة
 * @returns {string} الرقم منسقاً
 */
export function formatNumber(number, decimals = 0, locale = 'ar-SA') {
    try {
        return new Intl.NumberFormat(locale, {
            minimumFractionDigits: decimals,
            maximumFractionDigits: decimals
        }).format(number);
    } catch (error) {
        console.error('Number formatting error:', error);
        return number.toFixed(decimals);
    }
}

/**
 * تنسيق حالة الإقرار
 * @param {string} status - رمز الحالة
 * @returns {string} الحالة منسقة بالعربية
 */
export function formatStatus(status) {
    const statusMap = {
        'draft': 'مسودة',
        'submitted': 'مقدم',
        'approved': 'معتمد',
        'rejected': 'مرفوض',
        'amended': 'معدل',
        'canceled': 'ملغي',
        'overdue': 'متأخر',
        'pending': 'قيد المراجعة'
    };
    return statusMap[status] || status;
}

/**
 * تنسيق نوع الضريبة
 * @param {string} type - رمز نوع الضريبة
 * @returns {string} نوع الضريبة منسقاً بالعربية
 */
export function formatTaxType(type) {
    const typeMap = {
        'vat': 'ضريبة القيمة المضافة',
        'income': 'ضريبة الدخل',
        'withholding': 'ضريبة الاستقطاع',
        'zakat': 'الزكاة',
        'other': 'ضرائب أخرى'
    };
    return typeMap[type] || type;
}

/**
 * تنسيق الفروقات والتغييرات
 * @param {number} oldValue - القيمة القديمة
 * @param {number} newValue - القيمة الجديدة
 * @param {string} format - نوع التنسيق (currency, percentage, number)
 * @returns {string} الفرق منسقاً
 */
export function formatDifference(oldValue, newValue, format = 'number') {
    try {
        const difference = newValue - oldValue;
        const percentage = ((difference / Math.abs(oldValue)) * 100) || 0;
        
        const formattedDiff = format === 'currency' ? 
            formatCurrency(difference) : 
            format === 'percentage' ? 
                formatPercentage(difference) : 
                formatNumber(difference);

        const arrow = difference > 0 ? '↑' : difference < 0 ? '↓' : '→';
        const color = difference > 0 ? 'success' : difference < 0 ? 'danger' : 'neutral';
        
        return {
            value: formattedDiff,
            percentage: formatPercentage(percentage),
            arrow,
            color
        };
    } catch (error) {
        console.error('Difference formatting error:', error);
        return {
            value: '0',
            percentage: '0%',
            arrow: '→',
            color: 'neutral'
        };
    }
}

/**
 * تنسيق حجم الملف
 * @param {number} bytes - حجم الملف بالبايت
 * @returns {string} الحجم منسقاً
 */
export function formatFileSize(bytes) {
    if (bytes === 0) return '0 بايت';
    
    const k = 1024;
    const sizes = ['بايت', 'كيلوبايت', 'ميجابايت', 'جيجابايت'];
    
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
}