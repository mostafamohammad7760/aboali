/**
 * خدمة الحسابات والقيود المحاسبية
 * التاريخ: 2025-05-09 04:22:38
 * المستخدم: mostafamohammad7760
 */

import { Transaction } from 'sequelize';
import { JournalEntry, JournalItem, ChartAccount } from '../models';
import { AccountingError } from '../utils/errors';

interface JournalEntryItem {
  accountId: number;
  debit: number;
  credit: number;
  description?: string;
}

interface JournalEntryData {
  date: Date;
  referenceType?: string;
  referenceId?: number;
  items: JournalEntryItem[];
  notes?: string;
  transaction?: Transaction;
}

export class AccountingService {
  /**
   * إنشاء قيد محاسبي
   */
  public async createJournalEntry(data: JournalEntryData): Promise<JournalEntry> {
    const t = data.transaction || await JournalEntry.sequelize!.transaction();

    try {
      // التحقق من توازن القيد
      this.validateJournalBalance(data.items);

      // إنشاء رقم القيد
      const entryNumber = await this.generateJournalNumber();

      // إنشاء القيد
      const journalEntry = await JournalEntry.create({
        number: entryNumber,
        date: data.date,
        referenceType: data.referenceType,
        referenceId: data.referenceId,
        notes: data.notes,
        status: 'draft'
      }, { transaction: t });

      // إنشاء تفاصيل القيد
      for (const item of data.items) {
        await JournalItem.create({
          entryId: journalEntry.id,
          accountId: item.accountId,
          debit: item.debit,
          credit: item.credit,
          description: item.description
        }, { transaction: t });

        // تحديث رصيد الحساب
        await this.updateAccountBalance({
          accountId: item.accountId,
          debit: item.debit,
          credit: item.credit,
          transaction: t
        });
      }

      if (!data.transaction) {
        await t.commit();
      }

      return journalEntry;

    } catch (error) {
      if (!data.transaction) {
        await t.rollback();
      }
      throw error;
    }
  }

  /**
   * ترحيل القيد المحاسبي
   */
  public async postJournalEntry(id: number): Promise<void> {
    const t = await JournalEntry.sequelize!.transaction();

    try {
      const entry = await JournalEntry.findByPk(id, {
        include: [{ model: JournalItem }],
        transaction: t
      });

      if (!entry) {
        throw new AccountingError('القيد غير موجود');
      }

      if (entry.status === 'posted') {
        throw new AccountingError('القيد مرحل مسبقاً');
      }

      // التحقق من توازن القيد
      this.validateJournalBalance(entry.items);

      // تحديث حالة القيد
      await entry.update({
        status: 'posted',
        postedAt: new Date()
      }, { transaction: t });

      await t.commit();

    } catch (error) {
      await t.rollback();
      throw error;
    }
  }

  /**
   * إلغاء قيد محاسبي
   */
  public async reverseJournalEntry(id: number, date: Date): Promise<JournalEntry> {
    const t = await JournalEntry.sequelize!.transaction();

    try {
      const originalEntry = await JournalEntry.findByPk(id, {
        include: [{ model: JournalItem }],
        transaction: t
      });

      if (!originalEntry) {
        throw new AccountingError('القيد غير موجود');
      }

      if (originalEntry.status !== 'posted') {
        throw new AccountingError('لا يمكن إلغاء قيد غير مرحل');
      }

      // إنشاء قيد عكسي
      const reversalItems = originalEntry.items.map(item => ({
        accountId: item.accountId,
        debit: item.credit,
        credit: item.debit,
        description: `إلغاء القيد ${originalEntry.number}`
      }));

      const reversalEntry = await this.createJournalEntry({
        date,
        referenceType: 'reversal',
        referenceId: originalEntry.id,
        items: reversalItems,
        notes: `إلغاء القيد ${originalEntry.number}`,
        transaction: t
      });

      await t.commit();

      return reversalEntry;

    } catch (error) {
      await t.rollback();
      throw error;
    }
  }

  /**
   * تحديث رصيد الحساب
   */
  private async updateAccountBalance(data: {
    accountId: number;
    debit: number;
    credit: number;
    transaction: Transaction;
  }): Promise<void> {
    const account = await ChartAccount.findByPk(data.accountId, {
      transaction: data.transaction
    });

    if (!account) {
      throw new AccountingError('الحساب غير موجود');
    }

    // حساب الرصيد الجديد حسب نوع الحساب
    let newBalance = account.balance;

    switch (account.type) {
      case 'asset':
      case 'expense':
        newBalance += (data.debit - data.credit);
        break;
      case 'liability':
      case 'equity':
      case 'revenue':
        newBalance += (data.credit - data.debit);
        break;
    }

    await account.update({ balance: newBalance }, {
      transaction: data.transaction
    });
  }

  /**
   * التحقق من توازن القيد
   */
  private validateJournalBalance(items: JournalEntryItem[]): void {
    const totalDebit = items.reduce((sum, item) => sum + item.debit, 0);
    const totalCredit = items.reduce((sum, item) => sum + item.credit, 0);

    if (totalDebit !== totalCredit) {
      throw new AccountingError('القيد غير متوازن');
    }
  }

  /**
   * توليد رقم قيد جديد
   */
  private async generateJournalNumber(): Promise<string> {
    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    
    const lastEntry = await JournalEntry.findOne({
      where: {
        number: {
          [Op.like]: `JE${year}${month}%`
        }
      },
      order: [['number', 'DESC']]
    });

    const sequence = lastEntry
      ? parseInt(lastEntry.number.slice(-4)) + 1
      : 1;

    return `JE${year}${month}${String(sequence).padStart(4, '0')}`;
  }

  /**
   * استخراج ميزان المراجعة
   */
  public async getTrialBalance(date: Date): Promise<any> {
    const accounts = await ChartAccount.findAll({
      where: { active: true },
      order: [['code', 'ASC']]
    });

    const trialBalance = {
      accounts: [],
      totalDebit: 0,
      totalCredit: 0
    };

    for (const account of accounts) {
      const balance = await this.getAccountBalance(account.id, date);
      
      trialBalance.accounts.push({
        code: account.code,
        name: account.name,
        type: account.type,
        debit: balance > 0 ? Math.abs(balance) : 0,
        credit: balance < 0 ? Math.abs(balance) : 0
      });

      if (balance > 0) {
        trialBalance.totalDebit += Math.abs(balance);
      } else {
        trialBalance.totalCredit += Math.abs(balance);
      }
    }

    return trialBalance;
  }

  /**
   * استخراج رصيد حساب في تاريخ محدد
   */
  private async getAccountBalance(accountId: number, date: Date): Promise<number> {
    const result = await JournalItem.findAll({
      include: [{
        model: JournalEntry,
        where: {
          date: {
            [Op.lte]: date
          },
          status: 'posted'
        }
      }],
      where: {
        accountId
      }
    });

    return result.reduce((balance, item) => 
      balance + (item.debit - item.credit), 0);
  }
}