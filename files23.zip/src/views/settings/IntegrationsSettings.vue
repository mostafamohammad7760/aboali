/**
 * واجهة إدارة التكاملات
 * التاريخ: 2025-05-09 04:31:52
 * المستخدم: mostafamohammad7760
 */

<template>
  <div class="integrations-settings">
    <PageHeader
      title="إعدادات التكامل"
      subtitle="إدارة التكامل مع الأنظمة المحاسبية الخارجية"
    >
      <template #actions>
        <BaseButton
          variant="primary"
          icon="fa-plus"
          @click="showAddDialog = true"
        >
          إضافة تكامل جديد
        </BaseButton>
      </template>
    </PageHeader>

    <!-- قائمة التكاملات -->
    <div class="integrations-list">
      <div
        v-for="integration in integrations"
        :key="integration.code"
        class="integration-card"
      >
        <div class="card-header">
          <div class="system-info">
            <img
              :src="getSystemLogo(integration.system)"
              :alt="integration.system"
              class="system-logo"
            />
            <div class="system-details">
              <h3>{{ integration.name }}</h3>
              <span class="system-type">{{ getSystemLabel(integration.system) }}</span>
            </div>
          </div>
          <div class="status-badge" :class="integration.active ? 'active' : 'inactive'">
            {{ integration.active ? 'نشط' : 'غير نشط' }}
          </div>
        </div>

        <div class="card-content">
          <div class="config-details">
            <div class="config-item">
              <label>نوع الاتصال:</label>
              <span>{{ integration.config.format === 'json' ? 'JSON API' : 'XML API' }}</span>
            </div>
            <div class="config-item">
              <label>الرابط:</label>
              <span>{{ integration.config.endpoint }}</span>
            </div>
            <div class="config-item">
              <label>طريقة المصادقة:</label>
              <span>{{ integration.config.apiKey ? 'API Key' : 'Basic Auth' }}</span>
            </div>
          </div>

          <div class="last-sync" v-if="integration.lastSync">
            <i class="fas fa-sync"></i>
            <span>آخر مزامنة: {{ formatDateTime(integration.lastSync) }}</span>
          </div>
        </div>

        <div class="card-actions">
          <BaseButton
            variant="light"
            size="sm"
            icon="fa-cog"
            @click="editIntegration(integration)"
          >
            تعديل
          </BaseButton>
          <BaseButton
            variant="light"
            size="sm"
            icon="fa-sync"
            :loading="syncLoading[integration.code]"
            @click="syncIntegration(integration)"
          >
            مزامنة
          </BaseButton>
          <BaseButton
            variant="danger"
            size="sm"
            icon="fa-trash"
            @click="confirmDelete(integration)"
          >
            حذف
          </BaseButton>
        </div>
      </div>
    </div>

    <!-- نافذة إضافة/تعديل تكامل -->
    <BaseDialog
      :show="showAddDialog || !!editingIntegration"
      :title="editingIntegration ? 'تعديل تكامل' : 'إضافة تكامل جديد'"
      size="lg"
      @close="closeDialog"
    >
      <form @submit.prevent="saveIntegration" class="integration-form">
        <!-- معلومات أساسية -->
        <div class="form-section">
          <h4>معلومات أساسية</h4>
          <div class="form-grid">
            <BaseInput
              v-model="formData.name"
              label="اسم التكامل"
              required
            />
            <BaseInput
              v-model="formData.code"
              label="رمز التكامل"
              :disabled="!!editingIntegration"
              required
            />
            <BaseSelect
              v-model="formData.system"
              label="النظام"
              :options="systemOptions"
              required
            />
            <BaseSelect
              v-model="formData.config.format"
              label="تنسيق البيانات"
              :options="formatOptions"
              required
            />
          </div>
        </div>

        <!-- إعدادات الاتصال -->
        <div class="form-section">
          <h4>إعدادات الاتصال</h4>
          <div class="form-grid">
            <BaseInput
              v-model="formData.config.endpoint"
              label="رابط API"
              type="url"
              required
            />
            <BaseSelect
              v-model="formData.config.authType"
              label="طريقة المصادقة"
              :options="authOptions"
              required
            />
            
            <template v-if="formData.config.authType === 'apiKey'">
              <BaseInput
                v-model="formData.config.apiKey"
                label="API Key"
                type="password"
                required
              />
            </template>
            
            <template v-else>
              <BaseInput
                v-model="formData.config.username"
                label="اسم المستخدم"
                required
              />
              <BaseInput
                v-model="formData.config.password"
                label="كلمة المرور"
                type="password"
                required
              />
            </template>
          </div>
        </div>

        <!-- إعدادات متقدمة -->
        <div class="form-section">
          <h4>إعدادات متقدمة</h4>
          <div class="form-grid">
            <BaseInput
              v-model="formData.config.options.companyCode"
              label="رمز الشركة"
            />
            <BaseInput
              v-model="formData.config.options.currency"
              label="العملة الافتراضية"
              placeholder="SAR"
            />
            <BaseSelect
              v-model="formData.config.options.syncInterval"
              label="فترة المزامنة"
              :options="syncIntervalOptions"
            />
          </div>
        </div>

        <!-- خيارات التصدير -->
        <div class="form-section">
          <h4>خيارات التصدير</h4>
          <div class="export-options">
            <BaseCheckbox
              v-model="formData.config.exports.journalEntries"
              label="تصدير القيود المحاسبية"
            />
            <BaseCheckbox
              v-model="formData.config.exports.chartOfAccounts"
              label="تصدير شجرة الحسابات"
            />
            <BaseCheckbox
              v-model="formData.config.exports.financialStatements"
              label="تصدير التقارير المالية"
            />
          </div>
        </div>

        <div class="form-actions">
          <BaseButton
            variant="secondary"
            @click="closeDialog"
          >
            إلغاء
          </BaseButton>
          <BaseButton
            type="submit"
            variant="primary"
            :loading="saving"
          >
            حفظ
          </BaseButton>
        </div>
      </form>
    </BaseDialog>

    <!-- نافذة تأكيد الحذف -->
    <BaseDialog
      v-if="deletingIntegration"
      title="تأكيد الحذف"
      @close="deletingIntegration = null"
    >
      <p>
        هل أنت متأكد من حذف التكامل مع "{{ deletingIntegration.name }}"؟
        <br>
        هذا الإجراء لا يمكن التراجع عنه.
      </p>
      <template #footer>
        <BaseButton
          variant="secondary"
          @click="deletingIntegration = null"
        >
          إلغاء
        </BaseButton>
        <BaseButton
          variant="danger"
          :loading="deleting"
          @click="deleteIntegration"
        >
          تأكيد الحذف
        </BaseButton>
      </template>
    </BaseDialog>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, computed } from 'vue';
import { useToast } from '@/composables/useToast';
import { formatDateTime } from '@/utils/datetime';
import { IntegrationService } from '@/services/IntegrationService';

export default defineComponent({
  name: 'IntegrationsSettings',

  setup() {
    const toast = useToast();
    const integrationService = new IntegrationService();

    // حالة القائمة
    const integrations = ref<any[]>([]);
    const loading = ref(false);
    const syncLoading = ref<Record<string, boolean>>({});

    // حالة النموذج
    const showAddDialog = ref(false);
    const editingIntegration = ref<any>(null);
    const saving = ref(false);
    const formData = ref(getDefaultFormData());

    // حالة الحذف
    const deletingIntegration = ref<any>(null);
    const deleting = ref(false);

    // الخيارات
    const systemOptions = [
      { value: 'sage', label: 'Sage' },
      { value: 'quickbooks', label: 'QuickBooks' },
      { value: 'sap', label: 'SAP' },
      { value: 'excel', label: 'Excel' },
      { value: 'custom', label: 'نظام مخصص' }
    ];

    const formatOptions = [
      { value: 'json', label: 'JSON' },
      { value: 'xml', label: 'XML' }
    ];

    const authOptions = [
      { value: 'apiKey', label: 'API Key' },
      { value: 'basic', label: 'Basic Auth' }
    ];

    const syncIntervalOptions = [
      { value: 'realtime', label: 'مباشر' },
      { value: 'hourly', label: 'كل ساعة' },
      { value: 'daily', label: 'يومياً' },
      { value: 'manual', label: 'يدوي' }
    ];

    // تحميل البيانات
    const loadIntegrations = async () => {
      loading.value = true;
      try {
        integrations.value = await integrationService.getAll();
      } catch (error) {
        toast.error('حدث خطأ في تحميل التكاملات');
      } finally {
        loading.value = false;
      }
    };

    // حفظ التكامل
    const saveIntegration = async () => {
      saving.value = true;
      try {
        if (editingIntegration.value) {
          await integrationService.update(
            editingIntegration.value.id,
            formData.value
          );
          toast.success('تم تحديث التكامل بنجاح');
        } else {
          await integrationService.create(formData.value);
          toast.success('تم إضافة التكامل بنجاح');
        }
        
        await loadIntegrations();
        closeDialog();

      } catch (error) {
        toast.error('حدث خطأ في حفظ التكامل');
      } finally {
        saving.value = false;
      }
    };

    // حذف التكامل
    const deleteIntegration = async () => {
      if (!deletingIntegration.value) return;

      deleting.value = true;
      try {
        await integrationService.delete(deletingIntegration.value.id);
        await loadIntegrations();
        toast.success('تم حذف التكامل بنجاح');
        deletingIntegration.value = null;

      } catch (error) {
        toast.error('حدث خطأ في حذف التكامل');
      } finally {
        deleting.value = false;
      }
    };

    // مزامنة التكامل
    const syncIntegration = async (integration: any) => {
      syncLoading.value[integration.code] = true;
      try {
        await integrationService.sync(integration.id);
        toast.success('تمت المزامنة بنجاح');
        await loadIntegrations();

      } catch (error) {
        toast.error('حدث خطأ في المزامنة');
      } finally {
        syncLoading.value[integration.code] = false;
      }
    };

    // وظائف مساعدة
    const getSystemLogo = (system: string) => {
      return `/images/integrations/${system}.png`;
    };

    const getSystemLabel = (system: string) => {
      return systemOptions.find(opt => opt.value === system)?.label || system;
    };

    const getDefaultFormData = () => ({
      name: '',
      code: '',
      system: '',
      config: {
        format: 'json',
        authType: 'apiKey',
        endpoint: '',
        apiKey: '',
        username: '',
        password: '',
        options: {
          companyCode: '',
          currency: 'SAR',
          syncInterval: 'daily'
        },
        exports: {
          journalEntries: true,
          chartOfAccounts: true,
          financialStatements: true
        }
      }
    });

    const editIntegration = (integration: any) => {
      editingIntegration.value = integration;
      formData.value = { ...integration };
    };

    const closeDialog = () => {
      showAddDialog.value = false;
      editingIntegration.value = null;
      formData.value = getDefaultFormData();
    };

    // تحميل البيانات الأولية
    loadIntegrations();

    return {
      // الحالة
      integrations,
      loading,
      syncLoading,
      showAddDialog,
      editingIntegration,
      saving,
      formData,
      deletingIntegration,
      deleting,

      // الخيارات
      systemOptions,
      formatOptions,
      authOptions,
      syncIntervalOptions,

      // الوظائف
      saveIntegration,
      deleteIntegration,
      syncIntegration,
      editIntegration,
      closeDialog,
      confirmDelete: (integration: any) => {
        deletingIntegration.value = integration;
      },
      getSystemLogo,
      getSystemLabel,
      formatDateTime
    };
  }
});
</script>

<style lang="scss" scoped>
.integrations-settings {
  padding: 2rem;

  .integrations-list {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(400px, 1fr));
    gap: 1.5rem;
    margin-top: 2rem;
  }

  .integration-card {
    background: var(--bg-primary);
    border: 1px solid var(--border-color);
    border-radius: var(--border-radius);
    overflow: hidden;

    .card-header {
      padding: 1rem;
      border-bottom: 1px solid var(--border-color);
      display: flex;
      justify-content: space-between;
      align-items: center;

      .system-info {
        display: flex;
        align-items: center;
        gap: 1rem;

        .system-logo {
          width: 40px;
          height: 40px;
          object-fit: contain;
        }

        .system-details {
          h3 {
            margin: 0;
            font-size: 1.125rem;
          }

          .system-type {
            font-size: 0.875rem;
            color: var(--text-secondary);
          }
        }
      }

      .status-badge {
        padding: 0.25rem 0.75rem;
        border-radius: 1rem;
        font-size: 0.875rem;

        &.active {
          background: var(--success-light);
          color: var(--success-dark);
        }

        &.inactive {
          background: var(--danger-light);
          color: var(--danger-dark);
        }
      }
    }

    .card-content {
      padding: 1rem;

      .config-details {
        display: grid;
        gap: 0.5rem;

        .config-item {
          display: flex;
          gap: 0.5rem;

          label {
            color: var(--text-secondary);
            min-width: 120px;
          }

          span {
            word-break: break-all;
          }
        }
      }

      .last-sync {
        margin-top: 1rem;
        font-size: 0.875rem;
        color: var(--text-secondary);
        display: flex;
        align-items: center;
        gap: 0.5rem;
      }
    }

    .card-actions {
      padding: 1rem;
      border-top: 1px solid var(--border-color);
      display: flex;
      gap: 0.5rem;
      justify-content: flex-end;
    }
  }

  .integration-form {
    .form-section {
      margin-bottom: 2rem;

      h4 {
        margin-bottom: 1rem;
        color: var(--text-secondary);
      }

      .form-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 1rem;
      }

      .export-options {
        display: grid;
        gap: 0.5rem;
      }
    }

    .form-actions {
      display: flex;
      justify-content: flex-end;
      gap: 1rem;
      margin-top: 2rem;
    }
  }
}
</style>