import { AccountsPayableAPI } from './api.js';
import { ChartManager } from './chart_manager.js';

class AccountsPayable {
    constructor() {
        this.api = new AccountsPayableAPI();
        this.charts = new ChartManager();
        this.currentUser = 'mostafamohammad7760';
        
        this.initializeComponents();
        this.attachEventListeners();
        this.loadDashboardData();
        
        // تحديث الوقت كل ثانية
        this.updateDateTime();
        setInterval(() => this.updateDateTime(), 1000);
    }

    initializeComponents() {
        // عناصر لوحة المعلومات
        this.dashboardElements = {
            totalPayables: document.getElementById('totalPayables'),
            totalInvoices: document.getElementById('totalInvoices'),
            overduePayables: document.getElementById('overduePayables'),
            overdueInvoices: document.getElementById('overdueInvoices'),
            monthlyPayments: document.getElementById('monthlyPayments'),
            monthlyPaymentCount: document.getElementById('monthlyPaymentCount'),
            activeVendors: document.getElementById('activeVendors'),
            totalVendors: document.getElementById('totalVendors'),
            upcomingPaymentsTable: document.getElementById('upcomingPaymentsTable')
        };

        // تهيئة الرسوم البيانية
        this.initializeCharts();
    }

    attachEventListeners() {
        // مستمعات التنقل
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', (e) => this.handleNavigation(e));
        });

        // مستمعات النوافذ المنبثقة
        document.getElementById('vendorModal')?.addEventListener('submit', 
            (e) => this.handleVendorSubmit(e));
    }

    async loadDashboardData() {
        try {
            this.showLoading();

            const [
                summary,
                upcomingPayments,
                agingData,
                paymentsHistory
            ] = await Promise.all([
                this.api.getDashboardSummary(),
                this.api.getUpcomingPayments(),
                this.api.getAgingSummary(),
                this.api.getPaymentsHistory()
            ]);

            this.updateDashboardSummary(summary);
            this.renderUpcomingPayments(upcomingPayments);
            this.updateCharts(agingData, paymentsHistory);

            this.hideLoading();
        } catch (error) {
            this.hideLoading();
            this.showError('حدث خطأ أثناء تحميل البيانات');
            console.error(error);
        }
    }

    updateDashboardSummary(summary) {
        // تحديث الإحصائيات
        this.dashboardElements.totalPayables.textContent = 
            this.formatCurrency(summary.totalPayables);
        this.dashboardElements.totalInvoices.textContent = 
            summary.totalInvoices;
        this.dashboardElements.overduePayables.textContent = 
            this.formatCurrency(summary.overduePayables);
        this.dashboardElements.overdueInvoices.textContent = 
            summary.overdueInvoices;
        this.dashboardElements.monthlyPayments.textContent = 
            this.formatCurrency(summary.monthlyPayments);
        this.dashboardElements.monthlyPaymentCount.textContent = 
            summary.monthlyPaymentCount;
        this.dashboardElements.activeVendors.textContent = 
            summary.activeVendors;
        this.dashboardElements.totalVendors.textContent = 
            summary.totalVendors;
    }

    renderUpcomingPayments(payments) {
        const tbody = this.dashboardElements.upcomingPaymentsTable;
        tbody.innerHTML = '';

        payments.forEach(payment => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${payment.invoiceNumber}</td>
                <td>${payment.vendorName}</td>
                <td>${this.formatDate(payment.dueDate)}</td>
                <td>${this.formatCurrency(payment.amount)}</td>
                <td>
                    <span class="status-badge ${payment.status}">
                        ${this.translateStatus(payment.status)}
                    </span>
                </td>
            `;
            tbody.appendChild(tr);
        });
    }

    initializeCharts() {
        // تهيئة رسم تعمير الذمم
        this.charts.initializeAgingChart('agingChart', {
            labels: ['حالي', '30 يوم', '60 يوم', '90 يوم', '120 يوم', 'أكثر من 120'],
            datasets: [{
                data: [0, 0, 0, 0, 0, 0],
                backgroundColor: [
                    '#2ecc71',
                    '#3498db',
                    '#f1c40f',
                    '#e67e22',
                    '#e74c3c',
                    '#95a5a6'
                ]
            }]
        });

        // تهيئة رسم المدفوعات الشهرية
        this.charts.initializePaymentsChart('paymentsChart', {
            labels: [],
            datasets: [{
                label: 'المدفوعات',
                data: [],
                borderColor: '#2c4d76',
                fill: false
            }]
        });
    }

    updateCharts(agingData, paymentsHistory) {
        // تحديث رسم تعمير الذمم
        this.charts.updateAgingChart('agingChart', {
            data: [
                agingData.current,
                agingData.days30,
                agingData.days60,
                agingData.days90,
                agingData.days120,
                agingData.daysOver120
            ]
        });

        // تحديث رسم المدفوعات
        this.charts.updatePaymentsChart('paymentsChart', {
            labels: paymentsHistory.map(item => item.month),
            data: paymentsHistory.map(item => item.amount)
        });
    }

    handleNavigation(event) {
        event.preventDefault();
        const targetId = event.target.getAttribute('href').substring(1);
        
        // إخفاء جميع الأقسام
        document.querySelectorAll('main > section').forEach(section => {
            section.classList.add('hidden');
        });
        
        // إظهار القسم المطلوب
        document.getElementById(targetId)?.classList.remove('hidden');
        
        // تحديث القائمة النشطة
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.classList.remove('active');
        });
        event.target.classList.add('active');
    }

    // توابع مساعدة
    formatCurrency(amount) {
        return new Intl.NumberFormat('ar-SA', {
            style: 'currency',
            currency: 'SAR'
        }).format(amount);
    }

    formatDate(date) {
        return new Intl.DateTimeFormat('ar-SA', {
            year: 'numeric',
            month: 'numeric',
            day: 'numeric'
        }).format(new Date(date));
    }

    translateStatus(status) {
        const statusMap = {
            unpaid: 'غير مدفوع',
            'partially_paid': 'مدفوع جزئياً',
            paid: 'مدفوع',
            overdue: 'متأخر'
        };
        return statusMap[status] || status;
    }

    updateDateTime() {
        const now = new Date();
        document.getElementById('currentDateTime').textContent = 
            now.toISOString().replace('T', ' ').slice(0, 19);
    }

    showLoading() {
        const loader = document.createElement('div');
        loader.className = 'loading-overlay';
        loader.innerHTML = '<div class="loading-spinner"></div>';
        document.body.appendChild(loader);
    }

    hideLoading() {
        const loader = document.querySelector('.loading-overlay');
        if (loader) {
            loader.remove();
        }
    }

    showError(message) {
        // يمكن تحسين هذه الدالة لعرض رسائل خطأ أكثر جاذبية
        alert(message);
    }

    showSuccess(message) {
        // يمكن تحسين هذه الدالة لعرض رسائل نجاح أكثر جاذبية
        alert(message);
    }
}

// تهيئة التطبيق عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    new AccountsPayable();
});