/**
 * خدمة المصادقة والأمان
 * @class AuthService
 */
export class AuthService {
    constructor() {
        this.baseUrl = '/api/v1/auth';
        this.currentUser = null;
        this.tokenKey = 'auth_token';
        this.refreshTokenKey = 'refresh_token';
        this.lastActivityKey = 'last_activity';
        this.sessionTimeout = 30 * 60 * 1000; // 30 دقيقة
    }

    /**
     * تسجيل الدخول
     * @param {string} username - اسم المستخدم
     * @param {string} password - كلمة المرور
     * @returns {Promise<Object>} بيانات المستخدم وتوكن المصادقة
     */
    async login(username, password) {
        try {
            const response = await fetch(`${this.baseUrl}/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    username,
                    password,
                    timestamp: new Date().toISOString()
                })
            });

            if (!response.ok) {
                throw await this.handleAuthError(response);
            }

            const data = await response.json();
            this.setTokens(data.token, data.refreshToken);
            this.currentUser = data.user;
            this.updateLastActivity();

            // تسجيل عملية تسجيل الدخول
            await this.logActivity('login', {
                username: username,
                timestamp: new Date().toISOString()
            });

            return data;
        } catch (error) {
            console.error('Login error:', error);
            throw error;
        }
    }

    /**
     * التحقق من صحة رمز المصادقة الثنائية
     * @param {string} code - رمز المصادقة
     * @returns {Promise<boolean>} نتيجة التحقق
     */
    async verify2FA(code) {
        try {
            const response = await fetch(`${this.baseUrl}/verify-2fa`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.getToken()}`
                },
                body: JSON.stringify({
                    code,
                    timestamp: new Date().toISOString()
                })
            });

            if (!response.ok) {
                throw await this.handleAuthError(response);
            }

            const data = await response.json();
            return data.verified;
        } catch (error) {
            console.error('2FA verification error:', error);
            throw error;
        }
    }

    /**
     * تسجيل الخروج
     * @returns {Promise<void>}
     */
    async logout() {
        try {
            await this.logActivity('logout', {
                userId: this.currentUser?.id,
                timestamp: new Date().toISOString()
            });

            await fetch(`${this.baseUrl}/logout`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.getToken()}`
                }
            });

            this.clearTokens();
            this.currentUser = null;
        } catch (error) {
            console.error('Logout error:', error);
            // نمسح التوكن حتى في حالة الخطأ
            this.clearTokens();
            this.currentUser = null;
            throw error;
        }
    }

    /**
     * تجديد التوكن
     * @returns {Promise<string>} التوكن الجديد
     */
    async refreshToken() {
        try {
            const refreshToken = this.getRefreshToken();
            if (!refreshToken) {
                throw new Error('No refresh token available');
            }

            const response = await fetch(`${this.baseUrl}/refresh-token`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    refreshToken,
                    timestamp: new Date().toISOString()
                })
            });

            if (!response.ok) {
                throw await this.handleAuthError(response);
            }

            const data = await response.json();
            this.setTokens(data.token, data.refreshToken);
            return data.token;
        } catch (error) {
            console.error('Token refresh error:', error);
            this.clearTokens();
            throw error;
        }
    }

    /**
     * تغيير كلمة المرور
     * @param {string} currentPassword - كلمة المرور الحالية
     * @param {string} newPassword - كلمة المرور الجديدة
     * @returns {Promise<void>}
     */
    async changePassword(currentPassword, newPassword) {
        try {
            this.validatePassword(newPassword);

            const response = await fetch(`${this.baseUrl}/change-password`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.getToken()}`
                },
                body: JSON.stringify({
                    currentPassword,
                    newPassword,
                    timestamp: new Date().toISOString()
                })
            });

            if (!response.ok) {
                throw await this.handleAuthError(response);
            }

            await this.logActivity('password_change', {
                userId: this.currentUser?.id,
                timestamp: new Date().toISOString()
            });
        } catch (error) {
            console.error('Password change error:', error);
            throw error;
        }
    }

    /**
     * التحقق من صلاحيات المستخدم
     * @param {string} permission - الصلاحية المطلوبة
     * @returns {boolean} نتيجة التحقق
     */
    hasPermission(permission) {
        if (!this.currentUser || !this.currentUser.permissions) {
            return false;
        }
        return this.currentUser.permissions.includes(permission);
    }

    /**
     * التحقق من صلاحية الجلسة
     * @returns {boolean} حالة الجلسة
     */
    isSessionValid() {
        const lastActivity = localStorage.getItem(this.lastActivityKey);
        if (!lastActivity) return false;

        const now = new Date().getTime();
        const lastActivityTime = parseInt(lastActivity);
        return (now - lastActivityTime) < this.sessionTimeout;
    }

    /**
     * تحديث وقت آخر نشاط
     */
    updateLastActivity() {
        localStorage.setItem(this.lastActivityKey, new Date().getTime().toString());
    }

    /**
     * التحقق من قوة كلمة المرور
     * @param {string} password - كلمة المرور
     * @throws {Error} خطأ في حالة عدم تحقق الشروط
     */
    validatePassword(password) {
        const minLength = 8;
        const hasUpperCase = /[A-Z]/.test(password);
        const hasLowerCase = /[a-z]/.test(password);
        const hasNumbers = /\d/.test(password);
        const hasSpecialChars = /[!@#$%^&*(),.?":{}|<>]/.test(password);

        if (password.length < minLength) {
            throw new Error('كلمة المرور يجب أن تكون 8 أحرف على الأقل');
        }

        if (!(hasUpperCase && hasLowerCase && hasNumbers && hasSpecialChars)) {
            throw new Error('كلمة المرور يجب أن تحتوي على أحرف كبيرة وصغيرة وأرقام ورموز خاصة');
        }
    }

    /**
     * تسجيل نشاط المستخدم
     * @param {string} action - نوع النشاط
     * @param {Object} details - تفاصيل النشاط
     * @private
     */
    async logActivity(action, details) {
        try {
            await fetch(`${this.baseUrl}/activity-log`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.getToken()}`
                },
                body: JSON.stringify({
                    action,
                    details,
                    timestamp: new Date().toISOString(),
                    userId: this.currentUser?.id
                })
            });
        } catch (error) {
            console.error('Activity logging error:', error);
        }
    }

    /**
     * معالجة أخطاء المصادقة
     * @param {Response} response - كائن الاستجابة
     * @private
     */
    async handleAuthError(response) {
        let error;
        try {
            const data = await response.json();
            error = new Error(data.message || 'حدث خطأ في المصادقة');
            error.code = data.code;
        } catch {
            error = new Error('حدث خطأ غير متوقع');
        }
        error.status = response.status;
        return error;
    }

    // طرق إدارة التوكن
    getToken() {
        return localStorage.getItem(this.tokenKey);
    }

    getRefreshToken() {
        return localStorage.getItem(this.refreshTokenKey);
    }

    setTokens(token, refreshToken) {
        localStorage.setItem(this.tokenKey, token);
        localStorage.setItem(this.refreshTokenKey, refreshToken);
    }

    clearTokens() {
        localStorage.removeItem(this.tokenKey);
        localStorage.removeItem(this.refreshTokenKey);
        localStorage.removeItem(this.lastActivityKey);
    }
}

// تصدير نسخة واحدة من الخدمة
export const authService = new AuthService();