-- إنشاء جداول التحليل المالي

-- جدول النسب المالية
CREATE TABLE financial_ratios (
    ratio_id VARCHAR(20) PRIMARY KEY,
    period_id VARCHAR(20) NOT NULL,
    ratio_type ENUM(
        'liquidity',      -- نسب السيولة
        'profitability',  -- نسب الربحية
        'activity',       -- نسب النشاط
        'leverage',       -- نسب الرفع المالي
        'market',         -- نسب السوق
        'growth',         -- نسب النمو
        'efficiency'      -- نسب الكفاءة
    ) NOT NULL,
    ratio_code VARCHAR(50) NOT NULL,
    ratio_name VARCHAR(200) NOT NULL,
    numerator_value DECIMAL(18,2) NOT NULL,
    denominator_value DECIMAL(18,2) NOT NULL,
    ratio_value DECIMAL(18,4) NOT NULL,
    industry_average DECIMAL(18,4),
    target_value DECIMAL(18,4),
    variance_value DECIMAL(18,4),
    variance_percentage DECIMAL(5,2),
    is_favorable BOOLEAN,
    analysis_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (period_id) REFERENCES financial_periods(period_id)
);

-- جدول التحليل الأفقي
CREATE TABLE horizontal_analysis (
    analysis_id VARCHAR(20) PRIMARY KEY,
    account_id VARCHAR(20) NOT NULL,
    base_period_id VARCHAR(20) NOT NULL,
    compare_period_id VARCHAR(20) NOT NULL,
    statement_type ENUM('balance_sheet', 'income_statement', 'cash_flow') NOT NULL,
    base_amount DECIMAL(18,2) NOT NULL,
    compare_amount DECIMAL(18,2) NOT NULL,
    absolute_change DECIMAL(18,2) NOT NULL,
    percentage_change DECIMAL(5,2) NOT NULL,
    is_favorable BOOLEAN,
    analysis_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (account_id) REFERENCES chart_of_accounts(account_id),
    FOREIGN KEY (base_period_id) REFERENCES financial_periods(period_id),
    FOREIGN KEY (compare_period_id) REFERENCES financial_periods(period_id)
);

-- جدول التحليل الرأسي
CREATE TABLE vertical_analysis (
    analysis_id VARCHAR(20) PRIMARY KEY,
    account_id VARCHAR(20) NOT NULL,
    period_id VARCHAR(20) NOT NULL,
    statement_type ENUM('balance_sheet', 'income_statement', 'cash_flow') NOT NULL,
    account_amount DECIMAL(18,2) NOT NULL,
    base_amount DECIMAL(18,2) NOT NULL,
    percentage DECIMAL(5,2) NOT NULL,
    industry_average DECIMAL(5,2),
    variance_percentage DECIMAL(5,2),
    is_favorable BOOLEAN,
    analysis_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (account_id) REFERENCES chart_of_accounts(account_id),
    FOREIGN KEY (period_id) REFERENCES financial_periods(period_id)
);

-- جدول تحليل الاتجاهات
CREATE TABLE trend_analysis (
    analysis_id VARCHAR(20) PRIMARY KEY,
    account_id VARCHAR(20) NOT NULL,
    base_period_id VARCHAR(20) NOT NULL,
    trend_period_id VARCHAR(20) NOT NULL,
    statement_type ENUM('balance_sheet', 'income_statement', 'cash_flow') NOT NULL,
    base_amount DECIMAL(18,2) NOT NULL,
    trend_amount DECIMAL(18,2) NOT NULL,
    trend_index DECIMAL(5,2) NOT NULL,
    trend_direction ENUM('increasing', 'decreasing', 'stable') NOT NULL,
    trend_strength ENUM('strong', 'moderate', 'weak') NOT NULL,
    analysis_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (account_id) REFERENCES chart_of_accounts(account_id),
    FOREIGN KEY (base_period_id) REFERENCES financial_periods(period_id),
    FOREIGN KEY (trend_period_id) REFERENCES financial_periods(period_id)
);

-- جدول نقاط التحليل
CREATE TABLE analysis_points (
    point_id VARCHAR(20) PRIMARY KEY,
    period_id VARCHAR(20) NOT NULL,
    analysis_type ENUM(
        'ratio',
        'horizontal',
        'vertical',
        'trend',
        'comparative'
    ) NOT NULL,
    category ENUM(
        'strength',
        'weakness',
        'opportunity',
        'threat'
    ) NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    impact_level ENUM('high', 'medium', 'low') NOT NULL,
    recommendations TEXT,
    status ENUM('identified', 'analyzing', 'actioning', 'monitored') DEFAULT 'identified',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (period_id) REFERENCES financial_periods(period_id)
);

-- جدول المعايير القطاعية
CREATE TABLE industry_standards (
    standard_id VARCHAR(20) PRIMARY KEY,
    industry_code VARCHAR(20) NOT NULL,
    ratio_code VARCHAR(50) NOT NULL,
    period_id VARCHAR(20) NOT NULL,
    lower_bound DECIMAL(18,4),
    upper_bound DECIMAL(18,4),
    average_value DECIMAL(18,4) NOT NULL,
    median_value DECIMAL(18,4),
    quartile_1 DECIMAL(18,4),
    quartile_3 DECIMAL(18,4),
    sample_size INT,
    effective_date DATE NOT NULL,
    end_date DATE,
    source VARCHAR(200),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (period_id) REFERENCES financial_periods(period_id)
);

-- جدول التحليل المقارن
CREATE TABLE comparative_analysis (
    analysis_id VARCHAR(20) PRIMARY KEY,
    company_id VARCHAR(20) NOT NULL,
    competitor_id VARCHAR(20) NOT NULL,
    period_id VARCHAR(20) NOT NULL,
    ratio_code VARCHAR(50) NOT NULL,
    company_value DECIMAL(18,4) NOT NULL,
    competitor_value DECIMAL(18,4) NOT NULL,
    absolute_difference DECIMAL(18,4) NOT NULL,
    percentage_difference DECIMAL(5,2) NOT NULL,
    is_favorable BOOLEAN,
    analysis_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (period_id) REFERENCES financial_periods(period_id)
);

-- جدول التنبؤات المالية
CREATE TABLE financial_forecasts (
    forecast_id VARCHAR(20) PRIMARY KEY,
    account_id VARCHAR(20) NOT NULL,
    period_id VARCHAR(20) NOT NULL,
    statement_type ENUM('balance_sheet', 'income_statement', 'cash_flow') NOT NULL,
    forecast_method ENUM('trend', 'regression', 'moving_average', 'manual') NOT NULL,
    historical_value DECIMAL(18,2) NOT NULL,
    forecasted_value DECIMAL(18,2) NOT NULL,
    confidence_level DECIMAL(5,2),
    variance_range DECIMAL(5,2),
    assumptions TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (account_id) REFERENCES chart_of_accounts(account_id),
    FOREIGN KEY (period_id) REFERENCES financial_periods(period_id)
);

-- إجراءات مخزنة

DELIMITER //

-- إجراء حساب النسب المالية
CREATE PROCEDURE calculate_financial_ratios(
    IN p_period_id VARCHAR(20)
)
BEGIN
    -- حساب نسب السيولة
    -- نسبة التداول
    INSERT INTO financial_ratios (
        ratio_id,
        period_id,
        ratio_type,
        ratio_code,
        ratio_name,
        numerator_value,
        denominator_value,
        ratio_value,
        created_by
    )
    SELECT 
        UUID(),
        p_period_id,
        'liquidity',
        'current_ratio',
        'نسبة التداول',
        current_assets.amount,
        current_liabilities.amount,
        CASE 
            WHEN current_liabilities.amount = 0 THEN NULL
            ELSE current_assets.amount / current_liabilities.amount
        END,
        'mostafamohammad7760'
    FROM 
        (SELECT SUM(amount) as amount 
         FROM account_balances 
         WHERE period_id = p_period_id 
         AND account_type = 'current_assets') current_assets,
        (SELECT SUM(amount) as amount 
         FROM account_balances 
         WHERE period_id = p_period_id 
         AND account_type = 'current_liabilities') current_liabilities;

    -- حساب نسب الربحية
    -- هامش الربح الإجمالي
    INSERT INTO financial_ratios (
        ratio_id,
        period_id,
        ratio_type,
        ratio_code,
        ratio_name,
        numerator_value,
        denominator_value,
        ratio_value,
        created_by
    )
    SELECT 
        UUID(),
        p_period_id,
        'profitability',
        'gross_margin',
        'هامش الربح الإجمالي',
        gross_profit.amount,
        sales.amount,
        CASE 
            WHEN sales.amount = 0 THEN NULL
            ELSE gross_profit.amount / sales.amount * 100
        END,
        'mostafamohammad7760'
    FROM 
        (SELECT SUM(amount) as amount 
         FROM account_balances 
         WHERE period_id = p_period_id 
         AND account_code = 'gross_profit') gross_profit,
        (SELECT SUM(amount) as amount 
         FROM account_balances 
         WHERE period_id = p_period_id 
         AND account_code = 'sales') sales;
END //

-- إجراء إجراء التحليل الأفقي
CREATE PROCEDURE perform_horizontal_analysis(
    IN p_base_period_id VARCHAR(20),
    IN p_compare_period_id VARCHAR(20)
)
BEGIN
    INSERT INTO horizontal_analysis (
        analysis_id,
        account_id,
        base_period_id,
        compare_period_id,
        statement_type,
        base_amount,
        compare_amount,
        absolute_change,
        percentage_change,
        created_by
    )
    SELECT 
        UUID(),
        b.account_id,
        p_base_period_id,
        p_compare_period_id,
        CASE 
            WHEN a.account_type IN ('assets', 'liabilities', 'equity') 
            THEN 'balance_sheet'
            WHEN a.account_type IN ('revenues', 'expenses') 
            THEN 'income_statement'
            ELSE 'cash_flow'
        END,
        b.amount as base_amount,
        c.amount as compare_amount,
        c.amount - b.amount as absolute_change,
        CASE 
            WHEN b.amount = 0 THEN NULL
            ELSE ((c.amount - b.amount) / b.amount * 100)
        END,
        'mostafamohammad7760'
    FROM 
        account_balances b
        JOIN account_balances c ON b.account_id = c.account_id
        JOIN chart_of_accounts a ON b.account_id = a.account_id
    WHERE 
        b.period_id = p_base_period_id
        AND c.period_id = p_compare_period_id;
END //

DELIMITER ;

-- المؤشرات
CREATE INDEX idx_financial_ratios_type ON financial_ratios(ratio_type);
CREATE INDEX idx_financial_ratios_period ON financial_ratios(period_id);
CREATE INDEX idx_horizontal_analysis_periods ON horizontal_analysis(base_period_id, compare_period_id);
CREATE INDEX idx_horizontal_analysis_type ON horizontal_analysis(statement_type);
CREATE INDEX idx_vertical_analysis_period ON vertical_analysis(period_id);
CREATE INDEX idx_vertical_analysis_type ON vertical_analysis(statement_type);
CREATE INDEX idx_trend_analysis_periods ON trend_analysis(base_period_id, trend_period_id);
CREATE INDEX idx_trend_analysis_direction ON trend_analysis(trend_direction);
CREATE INDEX idx_analysis_points_type ON analysis_points(analysis_type);
CREATE INDEX idx_analysis_points_category ON analysis_points(category);
CREATE INDEX idx_industry_standards_ratio ON industry_standards(ratio_code);
CREATE INDEX idx_industry_standards_dates ON industry_standards(effective_date, end_date);
CREATE INDEX idx_comparative_analysis_company ON comparative_analysis(company_id, competitor_id);
CREATE INDEX idx_comparative_analysis_ratio ON comparative_analysis(ratio_code);
CREATE INDEX idx_financial_forecasts_method ON financial_forecasts(forecast_method);
CREATE INDEX idx_financial_forecasts_type ON financial_forecasts(statement_type);