import { FinancialReportsAPI } from './api/financial_reports_api.js';
import { ChartManager } from './chart_manager.js';
import { formatCurrency, formatNumber, formatDate, formatPercentage } from './utils/formatters.js';
import { validateReport, validateNote, validateAdjustment } from './utils/validators.js';

class FinancialReports {
    constructor() {
        this.api = new FinancialReportsAPI();
        this.charts = new ChartManager();
        this.currentUser = 'mostafamohammad7760';
        
        // تهيئة المكونات والبيانات
        this.initializeComponents();
        this.attachEventListeners();
        this.loadDashboardData();
        
        // تحديث الوقت كل ثانية
        this.updateDateTime();
        setInterval(() => this.updateDateTime(), 1000);
    }

    initializeComponents() {
        // عناصر لوحة المعلومات
        this.dashboardElements = {
            // حالة التقارير
            draftReports: document.getElementById('draftReports'),
            reviewReports: document.getElementById('reviewReports'),
            approvedReports: document.getElementById('approvedReports'),
            
            // المؤشرات الرئيسية
            currentRatio: document.getElementById('currentRatio'),
            roa: document.getElementById('roa'),
            debtRatio: document.getElementById('debtRatio'),
            
            // الإيضاحات
            draftNotes: document.getElementById('draftNotes'),
            reviewNotes: document.getElementById('reviewNotes'),
            approvedNotes: document.getElementById('approvedNotes'),
            
            // التسويات
            pendingAdjustments: document.getElementById('pendingAdjustments'),
            approvedAdjustments: document.getElementById('approvedAdjustments'),
            rejectedAdjustments: document.getElementById('rejectedAdjustments'),
            
            // الجداول
            latestReportsTable: document.getElementById('latestReportsTable')
        };

        // عناصر الفلترة
        this.filterElements = {
            ratiosPeriod: document.getElementById('ratiosPeriod'),
            itemsPeriod: document.getElementById('itemsPeriod')
        };

        // تهيئة الرسوم البيانية
        this.initializeCharts();
        
        // تهيئة القوالب
        this.reportRowTemplate = document.getElementById('reportRowTemplate');
    }

    async loadDashboardData() {
        try {
            this.showLoading();

            const [
                reportStats,
                ratioStats,
                noteStats,
                adjustmentStats,
                ratiosData,
                itemsData,
                latestReports
            ] = await Promise.all([
                this.api.getReportStats(),
                this.api.getRatioStats(),
                this.api.getNoteStats(),
                this.api.getAdjustmentStats(),
                this.api.getRatiosAnalysis(this.filterElements.ratiosPeriod.value),
                this.api.getItemsAnalysis(this.filterElements.itemsPeriod.value),
                this.api.getLatestReports()
            ]);

            this.updateReportStats(reportStats);
            this.updateRatioStats(ratioStats);
            this.updateNoteStats(noteStats);
            this.updateAdjustmentStats(adjustmentStats);
            this.updateCharts(ratiosData, itemsData);
            this.renderLatestReports(latestReports);

            this.hideLoading();
        } catch (error) {
            this.hideLoading();
            this.showError('حدث خطأ أثناء تحميل البيانات');
            console.error('Dashboard loading error:', error);
        }
    }

    initializeCharts() {
        // تهيئة رسم تحليل المؤشرات المالية
        this.charts.initializeLineChart('ratiosChart', {
            labels: [],
            datasets: [
                {
                    label: 'نسبة التداول',
                    data: [],
                    borderColor: '#27ae60',
                    backgroundColor: 'rgba(39, 174, 96, 0.1)',
                    fill: true
                },
                {
                    label: 'العائد على الأصول',
                    data: [],
                    borderColor: '#3498db',
                    backgroundColor: 'rgba(52, 152, 219, 0.1)',
                    fill: true
                },
                {
                    label: 'نسبة المديونية',
                    data: [],
                    borderColor: '#e74c3c',
                    backgroundColor: 'rgba(231, 76, 60, 0.1)',
                    fill: true
                }
            ],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => formatPercentage(value)
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: context => formatPercentage(context.parsed.y)
                        }
                    }
                }
            }
        });

        // تهيئة رسم تحليل البنود الرئيسية
        this.charts.initializeBarChart('itemsChart', {
            labels: [],
            datasets: [{
                data: [],
                backgroundColor: [
                    '#2ecc71',
                    '#3498db',
                    '#f1c40f',
                    '#e67e22',
                    '#e74c3c',
                    '#9b59b6'
                ]
            }],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => formatCurrency(value)
                        }
                    }
                },
                plugins: {
                    legend: {
                        position: 'right'
                    },
                    tooltip: {
                        callbacks: {
                            label: context => 
                                `${context.label}: ${formatCurrency(context.parsed.y)}`
                        }
                    }
                }
            }
        });
    }

    updateReportStats(stats) {
        this.dashboardElements.draftReports.textContent = stats.draft;
        this.dashboardElements.reviewReports.textContent = stats.review;
        this.dashboardElements.approvedReports.textContent = stats.approved;
    }

    updateRatioStats(stats) {
        this.dashboardElements.currentRatio.textContent = 
            formatNumber(stats.currentRatio, 2);
        this.dashboardElements.roa.textContent = 
            formatPercentage(stats.roa);
        this.dashboardElements.debtRatio.textContent = 
            formatPercentage(stats.debtRatio);
    }

    updateNoteStats(stats) {
        this.dashboardElements.draftNotes.textContent = stats.draft;
        this.dashboardElements.reviewNotes.textContent = stats.review;
        this.dashboardElements.approvedNotes.textContent = stats.approved;
    }

    updateAdjustmentStats(stats) {
        this.dashboardElements.pendingAdjustments.textContent = stats.pending;
        this.dashboardElements.approvedAdjustments.textContent = stats.approved;
        this.dashboardElements.rejectedAdjustments.textContent = stats.rejected;
    }

    updateCharts(ratiosData, itemsData) {
        // تحديث رسم تحليل المؤشرات المالية
        this.charts.updateLineChart('ratiosChart', {
            labels: ratiosData.labels,
            datasets: [
                {
                    data: ratiosData.currentRatio,
                    label: 'نسبة التداول'
                },
                {
                    data: ratiosData.roa,
                    label: 'العائد على الأصول'
                },
                {
                    data: ratiosData.debtRatio,
                    label: 'نسبة المديونية'
                }
            ]
        });

        // تحديث رسم تحليل البنود الرئيسية
        this.charts.updateBarChart('itemsChart', {
            labels: itemsData.labels,
            data: itemsData.values
        });
    }

    renderLatestReports(reports) {
        const tbody = this.dashboardElements.latestReportsTable;
        tbody.innerHTML = '';

        reports.forEach(report => {
            const tr = this.createReportRow(report);
            tbody.appendChild(tr);
        });
    }

    createReportRow(report) {
        const template = this.reportRowTemplate.content.cloneNode(true);
        const tr = template.querySelector('tr');
        
        tr.querySelector('.report-code').textContent = report.code;
        tr.querySelector('.report-name').textContent = report.name;
        tr.querySelector('.report-period').textContent = report.period;
        tr.querySelector('.report-type').textContent = this.translateReportType(report.type);
        tr.querySelector('.report-date').textContent = formatDate(report.reportDate);
        
        const statusCell = tr.querySelector('.report-status');
        statusCell.textContent = this.translateReportStatus(report.status);
        statusCell.classList.add(report.status.toLowerCase());

        // إضافة مستمعات الأحداث للأزرار
        tr.querySelector('.view-report').addEventListener('click', 
            () => this.viewReport(report.id));
        
        const editButton = tr.querySelector('.edit-report');
        const approveButton = tr.querySelector('.approve-report');
        
        if (report.status === 'draft') {
            editButton.addEventListener('click', 
                () => this.editReport(report.id));
            approveButton.style.display = 'none';
        } else if (report.status === 'review') {
            editButton.style.display = 'none';
            approveButton.addEventListener('click', 
                () => this.approveReport(report.id));
        } else {
            editButton.style.display = 'none';
            approveButton.style.display = 'none';
        }

        return tr;
    }

    attachEventListeners() {
        // مستمعات أحداث الإجراءات السريعة
        document.getElementById('createReport')?.addEventListener('click', 
            () => this.showReportModal());
        document.getElementById('createNote')?.addEventListener('click', 
            () => this.showNoteModal());
        document.getElementById('createAdjustment')?.addEventListener('click', 
            () => this.showAdjustmentModal());
        document.getElementById('exportReports')?.addEventListener('click', 
            () => this.exportSelectedReports());

        // مستمعات أحداث الفلترة
        this.filterElements.ratiosPeriod.addEventListener('change', 
            () => this.loadRatiosAnalysis());
        this.filterElements.itemsPeriod.addEventListener('change', 
            () => this.loadItemsAnalysis());

        // مستمعات أحداث التصدير
        document.getElementById('exportRatiosChart')?.addEventListener('click', 
            () => this.exportChart('ratiosChart'));
        document.getElementById('exportItemsChart')?.addEventListener('click', 
            () => this.exportChart('itemsChart'));

        // مستمعات أحداث عرض الكل
        document.getElementById('viewAllReports')?.addEventListener('click', 
            () => this.navigateToReports());
    }

    // توابع مساعدة
    translateReportType(type) {
        const typeMap = {
            balance_sheet: 'قائمة المركز المالي',
            income_statement: 'قائمة الدخل الشامل',
            cash_flow: 'قائمة التدفقات النقدية',
            changes_in_equity: 'قائمة التغيرات في حقوق الملكية'
        };
        return typeMap[type] || type;
    }

    translateReportStatus(status) {
        const statusMap = {
            draft: 'مسودة',
            review: 'قيد المراجعة',
            approved: 'معتمد',
            published: 'منشور'
        };
        return statusMap[status] || status;
    }

    updateDateTime() {
        document.getElementById('currentDateTime').textContent = 
            new Date().toISOString().slice(0, 19).replace('T', ' ');
    }

    showLoading() {
        const loader = document.createElement('div');
        loader.className = 'loading-overlay';
        loader.innerHTML = '<div class="loading-spinner"></div>';
        document.body.appendChild(loader);
    }

    hideLoading() {
        document.querySelector('.loading-overlay')?.remove();
    }

    showError(message) {
        console.error(message);
        // يمكن تحسين هذه الدالة لعرض رسائل خطأ أكثر جاذبية
        alert(message);
    }

    showSuccess(message) {
        // يمكن تحسين هذه الدالة لعرض رسائل نجاح أكثر جاذبية
        alert(message);
    }
}

// تهيئة التطبيق عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    new FinancialReports();
});