-- إنشاء جداول الحسابات المدينة والدائنة

-- جدول العملاء
CREATE TABLE customers (
    customer_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    contact_person VARCHAR(100),
    phone VARCHAR(20),
    email VARCHAR(100),
    tax_number VARCHAR(50),
    credit_limit DECIMAL(18,2),
    current_balance DECIMAL(18,2) DEFAULT 0,
    status ENUM('active', 'inactive', 'blocked') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50)
);

-- جدول الموردين
CREATE TABLE suppliers (
    supplier_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    contact_person VARCHAR(100),
    phone VARCHAR(20),
    email VARCHAR(100),
    tax_number VARCHAR(50),
    credit_limit DECIMAL(18,2),
    current_balance DECIMAL(18,2) DEFAULT 0,
    status ENUM('active', 'inactive', 'blocked') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50)
);

-- جدول فواتير المبيعات
CREATE TABLE sales_invoices (
    invoice_id VARCHAR(20) PRIMARY KEY,
    invoice_number VARCHAR(20) UNIQUE NOT NULL,
    customer_id VARCHAR(20) NOT NULL,
    invoice_date DATE NOT NULL,
    due_date DATE NOT NULL,
    currency_code VARCHAR(3) NOT NULL,
    exchange_rate DECIMAL(18,6) NOT NULL DEFAULT 1,
    subtotal DECIMAL(18,2) NOT NULL,
    discount_amount DECIMAL(18,2) DEFAULT 0,
    tax_amount DECIMAL(18,2) DEFAULT 0,
    total_amount DECIMAL(18,2) NOT NULL,
    paid_amount DECIMAL(18,2) DEFAULT 0,
    remaining_amount DECIMAL(18,2) NOT NULL,
    status ENUM('draft', 'posted', 'partially_paid', 'paid', 'cancelled') DEFAULT 'draft',
    payment_terms VARCHAR(200),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (currency_code) REFERENCES currencies(code)
);

-- جدول فواتير المشتريات
CREATE TABLE purchase_invoices (
    invoice_id VARCHAR(20) PRIMARY KEY,
    invoice_number VARCHAR(20) UNIQUE NOT NULL,
    supplier_id VARCHAR(20) NOT NULL,
    invoice_date DATE NOT NULL,
    due_date DATE NOT NULL,
    currency_code VARCHAR(3) NOT NULL,
    exchange_rate DECIMAL(18,6) NOT NULL DEFAULT 1,
    subtotal DECIMAL(18,2) NOT NULL,
    discount_amount DECIMAL(18,2) DEFAULT 0,
    tax_amount DECIMAL(18,2) DEFAULT 0,
    total_amount DECIMAL(18,2) NOT NULL,
    paid_amount DECIMAL(18,2) DEFAULT 0,
    remaining_amount DECIMAL(18,2) NOT NULL,
    status ENUM('draft', 'posted', 'partially_paid', 'paid', 'cancelled') DEFAULT 'draft',
    payment_terms VARCHAR(200),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id),
    FOREIGN KEY (currency_code) REFERENCES currencies(code)
);

-- جدول بنود فواتير المبيعات
CREATE TABLE sales_invoice_items (
    item_id VARCHAR(20) PRIMARY KEY,
    invoice_id VARCHAR(20) NOT NULL,
    product_id VARCHAR(20) NOT NULL,
    description TEXT,
    quantity DECIMAL(18,3) NOT NULL,
    unit_price DECIMAL(18,2) NOT NULL,
    discount_percentage DECIMAL(5,2) DEFAULT 0,
    discount_amount DECIMAL(18,2) DEFAULT 0,
    tax_percentage DECIMAL(5,2) DEFAULT 0,
    tax_amount DECIMAL(18,2) DEFAULT 0,
    total_amount DECIMAL(18,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    FOREIGN KEY (invoice_id) REFERENCES sales_invoices(invoice_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- جدول بنود فواتير المشتريات
CREATE TABLE purchase_invoice_items (
    item_id VARCHAR(20) PRIMARY KEY,
    invoice_id VARCHAR(20) NOT NULL,
    product_id VARCHAR(20) NOT NULL,
    description TEXT,
    quantity DECIMAL(18,3) NOT NULL,
    unit_price DECIMAL(18,2) NOT NULL,
    discount_percentage DECIMAL(5,2) DEFAULT 0,
    discount_amount DECIMAL(18,2) DEFAULT 0,
    tax_percentage DECIMAL(5,2) DEFAULT 0,
    tax_amount DECIMAL(18,2) DEFAULT 0,
    total_amount DECIMAL(18,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    FOREIGN KEY (invoice_id) REFERENCES purchase_invoices(invoice_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- جدول الدفعات المستلمة
CREATE TABLE received_payments (
    payment_id VARCHAR(20) PRIMARY KEY,
    payment_number VARCHAR(20) UNIQUE NOT NULL,
    customer_id VARCHAR(20) NOT NULL,
    payment_date DATE NOT NULL,
    currency_code VARCHAR(3) NOT NULL,
    exchange_rate DECIMAL(18,6) NOT NULL DEFAULT 1,
    amount DECIMAL(18,2) NOT NULL,
    payment_method ENUM('cash', 'bank_transfer', 'check', 'credit_card') NOT NULL,
    reference_number VARCHAR(50),
    notes TEXT,
    status ENUM('draft', 'posted', 'cancelled') DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (currency_code) REFERENCES currencies(code)
);

-- جدول الدفعات المسددة
CREATE TABLE made_payments (
    payment_id VARCHAR(20) PRIMARY KEY,
    payment_number VARCHAR(20) UNIQUE NOT NULL,
    supplier_id VARCHAR(20) NOT NULL,
    payment_date DATE NOT NULL,
    currency_code VARCHAR(3) NOT NULL,
    exchange_rate DECIMAL(18,6) NOT NULL DEFAULT 1,
    amount DECIMAL(18,2) NOT NULL,
    payment_method ENUM('cash', 'bank_transfer', 'check', 'credit_card') NOT NULL,
    reference_number VARCHAR(50),
    notes TEXT,
    status ENUM('draft', 'posted', 'cancelled') DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id),
    FOREIGN KEY (currency_code) REFERENCES currencies(code)
);

-- جدول توزيع الدفعات المستلمة على الفواتير
CREATE TABLE received_payment_allocations (
    allocation_id VARCHAR(20) PRIMARY KEY,
    payment_id VARCHAR(20) NOT NULL,
    invoice_id VARCHAR(20) NOT NULL,
    allocated_amount DECIMAL(18,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    FOREIGN KEY (payment_id) REFERENCES received_payments(payment_id),
    FOREIGN KEY (invoice_id) REFERENCES sales_invoices(invoice_id)
);

-- جدول توزيع الدفعات المسددة على الفواتير
CREATE TABLE made_payment_allocations (
    allocation_id VARCHAR(20) PRIMARY KEY,
    payment_id VARCHAR(20) NOT NULL,
    invoice_id VARCHAR(20) NOT NULL,
    allocated_amount DECIMAL(18,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    FOREIGN KEY (payment_id) REFERENCES made_payments(payment_id),
    FOREIGN KEY (invoice_id) REFERENCES purchase_invoices(invoice_id)
);

-- جدول تقادم الديون
CREATE TABLE aging_buckets (
    bucket_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    start_days INT NOT NULL,
    end_days INT,
    color_code VARCHAR(7),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50)
);

-- إجراءات مخزنة

DELIMITER //

-- إجراء إنشاء فاتورة مبيعات
CREATE PROCEDURE create_sales_invoice(
    IN p_customer_id VARCHAR(20),
    IN p_invoice_date DATE,
    IN p_due_date DATE,
    IN p_currency_code VARCHAR(3),
    IN p_payment_terms VARCHAR(200)
)
BEGIN
    DECLARE v_invoice_number VARCHAR(20);
    DECLARE v_exchange_rate DECIMAL(18,6);
    
    -- توليد رقم الفاتورة
    SELECT CONCAT('INV-', LPAD(COALESCE(MAX(SUBSTRING(invoice_number, 5)) + 1, 1), 6, '0'))
    INTO v_invoice_number
    FROM sales_invoices;
    
    -- الحصول على سعر الصرف
    SELECT rate INTO v_exchange_rate
    FROM exchange_rates
    WHERE currency_code = p_currency_code
    AND effective_date <= p_invoice_date
    ORDER BY effective_date DESC
    LIMIT 1;
    
    -- إدراج الفاتورة
    INSERT INTO sales_invoices (
        invoice_id,
        invoice_number,
        customer_id,
        invoice_date,
        due_date,
        currency_code,
        exchange_rate,
        payment_terms,
        created_by
    )
    VALUES (
        UUID(),
        v_invoice_number,
        p_customer_id,
        p_invoice_date,
        p_due_date,
        p_currency_code,
        COALESCE(v_exchange_rate, 1),
        p_payment_terms,
        'mostafamohammad7760'
    );
END //

-- إجراء إنشاء فاتورة مشتريات
CREATE PROCEDURE create_purchase_invoice(
    IN p_supplier_id VARCHAR(20),
    IN p_invoice_date DATE,
    IN p_due_date DATE,
    IN p_currency_code VARCHAR(3),
    IN p_payment_terms VARCHAR(200)
)
BEGIN
    DECLARE v_invoice_number VARCHAR(20);
    DECLARE v_exchange_rate DECIMAL(18,6);
    
    -- توليد رقم الفاتورة
    SELECT CONCAT('PUR-', LPAD(COALESCE(MAX(SUBSTRING(invoice_number, 5)) + 1, 1), 6, '0'))
    INTO v_invoice_number
    FROM purchase_invoices;
    
    -- الحصول على سعر الصرف
    SELECT rate INTO v_exchange_rate
    FROM exchange_rates
    WHERE currency_code = p_currency_code
    AND effective_date <= p_invoice_date
    ORDER BY effective_date DESC
    LIMIT 1;
    
    -- إدراج الفاتورة
    INSERT INTO purchase_invoices (
        invoice_id,
        invoice_number,
        supplier_id,
        invoice_date,
        due_date,
        currency_code,
        exchange_rate,
        payment_terms,
        created_by
    )
    VALUES (
        UUID(),
        v_invoice_number,
        p_supplier_id,
        p_invoice_date,
        p_due_date,
        p_currency_code,
        COALESCE(v_exchange_rate, 1),
        p_payment_terms,
        'mostafamohammad7760'
    );
END //

-- إجراء تسجيل دفعة مستلمة
CREATE PROCEDURE record_received_payment(
    IN p_customer_id VARCHAR(20),
    IN p_payment_date DATE,
    IN p_currency_code VARCHAR(3),
    IN p_amount DECIMAL(18,2),
    IN p_payment_method VARCHAR(20),
    IN p_reference_number VARCHAR(50)
)
BEGIN
    DECLARE v_payment_number VARCHAR(20);
    DECLARE v_exchange_rate DECIMAL(18,6);
    
    -- توليد رقم الدفعة
    SELECT CONCAT('REC-', LPAD(COALESCE(MAX(SUBSTRING(payment_number, 5)) + 1, 1), 6, '0'))
    INTO v_payment_number
    FROM received_payments;
    
    -- الحصول على سعر الصرف
    SELECT rate INTO v_exchange_rate
    FROM exchange_rates
    WHERE currency_code = p_currency_code
    AND effective_date <= p_payment_date
    ORDER BY effective_date DESC
    LIMIT 1;
    
    -- إدراج الدفعة
    INSERT INTO received_payments (
        payment_id,
        payment_number,
        customer_id,
        payment_date,
        currency_code,
        exchange_rate,
        amount,
        payment_method,
        reference_number,
        created_by
    )
    VALUES (
        UUID(),
        v_payment_number,
        p_customer_id,
        p_payment_date,
        p_currency_code,
        COALESCE(v_exchange_rate, 1),
        p_amount,
        p_payment_method,
        p_reference_number,
        'mostafamohammad7760'
    );
END //

DELIMITER ;

-- المؤشرات
CREATE INDEX idx_customers_status ON customers(status);
CREATE INDEX idx_suppliers_status ON suppliers(status);
CREATE INDEX idx_sales_invoices_customer ON sales_invoices(customer_id);
CREATE INDEX idx_sales_invoices_dates ON sales_invoices(invoice_date, due_date);
CREATE INDEX idx_sales_invoices_status ON sales_invoices(status);
CREATE INDEX idx_purchase_invoices_supplier ON purchase_invoices(supplier_id);
CREATE INDEX idx_purchase_invoices_dates ON purchase_invoices(invoice_date, due_date);
CREATE INDEX idx_purchase_invoices_status ON purchase_invoices(status);
CREATE INDEX idx_received_payments_customer ON received_payments(customer_id);
CREATE INDEX idx_received_payments_date ON received_payments(payment_date);
CREATE INDEX idx_received_payments_status ON received_payments(status);
CREATE INDEX idx_made_payments_supplier ON made_payments(supplier_id);
CREATE INDEX idx_made_payments_date ON made_payments(payment_date);
CREATE INDEX idx_made_payments_status ON made_payments(status);
CREATE INDEX idx_aging_buckets_days ON aging_buckets(start_days, end_days);