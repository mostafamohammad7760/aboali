<!-- 
شاشة المبيعات الرئيسية
التاريخ: 2025-05-09 03:27:24
المستخدم: mostafamohammad7760
-->

<template>
  <div class="sales-screen">
    <!-- القسم الأيسر - سلة المشتريات والدفع -->
    <div class="cart-section">
      <!-- معلومات العميل -->
      <div class="customer-info">
        <customer-selector
          v-model="selectedCustomer"
          @add-customer="showAddCustomer = true"
        />
      </div>

      <!-- قائمة المنتجات في السلة -->
      <div class="cart-items">
        <div v-if="cartItems.length === 0" class="empty-cart">
          <i class="fas fa-shopping-cart"></i>
          <p>السلة فارغة</p>
        </div>
        <template v-else>
          <div v-for="item in cartItems" 
               :key="item.product_id" 
               class="cart-item">
            <div class="item-info">
              <h4>{{ item.name }}</h4>
              <p>{{ formatCurrency(item.price) }} × {{ item.quantity }}</p>
            </div>
            <div class="item-actions">
              <button @click="decrementQuantity(item)">-</button>
              <input type="number" 
                     v-model.number="item.quantity"
                     @change="updateQuantity(item)">
              <button @click="incrementQuantity(item)">+</button>
              <button class="remove-btn" 
                      @click="removeItem(item)">
                <i class="fas fa-trash"></i>
              </button>
            </div>
            <div class="item-total">
              {{ formatCurrency(item.price * item.quantity) }}
            </div>
          </div>
        </template>
      </div>

      <!-- ملخص السلة -->
      <div class="cart-summary">
        <div class="summary-row">
          <span>إجمالي المنتجات</span>
          <span>{{ formatCurrency(subtotal) }}</span>
        </div>
        <div class="summary-row">
          <span>الضريبة ({{ taxRate }}%)</span>
          <span>{{ formatCurrency(taxAmount) }}</span>
        </div>
        <div class="summary-row" v-if="discount">
          <span>الخصم</span>
          <span>- {{ formatCurrency(discountAmount) }}</span>
        </div>
        <div class="summary-row total">
          <span>الإجمالي النهائي</span>
          <span>{{ formatCurrency(total) }}</span>
        </div>
      </div>

      <!-- أزرار الإجراءات -->
      <div class="cart-actions">
        <button class="btn btn-danger" 
                @click="clearCart"
                :disabled="!cartItems.length">
          إلغاء
        </button>
        <button class="btn btn-primary" 
                @click="showDiscountModal"
                :disabled="!cartItems.length">
          خصم
        </button>
        <button class="btn btn-success" 
                @click="proceedToPayment"
                :disabled="!canCheckout">
          الدفع
        </button>
      </div>
    </div>

    <!-- القسم الأيمن - المنتجات والفئات -->
    <div class="products-section">
      <!-- شريط البحث -->
      <div class="search-bar">
        <input type="text"
               v-model="searchQuery"
               placeholder="بحث عن منتج...">
        <button class="barcode-btn" @click="startBarcodeScanner">
          <i class="fas fa-barcode"></i>
        </button>
      </div>

      <!-- شريط الفئات -->
      <div class="categories-bar">
        <button v-for="category in categories"
                :key="category.id"
                :class="{ active: selectedCategory === category.id }"
                @click="selectCategory(category.id)">
          {{ category.name }}
        </button>
      </div>

      <!-- شبكة المنتجات -->
      <div class="products-grid">
        <div v-for="product in filteredProducts"
             :key="product.id"
             class="product-card"
             @click="addToCart(product)">
          <img :src="product.image_url" :alt="product.name">
          <h3>{{ product.name }}</h3>
          <p>{{ formatCurrency(product.price) }}</p>
          <span class="stock-badge" 
                :class="getStockStatusClass(product.stock_quantity)">
            {{ product.stock_quantity }} قطعة
          </span>
        </div>
      </div>
    </div>

    <!-- النوافذ المنبثقة -->
    <add-customer-modal
      v-if="showAddCustomer"
      @close="showAddCustomer = false"
      @customer-added="onCustomerAdded"
    />

    <discount-modal
      v-if="showDiscount"
      :subtotal="subtotal"
      @apply="applyDiscount"
      @close="showDiscount = false"
    />

    <payment-modal
      v-if="showPayment"
      :total="total"
      :customer="selectedCustomer"
      @payment-complete="completePayment"
      @close="showPayment = false"
    />
  </div>
</template>

<script>
// المزيد من الكود في الرسالة التالية...
</script>

<style lang="scss" scoped>
// المزيد من التنسيقات في الرسالة التالية...
</style>