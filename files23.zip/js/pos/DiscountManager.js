/**
 * مدير الخصومات - إدارة الخصومات والعروض في نظام نقاط البيع
 * @module DiscountManager
 * التاريخ: 2025-05-09 03:04:38
 * المستخدم: mostafamohammad7760
 */

export class DiscountManager {
    constructor(database) {
        this.db = database;
        this.discountTypes = {
            PERCENTAGE: 'percentage',
            FIXED: 'fixed',
            BUY_X_GET_Y: 'buy_x_get_y',
            BUNDLE: 'bundle',
            LOYALTY: 'loyalty'
        };
    }

    /**
     * إنشاء خصم جديد
     * @param {Object} discountData - بيانات الخصم
     */
    async createDiscount(discountData) {
        try {
            // التحقق من صحة البيانات
            this.validateDiscountData(discountData);

            const discountId = this.generateDiscountId();
            const query = `
                INSERT INTO discounts (
                    discount_id,
                    name,
                    description,
                    type,
                    value,
                    min_purchase,
                    max_discount,
                    start_date,
                    end_date,
                    is_active,
                    created_by
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `;

            await this.db.executeQuery(query, [
                discountId,
                discountData.name,
                discountData.description,
                discountData.type,
                discountData.value,
                discountData.min_purchase || 0,
                discountData.max_discount || null,
                discountData.start_date,
                discountData.end_date,
                true,
                this.currentUser
            ]);

            // إضافة شروط الخصم إذا وجدت
            if (discountData.conditions) {
                await this.addDiscountConditions(discountId, discountData.conditions);
            }

            // إضافة المنتجات المشمولة إذا وجدت
            if (discountData.products) {
                await this.addDiscountProducts(discountId, discountData.products);
            }

            return await this.getDiscount(discountId);
        } catch (error) {
            console.error('Error creating discount:', error);
            throw new Error('فشل إنشاء الخصم');
        }
    }

    /**
     * التحقق من صحة بيانات الخصم
     * @param {Object} data - بيانات الخصم
     */
    validateDiscountData(data) {
        const errors = [];

        if (!data.name || data.name.trim().length < 3) {
            errors.push('اسم الخصم يجب أن يكون أكثر من 3 أحرف');
        }

        if (!this.discountTypes[data.type]) {
            errors.push('نوع الخصم غير صالح');
        }

        if (data.type === this.discountTypes.PERCENTAGE) {
            if (data.value <= 0 || data.value > 100) {
                errors.push('نسبة الخصم يجب أن تكون بين 1 و 100');
            }
        }

        if (data.type === this.discountTypes.FIXED) {
            if (data.value <= 0) {
                errors.push('قيمة الخصم يجب أن تكون أكبر من 0');
            }
        }

        if (new Date(data.start_date) >= new Date(data.end_date)) {
            errors.push('تاريخ البداية يجب أن يكون قبل تاريخ النهاية');
        }

        if (errors.length > 0) {
            throw new Error(errors.join('\n'));
        }
    }

    /**
     * حساب الخصم على السلة
     * @param {Array} cartItems - عناصر السلة
     * @param {string} customerId - معرف العميل
     */
    async calculateCartDiscount(cartItems, customerId = null) {
        try {
            // الحصول على الخصومات النشطة
            const activeDiscounts = await this.getActiveDiscounts();
            let bestDiscount = { amount: 0, discount: null };

            for (const discount of activeDiscounts) {
                // التحقق من شروط الخصم
                if (!this.isDiscountApplicable(discount, cartItems, customerId)) {
                    continue;
                }

                const discountAmount = await this.calculateDiscountAmount(
                    discount,
                    cartItems,
                    customerId
                );

                if (discountAmount > bestDiscount.amount) {
                    bestDiscount = {
                        amount: discountAmount,
                        discount: discount
                    };
                }
            }

            return bestDiscount;
        } catch (error) {
            console.error('Error calculating cart discount:', error);
            throw new Error('فشل حساب الخصم');
        }
    }

    /**
     * التحقق من إمكانية تطبيق الخصم
     * @param {Object} discount - بيانات الخصم
     * @param {Array} cartItems - عناصر السلة
     * @param {string} customerId - معرف العميل
     */
    isDiscountApplicable(discount, cartItems, customerId) {
        // التحقق من تاريخ الصلاحية
        const now = new Date();
        if (now < new Date(discount.start_date) || now > new Date(discount.end_date)) {
            return false;
        }

        // حساب إجمالي السلة
        const cartTotal = cartItems.reduce(
            (total, item) => total + (item.price * item.quantity),
            0
        );

        // التحقق من الحد الأدنى للشراء
        if (discount.min_purchase && cartTotal < discount.min_purchase) {
            return false;
        }

        // التحقق من شروط العميل إذا وجدت
        if (discount.customer_conditions && customerId) {
            if (!this.checkCustomerConditions(discount.customer_conditions, customerId)) {
                return false;
            }
        }

        // التحقق من المنتجات المشمولة
        if (discount.product_conditions) {
            if (!this.checkProductConditions(discount.product_conditions, cartItems)) {
                return false;
            }
        }

        return true;
    }

    /**
     * حساب قيمة الخصم
     * @param {Object} discount - بيانات الخصم
     * @param {Array} cartItems - عناصر السلة
     * @param {string} customerId - معرف العميل
     */
    async calculateDiscountAmount(discount, cartItems, customerId) {
        let amount = 0;

        switch (discount.type) {
            case this.discountTypes.PERCENTAGE:
                amount = this.calculatePercentageDiscount(discount, cartItems);
                break;

            case this.discountTypes.FIXED:
                amount = this.calculateFixedDiscount(discount, cartItems);
                break;

            case this.discountTypes.BUY_X_GET_Y:
                amount = this.calculateBuyXGetYDiscount(discount, cartItems);
                break;

            case this.discountTypes.BUNDLE:
                amount = this.calculateBundleDiscount(discount, cartItems);
                break;

            case this.discountTypes.LOYALTY:
                amount = await this.calculateLoyaltyDiscount(discount, cartItems, customerId);
                break;
        }

        // التحقق من الحد الأقصى للخصم
        if (discount.max_discount && amount > discount.max_discount) {
            amount = discount.max_discount;
        }

        return amount;
    }

    /**
     * حساب خصم النسبة المئوية
     * @param {Object} discount - بيانات الخصم
     * @param {Array} cartItems - عناصر السلة
     */
    calculatePercentageDiscount(discount, cartItems) {
        const eligibleItems = this.getEligibleItems(discount, cartItems);
        const subtotal = eligibleItems.reduce(
            (total, item) => total + (item.price * item.quantity),
            0
        );

        return (subtotal * discount.value) / 100;
    }

    /**
     * حساب الخصم الثابت
     * @param {Object} discount - بيانات الخصم
     * @param {Array} cartItems - عناصر السلة
     */
    calculateFixedDiscount(discount, cartItems) {
        const eligibleItems = this.getEligibleItems(discount, cartItems);
        return eligibleItems.length > 0 ? discount.value : 0;
    }

    /**
     * الحصول على المنتجات المؤهلة للخصم
     * @param {Object} discount - بيانات الخصم
     * @param {Array} cartItems - عناصر السلة
     */
    getEligibleItems(discount, cartItems) {
        if (!discount.product_conditions) {
            return cartItems;
        }

        return cartItems.filter(item =>
            discount.product_conditions.products.includes(item.id)
        );
    }

    /**
     * توليد معرف فريد للخصم
     */
    generateDiscountId() {
        return 'DISC-' + Date.now().toString(36).toUpperCase();
    }
}