import { HRAPI } from './api/hr_api.js';
import { ChartManager } from './chart_manager.js';
import { formatNumber, formatDate, formatTime } from './utils/formatters.js';
import { validateEmployee, validateVacation, validateAttendance } from './utils/validators.js';

class HR {
    constructor() {
        this.api = new HRAPI();
        this.charts = new ChartManager();
        this.currentUser = 'mostafamohammad7760';
        
        // تهيئة المكونات والبيانات
        this.initializeComponents();
        this.attachEventListeners();
        this.loadDashboardData();
        
        // تحديث الوقت كل ثانية
        this.updateDateTime();
        setInterval(() => this.updateDateTime(), 1000);
    }

    initializeComponents() {
        // عناصر لوحة المعلومات
        this.dashboardElements = {
            // القوى العاملة
            totalEmployees: document.getElementById('totalEmployees'),
            fullTimeEmployees: document.getElementById('fullTimeEmployees'),
            partTimeEmployees: document.getElementById('partTimeEmployees'),
            
            // الحضور اليومي
            presentToday: document.getElementById('presentToday'),
            absentToday: document.getElementById('absentToday'),
            onVacationToday: document.getElementById('onVacationToday'),
            
            // طلبات الإجازات
            pendingVacations: document.getElementById('pendingVacations'),
            approvedVacations: document.getElementById('approvedVacations'),
            rejectedVacations: document.getElementById('rejectedVacations'),
            
            // تقييم الأداء
            pendingReviews: document.getElementById('pendingReviews'),
            averageRating: document.getElementById('averageRating'),
            lastReviewUpdate: document.getElementById('lastReviewUpdate'),
            
            // الجداول
            latestRequestsTable: document.getElementById('latestRequestsTable')
        };

        // عناصر الفلترة
        this.filterElements = {
            workforceChartPeriod: document.getElementById('workforceChartPeriod'),
            attendancePeriod: document.getElementById('attendancePeriod')
        };

        // تهيئة الرسوم البيانية
        this.initializeCharts();
        
        // تهيئة القوالب
        this.requestRowTemplate = document.getElementById('requestRowTemplate');
    }

    async loadDashboardData() {
        try {
            this.showLoading();

            const [
                workforceStats,
                attendanceStats,
                vacationStats,
                performanceStats,
                workforceAnalysis,
                attendanceAnalysis,
                latestRequests
            ] = await Promise.all([
                this.api.getWorkforceStats(),
                this.api.getAttendanceStats(),
                this.api.getVacationStats(),
                this.api.getPerformanceStats(),
                this.api.getWorkforceAnalysis(this.filterElements.workforceChartPeriod.value),
                this.api.getAttendanceAnalysis(this.filterElements.attendancePeriod.value),
                this.api.getLatestRequests()
            ]);

            this.updateWorkforceStats(workforceStats);
            this.updateAttendanceStats(attendanceStats);
            this.updateVacationStats(vacationStats);
            this.updatePerformanceStats(performanceStats);
            this.updateCharts(workforceAnalysis, attendanceAnalysis);
            this.renderLatestRequests(latestRequests);

            this.hideLoading();
        } catch (error) {
            this.hideLoading();
            this.showError('حدث خطأ أثناء تحميل البيانات');
            console.error('Dashboard loading error:', error);
        }
    }

    initializeCharts() {
        // تهيئة رسم تحليل القوى العاملة
        this.charts.initializeLineChart('workforceAnalysisChart', {
            labels: [],
            datasets: [
                {
                    label: 'موظفون جدد',
                    data: [],
                    borderColor: '#27ae60',
                    backgroundColor: 'rgba(39, 174, 96, 0.1)',
                    fill: true
                },
                {
                    label: 'إنهاء خدمة',
                    data: [],
                    borderColor: '#e74c3c',
                    backgroundColor: 'rgba(231, 76, 60, 0.1)',
                    fill: true
                }
            ],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => formatNumber(value)
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: context => formatNumber(context.parsed.y)
                        }
                    }
                }
            }
        });

        // تهيئة رسم تحليل الحضور
        this.charts.initializePieChart('attendanceAnalysisChart', {
            labels: [],
            datasets: [{
                data: [],
                backgroundColor: [
                    '#2ecc71', // حاضر
                    '#e74c3c', // غائب
                    '#f1c40f', // متأخر
                    '#3498db', // إجازة
                    '#95a5a6'  // أخرى
                ]
            }],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: context => 
                                `${context.label}: ${formatNumber(context.parsed)} (${context.dataset.data[context.dataIndex]}%)`
                        }
                    }
                }
            }
        });
    }

    updateWorkforceStats(stats) {
        this.dashboardElements.totalEmployees.textContent = 
            formatNumber(stats.total);
        this.dashboardElements.fullTimeEmployees.textContent = 
            formatNumber(stats.fullTime);
        this.dashboardElements.partTimeEmployees.textContent = 
            formatNumber(stats.partTime);
    }

    updateAttendanceStats(stats) {
        this.dashboardElements.presentToday.textContent = 
            formatNumber(stats.present);
        this.dashboardElements.absentToday.textContent = 
            formatNumber(stats.absent);
        this.dashboardElements.onVacationToday.textContent = 
            formatNumber(stats.onVacation);
    }

    updateVacationStats(stats) {
        this.dashboardElements.pendingVacations.textContent = 
            formatNumber(stats.pending);
        this.dashboardElements.approvedVacations.textContent = 
            formatNumber(stats.approved);
        this.dashboardElements.rejectedVacations.textContent = 
            formatNumber(stats.rejected);
    }

    updatePerformanceStats(stats) {
        this.dashboardElements.pendingReviews.textContent = 
            formatNumber(stats.pendingCount);
        this.dashboardElements.averageRating.textContent = 
            stats.averageRating.toFixed(1);
        this.dashboardElements.lastReviewUpdate.textContent = 
            stats.lastUpdate ? formatDate(stats.lastUpdate) : '-';
    }

    updateCharts(workforceData, attendanceData) {
        // تحديث رسم تحليل القوى العاملة
        this.charts.updateLineChart('workforceAnalysisChart', {
            labels: workforceData.labels,
            datasets: [
                {
                    data: workforceData.hired,
                    label: 'موظفون جدد'
                },
                {
                    data: workforceData.terminated,
                    label: 'إنهاء خدمة'
                }
            ]
        });

        // تحديث رسم تحليل الحضور
        this.charts.updatePieChart('attendanceAnalysisChart', {
            labels: attendanceData.labels,
            data: attendanceData.values
        });
    }

    renderLatestRequests(requests) {
        const tbody = this.dashboardElements.latestRequestsTable;
        tbody.innerHTML = '';

        requests.forEach(request => {
            const tr = this.createRequestRow(request);
            tbody.appendChild(tr);
        });
    }

    createRequestRow(request) {
        const template = this.requestRowTemplate.content.cloneNode(true);
        const tr = template.querySelector('tr');
        
        tr.querySelector('.request-number').textContent = request.number;
        tr.querySelector('.request-date').textContent = 
            formatDate(request.date);
        tr.querySelector('.employee-name').textContent = request.employee;
        tr.querySelector('.request-description').textContent = 
            request.description;
        
        const typeCell = tr.querySelector('.request-type');
        typeCell.textContent = this.translateRequestType(request.type);
        typeCell.classList.add(request.type.toLowerCase());
        
        const statusCell = tr.querySelector('.request-status');
        statusCell.textContent = this.translateRequestStatus(request.status);
        statusCell.classList.add(request.status.toLowerCase());

        // إضافة مستمعات الأحداث للأزرار
        tr.querySelector('.view-request').addEventListener('click', 
            () => this.viewRequest(request.id));
        
        const approveButton = tr.querySelector('.approve-request');
        const rejectButton = tr.querySelector('.reject-request');
        
        if (request.status === 'pending') {
            approveButton.addEventListener('click', 
                () => this.approveRequest(request.id));
            rejectButton.addEventListener('click', 
                () => this.rejectRequest(request.id));
        } else {
            approveButton.style.display = 'none';
            rejectButton.style.display = 'none';
        }

        return tr;
    }

    attachEventListeners() {
        // مستمعات أحداث الإجراءات السريعة
        document.getElementById('addEmployee')?.addEventListener('click', 
            () => this.showEmployeeModal());
        document.getElementById('recordAttendance')?.addEventListener('click', 
            () => this.showAttendanceModal());
        document.getElementById('requestVacation')?.addEventListener('click', 
            () => this.showVacationModal());
        document.getElementById('startReview')?.addEventListener('click', 
            () => this.showReviewModal());

        // مستمعات أحداث الفلترة
        this.filterElements.workforceChartPeriod.addEventListener('change', 
            () => this.loadWorkforceAnalysis());
        this.filterElements.attendancePeriod.addEventListener('change', 
            () => this.loadAttendanceAnalysis());

        // مستمعات أحداث التصدير
        document.getElementById('exportWorkforceChart')?.addEventListener('click', 
            () => this.exportChart('workforceAnalysisChart'));
        document.getElementById('exportAttendanceChart')?.addEventListener('click', 
            () => this.exportChart('attendanceAnalysisChart'));

        // مستمعات أحداث عرض الكل
        document.getElementById('viewAllRequests')?.addEventListener('click', 
            () => this.navigateToRequests());
    }

    // توابع مساعدة
    translateRequestType(type) {
        const typeMap = {
            vacation: 'إجازة',
            attendance: 'حضور وانصراف',
            performance: 'تقييم أداء'
        };
        return typeMap[type] || type;
    }

    translateRequestStatus(status) {
        const statusMap = {
            pending: 'معلق',
            approved: 'معتمد',
            rejected: 'مرفوض'
        };
        return statusMap[status] || status;
    }

    updateDateTime() {
        document.getElementById('currentDateTime').textContent = 
            new Date().toISOString().slice(0, 19).replace('T', ' ');
    }

    showLoading() {
        const loader = document.createElement('div');
        loader.className = 'loading-overlay';
        loader.innerHTML = '<div class="loading-spinner"></div>';
        document.body.appendChild(loader);
    }

    hideLoading() {
        document.querySelector('.loading-overlay')?.remove();
    }

    showError(message) {
        console.error(message);
        // يمكن تحسين هذه الدالة لعرض رسائل خطأ أكثر جاذبية
        alert(message);
    }

    showSuccess(message) {
        // يمكن تحسين هذه الدالة لعرض رسائل نجاح أكثر جاذبية
        alert(message);
    }
}

// تهيئة التطبيق عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    new HR();
});