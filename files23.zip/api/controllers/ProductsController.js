/**
 * وحدة التحكم بالمنتجات
 * التاريخ: 2025-05-09 03:22:43
 * المستخدم: mostafamohammad7760
 */

const ProductService = require('../services/ProductService');
const CategoryService = require('../services/CategoryService');
const { uploadImage } = require('../utils/fileUploader');
const { validateProduct } = require('../validators/productValidator');
const { ApiError, handleAsync } = require('../utils/errorHandler');
const cache = require('../utils/cache');

class ProductsController {
    constructor() {
        this.productService = new ProductService();
        this.categoryService = new CategoryService();
        this.CACHE_TTL = 3600; // مدة صلاحية الكاش بالثواني
    }

    /**
     * إنشاء منتج جديد
     * @route POST /api/products
     */
    createProduct = handleAsync(async (req, res) => {
        // التحقق من صحة البيانات
        const { error } = validateProduct(req.body);
        if (error) {
            throw new ApiError(400, error.details[0].message);
        }

        // معالجة الصورة إذا وجدت
        let imageUrl = null;
        if (req.files && req.files.image) {
            imageUrl = await uploadImage(req.files.image, 'products');
        }

        // إنشاء المنتج
        const productData = {
            ...req.body,
            image_url: imageUrl,
            created_by: req.user.id
        };

        const product = await this.productService.createProduct(productData);

        // حذف الكاش
        await cache.del('products:all');
        await cache.del(`categories:${product.category_id}:products`);

        res.status(201).json({
            success: true,
            data: product
        });
    });

    /**
     * تحديث منتج
     * @route PUT /api/products/:id
     */
    updateProduct = handleAsync(async (req, res) => {
        const { id } = req.params;

        // التحقق من وجود المنتج
        const existingProduct = await this.productService.getProductById(id);
        if (!existingProduct) {
            throw new ApiError(404, 'المنتج غير موجود');
        }

        // التحقق من صحة البيانات
        const { error } = validateProduct(req.body);
        if (error) {
            throw new ApiError(400, error.details[0].message);
        }

        // معالجة الصورة الجديدة إذا وجدت
        let imageUrl = existingProduct.image_url;
        if (req.files && req.files.image) {
            imageUrl = await uploadImage(req.files.image, 'products');
            // حذف الصورة القديمة
            if (existingProduct.image_url) {
                await this.deleteOldImage(existingProduct.image_url);
            }
        }

        // تحديث المنتج
        const productData = {
            ...req.body,
            image_url: imageUrl,
            updated_by: req.user.id
        };

        const updatedProduct = await this.productService.updateProduct(id, productData);

        // حذف الكاش
        await cache.del(`products:${id}`);
        await cache.del('products:all');
        await cache.del(`categories:${updatedProduct.category_id}:products`);
        if (existingProduct.category_id !== updatedProduct.category_id) {
            await cache.del(`categories:${existingProduct.category_id}:products`);
        }

        res.json({
            success: true,
            data: updatedProduct
        });
    });

    /**
     * حذف منتج
     * @route DELETE /api/products/:id
     */
    deleteProduct = handleAsync(async (req, res) => {
        const { id } = req.params;

        // التحقق من وجود المنتج
        const product = await this.productService.getProductById(id);
        if (!product) {
            throw new ApiError(404, 'المنتج غير موجود');
        }

        // التحقق من إمكانية الحذف
        const canDelete = await this.productService.canDeleteProduct(id);
        if (!canDelete.allowed) {
            throw new ApiError(400, canDelete.reason);
        }

        // حذف المنتج
        await this.productService.deleteProduct(id);

        // حذف الصورة إذا وجدت
        if (product.image_url) {
            await this.deleteOldImage(product.image_url);
        }

        // حذف الكاش
        await cache.del(`products:${id}`);
        await cache.del('products:all');
        await cache.del(`categories:${product.category_id}:products`);

        res.json({
            success: true,
            message: 'تم حذف المنتج بنجاح'
        });
    });

    /**
     * الحصول على قائمة المنتجات
     * @route GET /api/products
     */
    getProducts = handleAsync(async (req, res) => {
        const filters = {
            category_id: req.query.category_id,
            search: req.query.search,
            min_price: req.query.min_price,
            max_price: req.query.max_price,
            in_stock: req.query.in_stock === 'true'
        };

        const pagination = {
            page: parseInt(req.query.page) || 1,
            limit: parseInt(req.query.limit) || 10
        };

        const sorting = {
            field: req.query.sort_by || 'created_at',
            order: req.query.order || 'desc'
        };

        // محاولة جلب النتائج من الكاش
        const cacheKey = this.generateCacheKey('products', filters, pagination, sorting);
        let products = await cache.get(cacheKey);

        if (!products) {
            // جلب المنتجات من قاعدة البيانات
            products = await this.productService.getProducts(filters, pagination, sorting);
            
            // حفظ النتائج في الكاش
            await cache.set(cacheKey, products, this.CACHE_TTL);
        }

        res.json({
            success: true,
            data: products.data,
            pagination: products.pagination
        });
    });

    /**
     * الحصول على تفاصيل منتج محدد
     * @route GET /api/products/:id
     */
    getProductById = handleAsync(async (req, res) => {
        const { id } = req.params;

        // محاولة جلب المنتج من الكاش
        const cacheKey = `products:${id}`;
        let product = await cache.get(cacheKey);

        if (!product) {
            // جلب المنتج من قاعدة البيانات
            product = await this.productService.getProductById(id);
            if (!product) {
                throw new ApiError(404, 'المنتج غير موجود');
            }

            // حفظ المنتج في الكاش
            await cache.set(cacheKey, product, this.CACHE_TTL);
        }

        res.json({
            success: true,
            data: product
        });
    });

    /**
     * تحديث سعر منتج
     * @route PATCH /api/products/:id/price
     */
    updateProductPrice = handleAsync(async (req, res) => {
        const { id } = req.params;
        const { price, cost } = req.body;

        if (!price && !cost) {
            throw new ApiError(400, 'يجب تحديد السعر أو التكلفة');
        }

        const updatedProduct = await this.productService.updateProductPrice(id, {
            price,
            cost,
            updated_by: req.user.id
        });

        // حذف الكاش
        await cache.del(`products:${id}`);
        await cache.del('products:all');

        res.json({
            success: true,
            data: updatedProduct
        });
    });

    /**
     * تحديث مخزون منتج
     * @route PATCH /api/products/:id/stock
     */
    updateProductStock = handleAsync(async (req, res) => {
        const { id } = req.params;
        const { quantity, notes } = req.body;

        if (!quantity) {
            throw new ApiError(400, 'يجب تحديد الكمية');
        }

        const updatedProduct = await this.productService.updateProductStock(id, {
            quantity,
            notes,
            updated_by: req.user.id
        });

        // حذف الكاش
        await cache.del(`products:${id}`);
        await cache.del('products:all');

        res.json({
            success: true,
            data: updatedProduct
        });
    });

    /**
     * توليد مفتاح الكاش
     * @private
     */
    generateCacheKey(prefix, filters, pagination, sorting) {
        return `${prefix}:${JSON.stringify(filters)}:${JSON.stringify(pagination)}:${JSON.stringify(sorting)}`;
    }
}

module.exports = new ProductsController();