-- جداول وحدة المدفوعات والمقبوضات

-- جدول الصناديق النقدية
CREATE TABLE cash_registers (
    register_id VARCHAR(20) PRIMARY KEY,
    register_name_ar VARCHAR(100) NOT NULL,
    register_name_en VARCHAR(100),
    location VARCHAR(200),
    currency_code CHAR(3) NOT NULL,
    cashier_id VARCHAR(50),
    current_balance DECIMAL(18,2) DEFAULT 0,
    status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50)
);

-- جدول الحسابات البنكية
CREATE TABLE bank_accounts (
    account_id VARCHAR(20) PRIMARY KEY,
    bank_name VARCHAR(100) NOT NULL,
    branch_name VARCHAR(100),
    account_number VARCHAR(50) NOT NULL,
    iban VARCHAR(50),
    swift_code VARCHAR(20),
    currency_code CHAR(3) NOT NULL,
    account_type ENUM('current', 'savings', 'deposit') DEFAULT 'current',
    current_balance DECIMAL(18,2) DEFAULT 0,
    status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50)
);

-- جدول سندات الصرف
CREATE TABLE payment_vouchers (
    voucher_id VARCHAR(20) PRIMARY KEY,
    voucher_date DATE NOT NULL,
    beneficiary_name VARCHAR(200) NOT NULL,
    beneficiary_type ENUM('vendor', 'employee', 'other') NOT NULL,
    beneficiary_id VARCHAR(50),
    amount DECIMAL(18,2) NOT NULL,
    currency_code CHAR(3) NOT NULL,
    payment_method ENUM('cash', 'cheque', 'bank_transfer', 'credit_card') NOT NULL,
    payment_reference VARCHAR(50),
    description TEXT,
    status ENUM('draft', 'approved', 'paid', 'cancelled') DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    approved_at TIMESTAMP NULL,
    approved_by VARCHAR(50),
    paid_at TIMESTAMP NULL,
    paid_by VARCHAR(50)
);

-- جدول سندات القبض
CREATE TABLE receipt_vouchers (
    voucher_id VARCHAR(20) PRIMARY KEY,
    voucher_date DATE NOT NULL,
    payer_name VARCHAR(200) NOT NULL,
    payer_type ENUM('customer', 'employee', 'other') NOT NULL,
    payer_id VARCHAR(50),
    amount DECIMAL(18,2) NOT NULL,
    currency_code CHAR(3) NOT NULL,
    receipt_method ENUM('cash', 'cheque', 'bank_transfer', 'credit_card') NOT NULL,
    receipt_reference VARCHAR(50),
    description TEXT,
    status ENUM('draft', 'approved', 'received', 'cancelled') DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    approved_at TIMESTAMP NULL,
    approved_by VARCHAR(50),
    received_at TIMESTAMP NULL,
    received_by VARCHAR(50)
);

-- جدول الشيكات الصادرة
CREATE TABLE issued_cheques (
    cheque_id VARCHAR(20) PRIMARY KEY,
    voucher_id VARCHAR(20),
    cheque_number VARCHAR(50) NOT NULL,
    bank_account_id VARCHAR(20) NOT NULL,
    beneficiary_name VARCHAR(200) NOT NULL,
    amount DECIMAL(18,2) NOT NULL,
    issue_date DATE NOT NULL,
    due_date DATE NOT NULL,
    status ENUM('issued', 'cleared', 'cancelled', 'returned') DEFAULT 'issued',
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    FOREIGN KEY (voucher_id) REFERENCES payment_vouchers(voucher_id),
    FOREIGN KEY (bank_account_id) REFERENCES bank_accounts(account_id)
);

-- جدول الشيكات الواردة
CREATE TABLE received_cheques (
    cheque_id VARCHAR(20) PRIMARY KEY,
    voucher_id VARCHAR(20),
    cheque_number VARCHAR(50) NOT NULL,
    bank_name VARCHAR(100) NOT NULL,
    drawer_name VARCHAR(200) NOT NULL,
    amount DECIMAL(18,2) NOT NULL,
    receipt_date DATE NOT NULL,
    due_date DATE NOT NULL,
    deposit_account_id VARCHAR(20),
    status ENUM('received', 'deposited', 'cleared', 'returned') DEFAULT 'received',
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    FOREIGN KEY (voucher_id) REFERENCES receipt_vouchers(voucher_id),
    FOREIGN KEY (deposit_account_id) REFERENCES bank_accounts(account_id)
);

-- جدول حركات الصندوق
CREATE TABLE cash_transactions (
    transaction_id VARCHAR(20) PRIMARY KEY,
    register_id VARCHAR(20) NOT NULL,
    transaction_date DATETIME NOT NULL,
    transaction_type ENUM('deposit', 'withdrawal', 'transfer') NOT NULL,
    amount DECIMAL(18,2) NOT NULL,
    reference_type VARCHAR(50),
    reference_id VARCHAR(50),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    FOREIGN KEY (register_id) REFERENCES cash_registers(register_id)
);

-- جدول التسويات البنكية
CREATE TABLE bank_reconciliations (
    reconciliation_id VARCHAR(20) PRIMARY KEY,
    bank_account_id VARCHAR(20) NOT NULL,
    statement_date DATE NOT NULL,
    statement_balance DECIMAL(18,2) NOT NULL,
    book_balance DECIMAL(18,2) NOT NULL,
    status ENUM('draft', 'completed') DEFAULT 'draft',
    completed_at TIMESTAMP NULL,
    completed_by VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    FOREIGN KEY (bank_account_id) REFERENCES bank_accounts(account_id)
);

-- جدول بنود التسوية
CREATE TABLE reconciliation_items (
    item_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    reconciliation_id VARCHAR(20) NOT NULL,
    transaction_date DATE NOT NULL,
    description TEXT,
    amount DECIMAL(18,2) NOT NULL,
    item_type ENUM('outstanding_cheque', 'deposit_in_transit', 'bank_charge', 'bank_interest', 'error') NOT NULL,
    status ENUM('pending', 'cleared') DEFAULT 'pending',
    cleared_date DATE NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (reconciliation_id) REFERENCES bank_reconciliations(reconciliation_id)
);

-- إجراءات مخزنة

DELIMITER //

-- إجراء تحديث رصيد الصندوق
CREATE PROCEDURE update_cash_register_balance(
    IN p_register_id VARCHAR(20),
    IN p_amount DECIMAL(18,2),
    IN p_type ENUM('deposit', 'withdrawal')
)
BEGIN
    IF p_type = 'deposit' THEN
        UPDATE cash_registers 
        SET current_balance = current_balance + p_amount
        WHERE register_id = p_register_id;
    ELSE
        UPDATE cash_registers 
        SET current_balance = current_balance - p_amount
        WHERE register_id = p_register_id;
    END IF;
END //

-- إجراء تحديث رصيد الحساب البنكي
CREATE PROCEDURE update_bank_account_balance(
    IN p_account_id VARCHAR(20),
    IN p_amount DECIMAL(18,2),
    IN p_type ENUM('deposit', 'withdrawal')
)
BEGIN
    IF p_type = 'deposit' THEN
        UPDATE bank_accounts 
        SET current_balance = current_balance + p_amount
        WHERE account_id = p_account_id;
    ELSE
        UPDATE bank_accounts 
        SET current_balance = current_balance - p_amount
        WHERE account_id = p_account_id;
    END IF;
END //

DELIMITER ;