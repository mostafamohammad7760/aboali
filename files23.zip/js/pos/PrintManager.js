/**
 * مدير الطباعة - إدارة طباعة الفواتير والإيصالات في نظام نقاط البيع
 * @module PrintManager
 * التاريخ: 2025-05-09 03:11:51
 * المستخدم: mostafamohammad7760
 */

export class PrintManager {
    constructor(database) {
        this.db = database;
        this.printerConfig = {
            defaultPrinter: process.env.DEFAULT_PRINTER,
            paperWidth: 80, // عرض الورق بالملليمتر
            characterWidth: 48, // عدد الأحرف في السطر
            encoding: 'utf8',
            margins: {
                top: 0,
                bottom: 0,
                left: 0,
                right: 0
            }
        };

        // أنواع المستندات
        this.documentTypes = {
            INVOICE: 'invoice',
            RECEIPT: 'receipt',
            REPORT: 'report',
            KITCHEN_ORDER: 'kitchen_order',
            LABEL: 'label'
        };
    }

    /**
     * طباعة فاتورة
     * @param {Object} invoice - بيانات الفاتورة
     * @param {Object} options - خيارات الطباعة
     */
    async printInvoice(invoice, options = {}) {
        try {
            const template = await this.getInvoiceTemplate(invoice.type);
            const formattedData = await this.formatInvoiceData(invoice);
            const content = await this.renderTemplate(template, formattedData);

            return await this.print({
                type: this.documentTypes.INVOICE,
                content,
                copies: options.copies || 1,
                printer: options.printer || this.printerConfig.defaultPrinter
            });
        } catch (error) {
            console.error('Error printing invoice:', error);
            throw new Error('فشل طباعة الفاتورة');
        }
    }

    /**
     * تنسيق بيانات الفاتورة
     * @param {Object} invoice - بيانات الفاتورة
     */
    async formatInvoiceData(invoice) {
        // تحميل معلومات الشركة
        const companyInfo = await this.getCompanyInfo();

        // تنسيق التاريخ والوقت
        const dateTime = new Date(invoice.created_at);
        const formattedDate = dateTime.toLocaleDateString('ar-SA');
        const formattedTime = dateTime.toLocaleTimeString('ar-SA');

        // تنسيق المنتجات
        const items = invoice.items.map(item => ({
            ...item,
            totalPrice: this.formatCurrency(item.price * item.quantity),
            unitPrice: this.formatCurrency(item.price)
        }));

        // تنسيق الإجماليات
        const totals = {
            subtotal: this.formatCurrency(invoice.totals.subtotal),
            tax: this.formatCurrency(invoice.totals.tax),
            discount: this.formatCurrency(invoice.totals.discount),
            total: this.formatCurrency(invoice.totals.total)
        };

        // إنشاء رمز QR للفاتورة الضريبية
        const qrCode = await this.generateInvoiceQR(invoice);

        return {
            company: companyInfo,
            invoice_number: invoice.invoice_number,
            date: formattedDate,
            time: formattedTime,
            customer: invoice.customer,
            items,
            totals,
            qrCode,
            footer: await this.getInvoiceFooter()
        };
    }

    /**
     * طباعة إيصال
     * @param {Object} receipt - بيانات الإيصال
     * @param {Object} options - خيارات الطباعة
     */
    async printReceipt(receipt, options = {}) {
        try {
            const template = await this.getReceiptTemplate();
            const formattedData = await this.formatReceiptData(receipt);
            const content = await this.renderTemplate(template, formattedData);

            return await this.print({
                type: this.documentTypes.RECEIPT,
                content,
                copies: options.copies || 1,
                printer: options.printer || this.printerConfig.defaultPrinter
            });
        } catch (error) {
            console.error('Error printing receipt:', error);
            throw new Error('فشل طباعة الإيصال');
        }
    }

    /**
     * طباعة طلب للمطبخ
     * @param {Object} order - بيانات الطلب
     */
    async printKitchenOrder(order) {
        try {
            const template = await this.getKitchenOrderTemplate();
            const formattedData = await this.formatKitchenOrderData(order);
            const content = await this.renderTemplate(template, formattedData);

            return await this.print({
                type: this.documentTypes.KITCHEN_ORDER,
                content,
                printer: process.env.KITCHEN_PRINTER
            });
        } catch (error) {
            console.error('Error printing kitchen order:', error);
            throw new Error('فشل طباعة طلب المطبخ');
        }
    }

    /**
     * طباعة تقرير
     * @param {Object} report - بيانات التقرير
     * @param {Object} options - خيارات الطباعة
     */
    async printReport(report, options = {}) {
        try {
            const template = await this.getReportTemplate(report.type);
            const formattedData = await this.formatReportData(report);
            const content = await this.renderTemplate(template, formattedData);

            return await this.print({
                type: this.documentTypes.REPORT,
                content,
                printer: options.printer || this.printerConfig.defaultPrinter
            });
        } catch (error) {
            console.error('Error printing report:', error);
            throw new Error('فشل طباعة التقرير');
        }
    }

    /**
     * تنسيق النص للطباعة
     * @param {string} text - النص المراد تنسيقه
     * @param {Object} options - خيارات التنسيق
     */
    formatText(text, options = {}) {
        const {
            width = this.printerConfig.characterWidth,
            align = 'right',
            padding = ' '
        } = options;

        let formattedText = text.toString();

        // التحكم في العرض
        if (formattedText.length > width) {
            formattedText = formattedText.substring(0, width);
        } else if (formattedText.length < width) {
            const spaces = width - formattedText.length;
            if (align === 'center') {
                const leftPad = Math.floor(spaces / 2);
                const rightPad = spaces - leftPad;
                formattedText = padding.repeat(leftPad) + formattedText + padding.repeat(rightPad);
            } else if (align === 'left') {
                formattedText = formattedText + padding.repeat(spaces);
            } else {
                formattedText = padding.repeat(spaces) + formattedText;
            }
        }

        return formattedText;
    }

    /**
     * إضافة خط فاصل
     * @param {string} char - الرمز المستخدم للخط
     */
    addSeparatorLine(char = '-') {
        return char.repeat(this.printerConfig.characterWidth);
    }

    /**
     * تنسيق العملة
     * @param {number} amount - المبلغ
     */
    formatCurrency(amount) {
        return new Intl.NumberFormat('ar-SA', {
            style: 'currency',
            currency: 'SAR'
        }).format(amount);
    }

    /**
     * الحصول على قالب المستند
     * @param {string} type - نوع المستند
     */
    async getTemplate(type) {
        const [template] = await this.db.executeQuery(`
            SELECT content
            FROM print_templates
            WHERE type = ?
            AND is_active = 1
            ORDER BY version DESC
            LIMIT 1
        `, [type]);

        if (!template) {
            throw new Error('قالب الطباعة غير موجود');
        }

        return template.content;
    }

    /**
     * تسجيل عملية الطباعة
     * @param {Object} printJob - بيانات الطباعة
     */
    async logPrintJob(printJob) {
        const query = `
            INSERT INTO print_logs (
                job_id,
                type,
                document_id,
                printer,
                copies,
                status,
                created_by
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
        `;

        await this.db.executeQuery(query, [
            this.generatePrintJobId(),
            printJob.type,
            printJob.document_id,
            printJob.printer,
            printJob.copies,
            printJob.status,
            this.currentUser
        ]);
    }

    /**
     * توليد معرف فريد لمهمة الطباعة
     */
    generatePrintJobId() {
        return 'PRN-' + Date.now().toString(36).toUpperCase();
    }
}