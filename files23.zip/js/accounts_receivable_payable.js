// استيراد المكونات والخدمات اللازمة
import { AccountsAPI } from './api/accounts_api.js';
import { ChartManager } from './utils/chart_manager.js';
import { 
    formatCurrency, 
    formatDate, 
    formatPercentage,
    calculateAgingBucket 
} from './utils/formatters.js';
import { 
    validateInvoice, 
    validatePayment, 
    validateCustomer,
    validateSupplier 
} from './utils/validators.js';

class AccountsReceivablePayable {
    constructor() {
        // تهيئة الخدمات
        this.api = new AccountsAPI();
        this.charts = new ChartManager();
        this.currentUser = 'mostafamohammad7760';
        
        // تهيئة المكونات والبيانات
        this.initializeComponents();
        this.attachEventListeners();
        this.loadDashboardData();
        
        // تحديث الوقت كل ثانية
        this.updateDateTime();
        setInterval(() => this.updateDateTime(), 1000);
    }

    // تهيئة مكونات الواجهة
    initializeComponents() {
        // عناصر الملخص
        this.summaryElements = {
            // الحسابات المدينة
            totalReceivables: document.getElementById('totalReceivables'),
            overdueReceivables: document.getElementById('overdueReceivables'),
            collectedAmount: document.getElementById('collectedAmount'),
            receivableProgress: document.querySelector('.receivable .progress'),
            receivableProgressText: document.querySelector('.receivable .progress-text'),

            // الحسابات الدائنة
            totalPayables: document.getElementById('totalPayables'),
            overduePayables: document.getElementById('overduePayables'),
            paidAmount: document.getElementById('paidAmount'),
            payableProgress: document.querySelector('.payable .progress'),
            payableProgressText: document.querySelector('.payable .progress-text')
        };

        // عناصر الفلترة
        this.filterElements = {
            receivablePeriod: document.getElementById('receivablePeriod'),
            payablePeriod: document.getElementById('payablePeriod'),
            invoiceType: document.getElementById('invoiceType')
        };

        // تهيئة الرسوم البيانية
        this.initializeCharts();
    }

    // تهيئة الرسوم البيانية
    initializeCharts() {
        // رسم تحليل أعمار المدينين
        this.charts.initializeBarChart('receivablesAgingChart', {
            labels: ['0-30', '31-60', '61-90', '90+'],
            datasets: [{
                label: 'المبالغ المستحقة',
                data: [],
                backgroundColor: [
                    'rgba(46, 204, 113, 0.6)',
                    'rgba(52, 152, 219, 0.6)',
                    'rgba(241, 196, 15, 0.6)',
                    'rgba(231, 76, 60, 0.6)'
                ]
            }],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => formatCurrency(value)
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: context => formatCurrency(context.parsed.y)
                        }
                    }
                }
            }
        });

        // رسم تحليل أعمار الدائنين
        this.charts.initializeBarChart('payablesAgingChart', {
            labels: ['0-30', '31-60', '61-90', '90+'],
            datasets: [{
                label: 'المبالغ المستحقة',
                data: [],
                backgroundColor: [
                    'rgba(46, 204, 113, 0.6)',
                    'rgba(52, 152, 219, 0.6)',
                    'rgba(241, 196, 15, 0.6)',
                    'rgba(231, 76, 60, 0.6)'
                ]
            }],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => formatCurrency(value)
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: context => formatCurrency(context.parsed.y)
                        }
                    }
                }
            }
        });
    }

    // تحميل بيانات لوحة المعلومات
    async loadDashboardData() {
        try {
            this.showLoading();

            const [
                receivablesSummary,
                payablesSummary,
                receivablesAging,
                payablesAging,
                dueInvoices
            ] = await Promise.all([
                this.api.getReceivablesSummary(this.filterElements.receivablePeriod.value),
                this.api.getPayablesSummary(this.filterElements.payablePeriod.value),
                this.api.getReceivablesAging(),
                this.api.getPayablesAging(),
                this.api.getDueInvoices(this.filterElements.invoiceType.value)
            ]);

            this.updateSummary(receivablesSummary, payablesSummary);
            this.updateAgingCharts(receivablesAging, payablesAging);
            this.renderDueInvoices(dueInvoices);

            this.hideLoading();
        } catch (error) {
            this.hideLoading();
            this.showError('حدث خطأ أثناء تحميل البيانات');
            console.error('Dashboard loading error:', error);
        }
    }

    // تحديث ملخص الحسابات
    updateSummary(receivables, payables) {
        // تحديث الحسابات المدينة
        this.summaryElements.totalReceivables.textContent = 
            formatCurrency(receivables.totalAmount);
        this.summaryElements.overdueReceivables.textContent = 
            formatCurrency(receivables.overdueAmount);
        this.summaryElements.collectedAmount.textContent = 
            formatCurrency(receivables.collectedAmount);

        const receivableRate = (receivables.collectedAmount / receivables.totalAmount) * 100;
        this.summaryElements.receivableProgress.style.width = `${receivableRate}%`;
        this.summaryElements.receivableProgressText.textContent = 
            formatPercentage(receivableRate);

        // تحديث الحسابات الدائنة
        this.summaryElements.totalPayables.textContent = 
            formatCurrency(payables.totalAmount);
        this.summaryElements.overduePayables.textContent = 
            formatCurrency(payables.overdueAmount);
        this.summaryElements.paidAmount.textContent = 
            formatCurrency(payables.paidAmount);

        const payableRate = (payables.paidAmount / payables.totalAmount) * 100;
        this.summaryElements.payableProgress.style.width = `${payableRate}%`;
        this.summaryElements.payableProgressText.textContent = 
            formatPercentage(payableRate);
    }

    // تحديث رسوم تحليل الأعمار
    updateAgingCharts(receivablesAging, payablesAging) {
        this.charts.updateBarChart('receivablesAgingChart', {
            datasets: [{
                data: [
                    receivablesAging['0-30'],
                    receivablesAging['31-60'],
                    receivablesAging['61-90'],
                    receivablesAging['90+']
                ]
            }]
        });

        this.charts.updateBarChart('payablesAgingChart', {
            datasets: [{
                data: [
                    payablesAging['0-30'],
                    payablesAging['31-60'],
                    payablesAging['61-90'],
                    payablesAging['90+']
                ]
            }]
        });
    }

    // عرض الفواتير المستحقة
    renderDueInvoices(invoices) {
        const tbody = document.getElementById('dueInvoicesTable');
        tbody.innerHTML = '';

        invoices.forEach(invoice => {
            const tr = this.createInvoiceRow(invoice);
            tbody.appendChild(tr);
        });
    }

    // إنشاء صف فاتورة
    createInvoiceRow(invoice) {
        const template = document.getElementById('invoiceRowTemplate');
        const tr = template.content.cloneNode(true);

        tr.querySelector('.invoice-number').textContent = invoice.number;
        tr.querySelector('.party-name').textContent = invoice.partyName;
        tr.querySelector('.invoice-date').textContent = formatDate(invoice.date);
        tr.querySelector('.due-date').textContent = formatDate(invoice.dueDate);
        tr.querySelector('.total-amount').textContent = formatCurrency(invoice.totalAmount);
        tr.querySelector('.remaining-amount').textContent = formatCurrency(invoice.remainingAmount);
        
        const daysCount = calculateAgingBucket(invoice.dueDate);
        tr.querySelector('.days-count').textContent = daysCount;

        const statusBadge = tr.querySelector('.status-badge');
        this.setInvoiceStatus(statusBadge, invoice.status, daysCount);

        // إضافة مستمعات الأحداث للأزرار
        tr.querySelector('.view-invoice').addEventListener('click', 
            () => this.viewInvoice(invoice.id));
        tr.querySelector('.record-payment').addEventListener('click', 
            () => this.showPaymentModal(invoice));
        tr.querySelector('.send-reminder').addEventListener('click', 
            () => this.sendPaymentReminder(invoice));

        return tr;
    }

    // تحديد حالة الفاتورة
    setInvoiceStatus(badge, status, daysCount) {
        let className = '';
        let text = '';

        switch (status) {
            case 'paid':
                className = 'success';
                text = 'مدفوعة';
                break;
            case 'partially_paid':
                className = 'warning';
                text = 'مدفوعة جزئياً';
                break;
            default:
                if (daysCount > 90) {
                    className = 'danger';
                    text = 'متأخرة';
                } else if (daysCount > 60) {
                    className = 'warning';
                    text = 'متأخرة';
                } else {
                    className = 'info';
                    text = 'مستحقة';
                }
        }

        badge.className = `status-badge ${className}`;
        badge.textContent = text;
    }

    // إضافة مستمعات الأحداث
    attachEventListeners() {
        // مستمعات أحداث الفلترة
        this.filterElements.receivablePeriod.addEventListener('change', 
            () => this.loadDashboardData());
        this.filterElements.payablePeriod.addEventListener('change', 
            () => this.loadDashboardData());
        this.filterElements.invoiceType.addEventListener('change', 
            () => this.loadDueInvoices());

        // مستمعات أحداث الإجراءات السريعة
        document.getElementById('createSalesInvoice')?.addEventListener('click', 
            () => this.showCreateInvoiceModal('sales'));
        document.getElementById('createPurchaseInvoice')?.addEventListener('click', 
            () => this.showCreateInvoiceModal('purchase'));
        document.getElementById('recordPayment')?.addEventListener('click', 
            () => this.showPaymentModal());
        document.getElementById('recordReceipt')?.addEventListener('click', 
            () => this.showReceiptModal());

        // مستمع حدث تصدير تحليل الأعمار
        document.getElementById('exportAging')?.addEventListener('click', 
            () => this.exportAgingAnalysis());
    }

    // تحديث التاريخ والوقت
    updateDateTime() {
        const now = new Date();
        document.getElementById('currentDateTime').textContent = 
            now.toISOString().slice(0, 19).replace('T', ' ');
    }

    // إظهار التحميل
    showLoading() {
        const loader = document.createElement('div');
        loader.className = 'loading-overlay';
        loader.innerHTML = '<div class="loading-spinner"></div>';
        document.body.appendChild(loader);
    }

    // إخفاء التحميل
    hideLoading() {
        document.querySelector('.loading-overlay')?.remove();
    }

    // إظهار رسالة خطأ
    showError(message) {
        // يمكن تحسين هذه الدالة لعرض رسائل خطأ أكثر جاذبية
        console.error(message);
        alert(message);
    }

    // إظهار رسالة نجاح
    showSuccess(message) {
        // يمكن تحسين هذه الدالة لعرض رسائل نجاح أكثر جاذبية
        alert(message);
    }
}

// تهيئة التطبيق عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    new AccountsReceivablePayable();
});