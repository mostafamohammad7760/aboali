export class HRAPI {
    constructor() {
        this.baseUrl = '/api/v1/hr';
        this.defaultHeaders = {
            'Content-Type': 'application/json',
            'X-User-Id': 'mostafamohammad7760',
            'X-Timestamp': new Date().toISOString()
        };
    }

    async request(endpoint, options = {}) {
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                ...options,
                headers: {
                    ...this.defaultHeaders,
                    ...options.headers
                }
            });

            if (!response.ok) {
                throw await this.handleErrorResponse(response);
            }

            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            throw this.createUserFriendlyError(error);
        }
    }

    // طلبات لوحة المعلومات
    async getWorkforceStats() {
        return this.request('/dashboard/workforce-stats');
    }

    async getAttendanceStats() {
        return this.request('/dashboard/attendance-stats');
    }

    async getVacationStats() {
        return this.request('/dashboard/vacation-stats');
    }

    async getPerformanceStats() {
        return this.request('/dashboard/performance-stats');
    }

    async getWorkforceAnalysis(period = 'month') {
        return this.request(`/dashboard/workforce-analysis?period=${period}`);
    }

    async getAttendanceAnalysis(period = 'month') {
        return this.request(`/dashboard/attendance-analysis?period=${period}`);
    }

    async getLatestRequests() {
        return this.request('/dashboard/latest-requests');
    }

    // طلبات الموظفين
    async getEmployees(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/employees?${queryString}`);
    }

    async getEmployee(employeeId) {
        return this.request(`/employees/${employeeId}`);
    }

    async createEmployee(employeeData) {
        this.validateEmployeeData(employeeData);
        return this.request('/employees', {
            method: 'POST',
            body: JSON.stringify(employeeData)
        });
    }

    async updateEmployee(employeeId, employeeData) {
        this.validateEmployeeData(employeeData);
        return this.request(`/employees/${employeeId}`, {
            method: 'PUT',
            body: JSON.stringify(employeeData)
        });
    }

    async terminateEmployee(employeeId, terminationData) {
        return this.request(`/employees/${employeeId}/terminate`, {
            method: 'PUT',
            body: JSON.stringify(terminationData)
        });
    }

    // طلبات الإدارات
    async getDepartments(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/departments?${queryString}`);
    }

    async getDepartment(departmentId) {
        return this.request(`/departments/${departmentId}`);
    }

    async createDepartment(departmentData) {
        this.validateDepartmentData(departmentData);
        return this.request('/departments', {
            method: 'POST',
            body: JSON.stringify(departmentData)
        });
    }

    async updateDepartment(departmentId, departmentData) {
        this.validateDepartmentData(departmentData);
        return this.request(`/departments/${departmentId}`, {
            method: 'PUT',
            body: JSON.stringify(departmentData)
        });
    }

    async deleteDepartment(departmentId) {
        return this.request(`/departments/${departmentId}`, {
            method: 'DELETE'
        });
    }

    // طلبات الوظائف
    async getJobs(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/jobs?${queryString}`);
    }

    async getJob(jobId) {
        return this.request(`/jobs/${jobId}`);
    }

    async createJob(jobData) {
        this.validateJobData(jobData);
        return this.request('/jobs', {
            method: 'POST',
            body: JSON.stringify(jobData)
        });
    }

    async updateJob(jobId, jobData) {
        this.validateJobData(jobData);
        return this.request(`/jobs/${jobId}`, {
            method: 'PUT',
            body: JSON.stringify(jobData)
        });
    }

    async deleteJob(jobId) {
        return this.request(`/jobs/${jobId}`, {
            method: 'DELETE'
        });
    }

    // طلبات الحضور والانصراف
    async getAttendance(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/attendance?${queryString}`);
    }

    async recordAttendance(attendanceData) {
        this.validateAttendanceData(attendanceData);
        return this.request('/attendance', {
            method: 'POST',
            body: JSON.stringify(attendanceData)
        });
    }

    async updateAttendance(attendanceId, attendanceData) {
        this.validateAttendanceData(attendanceData);
        return this.request(`/attendance/${attendanceId}`, {
            method: 'PUT',
            body: JSON.stringify(attendanceData)
        });
    }

    // طلبات الإجازات
    async getVacations(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/vacations?${queryString}`);
    }

    async getVacation(vacationId) {
        return this.request(`/vacations/${vacationId}`);
    }

    async requestVacation(vacationData) {
        this.validateVacationData(vacationData);
        return this.request('/vacations', {
            method: 'POST',
            body: JSON.stringify(vacationData)
        });
    }

    async approveVacation(vacationId) {
        return this.request(`/vacations/${vacationId}/approve`, {
            method: 'PUT'
        });
    }

    async rejectVacation(vacationId, reason) {
        return this.request(`/vacations/${vacationId}/reject`, {
            method: 'PUT',
            body: JSON.stringify({ reason })
        });
    }

    // طلبات تقييم الأداء
    async getPerformanceReviews(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/performance-reviews?${queryString}`);
    }

    async getPerformanceReview(reviewId) {
        return this.request(`/performance-reviews/${reviewId}`);
    }

    async createPerformanceReview(reviewData) {
        this.validateReviewData(reviewData);
        return this.request('/performance-reviews', {
            method: 'POST',
            body: JSON.stringify(reviewData)
        });
    }

    async submitPerformanceReview(reviewId, reviewData) {
        this.validateReviewData(reviewData);
        return this.request(`/performance-reviews/${reviewId}/submit`, {
            method: 'PUT',
            body: JSON.stringify(reviewData)
        });
    }

    async approvePerformanceReview(reviewId) {
        return this.request(`/performance-reviews/${reviewId}/approve`, {
            method: 'PUT'
        });
    }

    // طلبات التقارير
    async getEmployeeReport(employeeId, params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/employee/${employeeId}?${queryString}`);
    }

    async getDepartmentReport(departmentId, params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/department/${departmentId}?${queryString}`);
    }

    async getAttendanceReport(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/attendance?${queryString}`);
    }

    async getVacationReport(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/vacations?${queryString}`);
    }

    // توابع التحقق من صحة البيانات
    validateEmployeeData(employeeData) {
        const requiredFields = [
            'firstName', 
            'lastName', 
            'gender', 
            'departmentId', 
            'jobId', 
            'hireDate', 
            'contractType', 
            'basicSalary'
        ];
        
        const missingFields = requiredFields.filter(field => !employeeData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        if (employeeData.email && !this.isValidEmail(employeeData.email)) {
            throw new Error('البريد الإلكتروني غير صالح');
        }

        return true;
    }

    validateDepartmentData(departmentData) {
        if (!departmentData.name) {
            throw new Error('اسم الإدارة مطلوب');
        }

        return true;
    }

    validateJobData(jobData) {
        const requiredFields = ['code', 'name'];
        
        const missingFields = requiredFields.filter(field => !jobData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        return true;
    }

    validateAttendanceData(attendanceData) {
        if (!attendanceData.employeeId || !attendanceData.date) {
            throw new Error('رقم الموظف والتاريخ مطلوبان');
        }

        return true;
    }

    validateVacationData(vacationData) {
        if (!vacationData.employeeId || !vacationData.startDate || !vacationData.endDate) {
            throw new Error('رقم الموظف وتاريخ البداية والنهاية مطلوبة');
        }

        if (new Date(vacationData.endDate) <= new Date(vacationData.startDate)) {
            throw new Error('تاريخ النهاية يجب أن يكون بعد تاريخ البداية');
        }

        return true;
    }

    validateReviewData(reviewData) {
        if (!reviewData.employeeId || !reviewData.reviewerId || !reviewData.reviewPeriod) {
            throw new Error('رقم الموظف والمراجع والفترة مطلوبة');
        }

        return true;
    }

    // توابع مساعدة
    isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    // توابع معالجة الأخطاء
    async handleErrorResponse(response) {
        let error;
        try {
            const errorData = await response.json();
            error = new Error(errorData.message || 'حدث خطأ غير معروف');
            error.code = errorData.code;
            error.details = errorData.details;
        } catch {
            error = new Error(`خطأ في الطلب: ${response.status}`);
        }
        error.status = response.status;
        return error;
    }

    createUserFriendlyError(error) {
        const errorMessages = {
            400: 'البيانات المدخلة غير صحيحة',
            401: 'يرجى تسجيل الدخول مرة أخرى',
            403: 'ليس لديك صلاحية للقيام بهذا الإجراء',
            404: 'لم يتم العثور على البيانات المطلوبة',
            409: 'تعارض في البيانات',
            422: 'البيانات المدخلة غير صالحة',
            500: 'حدث خطأ في النظام'
        };

        return new Error(
            errorMessages[error.status] || 
            error.message || 
            'حدث خطأ غير متوقع'
        );
    }
}