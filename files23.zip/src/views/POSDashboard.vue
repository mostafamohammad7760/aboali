<!--
مكون لوحة التحكم الرئيسية لنظام نقاط البيع
التاريخ: 2025-05-09 03:25:57
المستخدم: mostafamohammad7760
-->

<template>
  <div class="pos-dashboard">
    <!-- شريط التنقل العلوي -->
    <header class="pos-header">
      <div class="header-right">
        <button class="menu-toggle" @click="toggleSidebar">
          <i class="fas fa-bars"></i>
        </button>
        <h1>{{ storeName }}</h1>
      </div>
      
      <div class="header-center">
        <div class="shift-info" v-if="currentShift">
          <span>الوردية الحالية: {{ currentShift.id }}</span>
          <span>المبلغ الافتتاحي: {{ formatCurrency(currentShift.openingAmount) }}</span>
          <span>وقت البدء: {{ formatDateTime(currentShift.startedAt) }}</span>
        </div>
      </div>

      <div class="header-left">
        <div class="user-info">
          <span>{{ currentUser.name }}</span>
          <img :src="currentUser.avatar" :alt="currentUser.name" class="user-avatar">
        </div>
        <button class="btn btn-danger" @click="endShift" v-if="currentShift">
          إنهاء الوردية
        </button>
      </div>
    </header>

    <!-- القائمة الجانبية -->
    <aside class="pos-sidebar" :class="{ 'sidebar-collapsed': isSidebarCollapsed }">
      <nav class="sidebar-nav">
        <ul>
          <li>
            <router-link to="/pos/sales" class="nav-link" :class="{ active: currentRoute === 'sales' }">
              <i class="fas fa-shopping-cart"></i>
              <span>المبيعات</span>
            </router-link>
          </li>
          <li>
            <router-link to="/pos/products" class="nav-link" :class="{ active: currentRoute === 'products' }">
              <i class="fas fa-box"></i>
              <span>المنتجات</span>
            </router-link>
          </li>
          <li>
            <router-link to="/pos/customers" class="nav-link" :class="{ active: currentRoute === 'customers' }">
              <i class="fas fa-users"></i>
              <span>العملاء</span>
            </router-link>
          </li>
          <li>
            <router-link to="/pos/reports" class="nav-link" :class="{ active: currentRoute === 'reports' }">
              <i class="fas fa-chart-bar"></i>
              <span>التقارير</span>
            </router-link>
          </li>
          <li>
            <router-link to="/pos/settings" class="nav-link" :class="{ active: currentRoute === 'settings' }">
              <i class="fas fa-cog"></i>
              <span>الإعدادات</span>
            </router-link>
          </li>
        </ul>
      </nav>

      <div class="sidebar-footer">
        <button class="btn btn-light" @click="logout">
          <i class="fas fa-sign-out-alt"></i>
          <span>تسجيل الخروج</span>
        </button>
      </div>
    </aside>

    <!-- المحتوى الرئيسي -->
    <main class="pos-main">
      <!-- شريط الحالة -->
      <div class="status-bar">
        <div class="connection-status" :class="{ 'connected': isOnline }">
          {{ isOnline ? 'متصل' : 'غير متصل' }}
        </div>
        <div class="printer-status" :class="{ 'ready': isPrinterReady }">
          {{ isPrinterReady ? 'الطابعة جاهزة' : 'الطابعة غير جاهزة' }}
        </div>
        <div class="sync-status">
          آخر مزامنة: {{ lastSyncTime }}
        </div>
      </div>

      <!-- منطقة التنبيهات -->
      <div class="alerts-container" v-if="alerts.length">
        <div v-for="alert in alerts" :key="alert.id" 
             class="alert" :class="'alert-' + alert.type">
          <span class="alert-message">{{ alert.message }}</span>
          <button class="alert-close" @click="dismissAlert(alert.id)">×</button>
        </div>
      </div>

      <!-- منطقة المحتوى الديناميكي -->
      <router-view></router-view>
    </main>

    <!-- النوافذ المنبثقة -->
    <end-shift-modal
      v-if="showEndShiftModal"
      :shift="currentShift"
      @confirm="confirmEndShift"
      @cancel="cancelEndShift"
    />

    <!-- لوحة التنبيهات السريعة -->
    <div class="quick-actions" v-if="hasPermission('manage_pos')">
      <button class="quick-action-btn" @click="openDrawer">
        <i class="fas fa-cash-register"></i>
        <span>فتح الدرج</span>
      </button>
      <button class="quick-action-btn" @click="printLastReceipt">
        <i class="fas fa-print"></i>
        <span>طباعة آخر فاتورة</span>
      </button>
      <button class="quick-action-btn" @click="synchronizeData">
        <i class="fas fa-sync"></i>
        <span>مزامنة البيانات</span>
      </button>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted, onUnmounted } from 'vue';
import { useRouter } from 'vue-router';
import { useStore } from 'vuex';
import EndShiftModal from '@/components/pos/EndShiftModal.vue';
import { usePermissions } from '@/composables/usePermissions';
import { useNotifications } from '@/composables/useNotifications';
import { usePrinter } from '@/composables/usePrinter';
import { useConnection } from '@/composables/useConnection';

export default {
  name: 'POSDashboard',
  
  components: {
    EndShiftModal
  },

  setup() {
    const store = useStore();
    const router = useRouter();
    const { hasPermission } = usePermissions();
    const { showNotification } = useNotifications();
    const { isPrinterReady, openDrawer, printReceipt } = usePrinter();
    const { isOnline, startConnectionMonitoring, stopConnectionMonitoring } = useConnection();

    // حالة المكون
    const isSidebarCollapsed = ref(false);
    const showEndShiftModal = ref(false);
    const alerts = ref([]);
    const lastSyncTime = ref(null);

    // القيم المحسوبة
    const currentUser = computed(() => store.state.auth.user);
    const storeName = computed(() => store.state.pos.storeName);
    const currentShift = computed(() => store.state.pos.currentShift);
    const currentRoute = computed(() => router.currentRoute.value.name);

    // دورة حياة المكون
    onMounted(() => {
      initializeDashboard();
      startConnectionMonitoring();
      startDataSync();
    });

    onUnmounted(() => {
      stopConnectionMonitoring();
      stopDataSync();
    });

    // الوظائف
    const initializeDashboard = async () => {
      try {
        await store.dispatch('pos/initializeShift');
        await loadInitialData();
      } catch (error) {
        showNotification({
          type: 'error',
          message: 'فشل تهيئة النظام: ' + error.message
        });
      }
    };

    const loadInitialData = async () => {
      try {
        await Promise.all([
          store.dispatch('pos/loadProducts'),
          store.dispatch('pos/loadCategories'),
          store.dispatch('pos/loadSettings')
        ]);
      } catch (error) {
        console.error('فشل تحميل البيانات الأولية:', error);
      }
    };

    const toggleSidebar = () => {
      isSidebarCollapsed.value = !isSidebarCollapsed.value;
    };

    const endShift = () => {
      showEndShiftModal.value = true;
    };

    const confirmEndShift = async (shiftData) => {
      try {
        await store.dispatch('pos/endShift', shiftData);
        showEndShiftModal.value = false;
        router.push('/pos/shift-summary');
      } catch (error) {
        showNotification({
          type: 'error',
          message: 'فشل إنهاء الوردية: ' + error.message
        });
      }
    };

    const cancelEndShift = () => {
      showEndShiftModal.value = false;
    };

    const synchronizeData = async () => {
      try {
        await store.dispatch('pos/synchronizeData');
        lastSyncTime.value = new Date();
        showNotification({
          type: 'success',
          message: 'تمت المزامنة بنجاح'
        });
      } catch (error) {
        showNotification({
          type: 'error',
          message: 'فشلت المزامنة: ' + error.message
        });
      }
    };

    const logout = async () => {
      try {
        if (currentShift.value) {
          showNotification({
            type: 'warning',
            message: 'يجب إنهاء الوردية قبل تسجيل الخروج'
          });
          return;
        }
        await store.dispatch('auth/logout');
        router.push('/login');
      } catch (error) {
        showNotification({
          type: 'error',
          message: 'فشل تسجيل الخروج: ' + error.message
        });
      }
    };

    return {
      // الحالة
      isSidebarCollapsed,
      showEndShiftModal,
      alerts,
      lastSyncTime,
      isOnline,
      isPrinterReady,

      // القيم المحسوبة
      currentUser,
      storeName,
      currentShift,
      currentRoute,

      // الوظائف
      toggleSidebar,
      endShift,
      confirmEndShift,
      cancelEndShift,
      synchronizeData,
      logout,
      hasPermission,
      openDrawer,
      printLastReceipt: () => printReceipt(store.state.pos.lastReceipt),
      dismissAlert: (id) => {
        alerts.value = alerts.value.filter(alert => alert.id !== id);
      },

      // المساعدون
      formatCurrency: (amount) => new Intl.NumberFormat('ar-SA', {
        style: 'currency',
        currency: 'SAR'
      }).format(amount),
      
      formatDateTime: (date) => new Intl.DateTimeFormat('ar-SA', {
        dateStyle: 'medium',
        timeStyle: 'short'
      }).format(new Date(date))
    };
  }
};
</script>

<style lang="scss" scoped>
// التنسيقات في الرسالة التالية...
</style>