-- إنشاء جداول الموردين والعملاء

-- جدول المجموعات
CREATE TABLE contact_groups (
    group_id VARCHAR(20) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type ENUM('supplier', 'customer', 'both') NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    UNIQUE KEY unique_name (name)
);

-- جدول الموردين
CREATE TABLE suppliers (
    supplier_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE,
    name VARCHAR(200) NOT NULL,
    commercial_name VARCHAR(200),
    tax_number VARCHAR(50),
    credit_limit DECIMAL(18,2) DEFAULT 0,
    credit_period INT DEFAULT 0,
    email VARCHAR(255),
    phone VARCHAR(20),
    mobile VARCHAR(20),
    address TEXT,
    city VARCHAR(100),
    country VARCHAR(100),
    postal_code VARCHAR(20),
    website VARCHAR(255),
    bank_name VARCHAR(100),
    bank_account VARCHAR(50),
    bank_iban VARCHAR(50),
    payment_terms TEXT,
    delivery_terms TEXT,
    status ENUM('active', 'inactive', 'blocked') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50)
);

-- جدول العملاء
CREATE TABLE customers (
    customer_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE,
    name VARCHAR(200) NOT NULL,
    commercial_name VARCHAR(200),
    tax_number VARCHAR(50),
    credit_limit DECIMAL(18,2) DEFAULT 0,
    credit_period INT DEFAULT 0,
    email VARCHAR(255),
    phone VARCHAR(20),
    mobile VARCHAR(20),
    address TEXT,
    city VARCHAR(100),
    country VARCHAR(100),
    postal_code VARCHAR(20),
    website VARCHAR(255),
    bank_name VARCHAR(100),
    bank_account VARCHAR(50),
    bank_iban VARCHAR(50),
    payment_terms TEXT,
    shipping_address TEXT,
    price_list VARCHAR(20),
    discount_group VARCHAR(20),
    status ENUM('active', 'inactive', 'blocked') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50)
);

-- جدول علاقات المجموعات مع الموردين
CREATE TABLE supplier_groups (
    supplier_id VARCHAR(20),
    group_id VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (supplier_id, group_id),
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id),
    FOREIGN KEY (group_id) REFERENCES contact_groups(group_id)
);

-- جدول علاقات المجموعات مع العملاء
CREATE TABLE customer_groups (
    customer_id VARCHAR(20),
    group_id VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (customer_id, group_id),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (group_id) REFERENCES contact_groups(group_id)
);

-- جدول الأشخاص المسؤولين
CREATE TABLE contact_persons (
    person_id VARCHAR(20) PRIMARY KEY,
    contact_type ENUM('supplier', 'customer') NOT NULL,
    contact_id VARCHAR(20) NOT NULL,
    name VARCHAR(200) NOT NULL,
    position VARCHAR(100),
    department VARCHAR(100),
    email VARCHAR(255),
    phone VARCHAR(20),
    mobile VARCHAR(20),
    is_primary BOOLEAN DEFAULT FALSE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50)
);

-- جدول الوثائق
CREATE TABLE contact_documents (
    document_id VARCHAR(20) PRIMARY KEY,
    contact_type ENUM('supplier', 'customer') NOT NULL,
    contact_id VARCHAR(20) NOT NULL,
    name VARCHAR(200) NOT NULL,
    type VARCHAR(50) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    description TEXT,
    expiry_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50)
);

-- جدول سجل الأحداث
CREATE TABLE contact_events (
    event_id VARCHAR(20) PRIMARY KEY,
    contact_type ENUM('supplier', 'customer') NOT NULL,
    contact_id VARCHAR(20) NOT NULL,
    event_type VARCHAR(50) NOT NULL,
    event_date DATETIME NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50)
);

-- إجراءات مخزنة

DELIMITER //

-- إجراء تحديث حالة العميل بناءً على حد الائتمان
CREATE PROCEDURE update_customer_status(
    IN p_customer_id VARCHAR(20)
)
BEGIN
    DECLARE v_total_due DECIMAL(18,2);
    DECLARE v_credit_limit DECIMAL(18,2);
    
    -- حساب إجمالي المبالغ المستحقة
    SELECT 
        COALESCE(SUM(balance_amount), 0)
    INTO v_total_due
    FROM sales_invoices
    WHERE customer_id = p_customer_id
    AND payment_status != 'paid';
    
    -- الحصول على حد الائتمان
    SELECT credit_limit
    INTO v_credit_limit
    FROM customers
    WHERE customer_id = p_customer_id;
    
    -- تحديث حالة العميل
    UPDATE customers
    SET status = CASE
        WHEN v_total_due > v_credit_limit THEN 'blocked'
        ELSE 'active'
    END
    WHERE customer_id = p_customer_id;
END //

-- إجراء تحديث حالة المورد بناءً على حد الائتمان
CREATE PROCEDURE update_supplier_status(
    IN p_supplier_id VARCHAR(20)
)
BEGIN
    DECLARE v_total_due DECIMAL(18,2);
    DECLARE v_credit_limit DECIMAL(18,2);
    
    -- حساب إجمالي المبالغ المستحقة
    SELECT 
        COALESCE(SUM(balance_amount), 0)
    INTO v_total_due
    FROM purchase_invoices
    WHERE supplier_id = p_supplier_id
    AND payment_status != 'paid';
    
    -- الحصول على حد الائتمان
    SELECT credit_limit
    INTO v_credit_limit
    FROM suppliers
    WHERE supplier_id = p_supplier_id;
    
    -- تحديث حالة المورد
    UPDATE suppliers
    SET status = CASE
        WHEN v_total_due > v_credit_limit THEN 'blocked'
        ELSE 'active'
    END
    WHERE supplier_id = p_supplier_id;
END //

DELIMITER ;

-- المؤشرات
CREATE INDEX idx_suppliers_code ON suppliers(code);
CREATE INDEX idx_suppliers_name ON suppliers(name);
CREATE INDEX idx_suppliers_status ON suppliers(status);
CREATE INDEX idx_customers_code ON customers(code);
CREATE INDEX idx_customers_name ON customers(name);
CREATE INDEX idx_customers_status ON customers(status);
CREATE INDEX idx_contact_persons_contact ON contact_persons(contact_type, contact_id);
CREATE INDEX idx_contact_documents_contact ON contact_documents(contact_type, contact_id);
CREATE INDEX idx_contact_events_contact ON contact_events(contact_type, contact_id);