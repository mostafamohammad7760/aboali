export class RevenueAPI {
    constructor() {
        this.baseUrl = '/api/v1/revenue';
        this.defaultHeaders = {
            'Content-Type': 'application/json',
            'X-User-Id': 'mostafamohammad7760',
            'X-Timestamp': new Date().toISOString()
        };
    }

    async request(endpoint, options = {}) {
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                ...options,
                headers: {
                    ...this.defaultHeaders,
                    ...options.headers
                }
            });

            if (!response.ok) {
                throw await this.handleErrorResponse(response);
            }

            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            throw this.createUserFriendlyError(error);
        }
    }

    // طلبات لوحة المعلومات
    async getContractStats() {
        return this.request('/dashboard/contract-stats');
    }

    async getRevenueStats() {
        return this.request('/dashboard/revenue-stats');
    }

    async getBalanceStats() {
        return this.request('/dashboard/balance-stats');
    }

    async getObligationStats() {
        return this.request('/dashboard/obligation-stats');
    }

    async getRevenueAnalysis(period = 'month') {
        return this.request(`/dashboard/revenue-analysis?period=${period}`);
    }

    async getContractAnalysis(period = 'month') {
        return this.request(`/dashboard/contract-analysis?period=${period}`);
    }

    async getLatestContracts() {
        return this.request('/dashboard/latest-contracts');
    }

    // طلبات العقود
    async getContracts(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/contracts?${queryString}`);
    }

    async getContract(contractId) {
        return this.request(`/contracts/${contractId}`);
    }

    async createContract(contractData) {
        this.validateContractData(contractData);
        return this.request('/contracts', {
            method: 'POST',
            body: JSON.stringify(contractData)
        });
    }

    async updateContract(contractId, contractData) {
        this.validateContractData(contractData);
        return this.request(`/contracts/${contractId}`, {
            method: 'PUT',
            body: JSON.stringify(contractData)
        });
    }

    async completeContract(contractId) {
        return this.request(`/contracts/${contractId}/complete`, {
            method: 'PUT'
        });
    }

    async terminateContract(contractId, reason) {
        return this.request(`/contracts/${contractId}/terminate`, {
            method: 'PUT',
            body: JSON.stringify({ reason })
        });
    }

    // طلبات التزامات الأداء
    async getPerformanceObligations(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/obligations?${queryString}`);
    }

    async getPerformanceObligation(obligationId) {
        return this.request(`/obligations/${obligationId}`);
    }

    async createPerformanceObligation(obligationData) {
        this.validateObligationData(obligationData);
        return this.request('/obligations', {
            method: 'POST',
            body: JSON.stringify(obligationData)
        });
    }

    async updatePerformanceObligation(obligationId, obligationData) {
        this.validateObligationData(obligationData);
        return this.request(`/obligations/${obligationId}`, {
            method: 'PUT',
            body: JSON.stringify(obligationData)
        });
    }

    async updateCompletionPercentage(obligationId, percentage) {
        return this.request(`/obligations/${obligationId}/completion`, {
            method: 'PUT',
            body: JSON.stringify({ percentage })
        });
    }

    // طلبات أسعار المعاملات
    async getTransactionPrices(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/prices?${queryString}`);
    }

    async getTransactionPrice(priceId) {
        return this.request(`/prices/${priceId}`);
    }

    async updateTransactionPrice(priceId, priceData) {
        this.validatePriceData(priceData);
        return this.request(`/prices/${priceId}`, {
            method: 'PUT',
            body: JSON.stringify(priceData)
        });
    }

    // طلبات المقابل المتغير
    async getVariableConsideration(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/variable-consideration?${queryString}`);
    }

    async createVariableConsideration(considerationData) {
        this.validateConsiderationData(considerationData);
        return this.request('/variable-consideration', {
            method: 'POST',
            body: JSON.stringify(considerationData)
        });
    }

    async resolveVariableConsideration(considerationId, resolutionData) {
        return this.request(`/variable-consideration/${considerationId}/resolve`, {
            method: 'PUT',
            body: JSON.stringify(resolutionData)
        });
    }

    // طلبات تخصيص السعر
    async allocatePrice(contractId, allocationData) {
        this.validateAllocationData(allocationData);
        return this.request(`/contracts/${contractId}/allocate-price`, {
            method: 'POST',
            body: JSON.stringify(allocationData)
        });
    }

    // طلبات الاعتراف بالإيراد
    async recognizeRevenue(obligationId, recognitionData) {
        this.validateRecognitionData(recognitionData);
        return this.request(`/obligations/${obligationId}/recognize-revenue`, {
            method: 'POST',
            body: JSON.stringify(recognitionData)
        });
    }

    async reverseRecognition(revenueId, reason) {
        return this.request(`/revenue/${revenueId}/reverse`, {
            method: 'PUT',
            body: JSON.stringify({ reason })
        });
    }

    // طلبات أرصدة العقود
    async getContractAssets(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/contract-assets?${queryString}`);
    }

    async getContractLiabilities(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/contract-liabilities?${queryString}`);
    }

    async createContractAsset(assetData) {
        this.validateAssetData(assetData);
        return this.request('/contract-assets', {
            method: 'POST',
            body: JSON.stringify(assetData)
        });
    }

    async createContractLiability(liabilityData) {
        this.validateLiabilityData(liabilityData);
        return this.request('/contract-liabilities', {
            method: 'POST',
            body: JSON.stringify(liabilityData)
        });
    }

    // طلبات تكاليف العقود
    async getContractCosts(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/contract-costs?${queryString}`);
    }

    async createContractCost(costData) {
        this.validateCostData(costData);
        return this.request('/contract-costs', {
            method: 'POST',
            body: JSON.stringify(costData)
        });
    }

    async amortizeCost(costId, amortizationData) {
        return this.request(`/contract-costs/${costId}/amortize`, {
            method: 'PUT',
            body: JSON.stringify(amortizationData)
        });
    }

    // توابع التحقق من صحة البيانات
    validateContractData(contractData) {
        const requiredFields = [
            'customerId', 
            'contractDate', 
            'startDate', 
            'totalAmount',
            'contractType'
        ];
        
        const missingFields = requiredFields.filter(field => !contractData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        if (contractData.endDate && 
            new Date(contractData.endDate) <= new Date(contractData.startDate)) {
            throw new Error('تاريخ النهاية يجب أن يكون بعد تاريخ البداية');
        }

        return true;
    }

    validateObligationData(obligationData) {
        const requiredFields = [
            'contractId',
            'description',
            'amount',
            'allocationMethod',
            'recognitionMethod'
        ];
        
        const missingFields = requiredFields.filter(field => !obligationData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        return true;
    }

    validatePriceData(priceData) {
        if (!priceData.baseAmount || priceData.baseAmount <= 0) {
            throw new Error('يجب تحديد المبلغ الأساسي وأن يكون أكبر من صفر');
        }

        if (priceData.variableAmount && priceData.variableAmount < 0) {
            throw new Error('المبلغ المتغير يجب أن يكون صفر أو أكبر');
        }

        return true;
    }

    validateConsiderationData(considerationData) {
        const requiredFields = [
            'contractId',
            'type',
            'description',
            'estimationMethod',
            'estimatedAmount'
        ];
        
        const missingFields = requiredFields.filter(field => !considerationData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        return true;
    }

    validateAllocationData(allocationData) {
        if (!allocationData.obligations || !allocationData.obligations.length) {
            throw new Error('يجب تحديد التزام أداء واحد على الأقل');
        }

        const totalAllocation = allocationData.obligations.reduce(
            (sum, obligation) => sum + obligation.amount, 
            0
        );

        if (Math.abs(totalAllocation - allocationData.totalAmount) > 0.01) {
            throw new Error('مجموع المبالغ المخصصة يجب أن يساوي إجمالي سعر المعاملة');
        }

        return true;
    }

    validateRecognitionData(recognitionData) {
        const requiredFields = [
            'recognitionDate',
            'amount',
            'periodId'
        ];
        
        const missingFields = requiredFields.filter(field => !recognitionData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        return true;
    }

    validateAssetData(assetData) {
        const requiredFields = [
            'contractId',
            'obligationId',
            'amount',
            'recognitionDate'
        ];
        
        const missingFields = requiredFields.filter(field => !assetData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        return true;
    }

    validateLiabilityData(liabilityData) {
        const requiredFields = [
            'contractId',
            'obligationId',
            'amount',
            'recognitionDate'
        ];
        
        const missingFields = requiredFields.filter(field => !liabilityData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        return true;
    }

    validateCostData(costData) {
        const requiredFields = [
            'contractId',
            'type',
            'description',
            'amount',
            'amortizationMethod'
        ];
        
        const missingFields = requiredFields.filter(field => !costData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        return true;
    }

    // توابع معالجة الأخطاء
    async handleErrorResponse(response) {
        let error;
        try {
            const errorData = await response.json();
            error = new Error(errorData.message || 'حدث خطأ غير معروف');
            error.code = errorData.code;
            error.details = errorData.details;
        } catch {
            error = new Error(`خطأ في الطلب: ${response.status}`);
        }
        error.status = response.status;
        return error;
    }

    createUserFriendlyError(error) {
        const errorMessages = {
            400: 'البيانات المدخلة غير صحيحة',
            401: 'يرجى تسجيل الدخول مرة أخرى',
            403: 'ليس لديك صلاحية للقيام بهذا الإجراء',
            404: 'لم يتم العثور على البيانات المطلوبة',
            409: 'تعارض في البيانات',
            422: 'البيانات المدخلة غير صالحة',
            500: 'حدث خطأ في النظام'
        };

        return new Error(
            errorMessages[error.status] || 
            error.message || 
            'حدث خطأ غير متوقع'
        );
    }
}