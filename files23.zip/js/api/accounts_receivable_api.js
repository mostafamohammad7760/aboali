export class AccountsReceivableAPI {
    constructor() {
        this.baseUrl = '/api/v1/accounts-receivable';
        this.defaultHeaders = {
            'Content-Type': 'application/json',
            'X-User-Id': 'mostafamohammad7760',
            'X-Timestamp': new Date().toISOString()
        };
    }

    async request(endpoint, options = {}) {
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                ...options,
                headers: {
                    ...this.defaultHeaders,
                    ...options.headers
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            return data;
        } catch (error) {
            console.error('API Error:', error);
            throw new Error(`فشل في تنفيذ الطلب: ${error.message}`);
        }
    }

    // طلبات لوحة المعلومات
    async getDashboardSummary() {
        return this.request('/dashboard/summary');
    }

    async getExpectedCollections(days = 30) {
        return this.request(`/dashboard/expected-collections?days=${days}`);
    }

    async getAgingSummary() {
        return this.request('/dashboard/aging-summary');
    }

    async getCollectionsHistory(months = 12) {
        return this.request(`/dashboard/collections-history?months=${months}`);
    }

    async getTopCustomers(limit = 10) {
        return this.request(`/dashboard/top-customers?limit=${limit}`);
    }

    // طلبات العملاء
    async getCustomers(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/customers?${queryString}`);
    }

    async getCustomer(customerId) {
        return this.request(`/customers/${customerId}`);
    }

    async createCustomer(customerData) {
        return this.request('/customers', {
            method: 'POST',
            body: JSON.stringify(customerData)
        });
    }

    async updateCustomer(customerId, customerData) {
        return this.request(`/customers/${customerId}`, {
            method: 'PUT',
            body: JSON.stringify(customerData)
        });
    }

    async getCustomerStatement(customerId, params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/customers/${customerId}/statement?${queryString}`);
    }

    // طلبات الفواتير
    async getInvoices(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/invoices?${queryString}`);
    }

    async getInvoice(invoiceId) {
        return this.request(`/invoices/${invoiceId}`);
    }

    async createInvoice(invoiceData) {
        return this.request('/invoices', {
            method: 'POST',
            body: JSON.stringify(invoiceData)
        });
    }

    async updateInvoiceStatus(invoiceId, status) {
        return this.request(`/invoices/${invoiceId}/status`, {
            method: 'PUT',
            body: JSON.stringify({ status })
        });
    }

    // طلبات التحصيل
    async getCollections(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/collections?${queryString}`);
    }

    async createCollection(collectionData) {
        return this.request('/collections', {
            method: 'POST',
            body: JSON.stringify(collectionData)
        });
    }

    async getCollectionDetails(collectionId) {
        return this.request(`/collections/${collectionId}/details`);
    }

    // طلبات خطط التحصيل
    async getCollectionPlans(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/collection-plans?${queryString}`);
    }

    async createCollectionPlan(planData) {
        return this.request('/collection-plans', {
            method: 'POST',
            body: JSON.stringify(planData)
        });
    }

    async updateCollectionPlan(planId, planData) {
        return this.request(`/collection-plans/${planId}`, {
            method: 'PUT',
            body: JSON.stringify(planData)
        });
    }

    async getCollectionPlanInstallments(planId) {
        return this.request(`/collection-plans/${planId}/installments`);
    }

    // طلبات تعمير الذمم
    async getAgingReport(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/aging?${queryString}`);
    }

    async getCustomerAging(customerId) {
        return this.request(`/customers/${customerId}/aging`);
    }

    // طلبات التقارير
    async getReceivablesSummary(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/receivables-summary?${queryString}`);
    }

    async exportReport(reportType, params = {}) {
        const queryString = new URLSearchParams(params).toString();
        const response = await fetch(
            `${this.baseUrl}/reports/export/${reportType}?${queryString}`,
            {
                headers: this.defaultHeaders
            }
        );

        if (!response.ok) {
            throw new Error(`فشل في تصدير التقرير: ${response.status}`);
        }

        const blob = await response.blob();
        const filename = response.headers.get('Content-Disposition')
            ?.split('filename=')[1]
            ?.replace(/"/g, '') || `report-${Date.now()}.xlsx`;

        // تنزيل الملف
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
    }

    // طلبات الإحصائيات
    async getCustomerStatistics(customerId) {
        return this.request(`/customers/${customerId}/statistics`);
    }

    async getCollectionStatistics(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/statistics/collections?${queryString}`);
    }

    // وظائف المساعدة للتعامل مع الأخطاء
    handleApiError(error) {
        console.error('API Error:', error);
        
        // تصنيف الأخطاء
        if (error.name === 'TypeError' && !navigator.onLine) {
            throw new Error('لا يوجد اتصال بالإنترنت');
        }

        if (error.response) {
            switch (error.response.status) {
                case 400:
                    throw new Error('بيانات غير صحيحة');
                case 401:
                    throw new Error('غير مصرح بالوصول');
                case 403:
                    throw new Error('ليس لديك صلاحية لهذا الإجراء');
                case 404:
                    throw new Error('لم يتم العثور على البيانات المطلوبة');
                case 500:
                    throw new Error('خطأ في الخادم');
                default:
                    throw new Error('حدث خطأ غير متوقع');
            }
        }

        throw error;
    }

    // وظائف المساعدة للتحقق من صحة البيانات
    validateInvoiceData(invoiceData) {
        const requiredFields = ['customerId', 'invoiceDate', 'dueDate', 'items'];
        for (const field of requiredFields) {
            if (!invoiceData[field]) {
                throw new Error(`حقل ${field} مطلوب`);
            }
        }

        if (!Array.isArray(invoiceData.items) || invoiceData.items.length === 0) {
            throw new Error('يجب إضافة بند واحد على الأقل للفاتورة');
        }

        return true;
    }

    validateCollectionData(collectionData) {
        const requiredFields = ['customerId', 'amount', 'collectionDate', 'method'];
        for (const field of requiredFields) {
            if (!collectionData[field]) {
                throw new Error(`حقل ${field} مطلوب`);
            }
        }

        if (collectionData.amount <= 0) {
            throw new Error('يجب أن يكون المبلغ أكبر من صفر');
        }

        return true;
    }
}