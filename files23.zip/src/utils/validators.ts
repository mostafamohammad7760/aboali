/**
 * وظائف التحقق من صحة البيانات
 * التاريخ: 2025-05-09 03:44:06
 * المستخدم: mostafamohammad7760
 */

// التحقق من رقم الهاتف
export const validatePhone = (phone: string): boolean => {
  // يقبل الأرقام السعودية التي تبدأ بـ 5 ثم 8 أرقام
  const saudiPhoneRegex = /^5[0-9]{8}$/;
  return saudiPhoneRegex.test(phone);
};

// التحقق من البريد الإلكتروني
export const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

// التحقق من الرقم الضريبي
export const validateVAT = (vatNumber: string): boolean => {
  // الرقم الضريبي السعودي: 15 رقم، يبدأ بـ 3
  const vatRegex = /^3[0-9]{14}$/;
  return vatRegex.test(vatNumber);
};

// التحقق من رقم السجل التجاري
export const validateCR = (crNumber: string): boolean => {
  // رقم السجل التجاري: 10 أرقام
  const crRegex = /^[0-9]{10}$/;
  return crRegex.test(crNumber);
};

// التحقق من الباركود
export const validateBarcode = (barcode: string): boolean => {
  // EAN-13: 13 رقم
  const ean13Regex = /^[0-9]{13}$/;
  // EAN-8: 8 أرقام
  const ean8Regex = /^[0-9]{8}$/;
  // UPC-A: 12 رقم
  const upcaRegex = /^[0-9]{12}$/;
  // CODE-128: أي طول، أحرف وأرقام
  const code128Regex = /^[A-Za-z0-9-_+]{1,48}$/;

  return (
    ean13Regex.test(barcode) ||
    ean8Regex.test(barcode) ||
    upcaRegex.test(barcode) ||
    code128Regex.test(barcode)
  );
};

// التحقق من السعر
export const validatePrice = (price: number): boolean => {
  return price >= 0 && Number.isFinite(price) && !Number.isNaN(price);
};

// التحقق من الكمية
export const validateQuantity = (quantity: number): boolean => {
  return quantity >= 0 && Number.isInteger(quantity);
};

// التحقق من نسبة الخصم
export const validateDiscount = (discount: number): boolean => {
  return discount >= 0 && discount <= 100 && Number.isFinite(discount);
};

// التحقق من رقم المرجع
export const validateReference = (reference: string): boolean => {
  // رقم المرجع: أحرف وأرقام، 8-16 خانة
  const referenceRegex = /^[A-Za-z0-9-_]{8,16}$/;
  return referenceRegex.test(reference);
};

// التحقق من رقم الفاتورة
export const validateInvoiceNumber = (invoiceNumber: string): boolean => {
  // رقم الفاتورة: INV- متبوعة بـ 8 أرقام على الأقل
  const invoiceRegex = /^INV-[0-9]{8,}$/;
  return invoiceRegex.test(invoiceNumber);
};

// التحقق من التاريخ
export const validateDate = (date: string): boolean => {
  const dateObj = new Date(date);
  return dateObj instanceof Date && !isNaN(dateObj.getTime());
};

// التحقق من الوقت
export const validateTime = (time: string): boolean => {
  // الوقت بتنسيق 24 ساعة
  const timeRegex = /^([01]?[0-9]|2[0-3]):[0-5][0-9]$/;
  return timeRegex.test(time);
};

// التحقق من النص العربي
export const validateArabicText = (text: string): boolean => {
  // يقبل الحروف العربية والأرقام والمسافات وعلامات الترقيم
  const arabicRegex = /^[\u0600-\u06FF\s0-9.,!؟'"-]+$/;
  return arabicRegex.test(text);
};

// التحقق من رقم البطاقة البنكية
export const validateCreditCard = (cardNumber: string): boolean => {
  // خوارزمية Luhn للتحقق من صحة رقم البطاقة
  const digits = cardNumber.replace(/\D/g, '');
  
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }

  let sum = 0;
  let isEven = false;

  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i]);

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
};

// دالة مساعدة للتحقق من مجموعة من القيم
export const validateAll = (validations: { [key: string]: boolean }): boolean => {
  return Object.values(validations).every(isValid => isValid);
};

// دالة مساعدة لتجميع أخطاء التحقق
export const collectErrors = (
  validations: { [key: string]: boolean },
  errorMessages: { [key: string]: string }
): string[] => {
  return Object.entries(validations)
    .filter(([_, isValid]) => !isValid)
    .map(([key]) => errorMessages[key]);
};