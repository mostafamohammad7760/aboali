import { AccountsAPI } from './api/accounts_api.js';
import { ChartManager } from './chart_manager.js';
import { formatCurrency, formatNumber, formatDate } from './utils/formatters.js';
import { validateJournalEntry, validateAccount, validateCostCenter } from './utils/validators.js';

class Accounts {
    constructor() {
        this.api = new AccountsAPI();
        this.charts = new ChartManager();
        this.currentUser = 'mostafamohammad7760';
        
        // تهيئة المكونات والبيانات
        this.initializeComponents();
        this.attachEventListeners();
        this.loadDashboardData();
        
        // تحديث الوقت كل ثانية
        this.updateDateTime();
        setInterval(() => this.updateDateTime(), 1000);
    }

    initializeComponents() {
        // عناصر لوحة المعلومات
        this.dashboardElements = {
            // الأصول والالتزامات
            totalAssets: document.getElementById('totalAssets'),
            totalLiabilities: document.getElementById('totalLiabilities'),
            netAssets: document.getElementById('netAssets'),
            
            // الإيرادات والمصروفات
            totalRevenues: document.getElementById('totalRevenues'),
            totalExpenses: document.getElementById('totalExpenses'),
            netIncome: document.getElementById('netIncome'),
            
            // القيود اليومية
            unpostedEntries: document.getElementById('unpostedEntries'),
            todayPostedEntries: document.getElementById('todayPostedEntries'),
            cancelledEntries: document.getElementById('cancelledEntries'),
            
            // الفترة المحاسبية
            currentPeriodName: document.getElementById('currentPeriodName'),
            currentPeriodStatus: document.getElementById('currentPeriodStatus'),
            currentPeriodEndDate: document.getElementById('currentPeriodEndDate'),
            
            // الجداول
            latestEntriesTable: document.getElementById('latestEntriesTable')
        };

        // عناصر الفلترة
        this.filterElements = {
            financialChartPeriod: document.getElementById('financialChartPeriod'),
            costCentersPeriod: document.getElementById('costCentersPeriod')
        };

        // تهيئة الرسوم البيانية
        this.initializeCharts();
        
        // تهيئة القوالب
        this.journalEntryRowTemplate = document.getElementById('journalEntryRowTemplate');
    }

    async loadDashboardData() {
        try {
            this.showLoading();

            const [
                financialPosition,
                incomeStatement,
                entriesStats,
                currentPeriod,
                financialAnalysis,
                costCentersAnalysis,
                latestEntries
            ] = await Promise.all([
                this.api.getFinancialPosition(),
                this.api.getIncomeStatement(),
                this.api.getEntriesStats(),
                this.api.getCurrentPeriod(),
                this.api.getFinancialAnalysis(this.filterElements.financialChartPeriod.value),
                this.api.getCostCentersAnalysis(this.filterElements.costCentersPeriod.value),
                this.api.getLatestEntries()
            ]);

            this.updateFinancialPosition(financialPosition);
            this.updateIncomeStatement(incomeStatement);
            this.updateEntriesStats(entriesStats);
            this.updateCurrentPeriod(currentPeriod);
            this.updateCharts(financialAnalysis, costCentersAnalysis);
            this.renderLatestEntries(latestEntries);

            this.hideLoading();
        } catch (error) {
            this.hideLoading();
            this.showError('حدث خطأ أثناء تحميل البيانات');
            console.error('Dashboard loading error:', error);
        }
    }

    initializeCharts() {
        // تهيئة رسم تحليل الإيرادات والمصروفات
        this.charts.initializeLineChart('financialAnalysisChart', {
            labels: [],
            datasets: [
                {
                    label: 'الإيرادات',
                    data: [],
                    borderColor: '#27ae60',
                    backgroundColor: 'rgba(39, 174, 96, 0.1)',
                    fill: true
                },
                {
                    label: 'المصروفات',
                    data: [],
                    borderColor: '#e74c3c',
                    backgroundColor: 'rgba(231, 76, 60, 0.1)',
                    fill: true
                }
            ],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => formatCurrency(value)
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: context => formatCurrency(context.parsed.y)
                        }
                    }
                }
            }
        });

        // تهيئة رسم تحليل مراكز التكلفة
        this.charts.initializePieChart('costCentersAnalysisChart', {
            labels: [],
            datasets: [{
                data: [],
                backgroundColor: [
                    '#2ecc71',
                    '#3498db',
                    '#f1c40f',
                    '#e67e22',
                    '#e74c3c',
                    '#9b59b6',
                    '#34495e',
                    '#16a085'
                ]
            }],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: context => 
                                `${context.label}: ${formatCurrency(context.parsed)}`
                        }
                    }
                }
            }
        });
    }

    updateFinancialPosition(data) {
        this.dashboardElements.totalAssets.textContent = 
            formatCurrency(data.totalAssets);
        this.dashboardElements.totalLiabilities.textContent = 
            formatCurrency(data.totalLiabilities);
        this.dashboardElements.netAssets.textContent = 
            formatCurrency(data.netAssets);
    }

    updateIncomeStatement(data) {
        this.dashboardElements.totalRevenues.textContent = 
            formatCurrency(data.totalRevenues);
        this.dashboardElements.totalExpenses.textContent = 
            formatCurrency(data.totalExpenses);
        this.dashboardElements.netIncome.textContent = 
            formatCurrency(data.netIncome);
    }

    updateEntriesStats(stats) {
        this.dashboardElements.unpostedEntries.textContent = 
            formatNumber(stats.unposted);
        this.dashboardElements.todayPostedEntries.textContent = 
            formatNumber(stats.todayPosted);
        this.dashboardElements.cancelledEntries.textContent = 
            formatNumber(stats.cancelled);
    }

    updateCurrentPeriod(period) {
        this.dashboardElements.currentPeriodName.textContent = period.name;
        this.dashboardElements.currentPeriodStatus.textContent = 
            this.translatePeriodStatus(period.status);
        this.dashboardElements.currentPeriodEndDate.textContent = 
            formatDate(period.endDate);
    }

    updateCharts(financialAnalysis, costCentersAnalysis) {
        // تحديث رسم التحليل المالي
        this.charts.updateLineChart('financialAnalysisChart', {
            labels: financialAnalysis.labels,
            datasets: [
                {
                    data: financialAnalysis.revenues,
                    label: 'الإيرادات'
                },
                {
                    data: financialAnalysis.expenses,
                    label: 'المصروفات'
                }
            ]
        });

        // تحديث رسم مراكز التكلفة
        this.charts.updatePieChart('costCentersAnalysisChart', {
            labels: costCentersAnalysis.map(item => item.name),
            data: costCentersAnalysis.map(item => item.amount)
        });
    }

    renderLatestEntries(entries) {
        const tbody = this.dashboardElements.latestEntriesTable;
        tbody.innerHTML = '';

        entries.forEach(entry => {
            const tr = this.createEntryRow(entry);
            tbody.appendChild(tr);
        });
    }

    createEntryRow(entry) {
        const template = this.journalEntryRowTemplate.content.cloneNode(true);
        const tr = template.querySelector('tr');
        
        tr.querySelector('.entry-number').textContent = entry.entryNumber;
        tr.querySelector('.entry-date').textContent = formatDate(entry.entryDate);
        tr.querySelector('.entry-description').textContent = entry.description;
        tr.querySelector('.entry-type').textContent = 
            this.translateEntryType(entry.type);
        tr.querySelector('.entry-debit').textContent = 
            formatCurrency(entry.totalDebit);
        tr.querySelector('.entry-credit').textContent = 
            formatCurrency(entry.totalCredit);
        
        const statusCell = tr.querySelector('.entry-status');
        statusCell.textContent = this.translateEntryStatus(entry.status);
        statusCell.classList.add(entry.status.toLowerCase());

        // إضافة مستمعات الأحداث للأزرار
        tr.querySelector('.view-entry').addEventListener('click', 
            () => this.viewEntry(entry.entryId));
        
        const postButton = tr.querySelector('.post-entry');
        if (entry.status === 'draft') {
            postButton.addEventListener('click', 
                () => this.postEntry(entry.entryId));
        } else {
            postButton.style.display = 'none';
        }

        return tr;
    }

    attachEventListeners() {
        // مستمعات أحداث الإجراءات السريعة
        document.getElementById('createJournalEntry')?.addEventListener('click', 
            () => this.showEntryModal());
        document.getElementById('createAccount')?.addEventListener('click', 
            () => this.showAccountModal());
        document.getElementById('createCostCenter')?.addEventListener('click', 
            () => this.showCostCenterModal());
        document.getElementById('startNewPeriod')?.addEventListener('click', 
            () => this.showPeriodModal());

        // مستمعات أحداث الفلترة
        this.filterElements.financialChartPeriod.addEventListener('change', 
            () => this.loadFinancialAnalysis());
        this.filterElements.costCentersPeriod.addEventListener('change', 
            () => this.loadCostCentersAnalysis());

        // مستمعات أحداث التصدير
        document.getElementById('exportFinancialChart')?.addEventListener('click', 
            () => this.exportChart('financialAnalysisChart'));
        document.getElementById('exportCostCentersChart')?.addEventListener('click', 
            () => this.exportChart('costCentersAnalysisChart'));

        // مستمعات أحداث عرض الكل
        document.getElementById('viewAllEntries')?.addEventListener('click', 
            () => this.navigateToEntries());
    }

    // توابع مساعدة
    translateEntryType(type) {
        const typeMap = {
            manual: 'يدوي',
            automatic: 'تلقائي',
            adjustment: 'تسوية'
        };
        return typeMap[type] || type;
    }

    translateEntryStatus(status) {
        const statusMap = {
            draft: 'مسودة',
            posted: 'مرحل',
            cancelled: 'ملغي'
        };
        return statusMap[status] || status;
    }

    translatePeriodStatus(status) {
        const statusMap = {
            pending: 'معلق',
            active: 'نشط',
            closed: 'مغلق'
        };
        return statusMap[status] || status;
    }

    updateDateTime() {
        document.getElementById('currentDateTime').textContent = 
            new Date().toISOString().slice(0, 19).replace('T', ' ');
    }

    showLoading() {
        const loader = document.createElement('div');
        loader.className = 'loading-overlay';
        loader.innerHTML = '<div class="loading-spinner"></div>';
        document.body.appendChild(loader);
    }

    hideLoading() {
        document.querySelector('.loading-overlay')?.remove();
    }

    showError(message) {
        console.error(message);
        // يمكن تحسين هذه الدالة لعرض رسائل خطأ أكثر جاذبية
        alert(message);
    }

    showSuccess(message) {
        // يمكن تحسين هذه الدالة لعرض رسائل نجاح أكثر جاذبية
        alert(message);
    }
}

// تهيئة التطبيق عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    new Accounts();
});