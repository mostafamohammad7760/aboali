/**
 * وسيط التحقق من الصلاحيات
 * التاريخ: 2025-05-09 04:26:01
 * المستخدم: mostafamohammad7760
 */

import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { User } from '../../models';

export const authenticate = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
      throw new Error('غير مصرح');
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET!);
    const user = await User.findByPk(decoded.id);

    if (!user || !user.active) {
      throw new Error('غير مصرح');
    }

    req.user = user;
    next();

  } catch (error) {
    res.status(401).json({
      success: false,
      message: 'غير مصرح'
    });
  }
};

export const authorize = (permissions: string[]) => {
  return async (
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> => {
    try {
      const userPermissions = await req.user.getPermissions();
      
      const hasPermission = permissions.every(permission =>
        userPermissions.includes(permission)
      );

      if (!hasPermission) {
        throw new Error('غير مصرح');
      }

      next();

    } catch (error) {
      res.status(403).json({
        success: false,
        message: 'غير مصرح'
      });
    }
  };
};