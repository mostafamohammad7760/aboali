/**
 * مدير المنتجات - إدارة المنتجات في نظام نقاط البيع
 * @module ProductManager
 * التاريخ: 2025-05-09 02:58:56
 * المستخدم: mostafamohammad7760
 */

export class ProductManager {
    constructor(database) {
        this.db = database;
        this.cache = new Map();
        this.cacheTimeout = 5 * 60 * 1000; // 5 دقائق
        this.lastCacheUpdate = null;
    }

    /**
     * تحميل المنتجات من قاعدة البيانات
     * @param {string} categoryId - معرف الفئة (اختياري)
     */
    async loadProducts(categoryId = null) {
        try {
            // التحقق من الذاكرة المؤقتة
            const cacheKey = categoryId || 'all';
            if (this.isCacheValid(cacheKey)) {
                return this.cache.get(cacheKey);
            }

            // تحميل المنتجات من قاعدة البيانات
            const products = await this.db.getProducts(categoryId);
            
            // تخزين في الذاكرة المؤقتة
            this.cache.set(cacheKey, products);
            this.lastCacheUpdate = Date.now();

            return products;
        } catch (error) {
            console.error('Error loading products:', error);
            throw new Error('فشل تحميل المنتجات');
        }
    }

    /**
     * البحث عن منتجات
     * @param {string} query - نص البحث
     */
    async searchProducts(query) {
        try {
            if (!query || query.length < 2) {
                return [];
            }

            const results = await this.db.searchProducts(query);
            return this.processSearchResults(results, query);
        } catch (error) {
            console.error('Error searching products:', error);
            throw new Error('فشل البحث عن المنتجات');
        }
    }

    /**
     * معالجة نتائج البحث
     * @param {Array} results - نتائج البحث
     * @param {string} query - نص البحث
     */
    processSearchResults(results, query) {
        return results.map(product => ({
            ...product,
            relevance: this.calculateRelevance(product, query)
        })).sort((a, b) => b.relevance - a.relevance);
    }

    /**
     * حساب مدى صلة المنتج بالبحث
     * @param {Object} product - المنتج
     * @param {string} query - نص البحث
     */
    calculateRelevance(product, query) {
        let score = 0;
        const searchTerm = query.toLowerCase();

        // مطابقة الباركود
        if (product.barcode === query) {
            score += 100;
        }

        // مطابقة الاسم العربي
        if (product.name_ar.toLowerCase().includes(searchTerm)) {
            score += 50;
            if (product.name_ar.toLowerCase().startsWith(searchTerm)) {
                score += 25;
            }
        }

        // مطابقة الاسم الإنجليزي
        if (product.name_en?.toLowerCase().includes(searchTerm)) {
            score += 40;
            if (product.name_en.toLowerCase().startsWith(searchTerm)) {
                score += 20;
            }
        }

        return score;
    }

    /**
     * التحقق من صلاحية الذاكرة المؤقتة
     * @param {string} key - مفتاح الذاكرة المؤقتة
     */
    isCacheValid(key) {
        if (!this.cache.has(key) || !this.lastCacheUpdate) {
            return false;
        }

        return (Date.now() - this.lastCacheUpdate) < this.cacheTimeout;
    }

    /**
     * تحديث معلومات المخزون
     * @param {Array} items - العناصر المباعة
     */
    async updateInventory(items) {
        try {
            for (const item of items) {
                await this.db.updateProductStock(
                    item.id,
                    item.quantity,
                    'decrease'
                );
            }

            // مسح الذاكرة المؤقتة بعد تحديث المخزون
            this.clearCache();
        } catch (error) {
            console.error('Error updating inventory:', error);
            throw new Error('فشل تحديث المخزون');
        }
    }

    /**
     * التحقق من توفر المخزون
     * @param {Array} items - العناصر المطلوبة
     */
    async checkInventoryAvailability(items) {
        try {
            const unavailableItems = [];

            for (const item of items) {
                const product = await this.db.getProduct(item.id);
                if (!product || product.stock_quantity < item.quantity) {
                    unavailableItems.push({
                        id: item.id,
                        name: item.name,
                        requested: item.quantity,
                        available: product ? product.stock_quantity : 0
                    });
                }
            }

            return {
                isAvailable: unavailableItems.length === 0,
                unavailableItems
            };
        } catch (error) {
            console.error('Error checking inventory:', error);
            throw new Error('فشل التحقق من المخزون');
        }
    }

    /**
     * تنبيه انخفاض المخزون
     * @param {Object} product - المنتج
     */
    async checkLowStock(product) {
        if (product.stock_quantity <= product.min_quantity) {
            await this.notifyLowStock(product);
        }
    }

    /**
     * إرسال تنبيه انخفاض المخزون
     * @param {Object} product - المنتج
     */
    async notifyLowStock(product) {
        // يمكن تنفيذ آلية التنبيه المناسبة هنا
        // مثل إرسال بريد إلكتروني أو إشعار للمسؤولين
        console.warn('Low stock alert:', {
            productId: product.id,
            name: product.name_ar,
            currentStock: product.stock_quantity,
            minQuantity: product.min_quantity
        });
    }

    /**
     * تحديث أسعار المنتجات
     * @param {Array} updates - تحديثات الأسعار
     */
    async updatePrices(updates) {
        try {
            for (const update of updates) {
                await this.db.updateProductPrice(
                    update.productId,
                    update.newPrice,
                    update.userId
                );
            }

            // مسح الذاكرة المؤقتة بعد تحديث الأسعار
            this.clearCache();
        } catch (error) {
            console.error('Error updating prices:', error);
            throw new Error('فشل تحديث الأسعار');
        }
    }

    /**
     * تصدير بيانات المنتجات
     * @param {string} format - صيغة التصدير (csv, excel)
     */
    async exportProducts(format = 'csv') {
        try {
            const products = await this.loadProducts();
            
            switch (format.toLowerCase()) {
                case 'csv':
                    return this.exportToCSV(products);
                case 'excel':
                    return this.exportToExcel(products);
                default:
                    throw new Error('صيغة التصدير غير مدعومة');
            }
        } catch (error) {
            console.error('Error exporting products:', error);
            throw new Error('فشل تصدير المنتجات');
        }
    }

    /**
     * تصدير إلى CSV
     * @param {Array} products - المنتجات
     */
    exportToCSV(products) {
        const headers = [
            'معرف المنتج',
            'الباركود',
            'الاسم العربي',
            'الاسم الإنجليزي',
            'الفئة',
            'سعر البيع',
            'سعر التكلفة',
            'الكمية المتوفرة',
            'الحد الأدنى'
        ].join(',');

        const rows = products.map(product => [
            product.product_id,
            product.barcode,
            `"${product.name_ar}"`,
            `"${product.name_en || ''}"`,
            `"${product.category_name || ''}"`,
            product.selling_price,
            product.cost_price,
            product.stock_quantity,
            product.min_quantity
        ].join(','));

        return [headers, ...rows].join('\n');
    }

    /**
     * مسح الذاكرة المؤقتة
     */
    clearCache() {
        this.cache.clear();
        this.lastCacheUpdate = null;
    }
}