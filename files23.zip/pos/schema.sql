/**
 * قاعدة بيانات نظام نقاط البيع
 * التاريخ: 2025-05-09 02:47:45
 * المستخدم: mostafamohammad7760
 */

-- جدول المنتجات
CREATE TABLE products (
    product_id VARCHAR(36) PRIMARY KEY,
    barcode VARCHAR(50) UNIQUE,
    name_ar VARCHAR(255) NOT NULL,
    name_en VARCHAR(255),
    category_id VARCHAR(36),
    unit_id VARCHAR(36),
    selling_price DECIMAL(10, 2) NOT NULL,
    cost_price DECIMAL(10, 2) NOT NULL,
    vat_rate DECIMAL(5, 2) DEFAULT 0.15,
    stock_quantity INT DEFAULT 0,
    min_quantity INT DEFAULT 0,
    image_url VARCHAR(255),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(36),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(36),
    FOREIGN KEY (category_id) REFERENCES product_categories(category_id),
    FOREIGN KEY (unit_id) REFERENCES units(unit_id)
);

-- جدول فئات المنتجات
CREATE TABLE product_categories (
    category_id VARCHAR(36) PRIMARY KEY,
    name_ar VARCHAR(100) NOT NULL,
    name_en VARCHAR(100),
    parent_id VARCHAR(36),
    description TEXT,
    image_url VARCHAR(255),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(36),
    FOREIGN KEY (parent_id) REFERENCES product_categories(category_id)
);

-- جدول وحدات القياس
CREATE TABLE units (
    unit_id VARCHAR(36) PRIMARY KEY,
    name_ar VARCHAR(50) NOT NULL,
    name_en VARCHAR(50),
    symbol VARCHAR(10),
    is_base_unit BOOLEAN DEFAULT true,
    base_unit_id VARCHAR(36),
    conversion_factor DECIMAL(10, 4),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(36),
    FOREIGN KEY (base_unit_id) REFERENCES units(unit_id)
);

-- جدول المبيعات
CREATE TABLE sales (
    sale_id VARCHAR(36) PRIMARY KEY,
    invoice_number VARCHAR(20) UNIQUE NOT NULL,
    customer_id VARCHAR(36),
    sale_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    total_amount DECIMAL(10, 2) NOT NULL,
    discount_amount DECIMAL(10, 2) DEFAULT 0,
    vat_amount DECIMAL(10, 2) DEFAULT 0,
    net_amount DECIMAL(10, 2) NOT NULL,
    payment_method ENUM('cash', 'card', 'bank_transfer', 'multiple') NOT NULL,
    status ENUM('completed', 'cancelled', 'refunded') DEFAULT 'completed',
    notes TEXT,
    created_by VARCHAR(36),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(36),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

-- جدول تفاصيل المبيعات
CREATE TABLE sale_items (
    sale_item_id VARCHAR(36) PRIMARY KEY,
    sale_id VARCHAR(36) NOT NULL,
    product_id VARCHAR(36) NOT NULL,
    quantity DECIMAL(10, 2) NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    discount_amount DECIMAL(10, 2) DEFAULT 0,
    vat_amount DECIMAL(10, 2) DEFAULT 0,
    net_amount DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sale_id) REFERENCES sales(sale_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- جدول المدفوعات
CREATE TABLE payments (
    payment_id VARCHAR(36) PRIMARY KEY,
    sale_id VARCHAR(36) NOT NULL,
    payment_method ENUM('cash', 'card', 'bank_transfer') NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    reference_number VARCHAR(50),
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('completed', 'pending', 'failed', 'refunded') DEFAULT 'completed',
    created_by VARCHAR(36),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sale_id) REFERENCES sales(sale_id)
);

-- جدول العملاء
CREATE TABLE customers (
    customer_id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    email VARCHAR(100),
    tax_number VARCHAR(20),
    address TEXT,
    credit_limit DECIMAL(10, 2) DEFAULT 0,
    balance DECIMAL(10, 2) DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(36),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(36)
);

-- جدول المرتجعات
CREATE TABLE returns (
    return_id VARCHAR(36) PRIMARY KEY,
    sale_id VARCHAR(36) NOT NULL,
    return_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    total_amount DECIMAL(10, 2) NOT NULL,
    reason TEXT,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    created_by VARCHAR(36),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    approved_by VARCHAR(36),
    approved_at TIMESTAMP,
    FOREIGN KEY (sale_id) REFERENCES sales(sale_id)
);

-- جدول تفاصيل المرتجعات
CREATE TABLE return_items (
    return_item_id VARCHAR(36) PRIMARY KEY,
    return_id VARCHAR(36) NOT NULL,
    product_id VARCHAR(36) NOT NULL,
    quantity DECIMAL(10, 2) NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (return_id) REFERENCES returns(return_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- جدول الخزينة
CREATE TABLE cash_register (
    register_id VARCHAR(36) PRIMARY KEY,
    opening_amount DECIMAL(10, 2) NOT NULL,
    closing_amount DECIMAL(10, 2),
    actual_amount DECIMAL(10, 2),
    difference_amount DECIMAL(10, 2),
    opening_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    closing_date TIMESTAMP,
    status ENUM('open', 'closed') DEFAULT 'open',
    notes TEXT,
    opened_by VARCHAR(36),
    closed_by VARCHAR(36),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- جدول حركات الخزينة
CREATE TABLE cash_transactions (
    transaction_id VARCHAR(36) PRIMARY KEY,
    register_id VARCHAR(36) NOT NULL,
    transaction_type ENUM('sale', 'return', 'expense', 'deposit', 'withdrawal') NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    reference_id VARCHAR(36),
    notes TEXT,
    created_by VARCHAR(36),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (register_id) REFERENCES cash_register(register_id)
);

-- جدول تقارير الخزينة
CREATE TABLE register_reports (
    report_id VARCHAR(36) PRIMARY KEY,
    register_id VARCHAR(36) NOT NULL,
    report_date DATE NOT NULL,
    total_sales DECIMAL(10, 2) DEFAULT 0,
    total_returns DECIMAL(10, 2) DEFAULT 0,
    total_expenses DECIMAL(10, 2) DEFAULT 0,
    net_amount DECIMAL(10, 2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(36),
    FOREIGN KEY (register_id) REFERENCES cash_register(register_id)
);

-- إنشاء المؤشرات
CREATE INDEX idx_products_barcode ON products(barcode);
CREATE INDEX idx_products_category ON products(category_id);
CREATE INDEX idx_sales_date ON sales(sale_date);
CREATE INDEX idx_sales_customer ON sales(customer_id);
CREATE INDEX idx_sale_items_sale ON sale_items(sale_id);
CREATE INDEX idx_sale_items_product ON sale_items(product_id);
CREATE INDEX idx_payments_sale ON payments(sale_id);
CREATE INDEX idx_returns_sale ON returns(sale_id);
CREATE INDEX idx_cash_transactions_register ON cash_transactions(register_id);