/**
 * مكون حقل الإدخال الأساسي
 * التاريخ: 2025-05-09 03:52:21
 * المستخدم: mostafamohammad7760
 */

<template>
  <div 
    :class="[
      'base-input',
      {
        'has-error': error,
        'is-disabled': disabled,
        'is-readonly': readonly,
        'has-prefix': $slots.prefix,
        'has-suffix': $slots.suffix
      }
    ]"
  >
    <!-- التسمية -->
    <label v-if="label" :for="inputId" class="input-label">
      {{ label }}
      <span v-if="required" class="required-mark">*</span>
    </label>

    <div class="input-wrapper">
      <!-- عنصر البادئة -->
      <span v-if="$slots.prefix" class="input-affix prefix">
        <slot name="prefix"></slot>
      </span>

      <!-- حقل الإدخال -->
      <input
        :id="inputId"
        ref="inputRef"
        v-model="localValue"
        :type="currentType"
        :name="name"
        :placeholder="placeholder"
        :maxlength="maxlength"
        :minlength="minlength"
        :pattern="pattern"
        :readonly="readonly"
        :disabled="disabled"
        :required="required"
        :autocomplete="autocomplete"
        :dir="direction"
        @input="handleInput"
        @change="handleChange"
        @focus="handleFocus"
        @blur="handleBlur"
        @keydown="handleKeydown"
        @keyup="handleKeyup"
        @keypress="handleKeypress"
      >

      <!-- عنصر اللاحقة -->
      <span v-if="$slots.suffix" class="input-affix suffix">
        <slot name="suffix"></slot>
      </span>

      <!-- زر إظهار/إخفاء كلمة المرور -->
      <button
        v-if="type === 'password' && togglePassword"
        type="button"
        class="toggle-password"
        @click="togglePasswordVisibility"
      >
        <i :class="showPassword ? 'fas fa-eye-slash' : 'fas fa-eye'"></i>
      </button>

      <!-- زر المسح -->
      <button
        v-if="clearable && localValue"
        type="button"
        class="clear-input"
        @click="clearInput"
      >
        <i class="fas fa-times"></i>
      </button>
    </div>

    <!-- رسالة الخطأ -->
    <div v-if="error" class="error-message">
      {{ error }}
    </div>

    <!-- نص المساعدة -->
    <div v-if="hint && !error" class="hint-text">
      {{ hint }}
    </div>

    <!-- عداد الأحرف -->
    <div v-if="maxlength && showCount" class="char-counter">
      {{ localValue.length }}/{{ maxlength }}
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, computed, PropType } from 'vue';

export default defineComponent({
  name: 'BaseInput',

  props: {
    // القيمة
    modelValue: {
      type: [String, Number],
      default: ''
    },
    // المعرف
    id: {
      type: String,
      default: undefined
    },
    // التسمية
    label: {
      type: String,
      default: ''
    },
    // نوع الحقل
    type: {
      type: String as PropType<'text' | 'password' | 'email' | 'number' | 'tel' | 'url' | 'search'>,
      default: 'text'
    },
    // النص التلميحي
    placeholder: {
      type: String,
      default: ''
    },
    // الاسم
    name: {
      type: String,
      default: ''
    },
    // إلزامي
    required: {
      type: Boolean,
      default: false
    },
    // للقراءة فقط
    readonly: {
      type: Boolean,
      default: false
    },
    // معطل
    disabled: {
      type: Boolean,
      default: false
    },
    // الحد الأقصى للأحرف
    maxlength: {
      type: Number,
      default: undefined
    },
    // الحد الأدنى للأحرف
    minlength: {
      type: Number,
      default: undefined
    },
    // نمط التحقق
    pattern: {
      type: String,
      default: undefined
    },
    // الإكمال التلقائي
    autocomplete: {
      type: String,
      default: 'off'
    },
    // اتجاه النص
    direction: {
      type: String as PropType<'rtl' | 'ltr' | 'auto'>,
      default: 'auto'
    },
    // رسالة الخطأ
    error: {
      type: String,
      default: ''
    },
    // نص المساعدة
    hint: {
      type: String,
      default: ''
    },
    // قابل للمسح
    clearable: {
      type: Boolean,
      default: false
    },
    // إظهار عدد الأحرف
    showCount: {
      type: Boolean,
      default: false
    },
    // إمكانية إظهار/إخفاء كلمة المرور
    togglePassword: {
      type: Boolean,
      default: true
    }
  },

  emits: [
    'update:modelValue',
    'input',
    'change',
    'focus',
    'blur',
    'keydown',
    'keyup',
    'keypress',
    'clear'
  ],

  setup(props, { emit }) {
    const inputRef = ref<HTMLInputElement | null>(null);
    const showPassword = ref(false);
    const localValue = ref(props.modelValue);

    // معرف الحقل
    const inputId = computed(() => {
      return props.id || `input-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    });

    // نوع الحقل الحالي
    const currentType = computed(() => {
      if (props.type === 'password' && showPassword.value) {
        return 'text';
      }
      return props.type;
    });

    // معالجة التغييرات
    const handleInput = (event: Event) => {
      const target = event.target as HTMLInputElement;
      localValue.value = target.value;
      emit('update:modelValue', target.value);
      emit('input', event);
    };

    const handleChange = (event: Event) => {
      emit('change', event);
    };

    const handleFocus = (event: FocusEvent) => {
      emit('focus', event);
    };

    const handleBlur = (event: FocusEvent) => {
      emit('blur', event);
    };

    const handleKeydown = (event: KeyboardEvent) => {
      emit('keydown', event);
    };

    const handleKeyup = (event: KeyboardEvent) => {
      emit('keyup', event);
    };

    const handleKeypress = (event: KeyboardEvent) => {
      emit('keypress', event);
    };

    // تبديل رؤية كلمة المرور
    const togglePasswordVisibility = () => {
      showPassword.value = !showPassword.value;
    };

    // مسح القيمة
    const clearInput = () => {
      localValue.value = '';
      emit('update:modelValue', '');
      emit('clear');
      inputRef.value?.focus();
    };

    // التركيز على الحقل
    const focus = () => {
      inputRef.value?.focus();
    };

    // إلغاء التركيز
    const blur = () => {
      inputRef.value?.blur();
    };

    // تحديث القيمة المحلية عند تغيير القيمة الخارجية
    watch(
      () => props.modelValue,
      (newValue) => {
        localValue.value = newValue;
      }
    );

    return {
      inputRef,
      inputId,
      localValue,
      currentType,
      showPassword,
      handleInput,
      handleChange,
      handleFocus,
      handleBlur,
      handleKeydown,
      handleKeyup,
      handleKeypress,
      togglePasswordVisibility,
      clearInput,
      focus,
      blur
    };
  }
});
</script>

<style lang="scss" scoped>
.base-input {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;

  // تنسيق التسمية
  .input-label {
    font-weight: 500;
    color: var(--text-color);
    font-size: 0.875rem;

    .required-mark {
      color: var(--danger-color);
      margin-right: 0.25rem;
    }
  }

  // غلاف الحقل
  .input-wrapper {
    position: relative;
    display: flex;
    align-items: center;

    // الحقل نفسه
    input {
      width: 100%;
      padding: 0.625rem;
      border: 1px solid var(--border-color);
      border-radius: var(--border-radius);
      font-family: inherit;
      font-size: 1rem;
      color: var(--text-color);
      background: var(--input-bg);
      transition: all 0.2s ease;

      &::placeholder {
        color: var(--text-secondary);
      }

      &:focus {
        outline: none;
        border-color: var(--primary-color);
        box-shadow: 0 0 0 3px rgba(var(--primary-color-rgb), 0.1);
      }

      &:disabled {
        background: var(--disabled-bg);
        cursor: not-allowed;
      }

      &:read-only {
        background: var(--readonly-bg);
        cursor: default;
      }
    }

    // البادئة واللاحقة
    .input-affix {
      display: flex;
      align-items: center;
      padding: 0 0.625rem;
      color: var(--text-secondary);
      
      &.prefix {
        border-right: 1px solid var(--border-color);
      }
      
      &.suffix {
        border-left: 1px solid var(--border-color);
      }
    }

    // أزرار التحكم
    .toggle-password,
    .clear-input {
      position: absolute;
      right: 0.625rem;
      background: none;
      border: none;
      padding: 0.25rem;
      color: var(--text-secondary);
      cursor: pointer;
      opacity: 0.7;
      transition: opacity 0.2s;

      &:hover {
        opacity: 1;
      }
    }
  }

  // رسالة الخطأ
  .error-message {
    font-size: 0.75rem;
    color: var(--danger-color);
  }

  // نص المساعدة
  .hint-text {
    font-size: 0.75rem;
    color: var(--text-secondary);
  }

  // عداد الأحرف
  .char-counter {
    font-size: 0.75rem;
    color: var(--text-secondary);
    text-align: left;
  }

  // حالة الخطأ
  &.has-error {
    .input-wrapper input {
      border-color: var(--danger-color);
      
      &:focus {
        box-shadow: 0 0 0 3px rgba(var(--danger-color-rgb), 0.1);
      }
    }
  }

  // تعديلات البادئة واللاحقة
  &.has-prefix input {
    padding-right: 2.5rem;
  }

  &.has-suffix input {
    padding-left: 2.5rem;
  }
}
</style>