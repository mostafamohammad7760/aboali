/**
 * مصنع مزودي التخزين السحابي
 * التاريخ: 2025-05-09 04:40:56
 * المستخدم: mostafamohammad7760
 */

import { CloudStorageBase } from './CloudStorageBase';
import { S3Provider } from './S3Provider';
import { GoogleCloudProvider } from './GoogleCloudProvider';
import { AzureProvider } from './AzureProvider';
import { DropboxProvider } from './DropboxProvider';
import { OneDriveProvider } from './OneDriveProvider';

export type CloudStorageProvider = 
  | 'aws'
  | 'gcp'
  | 'azure'
  | 'dropbox'
  | 'onedrive';

export class CloudStorageFactory {
  private static providers = new Map<string, CloudStorageBase>();

  public static createProvider(
    type: CloudStorageProvider,
    config: Record<string, any>
  ): CloudStorageBase {
    const key = `${type}:${config.bucket || ''}`;

    if (!this.providers.has(key)) {
      let provider: CloudStorageBase;

      switch (type) {
        case 'aws':
          provider = new S3Provider(config);
          break;
        case 'gcp':
          provider = new GoogleCloudProvider(config);
          break;
        case 'azure':
          provider = new AzureProvider(config);
          break;
        case 'dropbox':
          provider = new DropboxProvider(config);
          break;
        case 'onedrive':
          provider = new OneDriveProvider(config);
          break;
        default:
          throw new Error(`مزود التخزين غير مدعوم: ${type}`);
      }

      this.providers.set(key, provider);
    }

    return this.providers.get(key)!;
  }

  public static clearProviders(): void {
    this.providers.clear();
  }
}