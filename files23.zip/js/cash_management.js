import { CashManagementAPI } from './api.js';

class CashManagement {
    constructor() {
        this.api = new CashManagementAPI();
        this.currentUser = 'mostafamohammad7760';
        this.initializeComponents();
        this.attachEventListeners();
        this.loadDashboardData();
    }

    initializeComponents() {
        // عناصر لوحة المعلومات
        this.dashboardElements = {
            totalCash: document.getElementById('totalCash'),
            totalBank: document.getElementById('totalBank'),
            totalPendingCheques: document.getElementById('totalPendingCheques'),
            totalLiquidity: document.getElementById('totalLiquidity'),
            activeCashRegisters: document.getElementById('activeCashRegisters'),
            activeBankAccounts: document.getElementById('activeBankAccounts'),
            pendingChequesCount: document.getElementById('pendingChequesCount'),
            lastUpdate: document.getElementById('lastUpdate')
        };

        // عناصر الصناديق
        this.cashRegistersGrid = document.getElementById('cashRegistersGrid');
        this.cashRegisterTemplate = document.getElementById('cashRegisterCardTemplate');
        
        // عناصر الحسابات البنكية
        this.bankAccountsTable = document.getElementById('bankAccountsTable');
        
        // النوافذ المنبثقة
        this.cashRegisterModal = document.getElementById('cashRegisterModal');
        this.bankAccountModal = document.getElementById('bankAccountModal');

        this.updateDateTime();
        setInterval(() => this.updateDateTime(), 1000);
    }

    attachEventListeners() {
        // أزرار الإضافة
        document.getElementById('addCashRegisterBtn')
            .addEventListener('click', () => this.showCashRegisterModal());
        document.getElementById('addBankAccountBtn')
            .addEventListener('click', () => this.showBankAccountModal());

        // أزرار التصدير
        document.getElementById('exportCashBtn')
            .addEventListener('click', () => this.exportCashData());
        document.getElementById('exportBankBtn')
            .addEventListener('click', () => this.exportBankData());

        // التنقل بين الأقسام
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', (e) => this.handleNavigation(e));
        });
    }

    async loadDashboardData() {
        try {
            this.showLoading();
            
            const [
                cashData,
                bankData,
                chequesData
            ] = await Promise.all([
                this.api.getCashSummary(),
                this.api.getBankSummary(),
                this.api.getChequesSummary()
            ]);

            this.updateDashboard(cashData, bankData, chequesData);
            this.hideLoading();
        } catch (error) {
            this.hideLoading();
            this.showError('حدث خطأ أثناء تحميل البيانات');
            console.error(error);
        }
    }

    updateDashboard(cashData, bankData, chequesData) {
        // تحديث إجماليات النقد
        this.dashboardElements.totalCash.textContent = 
            this.formatCurrency(cashData.totalBalance);
        this.dashboardElements.activeCashRegisters.textContent = 
            cashData.activeRegisters;

        // تحديث إجماليات البنوك
        this.dashboardElements.totalBank.textContent = 
            this.formatCurrency(bankData.totalBalance);
        this.dashboardElements.activeBankAccounts.textContent = 
            bankData.activeAccounts;

        // تحديث الشيكات
        this.dashboardElements.totalPendingCheques.textContent = 
            this.formatCurrency(chequesData.pendingAmount);
        this.dashboardElements.pendingChequesCount.textContent = 
            chequesData.pendingCount;

        // تحديث السيولة المتاحة
        const totalLiquidity = cashData.totalBalance + 
            bankData.totalBalance + 
            chequesData.pendingAmount;
        this.dashboardElements.totalLiquidity.textContent = 
            this.formatCurrency(totalLiquidity);

        // تحديث وقت آخر تحديث
        this.dashboardElements.lastUpdate.textContent = 
            new Date().toLocaleTimeString('ar-SA');
    }

    async loadCashRegisters() {
        try {
            const registers = await this.api.getCashRegisters();
            this.renderCashRegisters(registers);
        } catch (error) {
            this.showError('حدث خطأ أثناء تحميل بيانات الصناديق');
            console.error(error);
        }
    }

    renderCashRegisters(registers) {
        this.cashRegistersGrid.innerHTML = '';
        
        registers.forEach(register => {
            const card = this.createCashRegisterCard(register);
            this.cashRegistersGrid.appendChild(card);
        });
    }

    createCashRegisterCard(register) {
        const template = this.cashRegisterTemplate.content.cloneNode(true);
        
        // تعبئة بيانات البطاقة
        template.querySelector('.register-name').textContent = register.register_name_ar;
        template.querySelector('.register-status').textContent = 
            this.translateStatus(register.status);
        template.querySelector('.balance').textContent = 
            this.formatCurrency(register.current_balance);
        template.querySelector('.cashier').textContent = register.cashier_name;

        // إضافة معرف الصندوق
        const card = template.querySelector('.register-card');
        card.dataset.registerId = register.register_id;

        // إضافة مستمعات الأحداث
        card.querySelector('.view-transactions').addEventListener('click', () => 
            this.showTransactions(register.register_id));
        card.querySelector('.add-transaction').addEventListener('click', () => 
            this.showTransactionModal(register.register_id));

        return template;
    }

    showCashRegisterModal(registerId = null) {
        // تهيئة نموذج إضافة/تعديل صندوق
        this.cashRegisterModal.querySelector('.modal-title').textContent = 
            registerId ? 'تعديل صندوق' : 'إضافة صندوق جديد';

        if (registerId) {
            this.loadCashRegisterData(registerId);
        }

        this.cashRegisterModal.classList.remove('hidden');
    }

    async loadCashRegisterData(registerId) {
        try {
            const register = await this.api.getCashRegister(registerId);
            // تعبئة النموذج ببيانات الصندوق
            const form = this.cashRegisterModal.querySelector('form');
            form.elements['registerName'].value = register.register_name_ar;
            form.elements['location'].value = register.location;
            form.elements['currency'].value = register.currency_code;
            form.elements['cashier'].value = register.cashier_id;
        } catch (error) {
            this.showError('حدث خطأ أثناء تحميل بيانات الصندوق');
            console.error(error);
        }
    }

    async handleCashRegisterSubmit(event) {
        event.preventDefault();
        
        try {
            const form = event.target;
            const formData = new FormData(form);
            const registerData = {
                register_name_ar: formData.get('registerName'),
                location: formData.get('location'),
                currency_code: formData.get('currency'),
                cashier_id: formData.get('cashier')
            };

            const registerId = form.dataset.registerId;
            let response;

            if (registerId) {
                response = await this.api.updateCashRegister(registerId, registerData);
            } else {
                response = await this.api.createCashRegister(registerData);
            }

            if (response.success) {
                this.showSuccess(registerId ? 'تم تحديث الصندوق بنجاح' : 'تم إنشاء الصندوق بنجاح');
                this.hideCashRegisterModal();
                this.loadCashRegisters();
            }
        } catch (error) {
            this.showError('حدث خطأ أثناء حفظ بيانات الصندوق');
            console.error(error);
        }
    }

    // توابع مساعدة
    formatCurrency(amount) {
        return new Intl.NumberFormat('ar-SA', {
            style: 'currency',
            currency: 'SAR'
        }).format(amount);
    }

    translateStatus(status) {
        const statusMap = {
            active: 'نشط',
            inactive: 'غير نشط',
            suspended: 'موقوف'
        };
        return statusMap[status] || status;
    }

    updateDateTime() {
        const now = new Date();
        document.getElementById('currentDateTime').textContent = 
            now.toISOString().replace('T', ' ').slice(0, 19);
    }

    showLoading() {
        // إظهار مؤشر التحميل
        const loader = document.createElement('div');
        loader.className = 'loading-overlay';
        loader.innerHTML = '<div class="loading-spinner"></div>';
        document.body.appendChild(loader);
    }

    hideLoading() {
        // إخفاء مؤشر التحميل
        const loader = document.querySelector('.loading-overlay');
        if (loader) {
            loader.remove();
        }
    }

    showError(message) {
        // عرض رسالة خطأ
        alert(message); // يمكن استبدالها بمكون أفضل لعرض الرسائل
    }

    showSuccess(message) {
        // عرض رسالة نجاح
        alert(message); // يمكن استبدالها بمكون أفضل لعرض الرسائل
    }
}

// تهيئة التطبيق
document.addEventListener('DOMContentLoaded', () => {
    new CashManagement();
});