/**
 * مكون مساعد للطباعة
 * التاريخ: 2025-05-09 03:41:00
 * المستخدم: mostafamohammad7760
 */

import { ref } from 'vue';
import { useStore } from 'vuex';

interface PrinterSettings {
  width: number;
  characterSet: string;
  encoding: string;
  driver: string;
  paperCut: boolean;
  openCashDrawer: boolean;
}

interface PrintJob {
  id: string;
  content: string;
  settings: PrinterSettings;
  timestamp: number;
  status: 'pending' | 'printing' | 'completed' | 'failed';
  error?: string;
}

export function usePrinter() {
  const store = useStore();
  const isPrinting = ref(false);
  const currentJob = ref<PrintJob | null>(null);
  const printQueue = ref<PrintJob[]>([]);

  // الحصول على إعدادات الطابعة من المتجر
  const getPrinterSettings = (): PrinterSettings => {
    return store.state.pos.settings.printer || {
      width: 48,
      characterSet: 'arabic',
      encoding: 'cp864',
      driver: 'ESC/POS',
      paperCut: true,
      openCashDrawer: true
    };
  };

  // إنشاء محتوى الفاتورة
  const createReceiptContent = (saleData: any): string => {
    const settings = getPrinterSettings();
    let content = '';

    // ترويسة الفاتورة
    content += '\x1B\x40'; // تهيئة الطابعة
    content += '\x1B\x61\x01'; // توسيط النص
    
    // شعار المتجر (إذا وجد)
    if (store.state.pos.settings.storeLogo) {
      content += `\x1B\x2A${store.state.pos.settings.storeLogo}\n`;
    }

    // معلومات المتجر
    content += `${store.state.pos.settings.storeName}\n`;
    content += `${store.state.pos.settings.storeAddress}\n`;
    content += `هاتف: ${store.state.pos.settings.storePhone}\n`;
    content += '\x1B\x61\x00'; // محاذاة للجانب الأيمن

    // معلومات الفاتورة
    content += `\nرقم الفاتورة: ${saleData.invoiceNumber}\n`;
    content += `التاريخ: ${new Date().toLocaleDateString('ar-SA')}\n`;
    content += `الوقت: ${new Date().toLocaleTimeString('ar-SA')}\n`;
    
    // معلومات العميل
    if (saleData.customer) {
      content += `العميل: ${saleData.customer.name}\n`;
    }

    // خط فاصل
    content += '-'.repeat(settings.width) + '\n';

    // تفاصيل المنتجات
    content += 'المنتج'.padEnd(20) + 'الكمية'.padEnd(8) + 'السعر'.padEnd(10) + 'المجموع\n';
    content += '-'.repeat(settings.width) + '\n';

    saleData.items.forEach((item: any) => {
      content += `${item.name.slice(0, 19).padEnd(20)}`;
      content += `${item.quantity.toString().padEnd(8)}`;
      content += `${item.price.toFixed(2).padEnd(10)}`;
      content += `${(item.quantity * item.price).toFixed(2)}\n`;
    });

    // الإجماليات
    content += '-'.repeat(settings.width) + '\n';
    content += `المجموع: ${saleData.subtotal.toFixed(2)}\n`;
    
    if (saleData.discount) {
      content += `الخصم: ${saleData.discount.toFixed(2)}\n`;
    }
    
    content += `الضريبة (${(saleData.taxRate * 100).toFixed(0)}%): ${saleData.taxAmount.toFixed(2)}\n`;
    content += `الإجمالي النهائي: ${saleData.total.toFixed(2)}\n`;

    // معلومات الدفع
    content += '-'.repeat(settings.width) + '\n';
    content += `طريقة الدفع: ${saleData.payment.method}\n`;
    content += `المبلغ المستلم: ${saleData.payment.received.toFixed(2)}\n`;
    if (saleData.payment.change > 0) {
      content += `الباقي: ${saleData.payment.change.toFixed(2)}\n`;
    }

    // النقاط (إذا كان العميل مسجلاً في برنامج الولاء)
    if (saleData.customer && saleData.loyaltyPoints) {
      content += '-'.repeat(settings.width) + '\n';
      content += `النقاط المكتسبة: ${saleData.loyaltyPoints.earned}\n`;
      content += `إجمالي النقاط: ${saleData.loyaltyPoints.total}\n`;
    }

    // تذييل الفاتورة
    content += '\x1B\x61\x01'; // توسيط النص
    content += '\nشكراً لتسوقكم معنا\n';
    if (store.state.pos.settings.vatNumber) {
      content += `الرقم الضريبي: ${store.state.pos.settings.vatNumber}\n`;
    }

    // قطع الورق إذا كان مفعلاً
    if (settings.paperCut) {
      content += '\x1B\x69'; // أمر قطع الورق
    }

    return content;
  };

  // طباعة فاتورة
  const printReceipt = async (saleData: any): Promise<boolean> => {
    if (isPrinting.value) {
      // إضافة المهمة لقائمة الانتظار
      const job: PrintJob = {
        id: Date.now().toString(),
        content: createReceiptContent(saleData),
        settings: getPrinterSettings(),
        timestamp: Date.now(),
        status: 'pending'
      };
      printQueue.value.push(job);
      return true;
    }

    try {
      isPrinting.value = true;
      const content = createReceiptContent(saleData);
      const settings = getPrinterSettings();

      currentJob.value = {
        id: Date.now().toString(),
        content,
        settings,
        timestamp: Date.now(),
        status: 'printing'
      };

      // إرسال أمر الطباعة للخادم
      await store.dispatch('pos/print', {
        content,
        settings
      });

      currentJob.value.status = 'completed';
      return true;

    } catch (error) {
      currentJob.value = {
        ...currentJob.value!,
        status: 'failed',
        error: error.message
      };
      throw error;

    } finally {
      isPrinting.value = false;
      // معالجة قائمة الانتظار
      if (printQueue.value.length > 0) {
        const nextJob = printQueue.value.shift();
        if (nextJob) {
          printReceipt(nextJob);
        }
      }
    }
  };

  return {
    isPrinting,
    currentJob,
    printQueue,
    printReceipt
  };
}