/**
 * التحقق من صحة البيانات المتعلقة بالأمان
 * @module SecurityValidators
 * التاريخ: 2025-05-09 02:43:29
 * المستخدم: mostafamohammad7760
 */

export class SecurityValidators {
    /**
     * قواعد التحقق من صحة كلمة المرور
     */
    static PASSWORD_RULES = {
        minLength: 8,
        maxLength: 128,
        requireUppercase: true,
        requireLowercase: true,
        requireNumbers: true,
        requireSpecial: true,
        maxRepeatingChars: 2,
        bannedPasswords: [
            'Password123',
            '12345678',
            'qwerty123',
            'admin1234'
        ]
    };

    /**
     * التحقق من صحة كلمة المرور
     * @param {string} password - كلمة المرور
     * @returns {Object} نتيجة التحقق
     */
    static validatePassword(password) {
        const result = {
            isValid: true,
            errors: []
        };

        // التحقق من الطول
        if (password.length < this.PASSWORD_RULES.minLength) {
            result.errors.push(`كلمة المرور يجب أن تكون ${this.PASSWORD_RULES.minLength} أحرف على الأقل`);
        }
        if (password.length > this.PASSWORD_RULES.maxLength) {
            result.errors.push(`كلمة المرور لا يجب أن تتجاوز ${this.PASSWORD_RULES.maxLength} حرف`);
        }

        // التحقق من وجود الأحرف المطلوبة
        if (this.PASSWORD_RULES.requireUppercase && !/[A-Z]/.test(password)) {
            result.errors.push('كلمة المرور يجب أن تحتوي على حرف كبير واحد على الأقل');
        }
        if (this.PASSWORD_RULES.requireLowercase && !/[a-z]/.test(password)) {
            result.errors.push('كلمة المرور يجب أن تحتوي على حرف صغير واحد على الأقل');
        }
        if (this.PASSWORD_RULES.requireNumbers && !/\d/.test(password)) {
            result.errors.push('كلمة المرور يجب أن تحتوي على رقم واحد على الأقل');
        }
        if (this.PASSWORD_RULES.requireSpecial && !/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
            result.errors.push('كلمة المرور يجب أن تحتوي على رمز خاص واحد على الأقل');
        }

        // التحقق من التكرار
        const repeatingChars = password.match(/(.)\1{2,}/g);
        if (repeatingChars) {
            result.errors.push('كلمة المرور لا يجب أن تحتوي على أحرف متكررة أكثر من مرتين متتاليتين');
        }

        // التحقق من كلمات المرور المحظورة
        if (this.PASSWORD_RULES.bannedPasswords.includes(password)) {
            result.errors.push('كلمة المرور غير مقبولة لأنها شائعة جداً');
        }

        result.isValid = result.errors.length === 0;
        return result;
    }

    /**
     * التحقق من صحة البريد الإلكتروني
     * @param {string} email - البريد الإلكتروني
     * @returns {Object} نتيجة التحقق
     */
    static validateEmail(email) {
        const result = {
            isValid: true,
            errors: []
        };

        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

        if (!emailRegex.test(email)) {
            result.errors.push('صيغة البريد الإلكتروني غير صحيحة');
            result.isValid = false;
        }

        // التحقق من طول البريد الإلكتروني
        if (email.length > 254) {
            result.errors.push('البريد الإلكتروني طويل جداً');
            result.isValid = false;
        }

        return result;
    }

    /**
     * التحقق من صحة رقم الهاتف
     * @param {string} phone - رقم الهاتف
     * @returns {Object} نتيجة التحقق
     */
    static validatePhone(phone) {
        const result = {
            isValid: true,
            errors: []
        };

        // نمط أرقام الهواتف السعودية
        const phoneRegex = /^((\+9665)|(05))[0-9]{8}$/;

        if (!phoneRegex.test(phone)) {
            result.errors.push('رقم الهاتف غير صالح. يجب أن يكون رقم هاتف سعودي صحيح');
            result.isValid = false;
        }

        return result;
    }

    /**
     * التحقق من صحة رمز التحقق
     * @param {string} code - رمز التحقق
     * @param {number} expectedLength - الطول المتوقع
     * @returns {Object} نتيجة التحقق
     */
    static validateVerificationCode(code, expectedLength = 6) {
        const result = {
            isValid: true,
            errors: []
        };

        if (code.length !== expectedLength) {
            result.errors.push(`رمز التحقق يجب أن يكون ${expectedLength} أرقام`);
            result.isValid = false;
        }

        if (!/^\d+$/.test(code)) {
            result.errors.push('رمز التحقق يجب أن يحتوي على أرقام فقط');
            result.isValid = false;
        }

        return result;
    }

    /**
     * التحقق من صحة اسم المستخدم
     * @param {string} username - اسم المستخدم
     * @returns {Object} نتيجة التحقق
     */
    static validateUsername(username) {
        const result = {
            isValid: true,
            errors: []
        };

        // التحقق من الطول
        if (username.length < 3) {
            result.errors.push('اسم المستخدم يجب أن يكون 3 أحرف على الأقل');
            result.isValid = false;
        }

        // التحقق من الأحرف المسموحة
        if (!/^[a-zA-Z0-9._-]+$/.test(username)) {
            result.errors.push('اسم المستخدم يجب أن يحتوي على أحرف وأرقام ونقاط وشرطات فقط');
            result.isValid = false;
        }

        return result;
    }

    /**
     * التحقق من صحة التوكن
     * @param {string} token - التوكن
     * @returns {Object} نتيجة التحقق
     */
    static validateToken(token) {
        const result = {
            isValid: true,
            errors: []
        };

        try {
            // التأكد من وجود ثلاثة أجزاء للتوكن
            const parts = token.split('.');
            if (parts.length !== 3) {
                throw new Error('صيغة التوكن غير صحيحة');
            }

            // فك تشفير الجزء الثاني (payload)
            const payload = JSON.parse(atob(parts[1]));

            // التحقق من انتهاء الصلاحية
            if (payload.exp && Date.now() >= payload.exp * 1000) {
                throw new Error('التوكن منتهي الصلاحية');
            }

        } catch (error) {
            result.errors.push(error.message);
            result.isValid = false;
        }

        return result;
    }

    /**
     * التحقق من صحة عنوان IP
     * @param {string} ip - عنوان IP
     * @returns {Object} نتيجة التحقق
     */
    static validateIPAddress(ip) {
        const result = {
            isValid: true,
            errors: []
        };

        const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
        const ipv6Regex = /^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;

        if (!ipv4Regex.test(ip) && !ipv6Regex.test(ip)) {
            result.errors.push('عنوان IP غير صالح');
            result.isValid = false;
        }

        return result;
    }
}