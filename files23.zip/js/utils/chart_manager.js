/**
 * مدير الرسوم البيانية للضرائب والزكاة
 * @class ChartManager
 */
export class ChartManager {
    constructor() {
        this.charts = new Map();
        this.defaultOptions = {
            responsive: true,
            maintainAspectRatio: false,
            rtl: true,
            locale: 'ar-SA',
            font: {
                family: 'Cairo, sans-serif',
                size: 14
            },
            plugins: {
                legend: {
                    position: 'bottom',
                    rtl: true
                },
                tooltip: {
                    rtl: true,
                    textDirection: 'rtl'
                }
            }
        };
    }

    /**
     * تهيئة رسم بياني خطي
     * @param {string} canvasId - معرف عنصر الكانفس
     * @param {Object} config - إعدادات الرسم البياني
     * @returns {Chart} كائن الرسم البياني
     */
    initializeLineChart(canvasId, config) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) {
            throw new Error(`لم يتم العثور على عنصر الكانفس: ${canvasId}`);
        }

        const ctx = canvas.getContext('2d');
        const chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: config.labels || [],
                datasets: config.datasets || []
            },
            options: {
                ...this.defaultOptions,
                ...(config.options || {}),
                scales: {
                    x: {
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        beginAtZero: true,
                        position: 'right'
                    }
                }
            }
        });

        this.charts.set(canvasId, chart);
        return chart;
    }

    /**
     * تهيئة رسم بياني شريطي
     * @param {string} canvasId - معرف عنصر الكانفس
     * @param {Object} config - إعدادات الرسم البياني
     * @returns {Chart} كائن الرسم البياني
     */
    initializeBarChart(canvasId, config) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) {
            throw new Error(`لم يتم العثور على عنصر الكانفس: ${canvasId}`);
        }

        const ctx = canvas.getContext('2d');
        const chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: config.labels || [],
                datasets: config.datasets || []
            },
            options: {
                ...this.defaultOptions,
                ...(config.options || {}),
                scales: {
                    x: {
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        beginAtZero: true,
                        position: 'right'
                    }
                }
            }
        });

        this.charts.set(canvasId, chart);
        return chart;
    }

    /**
     * تهيئة رسم بياني دائري
     * @param {string} canvasId - معرف عنصر الكانفس
     * @param {Object} config - إعدادات الرسم البياني
     * @returns {Chart} كائن الرسم البياني
     */
    initializePieChart(canvasId, config) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) {
            throw new Error(`لم يتم العثور على عنصر الكانفس: ${canvasId}`);
        }

        const ctx = canvas.getContext('2d');
        const chart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: config.labels || [],
                datasets: config.datasets || []
            },
            options: {
                ...this.defaultOptions,
                ...(config.options || {}),
                plugins: {
                    ...this.defaultOptions.plugins,
                    legend: {
                        position: 'bottom',
                        rtl: true
                    }
                }
            }
        });

        this.charts.set(canvasId, chart);
        return chart;
    }

    /**
     * تحديث بيانات رسم بياني
     * @param {string} canvasId - معرف عنصر الكانفس
     * @param {Object} newData - البيانات الجديدة
     */
    updateChart(canvasId, newData) {
        const chart = this.charts.get(canvasId);
        if (!chart) {
            throw new Error(`لم يتم العثور على الرسم البياني: ${canvasId}`);
        }

        if (newData.labels) {
            chart.data.labels = newData.labels;
        }

        if (newData.datasets) {
            chart.data.datasets = newData.datasets;
        }

        chart.update();
    }

    /**
     * إنشاء رسم بياني للتحليل الضريبي
     * @param {string} canvasId - معرف عنصر الكانفس
     * @param {Object} data - بيانات التحليل
     */
    createTaxAnalysisChart(canvasId, data) {
        return this.initializeLineChart(canvasId, {
            labels: data.periods,
            datasets: [
                {
                    label: 'ضريبة القيمة المضافة',
                    data: data.vatValues,
                    borderColor: '#2c4d76',
                    tension: 0.4
                },
                {
                    label: 'ضريبة الدخل',
                    data: data.incomeTaxValues,
                    borderColor: '#27ae60',
                    tension: 0.4
                }
            ],
            options: {
                scales: {
                    y: {
                        ticks: {
                            callback: value => `${value.toLocaleString()} ريال`
                        }
                    }
                }
            }
        });
    }

    /**
     * إنشاء رسم بياني لتحليل الزكاة
     * @param {string} canvasId - معرف عنصر الكانفس
     * @param {Object} data - بيانات الزكاة
     */
    createZakatAnalysisChart(canvasId, data) {
        return this.initializeBarChart(canvasId, {
            labels: data.years,
            datasets: [
                {
                    label: 'وعاء الزكاة',
                    data: data.baseValues,
                    backgroundColor: '#27ae60'
                },
                {
                    label: 'الزكاة المستحقة',
                    data: data.zakatValues,
                    backgroundColor: '#2c4d76'
                }
            ],
            options: {
                scales: {
                    y: {
                        ticks: {
                            callback: value => `${value.toLocaleString()} ريال`
                        }
                    }
                }
            }
        });
    }

    /**
     * تنظيف الرسوم البيانية
     */
    destroyCharts() {
        this.charts.forEach(chart => {
            chart.destroy();
        });
        this.charts.clear();
    }
}