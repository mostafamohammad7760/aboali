-- نظام نقاط البيع - مخطط قاعدة البيانات (الجزء الثاني)
-- التاريخ: 2025-05-09 03:20:03
-- المستخدم: mostafamohammad7760

-- جدول الورديات
CREATE TABLE shifts (
    shift_id VARCHAR(36) PRIMARY KEY,
    cashier_id VARCHAR(36) NOT NULL,
    register_id VARCHAR(36) NOT NULL,
    opening_amount DECIMAL(10,2) NOT NULL,
    closing_amount DECIMAL(10,2),
    counted_amount DECIMAL(10,2),
    difference_amount DECIMAL(10,2),
    opening_note TEXT,
    closing_note TEXT,
    status VARCHAR(20) DEFAULT 'active',
    started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    closed_at DATETIME,
    created_by VARCHAR(36),
    closed_by VARCHAR(36),
    FOREIGN KEY (cashier_id) REFERENCES users(user_id)
);

-- جدول العمليات النقدية
CREATE TABLE cash_operations (
    operation_id VARCHAR(36) PRIMARY KEY,
    shift_id VARCHAR(36) NOT NULL,
    type VARCHAR(20) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(20) DEFAULT 'cash',
    reference_id VARCHAR(36),
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(36),
    FOREIGN KEY (shift_id) REFERENCES shifts(shift_id)
);

-- جدول حركات المخزون
CREATE TABLE inventory_transactions (
    transaction_id VARCHAR(36) PRIMARY KEY,
    type VARCHAR(20) NOT NULL,
    reference_id VARCHAR(36),
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(36)
);

-- جدول تفاصيل حركات المخزون
CREATE TABLE inventory_transaction_details (
    transaction_id VARCHAR(36),
    product_id VARCHAR(36),
    quantity INT NOT NULL,
    unit_cost DECIMAL(10,2),
    unit_price DECIMAL(10,2),
    batch_number VARCHAR(50),
    expiry_date DATE,
    location_id VARCHAR(36),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (transaction_id, product_id),
    FOREIGN KEY (transaction_id) REFERENCES inventory_transactions(transaction_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- جدول تنبيهات المخزون
CREATE TABLE inventory_alerts (
    alert_id VARCHAR(36) PRIMARY KEY,
    alert_type VARCHAR(20) NOT NULL,
    product_id VARCHAR(36) NOT NULL,
    message TEXT,
    status VARCHAR(20) DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    resolved_at DATETIME,
    created_by VARCHAR(36),
    resolved_by VARCHAR(36),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- جدول الخصومات
CREATE TABLE discounts (
    discount_id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    type VARCHAR(20) NOT NULL,
    value DECIMAL(10,2) NOT NULL,
    min_purchase DECIMAL(10,2) DEFAULT 0,
    max_discount DECIMAL(10,2),
    start_date DATETIME NOT NULL,
    end_date DATETIME NOT NULL,
    is_active BOOLEAN DEFAULT true,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME ON UPDATE CURRENT_TIMESTAMP,
    created_by VARCHAR(36),
    updated_by VARCHAR(36)
);

-- جدول شروط الخصومات
CREATE TABLE discount_conditions (
    discount_id VARCHAR(36),
    condition_type VARCHAR(20) NOT NULL,
    condition_value TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (discount_id, condition_type),
    FOREIGN KEY (discount_id) REFERENCES discounts(discount_id)
);

-- جدول المنتجات المشمولة في الخصومات
CREATE TABLE discount_products (
    discount_id VARCHAR(36),
    product_id VARCHAR(36),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (discount_id, product_id),
    FOREIGN KEY (discount_id) REFERENCES discounts(discount_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- جدول قوالب الطباعة
CREATE TABLE print_templates (
    template_id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type VARCHAR(20) NOT NULL,
    content TEXT NOT NULL,
    version INT DEFAULT 1,
    is_active BOOLEAN DEFAULT true,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME ON UPDATE CURRENT_TIMESTAMP,
    created_by VARCHAR(36),
    updated_by VARCHAR(36)
);

-- جدول سجلات الطباعة
CREATE TABLE print_logs (
    log_id VARCHAR(36) PRIMARY KEY,
    template_id VARCHAR(36) NOT NULL,
    content TEXT,
    printer_name VARCHAR(100),
    status VARCHAR(20),
    error_message TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(36),
    FOREIGN KEY (template_id) REFERENCES print_templates(template_id)
);

-- جدول الإشعارات
CREATE TABLE notifications (
    notification_id VARCHAR(36) PRIMARY KEY,
    type VARCHAR(20) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    recipient_type VARCHAR(20) NOT NULL,
    recipient_id VARCHAR(36),
    status VARCHAR(20) DEFAULT 'pending',
    priority VARCHAR(20) DEFAULT 'normal',
    read_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME,
    created_by VARCHAR(36)
);

-- جدول إشعارات المستخدمين
CREATE TABLE user_notifications (
    user_id VARCHAR(36),
    notification_id VARCHAR(36),
    is_read BOOLEAN DEFAULT false,
    read_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, notification_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (notification_id) REFERENCES notifications(notification_id)
);