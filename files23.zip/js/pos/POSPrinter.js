/**
 * مدير الطباعة - إدارة طباعة الفواتير والتقارير
 * @module POSPrinter
 * التاريخ: 2025-05-09 02:55:50
 * المستخدم: mostafamohammad7760
 */

export class POSPrinter {
    constructor() {
        this.printerConfig = {
            width: 48, // عرض الورق بالحروف
            encoding: 'windows-1256',
            defaultFont: 'monospace',
            fontSize: '12px',
            lineHeight: '1.2',
            logo: null, // يمكن إضافة شعار المتجر
            companyInfo: {
                name: 'اسم المتجر',
                address: 'عنوان المتجر',
                phone: '966500000000',
                vatNumber: '123456789012345'
            }
        };

        // قائمة الطابعات المتاحة
        this.availablePrinters = [];
        
        // الطابعة الافتراضية
        this.defaultPrinter = null;

        // تهيئة الطابعات
        this.initializePrinters();
    }

    /**
     * تهيئة الطابعات المتاحة
     */
    async initializePrinters() {
        try {
            if (typeof navigator.usb !== 'undefined') {
                // البحث عن طابعات USB
                const devices = await navigator.usb.getDevices();
                this.availablePrinters = devices.filter(device => 
                    device.configurations.some(config => 
                        config.interfaces.some(interface => 
                            interface.alternates.some(alternate => 
                                alternate.endpoints.some(endpoint => 
                                    endpoint.type === 'printer'
                                )
                            )
                        )
                    )
                );
            }

            // إذا كانت الطباعة عبر الويب متاحة
            if (typeof window.print === 'function') {
                this.availablePrinters.push({
                    type: 'browser',
                    name: 'Browser Print'
                });
            }
        } catch (error) {
            console.error('Error initializing printers:', error);
        }
    }

    /**
     * طباعة فاتورة
     * @param {Object} sale - بيانات عملية البيع
     */
    async printReceipt(sale) {
        try {
            const receiptHTML = this.generateReceiptHTML(sale);
            
            // إنشاء نافذة الطباعة
            const printWindow = window.open('', 'طباعة الفاتورة', 'height=600,width=800');
            printWindow.document.write('<html dir="rtl"><head><title>فاتورة</title>');
            
            // إضافة الأنماط
            printWindow.document.write(this.getReceiptStyles());
            
            // إضافة المحتوى
            printWindow.document.write('</head><body>');
            printWindow.document.write(receiptHTML);
            printWindow.document.write('</body></html>');
            
            // الانتظار حتى تحميل المحتوى
            printWindow.document.close();
            printWindow.focus();
            
            // طباعة
            await new Promise(resolve => setTimeout(resolve, 1000));
            printWindow.print();
            printWindow.close();

            return true;
        } catch (error) {
            console.error('Error printing receipt:', error);
            throw new Error('حدث خطأ أثناء الطباعة');
        }
    }

    /**
     * إنشاء HTML للفاتورة
     * @param {Object} sale - بيانات عملية البيع
     */
    generateReceiptHTML(sale) {
        const {
            invoice_number,
            sale_date,
            items,
            totals,
            payment,
            customer
        } = sale;

        return `
            <div class="receipt">
                ${this.printerConfig.logo ? 
                    `<img src="${this.printerConfig.logo}" class="logo" alt="شعار المتجر">` : 
                    ''
                }
                
                <div class="header">
                    <h1>${this.printerConfig.companyInfo.name}</h1>
                    <p>${this.printerConfig.companyInfo.address}</p>
                    <p>هاتف: ${this.printerConfig.companyInfo.phone}</p>
                    <p>الرقم الضريبي: ${this.printerConfig.companyInfo.vatNumber}</p>
                </div>

                <div class="invoice-info">
                    <p>رقم الفاتورة: ${invoice_number}</p>
                    <p>التاريخ: ${new Date(sale_date).toLocaleString('ar-SA')}</p>
                    ${customer ? `<p>العميل: ${customer.name}</p>` : ''}
                </div>

                <table class="items">
                    <thead>
                        <tr>
                            <th>المنتج</th>
                            <th>الكمية</th>
                            <th>السعر</th>
                            <th>المجموع</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${items.map(item => `
                            <tr>
                                <td>${item.name}</td>
                                <td>${item.quantity}</td>
                                <td>${this.formatCurrency(item.price)}</td>
                                <td>${this.formatCurrency(item.total)}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>

                <div class="totals">
                    <div class="total-row">
                        <span>المجموع الفرعي:</span>
                        <span>${this.formatCurrency(totals.subtotal)}</span>
                    </div>
                    ${totals.discount > 0 ? `
                        <div class="total-row">
                            <span>الخصم:</span>
                            <span>${this.formatCurrency(totals.discount)}</span>
                        </div>
                    ` : ''}
                    <div class="total-row">
                        <span>ضريبة القيمة المضافة (15%):</span>
                        <span>${this.formatCurrency(totals.tax)}</span>
                    </div>
                    <div class="total-row grand-total">
                        <span>الإجمالي:</span>
                        <span>${this.formatCurrency(totals.total)}</span>
                    </div>
                </div>

                <div class="payment-info">
                    <p>طريقة الدفع: ${payment.paymentMethod.name}</p>
                    ${payment.reference ? `<p>رقم المرجع: ${payment.reference}</p>` : ''}
                    ${payment.received > totals.total ? `
                        <div class="payment-details">
                            <p>المبلغ المستلم: ${this.formatCurrency(payment.received)}</p>
                            <p>المتبقي: ${this.formatCurrency(payment.change)}</p>
                        </div>
                    ` : ''}
                </div>

                <div class="footer">
                    <p>شكراً لتسوقكم معنا</p>
                    <p>الرجاء الاحتفاظ بالفاتورة للمراجعة</p>
                    <barcode>${invoice_number}</barcode>
                </div>
            </div>
        `;
    }

    /**
     * إنشاء أنماط CSS للفاتورة
     */
    getReceiptStyles() {
        return `
            <style>
                @media print {
                    @page {
                        margin: 0;
                        size: 80mm auto;
                    }
                }

                body {
                    font-family: ${this.printerConfig.defaultFont};
                    font-size: ${this.printerConfig.fontSize};
                    line-height: ${this.printerConfig.lineHeight};
                    margin: 0;
                    padding: 10px;
                }

                .receipt {
                    width: 100%;
                    max-width: 80mm;
                    margin: 0 auto;
                }

                .logo {
                    max-width: 150px;
                    height: auto;
                    display: block;
                    margin: 0 auto 10px;
                }

                .header {
                    text-align: center;
                    margin-bottom: 20px;
                }

                .header h1 {
                    margin: 0 0 5px;
                    font-size: 16px;
                }

                .header p {
                    margin: 2px 0;
                    font-size: 12px;
                }

                .invoice-info {
                    margin-bottom: 15px;
                    border-top: 1px dashed #000;
                    border-bottom: 1px dashed #000;
                    padding: 5px 0;
                }

                .items {
                    width: 100%;
                    border-collapse: collapse;
                    margin-bottom: 15px;
                }

                .items th,
                .items td {
                    text-align: right;
                    padding: 3px;
                    font-size: 12px;
                }

                .items th {
                    border-bottom: 1px solid #000;
                }

                .totals {
                    margin-bottom: 15px;
                    border-top: 1px dashed #000;
                }

                .total-row {
                    display: flex;
                    justify-content: space-between;
                    margin: 5px 0;
                }

                .grand-total {
                    font-weight: bold;
                    font-size: 14px;
                    border-top: 1px solid #000;
                    padding-top: 5px;
                }

                .payment-info {
                    margin-bottom: 15px;
                    padding: 5px 0;
                    border-top: 1px dashed #000;
                    border-bottom: 1px dashed #000;
                }

                .footer {
                    text-align: center;
                    font-size: 12px;
                    margin-top: 15px;
                }

                barcode {
                    display: block;
                    margin: 10px auto;
                    text-align: center;
                }
            </style>
        `;
    }

    /**
     * تنسيق المبالغ المالية
     * @param {number} amount - المبلغ
     */
    formatCurrency(amount) {
        return `${amount.toFixed(2)} ريال`;
    }

    /**
     * طباعة تقرير
     * @param {string} reportType - نوع التقرير
     * @param {Object} data - بيانات التقرير
     */
    async printReport(reportType, data) {
        // يمكن إضافة المزيد من أنواع التقارير هنا
        const reportTemplates = {
            'shift': this.generateShiftReport,
            'sales': this.generateSalesReport,
            'inventory': this.generateInventoryReport
        };

        if (!reportTemplates[reportType]) {
            throw new Error('نوع التقرير غير مدعوم');
        }

        const reportHTML = reportTemplates[reportType](data);
        await this.printContent(reportHTML);
    }

    /**
     * طباعة محتوى
     * @param {string} content - المحتوى المراد طباعته
     */
    async printContent(content) {
        try {
            const printWindow = window.open('', '', 'height=600,width=800');
            printWindow.document.write('<html><head><title>طباعة</title>');
            printWindow.document.write(this.getReceiptStyles());
            printWindow.document.write('</head><body>');
            printWindow.document.write(content);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.focus();
            
            await new Promise(resolve => setTimeout(resolve, 1000));
            printWindow.print();
            printWindow.close();

            return true;
        } catch (error) {
            console.error('Error printing content:', error);
            throw new Error('حدث خطأ أثناء الطباعة');
        }
    }
}