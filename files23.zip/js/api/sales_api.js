export class SalesAPI {
    constructor() {
        this.baseUrl = '/api/v1/sales';
        this.defaultHeaders = {
            'Content-Type': 'application/json',
            'X-User-Id': 'mostafamohammad7760',
            'X-Timestamp': new Date().toISOString()
        };
    }

    async request(endpoint, options = {}) {
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                ...options,
                headers: {
                    ...this.defaultHeaders,
                    ...options.headers
                }
            });

            if (!response.ok) {
                throw await this.handleErrorResponse(response);
            }

            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            throw this.createUserFriendlyError(error);
        }
    }

    // طلبات لوحة المعلومات
    async getSalesStats() {
        return this.request('/dashboard/sales-stats');
    }

    async getOrderStats() {
        return this.request('/dashboard/order-stats');
    }

    async getQuotationStats() {
        return this.request('/dashboard/quotation-stats');
    }

    async getReceivablesStats() {
        return this.request('/dashboard/receivables-stats');
    }

    async getSalesAnalysis(period = 'month') {
        return this.request(`/dashboard/sales-analysis?period=${period}`);
    }

    async getTopProducts(period = 'month') {
        return this.request(`/dashboard/top-products?period=${period}`);
    }

    async getLatestInvoices() {
        return this.request('/dashboard/latest-invoices');
    }

    // طلبات العملاء
    async getCustomers(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/customers?${queryString}`);
    }

    async getCustomer(customerId) {
        return this.request(`/customers/${customerId}`);
    }

    async createCustomer(customerData) {
        this.validateCustomerData(customerData);
        return this.request('/customers', {
            method: 'POST',
            body: JSON.stringify(customerData)
        });
    }

    async updateCustomer(customerId, customerData) {
        this.validateCustomerData(customerData);
        return this.request(`/customers/${customerId}`, {
            method: 'PUT',
            body: JSON.stringify(customerData)
        });
    }

    async deleteCustomer(customerId) {
        return this.request(`/customers/${customerId}`, {
            method: 'DELETE'
        });
    }

    // طلبات قوائم الأسعار
    async getPriceLists(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/price-lists?${queryString}`);
    }

    async getPriceList(priceListId) {
        return this.request(`/price-lists/${priceListId}`);
    }

    async createPriceList(priceListData) {
        this.validatePriceListData(priceListData);
        return this.request('/price-lists', {
            method: 'POST',
            body: JSON.stringify(priceListData)
        });
    }

    async updatePriceList(priceListId, priceListData) {
        this.validatePriceListData(priceListData);
        return this.request(`/price-lists/${priceListId}`, {
            method: 'PUT',
            body: JSON.stringify(priceListData)
        });
    }

    async deletePriceList(priceListId) {
        return this.request(`/price-lists/${priceListId}`, {
            method: 'DELETE'
        });
    }

    // طلبات عروض الأسعار
    async getQuotations(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/quotations?${queryString}`);
    }

    async getQuotation(quotationId) {
        return this.request(`/quotations/${quotationId}`);
    }

    async createQuotation(quotationData) {
        this.validateQuotationData(quotationData);
        return this.request('/quotations', {
            method: 'POST',
            body: JSON.stringify(quotationData)
        });
    }

    async updateQuotation(quotationId, quotationData) {
        this.validateQuotationData(quotationData);
        return this.request(`/quotations/${quotationId}`, {
            method: 'PUT',
            body: JSON.stringify(quotationData)
        });
    }

    async deleteQuotation(quotationId) {
        return this.request(`/quotations/${quotationId}`, {
            method: 'DELETE'
        });
    }

    async sendQuotation(quotationId) {
        return this.request(`/quotations/${quotationId}/send`, {
            method: 'PUT'
        });
    }

    async acceptQuotation(quotationId) {
        return this.request(`/quotations/${quotationId}/accept`, {
            method: 'PUT'
        });
    }

    async rejectQuotation(quotationId, reason) {
        return this.request(`/quotations/${quotationId}/reject`, {
            method: 'PUT',
            body: JSON.stringify({ reason })
        });
    }

    // طلبات أوامر البيع
    async getOrders(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/orders?${queryString}`);
    }

    async getOrder(orderId) {
        return this.request(`/orders/${orderId}`);
    }

    async createOrder(orderData) {
        this.validateOrderData(orderData);
        return this.request('/orders', {
            method: 'POST',
            body: JSON.stringify(orderData)
        });
    }

    async updateOrder(orderId, orderData) {
        this.validateOrderData(orderData);
        return this.request(`/orders/${orderId}`, {
            method: 'PUT',
            body: JSON.stringify(orderData)
        });
    }

    async confirmOrder(orderId) {
        return this.request(`/orders/${orderId}/confirm`, {
            method: 'PUT'
        });
    }

    async shipOrder(orderId, shippingData) {
        return this.request(`/orders/${orderId}/ship`, {
            method: 'PUT',
            body: JSON.stringify(shippingData)
        });
    }

    async deliverOrder(orderId) {
        return this.request(`/orders/${orderId}/deliver`, {
            method: 'PUT'
        });
    }

    async cancelOrder(orderId, reason) {
        return this.request(`/orders/${orderId}/cancel`, {
            method: 'PUT',
            body: JSON.stringify({ reason })
        });
    }

    // طلبات الفواتير
    async getInvoices(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/invoices?${queryString}`);
    }

    async getInvoice(invoiceId) {
        return this.request(`/invoices/${invoiceId}`);
    }

    async createInvoice(invoiceData) {
        this.validateInvoiceData(invoiceData);
        return this.request('/invoices', {
            method: 'POST',
            body: JSON.stringify(invoiceData)
        });
    }

    async updateInvoice(invoiceId, invoiceData) {
        this.validateInvoiceData(invoiceData);
        return this.request(`/invoices/${invoiceId}`, {
            method: 'PUT',
            body: JSON.stringify(invoiceData)
        });
    }

    async postInvoice(invoiceId) {
        return this.request(`/invoices/${invoiceId}/post`, {
            method: 'PUT'
        });
    }

    async collectPayment(invoiceId, paymentData) {
        this.validatePaymentData(paymentData);
        return this.request(`/invoices/${invoiceId}/collect`, {
            method: 'PUT',
            body: JSON.stringify(paymentData)
        });
    }

    async cancelInvoice(invoiceId, reason) {
        return this.request(`/invoices/${invoiceId}/cancel`, {
            method: 'PUT',
            body: JSON.stringify({ reason })
        });
    }

    // طلبات المرتجعات
    async getReturns(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/returns?${queryString}`);
    }

    async getReturn(returnId) {
        return this.request(`/returns/${returnId}`);
    }

    async createReturn(returnData) {
        this.validateReturnData(returnData);
        return this.request('/returns', {
            method: 'POST',
            body: JSON.stringify(returnData)
        });
    }

    async updateReturn(returnId, returnData) {
        this.validateReturnData(returnData);
        return this.request(`/returns/${returnId}`, {
            method: 'PUT',
            body: JSON.stringify(returnData)
        });
    }

    async postReturn(returnId) {
        return this.request(`/returns/${returnId}/post`, {
            method: 'PUT'
        });
    }

    async cancelReturn(returnId, reason) {
        return this.request(`/returns/${returnId}/cancel`, {
            method: 'PUT',
            body: JSON.stringify({ reason })
        });
    }

    // طلبات التقارير
    async getSalesReport(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/sales?${queryString}`);
    }

    async getCustomerStatement(customerId, params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/customer-statement/${customerId}?${queryString}`);
    }

    async getProductSalesReport(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/product-sales?${queryString}`);
    }

    async getSalesByCustomerReport(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/sales-by-customer?${queryString}`);
    }

    // توابع التحقق من صحة البيانات
    validateCustomerData(customerData) {
        const requiredFields = ['code', 'name'];
        
        const missingFields = requiredFields.filter(field => !customerData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        if (customerData.email && !this.isValidEmail(customerData.email)) {
            throw new Error('البريد الإلكتروني غير صالح');
        }

        return true;
    }

    validatePriceListData(priceListData) {
        if (!priceListData.name) {
            throw new Error('اسم قائمة الأسعار مطلوب');
        }

        return true;
    }

    validateQuotationData(quotationData) {
        if (!quotationData.customerId || !quotationData.items?.length) {
            throw new Error('العميل والأصناف مطلوبة');
        }

        quotationData.items.forEach((item, index) => {
            if (!item.itemId || !item.quantity || !item.unitPrice) {
                throw new Error(`البند رقم ${index + 1} يحتوي على بيانات ناقصة`);
            }
        });

        return true;
    }

    validateOrderData(orderData) {
        if (!orderData.customerId || !orderData.items?.length) {
            throw new Error('العميل والأصناف مطلوبة');
        }

        orderData.items.forEach((item, index) => {
            if (!item.itemId || !item.quantity || !item.unitPrice) {
                throw new Error(`البند رقم ${index + 1} يحتوي على بيانات ناقصة`);
            }
        });

        return true;
    }

    validateInvoiceData(invoiceData) {
        if (!invoiceData.customerId || !invoiceData.items?.length) {
            throw new Error('العميل والأصناف مطلوبة');
        }

        invoiceData.items.forEach((item, index) => {
            if (!item.itemId || !item.quantity || !item.unitPrice) {
                throw new Error(`البند رقم ${index + 1} يحتوي على بيانات ناقصة`);
            }
        });

        return true;
    }

    validateReturnData(returnData) {
        if (!returnData.customerId || !returnData.items?.length) {
            throw new Error('العميل والأصناف مطلوبة');
        }

        returnData.items.forEach((item, index) => {
            if (!item.itemId || !item.quantity || !item.unitPrice) {
                throw new Error(`البند رقم ${index + 1} يحتوي على بيانات ناقصة`);
            }
        });

        if (!returnData.reason) {
            throw new Error('سبب المرتجع مطلوب');
        }

        return true;
    }

    validatePaymentData(paymentData) {
        if (!paymentData.amount || paymentData.amount <= 0) {
            throw new Error('مبلغ الدفعة غير صالح');
        }

        if (!paymentData.paymentMethod) {
            throw new Error('طريقة الدفع مطلوبة');
        }

        return true;
    }

    // توابع مساعدة
    isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    // توابع معالجة الأخطاء
    async handleErrorResponse(response) {
        let error;
        try {
            const errorData = await response.json();
            error = new Error(errorData.message || 'حدث خطأ غير معروف');
            error.code = errorData.code;
            error.details = errorData.details;
        } catch {
            error = new Error(`خطأ في الطلب: ${response.status}`);
        }
        error.status = response.status;
        return error;
    }

    createUserFriendlyError(error) {
        const errorMessages = {
            400: 'البيانات المدخلة غير صحيحة',
            401: 'يرجى تسجيل الدخول مرة أخرى',
            403: 'ليس لديك صلاحية للقيام بهذا الإجراء',
            404: 'لم يتم العثور على البيانات المطلوبة',
            409: 'تعارض في البيانات',
            422: 'البيانات المدخلة غير صالحة',
            500: 'حدث خطأ في النظام'
        };

        return new Error(
            errorMessages[error.status] || 
            error.message || 
            'حدث خطأ غير متوقع'
        );
    }
}