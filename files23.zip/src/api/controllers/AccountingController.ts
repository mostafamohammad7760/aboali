/**
 * تحكم الحسابات API
 * التاريخ: 2025-05-09 04:26:01
 * المستخدم: mostafamohammad7760
 */

import { Request, Response } from 'express';
import { AccountingService } from '../../services/AccountingService';
import { validateRequest } from '../middleware/validation';
import { authorize } from '../middleware/auth';

export class AccountingController {
  private accountingService: AccountingService;

  constructor() {
    this.accountingService = new AccountingService();
  }

  /**
   * إنشاء قيد محاسبي
   */
  @authorize(['accounting.create_entry'])
  public async createJournalEntry(req: Request, res: Response): Promise<void> {
    try {
      validateRequest(req.body, {
        date: 'required|date',
        items: 'required|array|min:2',
        'items.*.accountId': 'required|numeric',
        'items.*.debit': 'required|numeric|min:0',
        'items.*.credit': 'required|numeric|min:0',
        notes: 'string'
      });

      const entry = await this.accountingService.createJournalEntry({
        date: new Date(req.body.date),
        items: req.body.items,
        notes: req.body.notes
      });

      res.status(201).json({
        success: true,
        data: entry
      });

    } catch (error) {
      res.status(400).json({
        success: false,
        message: error.message
      });
    }
  }

  /**
   * ترحيل قيد محاسبي
   */
  @authorize(['accounting.post_entry'])
  public async postJournalEntry(req: Request, res: Response): Promise<void> {
    try {
      validateRequest(req.params, {
        id: 'required|numeric'
      });

      await this.accountingService.postJournalEntry(
        parseInt(req.params.id)
      );

      res.status(200).json({
        success: true,
        message: 'تم ترحيل القيد بنجاح'
      });

    } catch (error) {
      res.status(400).json({
        success: false,
        message: error.message
      });
    }
  }

  /**
   * استخراج ميزان المراجعة
   */
  @authorize(['accounting.view_reports'])
  public async getTrialBalance(req: Request, res: Response): Promise<void> {
    try {
      validateRequest(req.query, {
        date: 'required|date'
      });

      const trialBalance = await this.accountingService.getTrialBalance(
        new Date(req.query.date as string)
      );

      res.status(200).json({
        success: true,
        data: trialBalance
      });

    } catch (error) {
      res.status(400).json({
        success: false,
        message: error.message
      });
    }
  }
}