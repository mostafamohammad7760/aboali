/**
 * نموذج إعدادات التكامل
 * التاريخ: 2025-05-09 04:30:01
 * المستخدم: mostafamohammad7760
 */

import { Model, DataTypes } from 'sequelize';
import { sequelize } from './index';

export class IntegrationSetting extends Model {
  public id!: number;
  public code!: string;
  public name!: string;
  public system!: string;
  public config!: any;
  public active!: boolean;
  public readonly createdAt!: Date;
  public readonly updatedAt!: Date;
}

IntegrationSetting.init({
  id: {
    type: DataTypes.BIGINT,
    autoIncrement: true,
    primaryKey: true
  },
  code: {
    type: DataTypes.STRING(50),
    allowNull: false,
    unique: true
  },
  name: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  system: {
    type: DataTypes.ENUM('sage', 'quickbooks', 'sap', 'excel', 'custom'),
    allowNull: false
  },
  config: {
    type: DataTypes.JSON,
    allowNull: false
  },
  active: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  }
}, {
  sequelize,
  tableName: 'integration_settings'
});