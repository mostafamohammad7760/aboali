import { SalesAPI } from './api/sales_api.js';
import { ChartManager } from './chart_manager.js';
import { formatCurrency, formatNumber, formatDate } from './utils/formatters.js';
import { validateQuotation, validateOrder, validateInvoice } from './utils/validators.js';

class Sales {
    constructor() {
        this.api = new SalesAPI();
        this.charts = new ChartManager();
        this.currentUser = 'mostafamohammad7760';
        
        // تهيئة المكونات والبيانات
        this.initializeComponents();
        this.attachEventListeners();
        this.loadDashboardData();
        
        // تحديث الوقت كل ثانية
        this.updateDateTime();
        setInterval(() => this.updateDateTime(), 1000);
    }

    initializeComponents() {
        // عناصر لوحة المعلومات
        this.dashboardElements = {
            // المبيعات
            totalSales: document.getElementById('totalSales'),
            totalPayments: document.getElementById('totalPayments'),
            totalReturns: document.getElementById('totalReturns'),
            
            // الطلبات
            processingOrders: document.getElementById('processingOrders'),
            shippedOrders: document.getElementById('shippedOrders'),
            deliveredOrders: document.getElementById('deliveredOrders'),
            
            // عروض الأسعار
            pendingQuotations: document.getElementById('pendingQuotations'),
            acceptedQuotations: document.getElementById('acceptedQuotations'),
            rejectedQuotations: document.getElementById('rejectedQuotations'),
            
            // المستحقات
            totalReceivables: document.getElementById('totalReceivables'),
            overdueReceivables: document.getElementById('overdueReceivables'),
            lastCollection: document.getElementById('lastCollection'),
            
            // الجداول
            latestInvoicesTable: document.getElementById('latestInvoicesTable')
        };

        // عناصر الفلترة
        this.filterElements = {
            salesChartPeriod: document.getElementById('salesChartPeriod'),
            topProductsPeriod: document.getElementById('topProductsPeriod')
        };

        // تهيئة الرسوم البيانية
        this.initializeCharts();
        
        // تهيئة القوالب
        this.invoiceRowTemplate = document.getElementById('invoiceRowTemplate');
    }

    async loadDashboardData() {
        try {
            this.showLoading();

            const [
                salesStats,
                orderStats,
                quotationStats,
                receivablesStats,
                salesAnalysis,
                topProducts,
                latestInvoices
            ] = await Promise.all([
                this.api.getSalesStats(),
                this.api.getOrderStats(),
                this.api.getQuotationStats(),
                this.api.getReceivablesStats(),
                this.api.getSalesAnalysis(this.filterElements.salesChartPeriod.value),
                this.api.getTopProducts(this.filterElements.topProductsPeriod.value),
                this.api.getLatestInvoices()
            ]);

            this.updateSalesStats(salesStats);
            this.updateOrderStats(orderStats);
            this.updateQuotationStats(quotationStats);
            this.updateReceivablesStats(receivablesStats);
            this.updateCharts(salesAnalysis, topProducts);
            this.renderLatestInvoices(latestInvoices);

            this.hideLoading();
        } catch (error) {
            this.hideLoading();
            this.showError('حدث خطأ أثناء تحميل البيانات');
            console.error('Dashboard loading error:', error);
        }
    }

    initializeCharts() {
        // تهيئة رسم تحليل المبيعات
        this.charts.initializeLineChart('salesAnalysisChart', {
            labels: [],
            datasets: [
                {
                    label: 'المبيعات',
                    data: [],
                    borderColor: '#27ae60',
                    backgroundColor: 'rgba(39, 174, 96, 0.1)',
                    fill: true
                },
                {
                    label: 'المرتجعات',
                    data: [],
                    borderColor: '#e74c3c',
                    backgroundColor: 'rgba(231, 76, 60, 0.1)',
                    fill: true
                }
            ],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => formatCurrency(value)
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: context => formatCurrency(context.parsed.y)
                        }
                    }
                }
            }
        });

        // تهيئة رسم أعلى المنتجات مبيعاً
        this.charts.initializeBarChart('topProductsChart', {
            labels: [],
            datasets: [{
                data: [],
                backgroundColor: [
                    '#2ecc71',
                    '#3498db',
                    '#f1c40f',
                    '#e67e22',
                    '#e74c3c',
                    '#9b59b6',
                    '#34495e',
                    '#16a085',
                    '#2980b9',
                    '#8e44ad'
                ]
            }],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: 'y',
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: context => 
                                `${context.label}: ${formatCurrency(context.parsed)}`
                        }
                    }
                }
            }
        });
    }

    updateSalesStats(stats) {
        this.dashboardElements.totalSales.textContent = 
            formatCurrency(stats.total);
        this.dashboardElements.totalPayments.textContent = 
            formatCurrency(stats.payments);
        this.dashboardElements.totalReturns.textContent = 
            formatCurrency(stats.returns);
    }

    updateOrderStats(stats) {
        this.dashboardElements.processingOrders.textContent = 
            formatNumber(stats.processing);
        this.dashboardElements.shippedOrders.textContent = 
            formatNumber(stats.shipped);
        this.dashboardElements.deliveredOrders.textContent = 
            formatNumber(stats.delivered);
    }

    updateQuotationStats(stats) {
        this.dashboardElements.pendingQuotations.textContent = 
            formatNumber(stats.pending);
        this.dashboardElements.acceptedQuotations.textContent = 
            formatNumber(stats.accepted);
        this.dashboardElements.rejectedQuotations.textContent = 
            formatNumber(stats.rejected);
    }

    updateReceivablesStats(stats) {
        this.dashboardElements.totalReceivables.textContent = 
            formatCurrency(stats.total);
        this.dashboardElements.overdueReceivables.textContent = 
            formatCurrency(stats.overdue);
        this.dashboardElements.lastCollection.textContent = 
            stats.lastCollection ? formatDate(stats.lastCollection) : '-';
    }

    updateCharts(salesData, productsData) {
        // تحديث رسم تحليل المبيعات
        this.charts.updateLineChart('salesAnalysisChart', {
            labels: salesData.labels,
            datasets: [
                {
                    data: salesData.sales,
                    label: 'المبيعات'
                },
                {
                    data: salesData.returns,
                    label: 'المرتجعات'
                }
            ]
        });

        // تحديث رسم أعلى المنتجات مبيعاً
        this.charts.updateBarChart('topProductsChart', {
            labels: productsData.labels,
            data: productsData.values
        });
    }

    renderLatestInvoices(invoices) {
        const tbody = this.dashboardElements.latestInvoicesTable;
        tbody.innerHTML = '';

        invoices.forEach(invoice => {
            const tr = this.createInvoiceRow(invoice);
            tbody.appendChild(tr);
        });
    }

    createInvoiceRow(invoice) {
        const template = this.invoiceRowTemplate.content.cloneNode(true);
        const tr = template.querySelector('tr');
        
        tr.querySelector('.invoice-number').textContent = invoice.number;
        tr.querySelector('.invoice-date').textContent = 
            formatDate(invoice.date);
        tr.querySelector('.customer-name').textContent = invoice.customer;
        tr.querySelector('.amount').textContent = 
            formatCurrency(invoice.amount);
        tr.querySelector('.paid').textContent = 
            formatCurrency(invoice.paid);
        tr.querySelector('.remaining').textContent = 
            formatCurrency(invoice.remaining);
        
        const statusCell = tr.querySelector('.invoice-status');
        statusCell.textContent = this.translateInvoiceStatus(invoice.status);
        statusCell.classList.add(invoice.status.toLowerCase());

        // إضافة مستمعات الأحداث للأزرار
        tr.querySelector('.view-invoice').addEventListener('click', 
            () => this.viewInvoice(invoice.id));
        
        const postButton = tr.querySelector('.post-invoice');
        const collectButton = tr.querySelector('.collect-payment');
        
        if (invoice.status === 'draft') {
            postButton.addEventListener('click', 
                () => this.postInvoice(invoice.id));
        } else {
            postButton.style.display = 'none';
        }
        
        if (['posted', 'partially_paid'].includes(invoice.status)) {
            collectButton.addEventListener('click', 
                () => this.collectPayment(invoice.id));
        } else {
            collectButton.style.display = 'none';
        }

        return tr;
    }

    attachEventListeners() {
        // مستمعات أحداث الإجراءات السريعة
        document.getElementById('createQuotation')?.addEventListener('click', 
            () => this.showQuotationModal());
        document.getElementById('createOrder')?.addEventListener('click', 
            () => this.showOrderModal());
        document.getElementById('createInvoice')?.addEventListener('click', 
            () => this.showInvoiceModal());
        document.getElementById('createReturn')?.addEventListener('click', 
            () => this.showReturnModal());

        // مستمعات أحداث الفلترة
        this.filterElements.salesChartPeriod.addEventListener('change', 
            () => this.loadSalesAnalysis());
        this.filterElements.topProductsPeriod.addEventListener('change', 
            () => this.loadTopProducts());

        // مستمعات أحداث التصدير
        document.getElementById('exportSalesChart')?.addEventListener('click', 
            () => this.exportChart('salesAnalysisChart'));
        document.getElementById('exportTopProductsChart')?.addEventListener('click', 
            () => this.exportChart('topProductsChart'));

        // مستمعات أحداث عرض الكل
        document.getElementById('viewAllInvoices')?.addEventListener('click', 
            () => this.navigateToInvoices());
    }

    // توابع مساعدة
    translateInvoiceStatus(status) {
        const statusMap = {
            draft: 'مسودة',
            posted: 'مرحلة',
            paid: 'مدفوعة',
            partially_paid: 'مدفوعة جزئياً',
            cancelled: 'ملغاة'
        };
        return statusMap[status] || status;
    }

    updateDateTime() {
        document.getElementById('currentDateTime').textContent = 
            new Date().toISOString().slice(0, 19).replace('T', ' ');
    }

    showLoading() {
        const loader = document.createElement('div');
        loader.className = 'loading-overlay';
        loader.innerHTML = '<div class="loading-spinner"></div>';
        document.body.appendChild(loader);
    }

    hideLoading() {
        document.querySelector('.loading-overlay')?.remove();
    }

    showError(message) {
        console.error(message);
        // يمكن تحسين هذه الدالة لعرض رسائل خطأ أكثر جاذبية
        alert(message);
    }

    showSuccess(message) {
        // يمكن تحسين هذه الدالة لعرض رسائل نجاح أكثر جاذبية
        alert(message);
    }
}

// تهيئة التطبيق عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    new Sales();
});