<!-- 
مكون إضافة عميل جديد
التاريخ: 2025-05-09 03:36:01
المستخدم: mostafamohammad7760
-->

<template>
  <div class="add-customer-modal">
    <div class="modal-overlay" @click="$emit('close')"></div>
    
    <div class="modal-content">
      <div class="modal-header">
        <h2>إضافة عميل جديد</h2>
        <button class="close-btn" @click="$emit('close')">
          <i class="fas fa-times"></i>
        </button>
      </div>

      <form @submit.prevent="handleSubmit" class="modal-body">
        <!-- البيانات الأساسية -->
        <div class="form-section">
          <h3>البيانات الأساسية</h3>
          
          <div class="form-group">
            <label>الاسم <span class="required">*</span></label>
            <input 
              type="text"
              v-model="form.name"
              :class="{ error: errors.name }"
              ref="nameInput"
              @input="validateField('name')"
            >
            <span class="error-message" v-if="errors.name">{{ errors.name }}</span>
          </div>

          <div class="form-group">
            <label>رقم الجوال <span class="required">*</span></label>
            <div class="phone-input">
              <select v-model="form.phoneCountry">
                <option value="+966">🇸🇦 +966</option>
                <option value="+971">🇦🇪 +971</option>
                <option value="+974">🇶🇦 +974</option>
                <option value="+965">🇰🇼 +965</option>
                <option value="+968">🇴🇲 +968</option>
                <option value="+973">🇧🇭 +973</option>
              </select>
              <input 
                type="tel"
                v-model="form.phone"
                :class="{ error: errors.phone }"
                @input="validateField('phone')"
                maxlength="9"
                placeholder="5xxxxxxxx"
              >
            </div>
            <span class="error-message" v-if="errors.phone">{{ errors.phone }}</span>
          </div>

          <div class="form-group">
            <label>البريد الإلكتروني</label>
            <input 
              type="email"
              v-model="form.email"
              :class="{ error: errors.email }"
              @input="validateField('email')"
            >
            <span class="error-message" v-if="errors.email">{{ errors.email }}</span>
          </div>
        </div>

        <!-- البيانات الإضافية -->
        <div class="form-section">
          <h3>بيانات إضافية</h3>

          <div class="form-group">
            <label>تاريخ الميلاد</label>
            <input 
              type="date"
              v-model="form.birthDate"
              :max="maxBirthDate"
            >
          </div>

          <div class="form-group">
            <label>الجنس</label>
            <div class="radio-group">
              <label class="radio-label">
                <input 
                  type="radio"
                  v-model="form.gender"
                  value="male"
                >
                ذكر
              </label>
              <label class="radio-label">
                <input 
                  type="radio"
                  v-model="form.gender"
                  value="female"
                >
                أنثى
              </label>
            </div>
          </div>

          <div class="form-group">
            <label>ملاحظات</label>
            <textarea 
              v-model="form.notes"
              rows="3"
              placeholder="أضف ملاحظات عن العميل..."
            ></textarea>
          </div>
        </div>

        <!-- خيارات البرنامج -->
        <div class="form-section">
          <h3>برنامج الولاء</h3>

          <div class="form-group">
            <label class="checkbox-label">
              <input 
                type="checkbox"
                v-model="form.joinLoyalty"
              >
              تسجيل في برنامج الولاء
            </label>
          </div>

          <div class="form-group" v-if="form.joinLoyalty">
            <label>نقاط ترحيبية</label>
            <input 
              type="number"
              v-model.number="form.welcomePoints"
              min="0"
              :max="maxWelcomePoints"
            >
          </div>
        </div>

        <!-- أزرار التحكم -->
        <div class="form-actions">
          <button 
            type="button" 
            class="btn btn-light"
            @click="$emit('close')"
          >
            إلغاء
          </button>
          <button 
            type="submit"
            class="btn btn-primary"
            :disabled="isSubmitting || !isValid"
          >
            <span v-if="isSubmitting">
              <i class="fas fa-spinner fa-spin"></i>
              جاري الحفظ...
            </span>
            <span v-else>
              <i class="fas fa-save"></i>
              حفظ
            </span>
          </button>
        </div>
      </form>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted } from 'vue';
import { useStore } from 'vuex';
import { useNotifications } from '@/composables/useNotifications';
import { validatePhone, validateEmail } from '@/utils/validators';

export default {
  name: 'AddCustomerModal',
  
  emits: ['close', 'customer-added'],

  setup(props, { emit }) {
    const store = useStore();
    const { showNotification } = useNotifications();
    const nameInput = ref(null);

    // نموذج البيانات
    const form = ref({
      name: '',
      phoneCountry: '+966',
      phone: '',
      email: '',
      birthDate: '',
      gender: 'male',
      notes: '',
      joinLoyalty: true,
      welcomePoints: store.state.pos.settings.defaultWelcomePoints || 0
    });

    // الأخطاء
    const errors = ref({});
    const isSubmitting = ref(false);

    // القيم المحسوبة
    const maxBirthDate = computed(() => {
      const date = new Date();
      date.setFullYear(date.getFullYear() - 16); // الحد الأدنى للعمر 16 سنة
      return date.toISOString().split('T')[0];
    });

    const maxWelcomePoints = computed(() => 
      store.state.pos.settings.maxWelcomePoints || 1000
    );

    const isValid = computed(() => {
      return form.value.name && 
             form.value.phone &&
             Object.keys(errors.value).length === 0;
    });

    // الوظائف
    const validateField = (field) => {
      errors.value = {
        ...errors.value,
        [field]: validateFieldValue(field, form.value[field])
      };

      // حذف الخطأ إذا كانت القيمة صحيحة
      if (!errors.value[field]) {
        delete errors.value[field];
      }
    };

    const validateFieldValue = (field, value) => {
      switch (field) {
        case 'name':
          return !value.trim() ? 'الاسم مطلوب' :
                 value.length < 3 ? 'الاسم يجب أن يكون 3 أحرف على الأقل' :
                 null;
        case 'phone':
          return !value ? 'رقم الجوال مطلوب' :
                 !validatePhone(value) ? 'رقم الجوال غير صحيح' :
                 null;
        case 'email':
          return value && !validateEmail(value) ? 'البريد الإلكتروني غير صحيح' : null;
        default:
          return null;
      }
    };

    const handleSubmit = async () => {
      // التحقق من جميع الحقول
      ['name', 'phone', 'email'].forEach(field => validateField(field));

      if (!isValid.value) return;

      isSubmitting.value = true;

      try {
        const customerData = {
          ...form.value,
          phone: form.value.phoneCountry + form.value.phone
        };

        const customer = await store.dispatch('customers/createCustomer', customerData);
        
        showNotification({
          type: 'success',
          message: 'تم إضافة العميل بنجاح'
        });

        emit('customer-added', customer);
        emit('close');

      } catch (error) {
        showNotification({
          type: 'error',
          message: 'فشل إضافة العميل: ' + error.message
        });
      } finally {
        isSubmitting.value = false;
      }
    };

    // تركيز حقل الاسم عند فتح النافذة
    onMounted(() => {
      nameInput.value?.focus();
    });

    return {
      form,
      errors,
      isSubmitting,
      maxBirthDate,
      maxWelcomePoints,
      isValid,
      nameInput,
      validateField,
      handleSubmit
    };
  }
};
</script>

<style lang="scss" scoped>
// التنسيقات في الرسالة التالية...
</style>