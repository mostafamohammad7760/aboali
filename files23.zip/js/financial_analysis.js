import { FinancialAnalysisAPI } from './api/financial_analysis_api.js';
import { ChartManager } from './chart_manager.js';
import { formatCurrency, formatNumber, formatDate, formatPercentage } from './utils/formatters.js';
import { validateRatio, validateAnalysisPoint, validateForecast } from './utils/validators.js';

class FinancialAnalysis {
    constructor() {
        this.api = new FinancialAnalysisAPI();
        this.charts = new ChartManager();
        this.currentUser = 'mostafamohammad7760';
        
        // تهيئة المكونات والبيانات
        this.initializeComponents();
        this.attachEventListeners();
        this.loadDashboardData();
        
        // تحديث الوقت كل ثانية
        this.updateDateTime();
        setInterval(() => this.updateDateTime(), 1000);
    }

    initializeComponents() {
        // عناصر المقاييس
        this.metricElements = {
            liquidityRatio: document.getElementById('liquidityRatio'),
            profitabilityRatio: document.getElementById('profitabilityRatio'),
            activityRatio: document.getElementById('activityRatio'),
            leverageRatio: document.getElementById('leverageRatio')
        };

        // عناصر الفلترة
        this.filterElements = {
            periodSelect: document.getElementById('periodSelect'),
            trendMetric: document.getElementById('trendMetric'),
            ratioType: document.getElementById('ratioType'),
            industryMetric: document.getElementById('industryMetric')
        };

        // عناصر نقاط التحليل
        this.pointsElements = {
            strengthPoints: document.getElementById('strengthPoints'),
            weaknessPoints: document.getElementById('weaknessPoints'),
            opportunityPoints: document.getElementById('opportunityPoints'),
            threatPoints: document.getElementById('threatPoints')
        };

        // عناصر المقارنة
        this.comparisonElements = {
            industryComparisonTable: document.getElementById('industryComparisonTable')
        };

        // تهيئة الرسوم البيانية
        this.initializeCharts();
        
        // تهيئة القوالب
        this.analysisPointTemplate = document.getElementById('analysisPointTemplate');
    }

    async loadDashboardData() {
        try {
            this.showLoading();

            const period = this.filterElements.periodSelect.value;
            
            const [
                metrics,
                trendData,
                ratiosData,
                analysisPoints,
                industryComparison
            ] = await Promise.all([
                this.api.getFinancialMetrics(period),
                this.api.getTrendAnalysis(period, this.filterElements.trendMetric.value),
                this.api.getRatiosAnalysis(period, this.filterElements.ratioType.value),
                this.api.getAnalysisPoints(period),
                this.api.getIndustryComparison(period, this.filterElements.industryMetric.value)
            ]);

            this.updateMetrics(metrics);
            this.updateCharts(trendData, ratiosData);
            this.renderAnalysisPoints(analysisPoints);
            this.renderIndustryComparison(industryComparison);

            this.hideLoading();
        } catch (error) {
            this.hideLoading();
            this.showError('حدث خطأ أثناء تحميل البيانات');
            console.error('Dashboard loading error:', error);
        }
    }

    initializeCharts() {
        // تهيئة رسم تحليل الاتجاهات
        this.charts.initializeLineChart('trendChart', {
            labels: [],
            datasets: [
                {
                    label: 'القيمة الفعلية',
                    data: [],
                    borderColor: '#2ecc71',
                    backgroundColor: 'rgba(46, 204, 113, 0.1)',
                    fill: true
                },
                {
                    label: 'القيمة المتوقعة',
                    data: [],
                    borderColor: '#3498db',
                    backgroundColor: 'rgba(52, 152, 219, 0.1)',
                    fill: true
                },
                {
                    label: 'الاتجاه',
                    data: [],
                    borderColor: '#f1c40f',
                    backgroundColor: 'transparent',
                    borderDash: [5, 5],
                    fill: false
                }
            ],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => formatCurrency(value)
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: context => formatCurrency(context.parsed.y)
                        }
                    }
                }
            }
        });

        // تهيئة رسم تحليل النسب
        this.charts.initializeBarChart('ratioChart', {
            labels: [],
            datasets: [
                {
                    label: 'القيمة الفعلية',
                    data: [],
                    backgroundColor: '#3498db'
                },
                {
                    label: 'متوسط القطاع',
                    data: [],
                    backgroundColor: '#95a5a6'
                }
            ],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => formatPercentage(value)
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: context => formatPercentage(context.parsed.y)
                        }
                    }
                }
            }
        });
    }

    updateMetrics(metrics) {
        // تحديث قيم المقاييس
        this.metricElements.liquidityRatio.textContent = 
            formatNumber(metrics.liquidity.value, 2);
        this.metricElements.profitabilityRatio.textContent = 
            formatPercentage(metrics.profitability.value);
        this.metricElements.activityRatio.textContent = 
            formatNumber(metrics.activity.value, 2);
        this.metricElements.leverageRatio.textContent = 
            formatNumber(metrics.leverage.value, 2);

        // تحديث نسب التغير
        this.updateMetricChange('liquidityRatio', metrics.liquidity.change);
        this.updateMetricChange('profitabilityRatio', metrics.profitability.change);
        this.updateMetricChange('activityRatio', metrics.activity.change);
        this.updateMetricChange('leverageRatio', metrics.leverage.change);
    }

    updateMetricChange(elementId, change) {
        const element = document.querySelector(`#${elementId}`).nextElementSibling;
        const icon = element.querySelector('i');
        const value = element.querySelector('span');

        element.className = `metric-change ${change >= 0 ? 'positive' : 'negative'}`;
        icon.className = `fas fa-arrow-${change >= 0 ? 'up' : 'down'}`;
        value.textContent = `${Math.abs(change)}%`;
    }

    updateCharts(trendData, ratiosData) {
        // تحديث رسم تحليل الاتجاهات
        this.charts.updateLineChart('trendChart', {
            labels: trendData.labels,
            datasets: [
                {
                    data: trendData.actual,
                    label: 'القيمة الفعلية'
                },
                {
                    data: trendData.forecast,
                    label: 'القيمة المتوقعة'
                },
                {
                    data: trendData.trend,
                    label: 'الاتجاه'
                }
            ]
        });

        // تحديث رسم تحليل النسب
        this.charts.updateBarChart('ratioChart', {
            labels: ratiosData.labels,
            datasets: [
                {
                    data: ratiosData.actual,
                    label: 'القيمة الفعلية'
                },
                {
                    data: ratiosData.industry,
                    label: 'متوسط القطاع'
                }
            ]
        });
    }

    renderAnalysisPoints(points) {
        // تفريغ القوائم الحالية
        Object.values(this.pointsElements).forEach(element => {
            element.innerHTML = '';
        });

        // تصنيف النقاط حسب نوعها
        points.forEach(point => {
            const element = this.pointsElements[`${point.category}Points`];
            if (element) {
                element.appendChild(this.createAnalysisPointElement(point));
            }
        });
    }

    createAnalysisPointElement(point) {
        const template = this.analysisPointTemplate.content.cloneNode(true);
        const li = template.querySelector('li');
        
        li.querySelector('.point-title').textContent = point.title;
        li.querySelector('.point-description').textContent = point.description;
        li.querySelector('.point-impact').textContent = 
            this.translateImpactLevel(point.impact_level);
        li.querySelector('.point-date').textContent = 
            formatDate(point.created_at);

        // إضافة الأصناف المناسبة
        li.querySelector('.point-impact').classList.add(point.impact_level);

        // إضافة مستمعات الأحداث
        li.querySelector('.edit-point').addEventListener('click', 
            () => this.editAnalysisPoint(point.point_id));
        li.querySelector('.delete-point').addEventListener('click', 
            () => this.deleteAnalysisPoint(point.point_id));

        return li;
    }

    renderIndustryComparison(comparison) {
        const tbody = this.comparisonElements.industryComparisonTable;
        tbody.innerHTML = '';

        comparison.forEach(item => {
            const tr = document.createElement('tr');
            
            tr.innerHTML = `
                <td>${item.metric_name}</td>
                <td>${this.formatMetricValue(item.current_value, item.metric_type)}</td>
                <td>${this.formatMetricValue(item.industry_average, item.metric_type)}</td>
                <td>${this.formatVariance(item.variance, item.is_favorable)}</td>
                <td>
                    <span class="evaluation ${item.evaluation.toLowerCase()}">
                        ${this.translateEvaluation(item.evaluation)}
                    </span>
                </td>
            `;

            tbody.appendChild(tr);
        });
    }

    attachEventListeners() {
        // مستمعات أحداث الفلترة
        this.filterElements.periodSelect.addEventListener('change', 
            () => this.loadDashboardData());
        this.filterElements.trendMetric.addEventListener('change', 
            () => this.loadTrendAnalysis());
        this.filterElements.ratioType.addEventListener('change', 
            () => this.loadRatiosAnalysis());
        this.filterElements.industryMetric.addEventListener('change', 
            () => this.loadIndustryComparison());

        // مستمعات أحداث التصدير
        document.getElementById('exportTrendChart')?.addEventListener('click', 
            () => this.exportChart('trendChart'));
        document.getElementById('exportRatioChart')?.addEventListener('click', 
            () => this.exportChart('ratioChart'));

        // مستمعات أحداث نقاط التحليل
        document.getElementById('addAnalysisPoint')?.addEventListener('click', 
            () => this.showAnalysisPointModal());
    }

    // توابع مساعدة
    translateImpactLevel(level) {
        const levels = {
            high: 'مرتفع',
            medium: 'متوسط',
            low: 'منخفض'
        };
        return levels[level] || level;
    }

    translateEvaluation(evaluation) {
        const evaluations = {
            excellent: 'ممتاز',
            good: 'جيد',
            fair: 'مقبول',
            poor: 'ضعيف'
        };
        return evaluations[evaluation] || evaluation;
    }

    formatMetricValue(value, type) {
        switch (type) {
            case 'currency':
                return formatCurrency(value);
            case 'percentage':
                return formatPercentage(value);
            case 'ratio':
                return formatNumber(value, 2);
            default:
                return value;
        }
    }

    formatVariance(variance, isFavorable) {
        const value = formatNumber(Math.abs(variance), 2) + '%';
        const color = isFavorable ? '#27ae60' : '#e74c3c';
        const icon = isFavorable ? '▲' : '▼';
        return `<span style="color: ${color}">${icon} ${value}</span>`;
    }

    updateDateTime() {
        document.getElementById('currentDateTime').textContent = 
            new Date().toISOString().slice(0, 19).replace('T', ' ');
    }

    showLoading() {
        const loader = document.createElement('div');
        loader.className = 'loading-overlay';
        loader.innerHTML = '<div class="loading-spinner"></div>';
        document.body.appendChild(loader);
    }

    hideLoading() {
        document.querySelector('.loading-overlay')?.remove();
    }

    showError(message) {
        console.error(message);
        // يمكن تحسين هذه الدالة لعرض رسائل خطأ أكثر جاذبية
        alert(message);
    }

    showSuccess(message) {
        // يمكن تحسين هذه الدالة لعرض رسائل نجاح أكثر جاذبية
        alert(message);
    }
}

// تهيئة التطبيق عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    new FinancialAnalysis();
});