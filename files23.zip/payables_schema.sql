-- إنشاء جداول الحسابات الدائنة

-- جدول الموردين
CREATE TABLE vendors (
    vendor_id VARCHAR(20) PRIMARY KEY,
    vendor_name_ar VARCHAR(200) NOT NULL,
    vendor_name_en VARCHAR(200),
    cr_number VARCHAR(50),
    tax_number VARCHAR(50),
    contact_person VARCHAR(100),
    phone VARCHAR(50),
    email VARCHAR(100),
    address TEXT,
    payment_terms INT DEFAULT 30,
    credit_limit DECIMAL(18,2),
    currency_code CHAR(3) NOT NULL,
    status ENUM('active', 'inactive', 'blocked') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50)
);

-- جدول فواتير الموردين
CREATE TABLE vendor_invoices (
    invoice_id VARCHAR(20) PRIMARY KEY,
    vendor_id VARCHAR(20) NOT NULL,
    invoice_number VARCHAR(50) NOT NULL,
    invoice_date DATE NOT NULL,
    due_date DATE NOT NULL,
    total_amount DECIMAL(18,2) NOT NULL,
    tax_amount DECIMAL(18,2) DEFAULT 0,
    discount_amount DECIMAL(18,2) DEFAULT 0,
    net_amount DECIMAL(18,2) NOT NULL,
    currency_code CHAR(3) NOT NULL,
    exchange_rate DECIMAL(10,6) DEFAULT 1,
    payment_status ENUM('unpaid', 'partially_paid', 'paid', 'cancelled') DEFAULT 'unpaid',
    description TEXT,
    reference_number VARCHAR(50),
    attachment_path VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    FOREIGN KEY (vendor_id) REFERENCES vendors(vendor_id)
);

-- جدول تفاصيل الفواتير
CREATE TABLE invoice_details (
    detail_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    invoice_id VARCHAR(20) NOT NULL,
    item_code VARCHAR(50),
    description TEXT,
    quantity DECIMAL(10,2) NOT NULL,
    unit_price DECIMAL(18,2) NOT NULL,
    tax_rate DECIMAL(5,2) DEFAULT 0,
    tax_amount DECIMAL(18,2) DEFAULT 0,
    discount_rate DECIMAL(5,2) DEFAULT 0,
    discount_amount DECIMAL(18,2) DEFAULT 0,
    net_amount DECIMAL(18,2) NOT NULL,
    cost_center_id VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (invoice_id) REFERENCES vendor_invoices(invoice_id)
);

-- جدول دفعات الموردين
CREATE TABLE vendor_payments (
    payment_id VARCHAR(20) PRIMARY KEY,
    vendor_id VARCHAR(20) NOT NULL,
    payment_date DATE NOT NULL,
    amount DECIMAL(18,2) NOT NULL,
    payment_method ENUM('cash', 'cheque', 'bank_transfer', 'credit_card') NOT NULL,
    payment_reference VARCHAR(50),
    description TEXT,
    status ENUM('pending', 'completed', 'cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    completed_at TIMESTAMP NULL,
    completed_by VARCHAR(50),
    FOREIGN KEY (vendor_id) REFERENCES vendors(vendor_id)
);

-- جدول توزيع الدفعات على الفواتير
CREATE TABLE payment_distributions (
    distribution_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    payment_id VARCHAR(20) NOT NULL,
    invoice_id VARCHAR(20) NOT NULL,
    amount DECIMAL(18,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    FOREIGN KEY (payment_id) REFERENCES vendor_payments(payment_id),
    FOREIGN KEY (invoice_id) REFERENCES vendor_invoices(invoice_id)
);

-- جدول تعمير الذمم الدائنة
CREATE TABLE payables_aging (
    aging_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    vendor_id VARCHAR(20) NOT NULL,
    invoice_id VARCHAR(20) NOT NULL,
    aging_date DATE NOT NULL,
    current_amount DECIMAL(18,2) DEFAULT 0,
    days_30 DECIMAL(18,2) DEFAULT 0,
    days_60 DECIMAL(18,2) DEFAULT 0,
    days_90 DECIMAL(18,2) DEFAULT 0,
    days_120 DECIMAL(18,2) DEFAULT 0,
    days_over_120 DECIMAL(18,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vendor_id) REFERENCES vendors(vendor_id),
    FOREIGN KEY (invoice_id) REFERENCES vendor_invoices(invoice_id)
);

-- إجراءات مخزنة

DELIMITER //

-- إجراء تحديث حالة دفع الفاتورة
CREATE PROCEDURE update_invoice_payment_status(
    IN p_invoice_id VARCHAR(20)
)
BEGIN
    DECLARE v_total_amount DECIMAL(18,2);
    DECLARE v_paid_amount DECIMAL(18,2);
    
    -- الحصول على إجمالي الفاتورة
    SELECT net_amount INTO v_total_amount
    FROM vendor_invoices
    WHERE invoice_id = p_invoice_id;
    
    -- حساب إجمالي المدفوع
    SELECT COALESCE(SUM(amount), 0) INTO v_paid_amount
    FROM payment_distributions
    WHERE invoice_id = p_invoice_id;
    
    -- تحديث حالة الفاتورة
    UPDATE vendor_invoices 
    SET payment_status = CASE
        WHEN v_paid_amount = 0 THEN 'unpaid'
        WHEN v_paid_amount < v_total_amount THEN 'partially_paid'
        ELSE 'paid'
    END
    WHERE invoice_id = p_invoice_id;
END //

-- إجراء حساب تعمير الذمم
CREATE PROCEDURE calculate_aging(
    IN p_vendor_id VARCHAR(20),
    IN p_date DATE
)
BEGIN
    -- حذف السجلات القديمة
    DELETE FROM payables_aging 
    WHERE vendor_id = p_vendor_id 
    AND aging_date = p_date;
    
    -- إدراج السجلات الجديدة
    INSERT INTO payables_aging (
        vendor_id,
        invoice_id,
        aging_date,
        current_amount,
        days_30,
        days_60,
        days_90,
        days_120,
        days_over_120
    )
    SELECT 
        vi.vendor_id,
        vi.invoice_id,
        p_date as aging_date,
        CASE WHEN DATEDIFF(p_date, vi.due_date) <= 0 
             THEN (vi.net_amount - COALESCE(pd.paid_amount, 0))
             ELSE 0 END as current_amount,
        CASE WHEN DATEDIFF(p_date, vi.due_date) BETWEEN 1 AND 30
             THEN (vi.net_amount - COALESCE(pd.paid_amount, 0))
             ELSE 0 END as days_30,
        CASE WHEN DATEDIFF(p_date, vi.due_date) BETWEEN 31 AND 60
             THEN (vi.net_amount - COALESCE(pd.paid_amount, 0))
             ELSE 0 END as days_60,
        CASE WHEN DATEDIFF(p_date, vi.due_date) BETWEEN 61 AND 90
             THEN (vi.net_amount - COALESCE(pd.paid_amount, 0))
             ELSE 0 END as days_90,
        CASE WHEN DATEDIFF(p_date, vi.due_date) BETWEEN 91 AND 120
             THEN (vi.net_amount - COALESCE(pd.paid_amount, 0))
             ELSE 0 END as days_120,
        CASE WHEN DATEDIFF(p_date, vi.due_date) > 120
             THEN (vi.net_amount - COALESCE(pd.paid_amount, 0))
             ELSE 0 END as days_over_120
    FROM vendor_invoices vi
    LEFT JOIN (
        SELECT invoice_id, SUM(amount) as paid_amount
        FROM payment_distributions
        GROUP BY invoice_id
    ) pd ON vi.invoice_id = pd.invoice_id
    WHERE vi.vendor_id = p_vendor_id
    AND vi.payment_status != 'paid'
    AND vi.payment_status != 'cancelled';
END //

DELIMITER ;