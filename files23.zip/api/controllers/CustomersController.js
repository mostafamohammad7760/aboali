/**
 * وحدة التحكم بالعملاء
 * التاريخ: 2025-05-09 03:24:46
 * المستخدم: mostafamohammad7760
 */

const CustomerService = require('../services/CustomerService');
const LoyaltyService = require('../services/LoyaltyService');
const { validateCustomer } = require('../validators/customerValidator');
const { ApiError, handleAsync } = require('../utils/errorHandler');
const cache = require('../utils/cache');

class CustomersController {
    constructor() {
        this.customerService = new CustomerService();
        this.loyaltyService = new LoyaltyService();
        this.CACHE_TTL = 3600;
    }

    /**
     * إنشاء عميل جديد
     * @route POST /api/customers
     */
    createCustomer = handleAsync(async (req, res) => {
        const { error } = validateCustomer(req.body);
        if (error) {
            throw new ApiError(400, error.details[0].message);
        }

        // التحقق من عدم تكرار رقم الجوال
        const existingCustomer = await this.customerService.findByPhone(req.body.phone);
        if (existingCustomer) {
            throw new ApiError(400, 'رقم الجوال مسجل مسبقاً');
        }

        const customerData = {
            ...req.body,
            membership_level: 'basic',
            points: 0,
            created_by: req.user.id
        };

        const customer = await this.customerService.createCustomer(customerData);

        // إرسال رسالة ترحيب
        await this.customerService.sendWelcomeMessage(customer);

        // حذف الكاش
        await cache.del('customers:all');

        res.status(201).json({
            success: true,
            data: customer
        });
    });

    /**
     * تحديث بيانات عميل
     * @route PUT /api/customers/:id
     */
    updateCustomer = handleAsync(async (req, res) => {
        const { id } = req.params;

        const existingCustomer = await this.customerService.getCustomerById(id);
        if (!existingCustomer) {
            throw new ApiError(404, 'العميل غير موجود');
        }

        const { error } = validateCustomer(req.body);
        if (error) {
            throw new ApiError(400, error.details[0].message);
        }

        // التحقق من عدم تكرار رقم الجوال
        if (req.body.phone && req.body.phone !== existingCustomer.phone) {
            const phoneExists = await this.customerService.findByPhone(req.body.phone);
            if (phoneExists) {
                throw new ApiError(400, 'رقم الجوال مسجل مسبقاً');
            }
        }

        const customerData = {
            ...req.body,
            updated_by: req.user.id
        };

        const updatedCustomer = await this.customerService.updateCustomer(id, customerData);

        // حذف الكاش
        await cache.del(`customers:${id}`);
        await cache.del('customers:all');

        res.json({
            success: true,
            data: updatedCustomer
        });
    });

    /**
     * الحصول على قائمة العملاء
     * @route GET /api/customers
     */
    getCustomers = handleAsync(async (req, res) => {
        const filters = {
            search: req.query.search,
            membership_level: req.query.membership_level,
            min_points: req.query.min_points,
            max_points: req.query.max_points
        };

        const pagination = {
            page: parseInt(req.query.page) || 1,
            limit: parseInt(req.query.limit) || 10
        };

        const sorting = {
            field: req.query.sort_by || 'created_at',
            order: req.query.order || 'desc'
        };

        const cacheKey = this.generateCacheKey('customers', filters, pagination, sorting);
        let customers = await cache.get(cacheKey);

        if (!customers) {
            customers = await this.customerService.getCustomers(filters, pagination, sorting);
            await cache.set(cacheKey, customers, this.CACHE_TTL);
        }

        res.json({
            success: true,
            data: customers.data,
            pagination: customers.pagination
        });
    });

    /**
     * الحصول على تفاصيل عميل محدد
     * @route GET /api/customers/:id
     */
    getCustomerById = handleAsync(async (req, res) => {
        const { id } = req.params;
        const includeDetails = req.query.include_details === 'true';

        const cacheKey = `customers:${id}${includeDetails ? ':details' : ''}`;
        let customer = await cache.get(cacheKey);

        if (!customer) {
            customer = await this.customerService.getCustomerById(id, includeDetails);
            if (!customer) {
                throw new ApiError(404, 'العميل غير موجود');
            }
            await cache.set(cacheKey, customer, this.CACHE_TTL);
        }

        res.json({
            success: true,
            data: customer
        });
    });

    /**
     * الحصول على سجل مشتريات العميل
     * @route GET /api/customers/:id/history
     */
    getCustomerHistory = handleAsync(async (req, res) => {
        const { id } = req.params;
        const filters = {
            start_date: req.query.start_date,
            end_date: req.query.end_date
        };

        const pagination = {
            page: parseInt(req.query.page) || 1,
            limit: parseInt(req.query.limit) || 10
        };

        const history = await this.customerService.getCustomerHistory(id, filters, pagination);

        res.json({
            success: true,
            data: history.data,
            pagination: history.pagination
        });
    });

    /**
     * تعديل رصيد نقاط العميل
     * @route POST /api/customers/:id/points
     */
    adjustCustomerPoints = handleAsync(async (req, res) => {
        const { id } = req.params;
        const { points, type, reason } = req.body;

        if (!points || !type || !reason) {
            throw new ApiError(400, 'جميع الحقول مطلوبة');
        }

        if (!['add', 'deduct'].includes(type)) {
            throw new ApiError(400, 'نوع العملية غير صالح');
        }

        const result = await this.loyaltyService.adjustPoints(id, {
            points: parseInt(points),
            type,
            reason,
            adjusted_by: req.user.id
        });

        // حذف الكاش
        await cache.del(`customers:${id}`);
        await cache.del('customers:all');

        res.json({
            success: true,
            data: result
        });
    });

    /**
     * تحديث مستوى عضوية العميل
     * @route POST /api/customers/:id/membership
     */
    updateMembershipLevel = handleAsync(async (req, res) => {
        const { id } = req.params;
        const { level, reason } = req.body;

        if (!level || !reason) {
            throw new ApiError(400, 'جميع الحقول مطلوبة');
        }

        const result = await this.loyaltyService.updateMembership(id, {
            level,
            reason,
            updated_by: req.user.id
        });

        // حذف الكاش
        await cache.del(`customers:${id}`);
        await cache.del('customers:all');

        res.json({
            success: true,
            data: result
        });
    });

    /**
     * توليد مفتاح الكاش
     * @private
     */
    generateCacheKey(prefix, filters, pagination, sorting) {
        return `${prefix}:${JSON.stringify(filters)}:${JSON.stringify(pagination)}:${JSON.stringify(sorting)}`;
    }
}

module.exports = new CustomersController();