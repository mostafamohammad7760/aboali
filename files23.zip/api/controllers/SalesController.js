/**
 * وحدة التحكم بالمبيعات
 * التاريخ: 2025-05-09 03:21:25
 * المستخدم: mostafamohammad7760
 */

const SalesService = require('../services/SalesService');
const InventoryService = require('../services/InventoryService');
const CustomerService = require('../services/CustomerService');
const PrintService = require('../services/PrintService');
const { validateSaleData } = require('../validators/saleValidator');
const { ApiError, handleAsync } = require('../utils/errorHandler');

class SalesController {
    constructor() {
        this.salesService = new SalesService();
        this.inventoryService = new InventoryService();
        this.customerService = new CustomerService();
        this.printService = new PrintService();
    }

    /**
     * إنشاء عملية بيع جديدة
     * @route POST /api/sales
     */
    createSale = handleAsync(async (req, res) => {
        const { error } = validateSaleData(req.body);
        if (error) {
            throw new ApiError(400, error.details[0].message);
        }

        // التحقق من توفر المخزون
        await this.checkInventoryAvailability(req.body.items);

        // بدء المعاملة
        const sale = await this.salesService.beginTransaction();

        try {
            // إضافة تفاصيل البيع
            const saleData = {
                ...req.body,
                cashier_id: req.user.id,
                created_by: req.user.id
            };

            // إنشاء عملية البيع
            const createdSale = await this.salesService.createSale(saleData);

            // تحديث المخزون
            await this.inventoryService.updateInventory(createdSale.items);

            // تحديث نقاط العميل إذا كان موجوداً
            if (createdSale.customer_id) {
                await this.customerService.updateCustomerPoints(
                    createdSale.customer_id,
                    createdSale.total_amount
                );
            }

            // طباعة الفاتورة
            await this.printService.printInvoice(createdSale);

            // إتمام المعاملة
            await this.salesService.commitTransaction();

            res.status(201).json({
                success: true,
                data: createdSale
            });
        } catch (error) {
            await this.salesService.rollbackTransaction();
            throw error;
        }
    });

    /**
     * الحصول على قائمة المبيعات
     * @route GET /api/sales
     */
    getSales = handleAsync(async (req, res) => {
        const filters = {
            start_date: req.query.start_date,
            end_date: req.query.end_date,
            customer_id: req.query.customer_id,
            cashier_id: req.query.cashier_id,
            payment_method: req.query.payment_method,
            status: req.query.status
        };

        const pagination = {
            page: parseInt(req.query.page) || 1,
            limit: parseInt(req.query.limit) || 10
        };

        const sales = await this.salesService.getSales(filters, pagination);

        res.json({
            success: true,
            data: sales.data,
            pagination: sales.pagination
        });
    });

    /**
     * الحصول على تفاصيل عملية بيع محددة
     * @route GET /api/sales/:id
     */
    getSaleById = handleAsync(async (req, res) => {
        const sale = await this.salesService.getSaleById(req.params.id);
        
        if (!sale) {
            throw new ApiError(404, 'عملية البيع غير موجودة');
        }

        res.json({
            success: true,
            data: sale
        });
    });

    /**
     * إلغاء عملية بيع
     * @route PUT /api/sales/:id/void
     */
    voidSale = handleAsync(async (req, res) => {
        const { id } = req.params;
        const { reason } = req.body;

        if (!reason) {
            throw new ApiError(400, 'يجب تحديد سبب الإلغاء');
        }

        // التحقق من وجود عملية البيع
        const sale = await this.salesService.getSaleById(id);
        if (!sale) {
            throw new ApiError(404, 'عملية البيع غير موجودة');
        }

        // التحقق من إمكانية الإلغاء
        if (sale.status !== 'completed') {
            throw new ApiError(400, 'لا يمكن إلغاء هذه العملية');
        }

        try {
            // بدء معاملة الإلغاء
            await this.salesService.beginTransaction();

            // تحديث حالة عملية البيع
            const voidedSale = await this.salesService.voidSale(id, {
                reason,
                voided_by: req.user.id
            });

            // إعادة المخزون
            await this.inventoryService.reverseInventoryUpdate(sale.items);

            // إعادة نقاط العميل إذا كان موجوداً
            if (sale.customer_id) {
                await this.customerService.reverseCustomerPoints(
                    sale.customer_id,
                    sale.total_amount
                );
            }

            // طباعة إيصال الإلغاء
            await this.printService.printVoidReceipt(voidedSale);

            // إتمام معاملة الإلغاء
            await this.salesService.commitTransaction();

            res.json({
                success: true,
                data: voidedSale
            });
        } catch (error) {
            await this.salesService.rollbackTransaction();
            throw error;
        }
    });

    /**
     * إصدار مرتجع لعملية بيع
     * @route POST /api/sales/:id/refund
     */
    refundSale = handleAsync(async (req, res) => {
        const { id } = req.params;
        const { items, reason } = req.body;

        if (!items || !items.length) {
            throw new ApiError(400, 'يجب تحديد المنتجات المرتجعة');
        }

        if (!reason) {
            throw new ApiError(400, 'يجب تحديد سبب المرتجع');
        }

        // التحقق من وجود عملية البيع
        const sale = await this.salesService.getSaleById(id);
        if (!sale) {
            throw new ApiError(404, 'عملية البيع غير موجودة');
        }

        // التحقق من صحة المنتجات المرتجعة
        this.validateRefundItems(sale.items, items);

        try {
            // بدء معاملة المرتجع
            await this.salesService.beginTransaction();

            // إنشاء المرتجع
            const refund = await this.salesService.createRefund(id, {
                items,
                reason,
                refunded_by: req.user.id
            });

            // تحديث المخزون
            await this.inventoryService.handleRefundInventory(items);

            // تحديث نقاط العميل إذا كان موجوداً
            if (sale.customer_id) {
                await this.customerService.handleRefundPoints(
                    sale.customer_id,
                    refund.total_amount
                );
            }

            // طباعة إيصال المرتجع
            await this.printService.printRefundReceipt(refund);

            // إتمام معاملة المرتجع
            await this.salesService.commitTransaction();

            res.json({
                success: true,
                data: refund
            });
        } catch (error) {
            await this.salesService.rollbackTransaction();
            throw error;
        }
    });

    /**
     * التحقق من توفر المخزون
     * @private
     */
    async checkInventoryAvailability(items) {
        for (const item of items) {
            const stock = await this.inventoryService.getProductStock(item.product_id);
            if (stock < item.quantity) {
                throw new ApiError(400, `المنتج ${item.product_name} غير متوفر بالكمية المطلوبة`);
            }
        }
    }

    /**
     * التحقق من صحة المنتجات المرتجعة
     * @private
     */
    validateRefundItems(originalItems, refundItems) {
        for (const refundItem of refundItems) {
            const originalItem = originalItems.find(
                item => item.product_id === refundItem.product_id
            );

            if (!originalItem) {
                throw new ApiError(400, `المنتج ${refundItem.product_name} غير موجود في الفاتورة الأصلية`);
            }

            if (refundItem.quantity > originalItem.quantity) {
                throw new ApiError(400, `كمية المرتجع للمنتج ${refundItem.product_name} أكبر من الكمية الأصلية`);
            }
        }
    }
}

module.exports = new SalesController();