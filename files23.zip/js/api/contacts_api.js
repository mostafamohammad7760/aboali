export class ContactsAPI {
    constructor() {
        this.baseUrl = '/api/v1/contacts';
        this.defaultHeaders = {
            'Content-Type': 'application/json',
            'X-User-Id': 'mostafamohammad7760',
            'X-Timestamp': new Date().toISOString()
        };
    }

    async request(endpoint, options = {}) {
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                ...options,
                headers: {
                    ...this.defaultHeaders,
                    ...options.headers
                }
            });

            if (!response.ok) {
                throw await this.handleErrorResponse(response);
            }

            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            throw this.createUserFriendlyError(error);
        }
    }

    // طلبات لوحة المعلومات
    async getSuppliersStats() {
        return this.request('/dashboard/suppliers-stats');
    }

    async getCustomersStats() {
        return this.request('/dashboard/customers-stats');
    }

    async getDebtsData() {
        return this.request('/dashboard/debts-data');
    }

    async getSuppliersAnalysis(period = 'month') {
        return this.request(`/dashboard/suppliers-analysis?period=${period}`);
    }

    async getCustomersAnalysis(period = 'month') {
        return this.request(`/dashboard/customers-analysis?period=${period}`);
    }

    async getLatestEvents() {
        return this.request('/dashboard/latest-events');
    }

    async getExpiredDocuments() {
        return this.request('/dashboard/expired-documents');
    }

    // طلبات الموردين
    async getSuppliers(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/suppliers?${queryString}`);
    }

    async getSupplier(supplierId) {
        return this.request(`/suppliers/${supplierId}`);
    }

    async createSupplier(supplierData) {
        this.validateSupplierData(supplierData);
        return this.request('/suppliers', {
            method: 'POST',
            body: JSON.stringify(supplierData)
        });
    }

    async updateSupplier(supplierId, supplierData) {
        this.validateSupplierData(supplierData);
        return this.request(`/suppliers/${supplierId}`, {
            method: 'PUT',
            body: JSON.stringify(supplierData)
        });
    }

    async deleteSupplier(supplierId) {
        return this.request(`/suppliers/${supplierId}`, {
            method: 'DELETE'
        });
    }

    async updateSupplierStatus(supplierId, status, reason) {
        return this.request(`/suppliers/${supplierId}/status`, {
            method: 'PUT',
            body: JSON.stringify({ status, reason })
        });
    }

    // طلبات العملاء
    async getCustomers(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/customers?${queryString}`);
    }

    async getCustomer(customerId) {
        return this.request(`/customers/${customerId}`);
    }

    async createCustomer(customerData) {
        this.validateCustomerData(customerData);
        return this.request('/customers', {
            method: 'POST',
            body: JSON.stringify(customerData)
        });
    }

    async updateCustomer(customerId, customerData) {
        this.validateCustomerData(customerData);
        return this.request(`/customers/${customerId}`, {
            method: 'PUT',
            body: JSON.stringify(customerData)
        });
    }

    async deleteCustomer(customerId) {
        return this.request(`/customers/${customerId}`, {
            method: 'DELETE'
        });
    }

    async updateCustomerStatus(customerId, status, reason) {
        return this.request(`/customers/${customerId}/status`, {
            method: 'PUT',
            body: JSON.stringify({ status, reason })
        });
    }

    // طلبات المجموعات
    async getGroups(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/groups?${queryString}`);
    }

    async getGroup(groupId) {
        return this.request(`/groups/${groupId}`);
    }

    async createGroup(groupData) {
        this.validateGroupData(groupData);
        return this.request('/groups', {
            method: 'POST',
            body: JSON.stringify(groupData)
        });
    }

    async updateGroup(groupId, groupData) {
        this.validateGroupData(groupData);
        return this.request(`/groups/${groupId}`, {
            method: 'PUT',
            body: JSON.stringify(groupData)
        });
    }

    async deleteGroup(groupId) {
        return this.request(`/groups/${groupId}`, {
            method: 'DELETE'
        });
    }

    // طلبات الأشخاص المسؤولين
    async getContactPersons(contactType, contactId) {
        return this.request(`/${contactType}s/${contactId}/persons`);
    }

    async createContactPerson(contactType, contactId, personData) {
        this.validatePersonData(personData);
        return this.request(`/${contactType}s/${contactId}/persons`, {
            method: 'POST',
            body: JSON.stringify(personData)
        });
    }

    async updateContactPerson(personId, personData) {
        this.validatePersonData(personData);
        return this.request(`/persons/${personId}`, {
            method: 'PUT',
            body: JSON.stringify(personData)
        });
    }

    async deleteContactPerson(personId) {
        return this.request(`/persons/${personId}`, {
            method: 'DELETE'
        });
    }

    // طلبات الوثائق
    async getDocuments(contactType, contactId) {
        return this.request(`/${contactType}s/${contactId}/documents`);
    }

    async uploadDocument(contactType, contactId, documentData) {
        const formData = new FormData();
        formData.append('file', documentData.file);
        formData.append('metadata', JSON.stringify({
            name: documentData.name,
            type: documentData.type,
            description: documentData.description,
            expiryDate: documentData.expiryDate
        }));

        return this.request(`/${contactType}s/${contactId}/documents`, {
            method: 'POST',
            body: formData,
            headers: {
                // حذف Content-Type ليتم تعيينه تلقائياً مع FormData
                'Content-Type': undefined
            }
        });
    }

    async updateDocument(documentId, documentData) {
        return this.request(`/documents/${documentId}`, {
            method: 'PUT',
            body: JSON.stringify(documentData)
        });
    }

    async deleteDocument(documentId) {
        return this.request(`/documents/${documentId}`, {
            method: 'DELETE'
        });
    }

    // طلبات الاستيراد والتصدير
    async importContacts(file, type) {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('type', type);

        return this.request('/import', {
            method: 'POST',
            body: formData,
            headers: {
                'Content-Type': undefined
            }
        });
    }

    async exportContacts(type, filters = {}) {
        const queryString = new URLSearchParams(filters).toString();
        const response = await fetch(
            `${this.baseUrl}/export/${type}?${queryString}`,
            {
                headers: this.defaultHeaders
            }
        );

        if (!response.ok) {
            throw await this.handleErrorResponse(response);
        }

        return response.blob();
    }

    // توابع التحقق من صحة البيانات
    validateSupplierData(supplierData) {
        const requiredFields = ['name', 'email', 'phone'];
        
        const missingFields = requiredFields.filter(field => !supplierData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        if (supplierData.email && !this.isValidEmail(supplierData.email)) {
            throw new Error('البريد الإلكتروني غير صالح');
        }

        return true;
    }

    validateCustomerData(customerData) {
        const requiredFields = ['name', 'email', 'phone'];
        
        const missingFields = requiredFields.filter(field => !customerData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        if (customerData.email && !this.isValidEmail(customerData.email)) {
            throw new Error('البريد الإلكتروني غير صالح');
        }

        return true;
    }

    validateGroupData(groupData) {
        if (!groupData.name) {
            throw new Error('اسم المجموعة مطلوب');
        }

        if (!['supplier', 'customer', 'both'].includes(groupData.type)) {
            throw new Error('نوع المجموعة غير صالح');
        }

        return true;
    }

    validatePersonData(personData) {
        const requiredFields = ['name', 'position', 'email'];
        
        const missingFields = requiredFields.filter(field => !personData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        if (personData.email && !this.isValidEmail(personData.email)) {
            throw new Error('البريد الإلكتروني غير صالح');
        }

        return true;
    }

    // توابع مساعدة
    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    async handleErrorResponse(response) {
        let error;
        try {
            const errorData = await response.json();
            error = new Error(errorData.message || 'حدث خطأ غير معروف');
            error.code = errorData.code;
            error.details = errorData.details;
        } catch {
            error = new Error(`خطأ في الطلب: ${response.status}`);
        }
        error.status = response.status;
        return error;
    }

    createUserFriendlyError(error) {
        const errorMessages = {
            400: 'البيانات المدخلة غير صحيحة',
            401: 'يرجى تسجيل الدخول مرة أخرى',
            403: 'ليس لديك صلاحية للقيام بهذا الإجراء',
            404: 'لم يتم العثور على البيانات المطلوبة',
            409: 'تعارض في البيانات',
            422: 'البيانات المدخلة غير صالحة',
            500: 'حدث خطأ في النظام'
        };

        return new Error(
            errorMessages[error.status] || 
            error.message || 
            'حدث خطأ غير متوقع'
        );
    }
}