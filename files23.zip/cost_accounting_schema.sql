-- إنشاء جداول محاسبة التكاليف

-- جدول مراكز التكلفة
CREATE TABLE cost_centers (
    center_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    type ENUM('production', 'service', 'administrative') NOT NULL,
    parent_id VARCHAR(20),
    status ENUM('active', 'inactive') DEFAULT 'active',
    budget_amount DECIMAL(18,2),
    actual_amount DECIMAL(18,2),
    variance_amount DECIMAL(18,2),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (parent_id) REFERENCES cost_centers(center_id)
);

-- جدول عناصر التكاليف
CREATE TABLE cost_elements (
    element_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    type ENUM('direct_material', 'direct_labor', 'overhead', 'variable', 'fixed') NOT NULL,
    nature ENUM('production', 'period') NOT NULL,
    behavior ENUM('fixed', 'variable', 'mixed', 'step') NOT NULL,
    account_id VARCHAR(20),
    status ENUM('active', 'inactive') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (account_id) REFERENCES chart_of_accounts(account_id)
);

-- جدول وحدات التكلفة
CREATE TABLE cost_units (
    unit_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    type ENUM('product', 'service', 'process', 'batch', 'order') NOT NULL,
    measurement_unit VARCHAR(50) NOT NULL,
    standard_cost DECIMAL(18,2),
    actual_cost DECIMAL(18,2),
    variance_cost DECIMAL(18,2),
    status ENUM('active', 'inactive') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50)
);

-- جدول معايير التكلفة
CREATE TABLE cost_standards (
    standard_id VARCHAR(20) PRIMARY KEY,
    element_id VARCHAR(20) NOT NULL,
    unit_id VARCHAR(20) NOT NULL,
    quantity DECIMAL(18,3) NOT NULL,
    price DECIMAL(18,2) NOT NULL,
    total_amount DECIMAL(18,2) NOT NULL,
    effective_date DATE NOT NULL,
    end_date DATE,
    status ENUM('active', 'inactive') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (element_id) REFERENCES cost_elements(element_id),
    FOREIGN KEY (unit_id) REFERENCES cost_units(unit_id)
);

-- جدول توزيع التكاليف
CREATE TABLE cost_allocations (
    allocation_id VARCHAR(20) PRIMARY KEY,
    period_id VARCHAR(20) NOT NULL,
    from_center_id VARCHAR(20) NOT NULL,
    to_center_id VARCHAR(20) NOT NULL,
    element_id VARCHAR(20) NOT NULL,
    allocation_basis VARCHAR(100) NOT NULL,
    basis_quantity DECIMAL(18,3),
    basis_amount DECIMAL(18,2),
    allocation_percentage DECIMAL(5,2),
    allocated_amount DECIMAL(18,2) NOT NULL,
    status ENUM('draft', 'posted') DEFAULT 'draft',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (period_id) REFERENCES financial_periods(period_id),
    FOREIGN KEY (from_center_id) REFERENCES cost_centers(center_id),
    FOREIGN KEY (to_center_id) REFERENCES cost_centers(center_id),
    FOREIGN KEY (element_id) REFERENCES cost_elements(element_id)
);

-- جدول التكاليف الفعلية
CREATE TABLE actual_costs (
    cost_id VARCHAR(20) PRIMARY KEY,
    period_id VARCHAR(20) NOT NULL,
    center_id VARCHAR(20) NOT NULL,
    element_id VARCHAR(20) NOT NULL,
    unit_id VARCHAR(20),
    quantity DECIMAL(18,3),
    price DECIMAL(18,2),
    amount DECIMAL(18,2) NOT NULL,
    transaction_date DATE NOT NULL,
    reference_type VARCHAR(50),
    reference_id VARCHAR(20),
    status ENUM('draft', 'posted') DEFAULT 'draft',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (period_id) REFERENCES financial_periods(period_id),
    FOREIGN KEY (center_id) REFERENCES cost_centers(center_id),
    FOREIGN KEY (element_id) REFERENCES cost_elements(element_id),
    FOREIGN KEY (unit_id) REFERENCES cost_units(unit_id)
);

-- جدول تحليل الانحرافات
CREATE TABLE cost_variances (
    variance_id VARCHAR(20) PRIMARY KEY,
    period_id VARCHAR(20) NOT NULL,
    element_id VARCHAR(20) NOT NULL,
    unit_id VARCHAR(20) NOT NULL,
    variance_type ENUM('price', 'quantity', 'efficiency', 'volume', 'mix') NOT NULL,
    standard_amount DECIMAL(18,2) NOT NULL,
    actual_amount DECIMAL(18,2) NOT NULL,
    variance_amount DECIMAL(18,2) NOT NULL,
    variance_percentage DECIMAL(5,2),
    is_favorable BOOLEAN,
    analysis_date DATE NOT NULL,
    status ENUM('draft', 'reviewed', 'approved') DEFAULT 'draft',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (period_id) REFERENCES financial_periods(period_id),
    FOREIGN KEY (element_id) REFERENCES cost_elements(element_id),
    FOREIGN KEY (unit_id) REFERENCES cost_units(unit_id)
);

-- جدول أوامر التكلفة
CREATE TABLE cost_orders (
    order_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    description TEXT NOT NULL,
    unit_id VARCHAR(20) NOT NULL,
    quantity DECIMAL(18,3) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE,
    estimated_cost DECIMAL(18,2),
    actual_cost DECIMAL(18,2),
    variance_cost DECIMAL(18,2),
    completion_percentage DECIMAL(5,2) DEFAULT 0,
    status ENUM('planned', 'in_progress', 'completed', 'cancelled') DEFAULT 'planned',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (unit_id) REFERENCES cost_units(unit_id)
);

-- جدول تكاليف الأوامر
CREATE TABLE order_costs (
    entry_id VARCHAR(20) PRIMARY KEY,
    order_id VARCHAR(20) NOT NULL,
    element_id VARCHAR(20) NOT NULL,
    center_id VARCHAR(20) NOT NULL,
    quantity DECIMAL(18,3),
    price DECIMAL(18,2),
    amount DECIMAL(18,2) NOT NULL,
    transaction_date DATE NOT NULL,
    status ENUM('draft', 'posted') DEFAULT 'draft',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (order_id) REFERENCES cost_orders(order_id),
    FOREIGN KEY (element_id) REFERENCES cost_elements(element_id),
    FOREIGN KEY (center_id) REFERENCES cost_centers(center_id)
);

-- جدول أسس التوزيع
CREATE TABLE allocation_bases (
    basis_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    type ENUM('direct', 'stepped', 'reciprocal') NOT NULL,
    unit_of_measure VARCHAR(50),
    calculation_method TEXT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50)
);

-- جدول معاملات التوزيع
CREATE TABLE allocation_rates (
    rate_id VARCHAR(20) PRIMARY KEY,
    basis_id VARCHAR(20) NOT NULL,
    from_center_id VARCHAR(20) NOT NULL,
    to_center_id VARCHAR(20) NOT NULL,
    rate_percentage DECIMAL(5,2) NOT NULL,
    effective_date DATE NOT NULL,
    end_date DATE,
    status ENUM('active', 'inactive') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (basis_id) REFERENCES allocation_bases(basis_id),
    FOREIGN KEY (from_center_id) REFERENCES cost_centers(center_id),
    FOREIGN KEY (to_center_id) REFERENCES cost_centers(center_id)
);

-- إجراءات مخزنة

DELIMITER //

-- إجراء إنشاء مركز تكلفة
CREATE PROCEDURE create_cost_center(
    IN p_code VARCHAR(20),
    IN p_name VARCHAR(200),
    IN p_type VARCHAR(20),
    IN p_parent_id VARCHAR(20),
    IN p_budget_amount DECIMAL(18,2)
)
BEGIN
    INSERT INTO cost_centers (
        center_id,
        code,
        name,
        type,
        parent_id,
        budget_amount,
        created_by
    )
    VALUES (
        UUID(),
        p_code,
        p_name,
        p_type,
        p_parent_id,
        p_budget_amount,
        'mostafamohammad7760'
    );
END //

-- إجراء توزيع التكاليف
CREATE PROCEDURE allocate_costs(
    IN p_period_id VARCHAR(20),
    IN p_allocation_basis VARCHAR(20)
)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_from_center VARCHAR(20);
    DECLARE v_to_center VARCHAR(20);
    DECLARE v_rate DECIMAL(5,2);
    DECLARE v_amount DECIMAL(18,2);
    
    -- قراءة معدلات التوزيع
    DECLARE rate_cursor CURSOR FOR 
        SELECT from_center_id, to_center_id, rate_percentage
        FROM allocation_rates ar
        JOIN allocation_bases ab ON ar.basis_id = ab.basis_id
        WHERE ab.code = p_allocation_basis
        AND ar.status = 'active';
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    -- بدء المعاملة
    START TRANSACTION;
    
    OPEN rate_cursor;
    
    read_loop: LOOP
        FETCH rate_cursor INTO v_from_center, v_to_center, v_rate;
        
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        -- حساب المبلغ المراد توزيعه
        SELECT SUM(amount) * (v_rate / 100)
        INTO v_amount
        FROM actual_costs
        WHERE period_id = p_period_id
        AND center_id = v_from_center;
        
        -- إنشاء سجل التوزيع
        INSERT INTO cost_allocations (
            allocation_id,
            period_id,
            from_center_id,
            to_center_id,
            element_id,
            allocation_basis,
            allocation_percentage,
            allocated_amount,
            created_by
        )
        VALUES (
            UUID(),
            p_period_id,
            v_from_center,
            v_to_center,
            (SELECT element_id FROM cost_elements WHERE code = 'ALLOC'),
            p_allocation_basis,
            v_rate,
            v_amount,
            'mostafamohammad7760'
        );
        
    END LOOP;
    
    CLOSE rate_cursor;
    
    COMMIT;
END //

DELIMITER ;

-- المؤشرات
CREATE INDEX idx_cost_centers_type ON cost_centers(type);
CREATE INDEX idx_cost_centers_status ON cost_centers(status);
CREATE INDEX idx_cost_elements_type ON cost_elements(type);
CREATE INDEX idx_cost_elements_status ON cost_elements(status);
CREATE INDEX idx_cost_units_type ON cost_units(type);
CREATE INDEX idx_cost_units_status ON cost_units(status);
CREATE INDEX idx_cost_standards_dates ON cost_standards(effective_date, end_date);
CREATE INDEX idx_cost_standards_status ON cost_standards(status);
CREATE INDEX idx_cost_allocations_period ON cost_allocations(period_id);
CREATE INDEX idx_cost_allocations_status ON cost_allocations(status);
CREATE INDEX idx_actual_costs_period ON actual_costs(period_id);
CREATE INDEX idx_actual_costs_dates ON actual_costs(transaction_date);
CREATE INDEX idx_actual_costs_status ON actual_costs(status);
CREATE INDEX idx_cost_variances_period ON cost_variances(period_id);
CREATE INDEX idx_cost_variances_dates ON cost_variances(analysis_date);
CREATE INDEX idx_cost_variances_status ON cost_variances(status);
CREATE INDEX idx_cost_orders_dates ON cost_orders(start_date, end_date);
CREATE INDEX idx_cost_orders_status ON cost_orders(status);
CREATE INDEX idx_order_costs_dates ON order_costs(transaction_date);
CREATE INDEX idx_order_costs_status ON order_costs(status);
CREATE INDEX idx_allocation_bases_type ON allocation_bases(type);
CREATE INDEX idx_allocation_bases_status ON allocation_bases(status);
CREATE INDEX idx_allocation_rates_dates ON allocation_rates(effective_date, end_date);
CREATE INDEX idx_allocation_rates_status ON allocation_rates(status);