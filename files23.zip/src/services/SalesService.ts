/**
 * خدمة المبيعات
 * التاريخ: 2025-05-09 04:19:20
 * المستخدم: mostafamohammad7760
 */

import { Transaction } from 'sequelize';
import { Sale, Product, Inventory } from '../models';
import { createJournalEntry } from './AccountingService';
import { updateInventory } from './InventoryService';

interface SaleItem {
  productId: number;
  quantity: number;
  unitPrice: number;
  discountType?: 'percentage' | 'fixed';
  discountValue?: number;
  taxRate?: number;
}

interface SaleData {
  customerId: number;
  warehouseId: number;
  userId: number;
  items: SaleItem[];
  discountType?: 'percentage' | 'fixed';
  discountValue?: number;
  notes?: string;
}

export class SalesService {
  /**
   * إنشاء عملية بيع جديدة
   */
  public async createSale(data: SaleData, transaction?: Transaction): Promise<Sale> {
    const t = transaction || await Sale.sequelize!.transaction();

    try {
      // إنشاء رقم الفاتورة
      const saleNumber = await this.generateSaleNumber();

      // حساب المبالغ
      let subtotal = 0;
      let totalTax = 0;
      
      // معالجة المنتجات
      for (const item of data.items) {
        const product = await Product.findByPk(item.productId);
        if (!product) {
          throw new Error(`المنتج غير موجود: ${item.productId}`);
        }

        // التحقق من المخزون
        const inventory = await Inventory.findOne({
          where: {
            productId: item.productId,
            warehouseId: data.warehouseId
          }
        });

        if (!inventory || inventory.quantity < item.quantity) {
          throw new Error(`الكمية غير متوفرة للمنتج: ${product.name}`);
        }

        // حساب قيمة المنتج
        const itemTotal = item.quantity * item.unitPrice;
        const itemDiscount = this.calculateDiscount(itemTotal, item.discountType, item.discountValue);
        const itemTax = (itemTotal - itemDiscount) * (item.taxRate || 0) / 100;

        subtotal += itemTotal;
        totalTax += itemTax;

        // تحديث المخزون
        await updateInventory({
          productId: item.productId,
          warehouseId: data.warehouseId,
          quantity: -item.quantity,
          transaction: t
        });
      }

      // حساب الخصم الإجمالي
      const totalDiscount = this.calculateDiscount(subtotal, data.discountType, data.discountValue);

      // حساب الإجمالي النهائي
      const total = subtotal - totalDiscount + totalTax;

      // إنشاء الفاتورة
      const sale = await Sale.create({
        number: saleNumber,
        date: new Date(),
        customerId: data.customerId,
        warehouseId: data.warehouseId,
        userId: data.userId,
        subtotal,
        discountType: data.discountType,
        discountValue: data.discountValue,
        taxAmount: totalTax,
        total,
        status: 'draft',
        notes: data.notes
      }, { transaction: t });

      // إنشاء قيد محاسبي
      await createJournalEntry({
        date: new Date(),
        referenceType: 'sale',
        referenceId: sale.id,
        items: [
          {
            accountId: 1, // حساب المبيعات
            debit: 0,
            credit: total
          },
          {
            accountId: 2, // حساب العملاء
            debit: total,
            credit: 0
          }
        ],
        transaction: t
      });

      if (!transaction) {
        await t.commit();
      }

      return sale;

    } catch (error) {
      if (!transaction) {
        await t.rollback();
      }
      throw error;
    }
  }

  /**
   * حساب قيمة الخصم
   */
  private calculateDiscount(amount: number, type?: 'percentage' | 'fixed', value?: number): number {
    if (!value) return 0;
    
    if (type === 'percentage') {
      return amount * (value / 100);
    }
    
    return Math.min(value, amount);
  }

  /**
   * توليد رقم فاتورة جديد
   */
  private async generateSaleNumber(): Promise<string> {
    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    
    const lastSale = await Sale.findOne({
      where: {
        number: {
          [Op.like]: `INV${year}${month}%`
        }
      },
      order: [['number', 'DESC']]
    });

    const sequence = lastSale
      ? parseInt(lastSale.number.slice(-4)) + 1
      : 1;

    return `INV${year}${month}${String(sequence).padStart(4, '0')}`;
  }
}