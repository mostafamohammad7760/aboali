-- إنشاء قاعدة البيانات
CREATE DATABASE IF NOT EXISTS accounting_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE accounting_system;

-- جدول شجرة الحسابات
CREATE TABLE account_tree (
    account_id VARCHAR(20) PRIMARY KEY,
    parent_id VARCHAR(20),
    account_name_ar VARCHAR(100) NOT NULL,
    account_name_en VARCHAR(100),
    account_type ENUM('asset', 'liability', 'equity', 'revenue', 'expense') NOT NULL,
    level INT NOT NULL,
    is_parent BOOLEAN DEFAULT FALSE,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (parent_id) REFERENCES account_tree(account_id)
);

-- جدول القيود المحاسبية
CREATE TABLE journal_entries (
    entry_id VARCHAR(20) PRIMARY KEY,
    entry_date DATE NOT NULL,
    description TEXT,
    entry_type ENUM('manual', 'automatic', 'closing') NOT NULL,
    status ENUM('draft', 'posted', 'verified', 'cancelled') DEFAULT 'draft',
    total_debit DECIMAL(18,2) DEFAULT 0,
    total_credit DECIMAL(18,2) DEFAULT 0,
    reference_number VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    posted_at TIMESTAMP NULL,
    posted_by VARCHAR(50),
    verified_at TIMESTAMP NULL,
    verified_by VARCHAR(50)
);

-- جدول تفاصيل القيود
CREATE TABLE journal_entry_details (
    detail_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    entry_id VARCHAR(20),
    account_id VARCHAR(20),
    debit_amount DECIMAL(18,2) DEFAULT 0,
    credit_amount DECIMAL(18,2) DEFAULT 0,
    description TEXT,
    cost_center_id VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (entry_id) REFERENCES journal_entries(entry_id),
    FOREIGN KEY (account_id) REFERENCES account_tree(account_id)
);

-- جدول مراكز التكلفة
CREATE TABLE cost_centers (
    cost_center_id VARCHAR(20) PRIMARY KEY,
    name_ar VARCHAR(100) NOT NULL,
    name_en VARCHAR(100),
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50)
);

-- جدول أرصدة الحسابات
CREATE TABLE account_balances (
    account_id VARCHAR(20),
    fiscal_year INT,
    period INT,
    opening_balance DECIMAL(18,2) DEFAULT 0,
    current_balance DECIMAL(18,2) DEFAULT 0,
    last_updated TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (account_id, fiscal_year, period),
    FOREIGN KEY (account_id) REFERENCES account_tree(account_id)
);

-- إجراء مخزن للتحقق من توازن القيد
DELIMITER //
CREATE PROCEDURE verify_journal_entry(IN p_entry_id VARCHAR(20))
BEGIN
    DECLARE v_total_debit DECIMAL(18,2);
    DECLARE v_total_credit DECIMAL(18,2);
    
    -- حساب مجموع المدين والدائن
    SELECT 
        SUM(debit_amount), 
        SUM(credit_amount)
    INTO 
        v_total_debit, 
        v_total_credit
    FROM journal_entry_details
    WHERE entry_id = p_entry_id;
    
    -- تحديث المجاميع في القيد الرئيسي
    UPDATE journal_entries 
    SET 
        total_debit = v_total_debit,
        total_credit = v_total_credit
    WHERE entry_id = p_entry_id;
    
    -- التحقق من التوازن
    IF v_total_debit = v_total_credit THEN
        UPDATE journal_entries 
        SET status = 'verified',
            verified_at = CURRENT_TIMESTAMP
        WHERE entry_id = p_entry_id;
    ELSE
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'القيد غير متوازن';
    END IF;
END //
DELIMITER ;