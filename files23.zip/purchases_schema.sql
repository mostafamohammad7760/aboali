-- إنشاء جداول المشتريات

-- جدول الموردين
CREATE TABLE suppliers (
    supplier_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    contact_person VARCHAR(100),
    phone VARCHAR(20),
    email VARCHAR(100),
    address TEXT,
    tax_number VARCHAR(50),
    credit_limit DECIMAL(18,2) DEFAULT 0,
    balance DECIMAL(18,2) DEFAULT 0,
    status ENUM('active', 'inactive') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50)
);

-- جدول طلبات عروض الأسعار
CREATE TABLE purchase_requests (
    request_id VARCHAR(20) PRIMARY KEY,
    request_number VARCHAR(20) UNIQUE NOT NULL,
    request_date DATE NOT NULL,
    required_date DATE,
    department_id VARCHAR(20),
    status ENUM('draft', 'pending', 'approved', 'rejected', 'cancelled', 'completed') DEFAULT 'draft',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (department_id) REFERENCES departments(department_id)
);

-- جدول تفاصيل طلبات عروض الأسعار
CREATE TABLE purchase_request_details (
    detail_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    request_id VARCHAR(20) NOT NULL,
    item_id VARCHAR(20) NOT NULL,
    unit_id VARCHAR(20) NOT NULL,
    quantity DECIMAL(18,3) NOT NULL,
    received_quantity DECIMAL(18,3) DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (request_id) REFERENCES purchase_requests(request_id),
    FOREIGN KEY (item_id) REFERENCES items(item_id),
    FOREIGN KEY (unit_id) REFERENCES units(unit_id)
);

-- جدول عروض أسعار الموردين
CREATE TABLE supplier_quotations (
    quotation_id VARCHAR(20) PRIMARY KEY,
    quotation_number VARCHAR(20) UNIQUE NOT NULL,
    quotation_date DATE NOT NULL,
    supplier_id VARCHAR(20) NOT NULL,
    request_id VARCHAR(20),
    validity_days INT DEFAULT 30,
    total_amount DECIMAL(18,2) DEFAULT 0,
    discount_amount DECIMAL(18,2) DEFAULT 0,
    net_amount DECIMAL(18,2) DEFAULT 0,
    tax_amount DECIMAL(18,2) DEFAULT 0,
    grand_total DECIMAL(18,2) DEFAULT 0,
    status ENUM('draft', 'received', 'accepted', 'rejected', 'expired', 'converted') DEFAULT 'draft',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id),
    FOREIGN KEY (request_id) REFERENCES purchase_requests(request_id)
);

-- جدول تفاصيل عروض أسعار الموردين
CREATE TABLE supplier_quotation_details (
    detail_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    quotation_id VARCHAR(20) NOT NULL,
    item_id VARCHAR(20) NOT NULL,
    unit_id VARCHAR(20) NOT NULL,
    quantity DECIMAL(18,3) NOT NULL,
    unit_price DECIMAL(18,2) NOT NULL,
    discount_percentage DECIMAL(5,2) DEFAULT 0,
    discount_amount DECIMAL(18,2) DEFAULT 0,
    net_amount DECIMAL(18,2) DEFAULT 0,
    tax_percentage DECIMAL(5,2) DEFAULT 0,
    tax_amount DECIMAL(18,2) DEFAULT 0,
    total_amount DECIMAL(18,2) DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (quotation_id) REFERENCES supplier_quotations(quotation_id),
    FOREIGN KEY (item_id) REFERENCES items(item_id),
    FOREIGN KEY (unit_id) REFERENCES units(unit_id)
);

-- جدول أوامر الشراء
CREATE TABLE purchase_orders (
    order_id VARCHAR(20) PRIMARY KEY,
    order_number VARCHAR(20) UNIQUE NOT NULL,
    order_date DATE NOT NULL,
    supplier_id VARCHAR(20) NOT NULL,
    quotation_id VARCHAR(20),
    expected_date DATE,
    total_amount DECIMAL(18,2) DEFAULT 0,
    discount_amount DECIMAL(18,2) DEFAULT 0,
    net_amount DECIMAL(18,2) DEFAULT 0,
    tax_amount DECIMAL(18,2) DEFAULT 0,
    grand_total DECIMAL(18,2) DEFAULT 0,
    status ENUM('draft', 'confirmed', 'partial_received', 'received', 'cancelled') DEFAULT 'draft',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id),
    FOREIGN KEY (quotation_id) REFERENCES supplier_quotations(quotation_id)
);

-- جدول تفاصيل أوامر الشراء
CREATE TABLE purchase_order_details (
    detail_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    order_id VARCHAR(20) NOT NULL,
    item_id VARCHAR(20) NOT NULL,
    unit_id VARCHAR(20) NOT NULL,
    quantity DECIMAL(18,3) NOT NULL,
    received_quantity DECIMAL(18,3) DEFAULT 0,
    unit_price DECIMAL(18,2) NOT NULL,
    discount_percentage DECIMAL(5,2) DEFAULT 0,
    discount_amount DECIMAL(18,2) DEFAULT 0,
    net_amount DECIMAL(18,2) DEFAULT 0,
    tax_percentage DECIMAL(5,2) DEFAULT 0,
    tax_amount DECIMAL(18,2) DEFAULT 0,
    total_amount DECIMAL(18,2) DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES purchase_orders(order_id),
    FOREIGN KEY (item_id) REFERENCES items(item_id),
    FOREIGN KEY (unit_id) REFERENCES units(unit_id)
);

-- جدول فواتير المشتريات
CREATE TABLE purchase_invoices (
    invoice_id VARCHAR(20) PRIMARY KEY,
    invoice_number VARCHAR(20) UNIQUE NOT NULL,
    invoice_date DATE NOT NULL,
    supplier_id VARCHAR(20) NOT NULL,
    order_id VARCHAR(20),
    total_amount DECIMAL(18,2) DEFAULT 0,
    discount_amount DECIMAL(18,2) DEFAULT 0,
    net_amount DECIMAL(18,2) DEFAULT 0,
    tax_amount DECIMAL(18,2) DEFAULT 0,
    grand_total DECIMAL(18,2) DEFAULT 0,
    paid_amount DECIMAL(18,2) DEFAULT 0,
    remaining_amount DECIMAL(18,2) DEFAULT 0,
    status ENUM('draft', 'posted', 'paid', 'partially_paid', 'cancelled') DEFAULT 'draft',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id),
    FOREIGN KEY (order_id) REFERENCES purchase_orders(order_id)
);

-- جدول تفاصيل فواتير المشتريات
CREATE TABLE purchase_invoice_details (
    detail_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    invoice_id VARCHAR(20) NOT NULL,
    item_id VARCHAR(20) NOT NULL,
    unit_id VARCHAR(20) NOT NULL,
    quantity DECIMAL(18,3) NOT NULL,
    unit_price DECIMAL(18,2) NOT NULL,
    discount_percentage DECIMAL(5,2) DEFAULT 0,
    discount_amount DECIMAL(18,2) DEFAULT 0,
    net_amount DECIMAL(18,2) DEFAULT 0,
    tax_percentage DECIMAL(5,2) DEFAULT 0,
    tax_amount DECIMAL(18,2) DEFAULT 0,
    total_amount DECIMAL(18,2) DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (invoice_id) REFERENCES purchase_invoices(invoice_id),
    FOREIGN KEY (item_id) REFERENCES items(item_id),
    FOREIGN KEY (unit_id) REFERENCES units(unit_id)
);

-- جدول مرتجعات المشتريات
CREATE TABLE purchase_returns (
    return_id VARCHAR(20) PRIMARY KEY,
    return_number VARCHAR(20) UNIQUE NOT NULL,
    return_date DATE NOT NULL,
    supplier_id VARCHAR(20) NOT NULL,
    invoice_id VARCHAR(20),
    total_amount DECIMAL(18,2) DEFAULT 0,
    discount_amount DECIMAL(18,2) DEFAULT 0,
    net_amount DECIMAL(18,2) DEFAULT 0,
    tax_amount DECIMAL(18,2) DEFAULT 0,
    grand_total DECIMAL(18,2) DEFAULT 0,
    status ENUM('draft', 'posted', 'cancelled') DEFAULT 'draft',
    reason TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id),
    FOREIGN KEY (invoice_id) REFERENCES purchase_invoices(invoice_id)
);

-- جدول تفاصيل مرتجعات المشتريات
CREATE TABLE purchase_return_details (
    detail_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    return_id VARCHAR(20) NOT NULL,
    item_id VARCHAR(20) NOT NULL,
    unit_id VARCHAR(20) NOT NULL,
    quantity DECIMAL(18,3) NOT NULL,
    unit_price DECIMAL(18,2) NOT NULL,
    discount_percentage DECIMAL(5,2) DEFAULT 0,
    discount_amount DECIMAL(18,2) DEFAULT 0,
    net_amount DECIMAL(18,2) DEFAULT 0,
    tax_percentage DECIMAL(5,2) DEFAULT 0,
    tax_amount DECIMAL(18,2) DEFAULT 0,
    total_amount DECIMAL(18,2) DEFAULT 0,
    reason TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (return_id) REFERENCES purchase_returns(return_id),
    FOREIGN KEY (item_id) REFERENCES items(item_id),
    FOREIGN KEY (unit_id) REFERENCES units(unit_id)
);

-- إجراءات مخزنة

DELIMITER //

-- إجراء تحديث مجاميع عرض السعر
CREATE PROCEDURE update_supplier_quotation_totals(
    IN p_quotation_id VARCHAR(20)
)
BEGIN
    DECLARE v_total_amount DECIMAL(18,2);
    DECLARE v_discount_amount DECIMAL(18,2);
    DECLARE v_net_amount DECIMAL(18,2);
    DECLARE v_tax_amount DECIMAL(18,2);
    DECLARE v_grand_total DECIMAL(18,2);
    
    -- حساب المجاميع
    SELECT 
        COALESCE(SUM(total_amount), 0),
        COALESCE(SUM(discount_amount), 0),
        COALESCE(SUM(net_amount), 0),
        COALESCE(SUM(tax_amount), 0),
        COALESCE(SUM(total_amount), 0)
    INTO 
        v_total_amount,
        v_discount_amount,
        v_net_amount,
        v_tax_amount,
        v_grand_total
    FROM supplier_quotation_details
    WHERE quotation_id = p_quotation_id;
    
    -- تحديث المجاميع
    UPDATE supplier_quotations
    SET 
        total_amount = v_total_amount,
        discount_amount = v_discount_amount,
        net_amount = v_net_amount,
        tax_amount = v_tax_amount,
        grand_total = v_grand_total,
        updated_at = NOW()
    WHERE quotation_id = p_quotation_id;
END //

-- إجراء تحديث مجاميع أمر الشراء
CREATE PROCEDURE update_purchase_order_totals(
    IN p_order_id VARCHAR(20)
)
BEGIN
    DECLARE v_total_amount DECIMAL(18,2);
    DECLARE v_discount_amount DECIMAL(18,2);
    DECLARE v_net_amount DECIMAL(18,2);
    DECLARE v_tax_amount DECIMAL(18,2);
    DECLARE v_grand_total DECIMAL(18,2);
    
    -- حساب المجاميع
    SELECT 
        COALESCE(SUM(total_amount), 0),
        COALESCE(SUM(discount_amount), 0),
        COALESCE(SUM(net_amount), 0),
        COALESCE(SUM(tax_amount), 0),
        COALESCE(SUM(total_amount), 0)
    INTO 
        v_total_amount,
        v_discount_amount,
        v_net_amount,
        v_tax_amount,
        v_grand_total
    FROM purchase_order_details
    WHERE order_id = p_order_id;
    
    -- تحديث المجاميع
    UPDATE purchase_orders
    SET 
        total_amount = v_total_amount,
        discount_amount = v_discount_amount,
        net_amount = v_net_amount,
        tax_amount = v_tax_amount,
        grand_total = v_grand_total,
        updated_at = NOW()
    WHERE order_id = p_order_id;
END //

-- إجراء تحديث مجاميع فاتورة المشتريات
CREATE PROCEDURE update_purchase_invoice_totals(
    IN p_invoice_id VARCHAR(20)
)
BEGIN
    DECLARE v_total_amount DECIMAL(18,2);
    DECLARE v_discount_amount DECIMAL(18,2);
    DECLARE v_net_amount DECIMAL(18,2);
    DECLARE v_tax_amount DECIMAL(18,2);
    DECLARE v_grand_total DECIMAL(18,2);
    DECLARE v_paid_amount DECIMAL(18,2);
    
    -- حساب المجاميع
    SELECT 
        COALESCE(SUM(total_amount), 0),
        COALESCE(SUM(discount_amount), 0),
        COALESCE(SUM(net_amount), 0),
        COALESCE(SUM(tax_amount), 0),
        COALESCE(SUM(total_amount), 0)
    INTO 
        v_total_amount,
        v_discount_amount,
        v_net_amount,
        v_tax_amount,
        v_grand_total
    FROM purchase_invoice_details
    WHERE invoice_id = p_invoice_id;
    
    -- الحصول على المبلغ المدفوع
    SELECT COALESCE(paid_amount, 0)
    INTO v_paid_amount
    FROM purchase_invoices
    WHERE invoice_id = p_invoice_id;
    
    -- تحديث المجاميع
    UPDATE purchase_invoices
    SET 
        total_amount = v_total_amount,
        discount_amount = v_discount_amount,
        net_amount = v_net_amount,
        tax_amount = v_tax_amount,
        grand_total = v_grand_total,
        remaining_amount = v_grand_total - v_paid_amount,
        updated_at = NOW()
    WHERE invoice_id = p_invoice_id;
END //

DELIMITER ;

-- المؤشرات
CREATE INDEX idx_suppliers_status ON suppliers(status);
CREATE INDEX idx_purchase_requests_department ON purchase_requests(department_id);
CREATE INDEX idx_purchase_requests_dates ON purchase_requests(request_date, required_date);
CREATE INDEX idx_purchase_requests_status ON purchase_requests(status);
CREATE INDEX idx_supplier_quotations_supplier ON supplier_quotations(supplier_id);
CREATE INDEX idx_supplier_quotations_dates ON supplier_quotations(quotation_date);
CREATE INDEX idx_supplier_quotations_status ON supplier_quotations(status);
CREATE INDEX idx_purchase_orders_supplier ON purchase_orders(supplier_id);
CREATE INDEX idx_purchase_orders_dates ON purchase_orders(order_date, expected_date);
CREATE INDEX idx_purchase_orders_status ON purchase_orders(status);
CREATE INDEX idx_purchase_invoices_supplier ON purchase_invoices(supplier_id);
CREATE INDEX idx_purchase_invoices_dates ON purchase_invoices(invoice_date);
CREATE INDEX idx_purchase_invoices_status ON purchase_invoices(status);
CREATE INDEX idx_purchase_returns_supplier ON purchase_returns(supplier_id);
CREATE INDEX idx_purchase_returns_dates ON purchase_returns(return_date);
CREATE INDEX idx_purchase_returns_status ON purchase_returns(status);