/**
 * إدارة واجهة المستخدم لنظام المصادقة والأمان
 * @module SecurityUI
 * التاريخ: 2025-05-09 02:40:49
 * المستخدم: mostafamohammad7760
 */

import { authService } from './services/AuthService.js';
import { securityAPI } from './api/SecurityAPI.js';

class SecurityUI {
    constructor() {
        // تهيئة المتغيرات
        this.currentUser = null;
        this.currentSection = 'users';
        this.modals = {};
        this.tables = {};
        this.forms = {};
        
        // تهيئة المكونات
        this.initializeComponents();
        this.attachEventListeners();
        this.loadInitialData();
        
        // تحديث معلومات المستخدم والوقت
        this.updateUserInfo();
        setInterval(() => this.updateDateTime(), 1000);
    }

    /**
     * تهيئة مكونات الواجهة
     */
    initializeComponents() {
        // تهيئة النوافذ المنبثقة
        this.modals = {
            user: document.getElementById('userModal'),
            twoFactor: document.getElementById('twoFactorModal'),
            changePassword: document.getElementById('changePasswordModal')
        };

        // تهيئة النماذج
        this.forms = {
            user: document.getElementById('userForm'),
            twoFactor: document.getElementById('twoFactorForm'),
            changePassword: document.getElementById('changePasswordForm')
        };

        // تهيئة الجداول
        this.tables = {
            users: document.getElementById('usersTable')
        };

        // تهيئة عناصر التصفية
        this.filters = {
            userSearch: document.getElementById('userSearch'),
            departmentFilter: document.getElementById('departmentFilter'),
            statusFilter: document.getElementById('statusFilter')
        };
    }

    /**
     * إضافة مستمعات الأحداث
     */
    attachEventListeners() {
        // أحداث القائمة
        document.querySelectorAll('.menu-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                this.switchSection(e.currentTarget.getAttribute('href').substring(1));
            });
        });

        // أحداث الأزرار
        document.getElementById('addUserBtn')?.addEventListener('click', () => this.showUserModal());
        document.getElementById('exportUsersBtn')?.addEventListener('click', () => this.exportUsers());

        // أحداث النماذج
        this.forms.user?.addEventListener('submit', (e) => this.handleUserFormSubmit(e));
        this.forms.twoFactor?.addEventListener('submit', (e) => this.handleTwoFactorFormSubmit(e));
        this.forms.changePassword?.addEventListener('submit', (e) => this.handleChangePasswordFormSubmit(e));

        // أحداث الفلترة
        Object.values(this.filters).forEach(filter => {
            filter?.addEventListener('change', () => this.applyFilters());
        });

        // أحداث النوافذ المنبثقة
        document.querySelectorAll('.close-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.closeModal(e.target.closest('.modal')));
        });

        // أحداث لوحة المفاتيح
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeAllModals();
            }
        });
    }

    /**
     * تحميل البيانات الأولية
     */
    async loadInitialData() {
        try {
            // تحميل بيانات المستخدمين
            const users = await securityAPI.getUsers();
            this.renderUsersTable(users);

            // تحميل الأقسام
            const departments = await this.loadDepartments();
            this.populateDepartmentFilters(departments);

            // تحميل الأدوار
            const roles = await securityAPI.getRoles();
            this.populateRoleSelects(roles);

        } catch (error) {
            this.showError('حدث خطأ أثناء تحميل البيانات');
            console.error('Data loading error:', error);
        }
    }

    /**
     * تبديل الأقسام
     */
    switchSection(sectionId) {
        document.querySelectorAll('.content-section').forEach(section => {
            section.classList.remove('active');
        });
        document.querySelectorAll('.menu-item').forEach(item => {
            item.classList.remove('active');
        });

        document.getElementById(sectionId)?.classList.add('active');
        document.querySelector(`[href="#${sectionId}"]`)?.classList.add('active');
        
        this.currentSection = sectionId;
        this.loadSectionData(sectionId);
    }

    /**
     * تحميل بيانات القسم
     */
    async loadSectionData(sectionId) {
        switch (sectionId) {
            case 'users':
                const users = await securityAPI.getUsers();
                this.renderUsersTable(users);
                break;
            case 'roles':
                const roles = await securityAPI.getRoles();
                this.renderRolesTable(roles);
                break;
            case 'logs':
                const logs = await securityAPI.getActivityLogs();
                this.renderActivityLogs(logs);
                break;
            // إضافة المزيد من الحالات حسب الحاجة
        }
    }

    /**
     * عرض جدول المستخدمين
     */
    renderUsersTable(users) {
        const tbody = this.tables.users.querySelector('tbody');
        tbody.innerHTML = '';

        users.forEach(user => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${this.escapeHtml(user.username)}</td>
                <td>${this.escapeHtml(user.full_name)}</td>
                <td>${this.escapeHtml(user.email)}</td>
                <td>${this.escapeHtml(user.department)}</td>
                <td>
                    <span class="status-badge ${user.account_status}">
                        ${this.getStatusText(user.account_status)}
                    </span>
                </td>
                <td>${this.formatDate(user.last_login)}</td>
                <td>
                    <button class="btn btn-secondary btn-sm" onclick="editUser('${user.user_id}')">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-danger btn-sm" onclick="deleteUser('${user.user_id}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    }

    /**
     * معالجة نموذج المستخدم
     */
    async handleUserFormSubmit(event) {
        event.preventDefault();
        try {
            const formData = new FormData(event.target);
            const userData = Object.fromEntries(formData.entries());

            if (userData.user_id) {
                await securityAPI.updateUser(userData.user_id, userData);
                this.showSuccess('تم تحديث المستخدم بنجاح');
            } else {
                await securityAPI.createUser(userData);
                this.showSuccess('تم إنشاء المستخدم بنجاح');
            }

            this.closeModal(this.modals.user);
            this.loadSectionData('users');
        } catch (error) {
            this.showError(error.message);
        }
    }

    /**
     * توابع مساعدة
     */
    escapeHtml(str) {
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    formatDate(date) {
        return new Date(date).toLocaleString('ar-SA');
    }

    getStatusText(status) {
        const statusMap = {
            'active': 'نشط',
            'inactive': 'غير نشط',
            'locked': 'مقفل',
            'expired': 'منتهي'
        };
        return statusMap[status] || status;
    }

    showError(message) {
        // يمكن استخدام مكتبة للإشعارات مثل toastr
        alert(message);
    }

    showSuccess(message) {
        // يمكن استخدام مكتبة للإشعارات مثل toastr
        alert(message);
    }

    updateDateTime() {
        const now = new Date();
        document.getElementById('currentDateTime').textContent = 
            now.toISOString().slice(0, 19).replace('T', ' ');
    }

    updateUserInfo() {
        document.getElementById('currentUser').textContent = 'mostafamohammad7760';
    }
}

// تهيئة النظام عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    window.securityUI = new SecurityUI();
});