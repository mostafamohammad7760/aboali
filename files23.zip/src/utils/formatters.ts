/**
 * وظائف تنسيق البيانات
 * التاريخ: 2025-05-09 03:45:16
 * المستخدم: mostafamohammad7760
 */

// تنسيق العملة
export const formatCurrency = (
  amount: number,
  currency: string = 'SAR',
  locale: string = 'ar-SA'
): string => {
  return new Intl.NumberFormat(locale, {
    style: 'currency',
    currency: currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(amount);
};

// تنسيق الأرقام
export const formatNumber = (
  number: number,
  locale: string = 'ar-SA',
  options: Intl.NumberFormatOptions = {}
): string => {
  return new Intl.NumberFormat(locale, options).format(number);
};

// تنسيق النسب المئوية
export const formatPercentage = (
  value: number,
  locale: string = 'ar-SA',
  decimals: number = 2
): string => {
  return new Intl.NumberFormat(locale, {
    style: 'percent',
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals
  }).format(value / 100);
};

// تنسيق التاريخ
export const formatDate = (
  date: Date | string | number,
  locale: string = 'ar-SA',
  options: Intl.DateTimeFormatOptions = { dateStyle: 'medium' }
): string => {
  const dateObj = date instanceof Date ? date : new Date(date);
  return new Intl.DateTimeFormat(locale, options).format(dateObj);
};

// تنسيق الوقت
export const formatTime = (
  date: Date | string | number,
  locale: string = 'ar-SA',
  options: Intl.DateTimeFormatOptions = { timeStyle: 'medium' }
): string => {
  const dateObj = date instanceof Date ? date : new Date(date);
  return new Intl.DateTimeFormat(locale, options).format(dateObj);
};

// تنسيق التاريخ والوقت معاً
export const formatDateTime = (
  date: Date | string | number,
  locale: string = 'ar-SA'
): string => {
  const dateObj = date instanceof Date ? date : new Date(date);
  return new Intl.DateTimeFormat(locale, {
    dateStyle: 'medium',
    timeStyle: 'medium'
  }).format(dateObj);
};

// تنسيق المدة الزمنية
export const formatDuration = (milliseconds: number): string => {
  const seconds = Math.floor(milliseconds / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (days > 0) {
    return `${days} يوم${days > 2 ? '' : 'ان'}`;
  } else if (hours > 0) {
    return `${hours} ساعة${hours > 2 ? '' : 'تان'}`;
  } else if (minutes > 0) {
    return `${minutes} دقيقة${minutes > 2 ? '' : 'تان'}`;
  } else {
    return `${seconds} ثانية${seconds > 2 ? '' : 'تان'}`;
  }
};

// تنسيق الوقت النسبي
export const formatRelativeTime = (
  date: Date | string | number,
  locale: string = 'ar-SA'
): string => {
  const dateObj = date instanceof Date ? date : new Date(date);
  const now = new Date();
  const diffTime = Math.abs(now.getTime() - dateObj.getTime());
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

  const rtf = new Intl.RelativeTimeFormat(locale, { numeric: 'auto' });

  if (diffDays === 0) {
    const diffHours = Math.floor(diffTime / (1000 * 60 * 60));
    if (diffHours === 0) {
      const diffMinutes = Math.floor(diffTime / (1000 * 60));
      if (diffMinutes === 0) {
        return 'الآن';
      }
      return rtf.format(-diffMinutes, 'minute');
    }
    return rtf.format(-diffHours, 'hour');
  }
  if (diffDays < 30) {
    return rtf.format(-diffDays, 'day');
  }
  if (diffDays < 365) {
    const diffMonths = Math.floor(diffDays / 30);
    return rtf.format(-diffMonths, 'month');
  }
  const diffYears = Math.floor(diffDays / 365);
  return rtf.format(-diffYears, 'year');
};

// تنسيق حجم الملف
export const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 بايت';

  const k = 1024;
  const sizes = ['بايت', 'كيلوبايت', 'ميجابايت', 'جيجابايت', 'تيرابايت'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));

  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
};

// تنسيق رقم الهاتف
export const formatPhoneNumber = (
  phone: string,
  countryCode: string = '+966'
): string => {
  // إزالة كل شيء ما عدا الأرقام
  const cleaned = phone.replace(/\D/g, '');
  
  // إضافة رمز الدولة إذا لم يكن موجوداً
  const withCountry = cleaned.startsWith(countryCode.slice(1)) 
    ? cleaned 
    : countryCode.slice(1) + cleaned;

  // تنسيق الرقم: +966 5x xxxx xxx
  const match = withCountry.match(/^(\d{3})(\d{2})(\d{3})(\d{3})$/);
  
  if (match) {
    return `+${match[1]} ${match[2]} ${match[3]} ${match[4]}`;
  }

  return phone;
};

// تنسيق رقم البطاقة البنكية
export const formatCreditCard = (cardNumber: string): string => {
  const cleaned = cardNumber.replace(/\D/g, '');
  const groups = cleaned.match(/(\d{4})/g) || [];
  return groups.join(' ');
};

// تنسيق الباركود
export const formatBarcode = (barcode: string): string => {
  // EAN-13: xxxx xxxx xxxxx
  if (barcode.length === 13) {
    return `${barcode.slice(0, 4)} ${barcode.slice(4, 8)} ${barcode.slice(8)}`;
  }
  // EAN-8: xxxx xxxx
  if (barcode.length === 8) {
    return `${barcode.slice(0, 4)} ${barcode.slice(4)}`;
  }
  return barcode;
};

// تنسيق النص للعرض المختصر
export const truncateText = (
  text: string,
  maxLength: number = 50,
  suffix: string = '...'
): string => {
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength - suffix.length) + suffix;
};

// تحويل الأرقام إلى كلمات عربية
export const numberToArabicWords = (num: number): string => {
  const arabicNumbers = [
    '', 'واحد', 'اثنان', 'ثلاثة', 'أربعة', 'خمسة', 'ستة', 'سبعة', 'ثمانية', 'تسعة',
    'عشرة', 'أحد عشر', 'اثنا عشر', 'ثلاثة عشر', 'أربعة عشر', 'خمسة عشر',
    'ستة عشر', 'سبعة عشر', 'ثمانية عشر', 'تسعة عشر'
  ];

  const tens = [
    '', '', 'عشرون', 'ثلاثون', 'أربعون', 'خمسون', 'ستون', 'سبعون', 'ثمانون', 'تسعون'
  ];

  if (num === 0) return 'صفر';
  if (num < 20) return arabicNumbers[num];
  if (num < 100) {
    const digit = num % 10;
    const ten = Math.floor(num / 10);
    return digit ? `${arabicNumbers[digit]} و${tens[ten]}` : tens[ten];
  }
  
  return num.toString(); // للأرقام الأكبر من 99
};