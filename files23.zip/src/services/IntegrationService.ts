/**
 * خدمة التكامل مع الأنظمة الخارجية
 * التاريخ: 2025-05-09 04:30:01
 * المستخدم: mostafamohammad7760
 */

import { ExternalSystemIntegration, ExternalSystemConfig } from '../integrations/ExternalSystemIntegration';
import { IntegrationSetting } from '../models';
import { logger } from '../utils/logger';

export class IntegrationService {
  private integrations: Map<string, ExternalSystemIntegration> = new Map();

  /**
   * تهيئة التكاملات من الإعدادات
   */
  public async initialize(): Promise<void> {
    try {
      const settings = await IntegrationSetting.findAll({
        where: { active: true }
      });

      for (const setting of settings) {
        this.integrations.set(
          setting.code,
          new ExternalSystemIntegration(setting.config)
        );
      }

      logger.info(`تم تهيئة ${settings.length} تكامل بنجاح`);

    } catch (error) {
      logger.error('خطأ في تهيئة التكاملات:', error);
      throw error;
    }
  }

  /**
   * تصدير بيانات محاسبية
   */
  public async exportAccountingData(data: {
    type: 'journal-entries' | 'chart-of-accounts' | 'financial-statements';
    system: string;
    data: any;
  }): Promise<void> {
    const integration = this.integrations.get(data.system);
    if (!integration) {
      throw new Error(`التكامل غير موجود: ${data.system}`);
    }

    switch (data.type) {
      case 'journal-entries':
        await integration.exportJournalEntries(data.data);
        break;
      case 'chart-of-accounts':
        await integration.exportChartOfAccounts(data.data);
        break;
      case 'financial-statements':
        await integration.exportFinancialStatements(data.data);
        break;
    }
  }
}