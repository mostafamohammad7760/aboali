-- إنشاء جداول التقارير المالية

-- جدول الفترات المالية
CREATE TABLE financial_periods (
    period_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    is_closed BOOLEAN DEFAULT FALSE,
    status ENUM('active', 'closed', 'archived') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    CONSTRAINT chk_dates CHECK (end_date >= start_date)
);

-- جدول معايير التقارير المالية الدولية
CREATE TABLE ifrs_standards (
    standard_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    effective_date DATE,
    version VARCHAR(20),
    category ENUM('presentation', 'measurement', 'disclosure') NOT NULL,
    status ENUM('active', 'superseded', 'withdrawn') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50)
);

-- جدول قوالب التقارير المالية
CREATE TABLE report_templates (
    template_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    type ENUM('balance_sheet', 'income_statement', 'cash_flow', 'changes_in_equity', 'notes') NOT NULL,
    format ENUM('pdf', 'excel', 'html') NOT NULL,
    structure JSON,
    standard_id VARCHAR(20),
    is_default BOOLEAN DEFAULT FALSE,
    status ENUM('active', 'inactive') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (standard_id) REFERENCES ifrs_standards(standard_id)
);

-- جدول التقارير المالية
CREATE TABLE financial_reports (
    report_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    period_id VARCHAR(20) NOT NULL,
    template_id VARCHAR(20) NOT NULL,
    report_date DATE NOT NULL,
    status ENUM('draft', 'reviewed', 'approved', 'published') DEFAULT 'draft',
    data JSON,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    reviewed_at TIMESTAMP,
    reviewed_by VARCHAR(50),
    approved_at TIMESTAMP,
    approved_by VARCHAR(50),
    published_at TIMESTAMP,
    published_by VARCHAR(50),
    FOREIGN KEY (period_id) REFERENCES financial_periods(period_id),
    FOREIGN KEY (template_id) REFERENCES report_templates(template_id)
);

-- جدول السياسات المحاسبية
CREATE TABLE accounting_policies (
    policy_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    standard_id VARCHAR(20),
    category VARCHAR(100) NOT NULL,
    status ENUM('active', 'inactive') DEFAULT 'active',
    effective_date DATE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (standard_id) REFERENCES ifrs_standards(standard_id)
);

-- جدول الإيضاحات المتممة للقوائم المالية
CREATE TABLE financial_notes (
    note_id VARCHAR(20) PRIMARY KEY,
    report_id VARCHAR(20) NOT NULL,
    note_number INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    category VARCHAR(100),
    reference_standard VARCHAR(20),
    attachments JSON,
    status ENUM('draft', 'reviewed', 'approved') DEFAULT 'draft',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (report_id) REFERENCES financial_reports(report_id),
    FOREIGN KEY (reference_standard) REFERENCES ifrs_standards(standard_id)
);

-- جدول التسويات والتعديلات
CREATE TABLE financial_adjustments (
    adjustment_id VARCHAR(20) PRIMARY KEY,
    report_id VARCHAR(20) NOT NULL,
    account_id VARCHAR(20) NOT NULL,
    adjustment_date DATE NOT NULL,
    type ENUM('reclassification', 'correction', 'ifrs_adjustment') NOT NULL,
    amount DECIMAL(18,2) NOT NULL,
    description TEXT NOT NULL,
    reference_standard VARCHAR(20),
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    approved_at TIMESTAMP,
    approved_by VARCHAR(50),
    FOREIGN KEY (report_id) REFERENCES financial_reports(report_id),
    FOREIGN KEY (account_id) REFERENCES chart_of_accounts(account_id),
    FOREIGN KEY (reference_standard) REFERENCES ifrs_standards(standard_id)
);

-- جدول المؤشرات المالية
CREATE TABLE financial_ratios (
    ratio_id VARCHAR(20) PRIMARY KEY,
    report_id VARCHAR(20) NOT NULL,
    code VARCHAR(20) NOT NULL,
    name VARCHAR(200) NOT NULL,
    category ENUM('liquidity', 'profitability', 'solvency', 'efficiency') NOT NULL,
    formula TEXT NOT NULL,
    value DECIMAL(18,4),
    benchmark DECIMAL(18,4),
    analysis TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (report_id) REFERENCES financial_reports(report_id)
);

-- إجراءات مخزنة

DELIMITER //

-- إجراء إنشاء تقرير مالي
CREATE PROCEDURE create_financial_report(
    IN p_period_id VARCHAR(20),
    IN p_template_id VARCHAR(20),
    IN p_report_date DATE
)
BEGIN
    DECLARE v_report_id VARCHAR(20);
    DECLARE v_code VARCHAR(20);
    
    -- توليد كود التقرير
    SET v_code = CONCAT('FR', DATE_FORMAT(NOW(), '%Y%m%d%H%i%s'));
    
    -- إنشاء التقرير
    INSERT INTO financial_reports (
        report_id,
        code,
        name,
        period_id,
        template_id,
        report_date,
        created_by
    )
    VALUES (
        UUID(),
        v_code,
        (SELECT CONCAT('تقرير ', name) FROM financial_periods WHERE period_id = p_period_id),
        p_period_id,
        p_template_id,
        p_report_date,
        'mostafamohammad7760'
    );
    
    -- استرجاع معرف التقرير
    SET v_report_id = LAST_INSERT_ID();
    
    -- إنشاء الإيضاحات المتممة الأساسية
    INSERT INTO financial_notes (
        note_id,
        report_id,
        note_number,
        title,
        content,
        created_by
    )
    VALUES
    (UUID(), v_report_id, 1, 'معلومات عامة عن المنشأة', 'يتم تعديل هذا المحتوى', 'mostafamohammad7760'),
    (UUID(), v_report_id, 2, 'أسس إعداد القوائم المالية', 'يتم تعديل هذا المحتوى', 'mostafamohammad7760'),
    (UUID(), v_report_id, 3, 'السياسات المحاسبية الهامة', 'يتم تعديل هذا المحتوى', 'mostafamohammad7760');
    
    -- حساب المؤشرات المالية الأساسية
    INSERT INTO financial_ratios (
        ratio_id,
        report_id,
        code,
        name,
        category,
        formula,
        created_by
    )
    VALUES
    (UUID(), v_report_id, 'CR', 'نسبة التداول', 'liquidity', 'current_assets / current_liabilities', 'mostafamohammad7760'),
    (UUID(), v_report_id, 'QR', 'النسبة السريعة', 'liquidity', '(current_assets - inventory) / current_liabilities', 'mostafamohammad7760'),
    (UUID(), v_report_id, 'ROA', 'العائد على الأصول', 'profitability', 'net_income / total_assets', 'mostafamohammad7760'),
    (UUID(), v_report_id, 'ROE', 'العائد على حقوق الملكية', 'profitability', 'net_income / total_equity', 'mostafamohammad7760'),
    (UUID(), v_report_id, 'DR', 'نسبة الديون', 'solvency', 'total_liabilities / total_assets', 'mostafamohammad7760'),
    (UUID(), v_report_id, 'AT', 'معدل دوران الأصول', 'efficiency', 'sales / total_assets', 'mostafamohammad7760');
END //

-- إجراء حساب المؤشرات المالية
CREATE PROCEDURE calculate_financial_ratios(
    IN p_report_id VARCHAR(20)
)
BEGIN
    DECLARE v_current_assets DECIMAL(18,2);
    DECLARE v_current_liabilities DECIMAL(18,2);
    DECLARE v_inventory DECIMAL(18,2);
    DECLARE v_net_income DECIMAL(18,2);
    DECLARE v_total_assets DECIMAL(18,2);
    DECLARE v_total_equity DECIMAL(18,2);
    DECLARE v_total_liabilities DECIMAL(18,2);
    DECLARE v_sales DECIMAL(18,2);
    
    -- استرجاع البيانات المالية
    -- يتم تنفيذ الحسابات هنا بناءً على البيانات الفعلية
    
    -- تحديث المؤشرات
    UPDATE financial_ratios
    SET value = 
        CASE code
            WHEN 'CR' THEN v_current_assets / NULLIF(v_current_liabilities, 0)
            WHEN 'QR' THEN (v_current_assets - v_inventory) / NULLIF(v_current_liabilities, 0)
            WHEN 'ROA' THEN v_net_income / NULLIF(v_total_assets, 0)
            WHEN 'ROE' THEN v_net_income / NULLIF(v_total_equity, 0)
            WHEN 'DR' THEN v_total_liabilities / NULLIF(v_total_assets, 0)
            WHEN 'AT' THEN v_sales / NULLIF(v_total_assets, 0)
        END,
        updated_at = NOW(),
        updated_by = 'mostafamohammad7760'
    WHERE report_id = p_report_id;
END //

DELIMITER ;

-- المؤشرات
CREATE INDEX idx_financial_periods_dates ON financial_periods(start_date, end_date);
CREATE INDEX idx_financial_periods_status ON financial_periods(status);
CREATE INDEX idx_ifrs_standards_code ON ifrs_standards(code);
CREATE INDEX idx_ifrs_standards_status ON ifrs_standards(status);
CREATE INDEX idx_report_templates_type ON report_templates(type);
CREATE INDEX idx_report_templates_status ON report_templates(status);
CREATE INDEX idx_financial_reports_period ON financial_reports(period_id);
CREATE INDEX idx_financial_reports_dates ON financial_reports(report_date);
CREATE INDEX idx_financial_reports_status ON financial_reports(status);
CREATE INDEX idx_accounting_policies_category ON accounting_policies(category);
CREATE INDEX idx_accounting_policies_status ON accounting_policies(status);
CREATE INDEX idx_financial_notes_report ON financial_notes(report_id);
CREATE INDEX idx_financial_notes_status ON financial_notes(status);
CREATE INDEX idx_financial_adjustments_report ON financial_adjustments(report_id);
CREATE INDEX idx_financial_adjustments_dates ON financial_adjustments(adjustment_date);
CREATE INDEX idx_financial_adjustments_status ON financial_adjustments(status);
CREATE INDEX idx_financial_ratios_report ON financial_ratios(report_id);
CREATE INDEX idx_financial_ratios_category ON financial_ratios(category);

-- إدخال البيانات الأساسية

-- معايير التقارير المالية الدولية
INSERT INTO ifrs_standards (standard_id, code, name, category, status) VALUES
('IFRS1', 'IFRS 1', 'تطبيق معايير التقارير المالية الدولية لأول مرة', 'presentation', 'active'),
('IFRS7', 'IFRS 7', 'الأدوات المالية: الإفصاحات', 'disclosure', 'active'),
('IFRS9', 'IFRS 9', 'الأدوات المالية', 'measurement', 'active'),
('IFRS15', 'IFRS 15', 'الإيرادات من العقود مع العملاء', 'measurement', 'active'),
('IFRS16', 'IFRS 16', 'عقود الإيجار', 'measurement', 'active'),
('IAS1', 'IAS 1', 'عرض القوائم المالية', 'presentation', 'active'),
('IAS7', 'IAS 7', 'قائمة التدفقات النقدية', 'presentation', 'active'),
('IAS8', 'IAS 8', 'السياسات المحاسبية والتغيرات في التقديرات المحاسبية والأخطاء', 'presentation', 'active');

-- قوالب التقارير المالية الأساسية
INSERT INTO report_templates (template_id, code, name, type, format, is_default, status) VALUES
('TPL1', 'BS_IFRS', 'قائمة المركز المالي وفق IFRS', 'balance_sheet', 'pdf', true, 'active'),
('TPL2', 'IS_IFRS', 'قائمة الدخل الشامل وفق IFRS', 'income_statement', 'pdf', true, 'active'),
('TPL3', 'CF_IFRS', 'قائمة التدفقات النقدية وفق IFRS', 'cash_flow', 'pdf', true, 'active'),
('TPL4', 'CE_IFRS', 'قائمة التغيرات في حقوق الملكية وفق IFRS', 'changes_in_equity', 'pdf', true, 'active');