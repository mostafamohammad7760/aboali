/**
 * واجهة برمجة التطبيقات للضرائب والزكاة
 * @class TaxAPI
 */
export class TaxAPI {
    constructor() {
        this.baseUrl = '/api/v1/tax';
        this.defaultHeaders = {
            'Content-Type': 'application/json',
            'X-User-Id': 'mostafamohammad7760',
            'X-Timestamp': new Date().toISOString()
        };
    }

    /**
     * تنفيذ طلب HTTP
     * @private
     */
    async request(endpoint, options = {}) {
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                ...options,
                headers: {
                    ...this.defaultHeaders,
                    ...options.headers
                }
            });

            if (!response.ok) {
                throw await this.handleErrorResponse(response);
            }

            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            throw this.createUserFriendlyError(error);
        }
    }

    /**
     * طلبات ضريبة القيمة المضافة
     */
    async getVATSummary(period = 'current') {
        return this.request(`/vat/summary?period=${period}`);
    }

    async calculateVAT(data) {
        return this.request('/vat/calculate', {
            method: 'POST',
            body: JSON.stringify(data)
        });
    }

    async submitVATReturn(returnData) {
        this.validateVATReturn(returnData);
        return this.request('/vat/returns', {
            method: 'POST',
            body: JSON.stringify(returnData)
        });
    }

    async getVATReturn(returnId) {
        return this.request(`/vat/returns/${returnId}`);
    }

    async amendVATReturn(returnId, amendmentData) {
        return this.request(`/vat/returns/${returnId}/amend`, {
            method: 'POST',
            body: JSON.stringify(amendmentData)
        });
    }

    /**
     * طلبات الزكاة
     */
    async getZakatSummary(period = 'current') {
        return this.request(`/zakat/summary?period=${period}`);
    }

    async calculateZakat(baseData) {
        this.validateZakatBase(baseData);
        return this.request('/zakat/calculate', {
            method: 'POST',
            body: JSON.stringify(baseData)
        });
    }

    async submitZakatBase(baseData) {
        this.validateZakatBase(baseData);
        return this.request('/zakat/base', {
            method: 'POST',
            body: JSON.stringify(baseData)
        });
    }

    async getZakatBase(baseId) {
        return this.request(`/zakat/base/${baseId}`);
    }

    async updateZakatBase(baseId, baseData) {
        this.validateZakatBase(baseData);
        return this.request(`/zakat/base/${baseId}`, {
            method: 'PUT',
            body: JSON.stringify(baseData)
        });
    }

    /**
     * طلبات الإقرارات الضريبية
     */
    async getUpcomingReturns() {
        return this.request('/returns/upcoming');
    }

    async getTaxReturn(returnId) {
        return this.request(`/returns/${returnId}`);
    }

    async submitTaxReturn(returnData) {
        this.validateTaxReturn(returnData);
        return this.request('/returns', {
            method: 'POST',
            body: JSON.stringify(returnData)
        });
    }

    async updateTaxReturn(returnId, returnData) {
        this.validateTaxReturn(returnData);
        return this.request(`/returns/${returnId}`, {
            method: 'PUT',
            body: JSON.stringify(returnData)
        });
    }

    /**
     * طلبات التحليل والتقارير
     */
    async getTaxAnalysis(period = 'monthly') {
        return this.request(`/analysis/tax?period=${period}`);
    }

    async getZakatComparison(years = 3) {
        return this.request(`/analysis/zakat?years=${years}`);
    }

    async generateReport(reportConfig) {
        return this.request('/reports/generate', {
            method: 'POST',
            body: JSON.stringify(reportConfig)
        });
    }

    /**
     * طلبات المستندات
     */
    async uploadDocument(documentData, file) {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('metadata', JSON.stringify(documentData));

        return this.request('/documents/upload', {
            method: 'POST',
            body: formData,
            headers: {
                // لا نضيف Content-Type هنا لأن fetch سيضيفه تلقائياً مع boundary
                'X-User-Id': this.defaultHeaders['X-User-Id'],
                'X-Timestamp': new Date().toISOString()
            }
        });
    }

    async getDocument(documentId) {
        return this.request(`/documents/${documentId}`);
    }

    async listDocuments(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/documents?${queryString}`);
    }

    /**
     * التحقق من صحة البيانات
     */
    validateVATReturn(returnData) {
        const requiredFields = [
            'period_start',
            'period_end',
            'sales_amount',
            'purchases_amount',
            'vat_on_sales',
            'vat_on_purchases'
        ];

        this.validateRequiredFields(returnData, requiredFields);

        if (returnData.vat_on_sales < 0 || returnData.vat_on_purchases < 0) {
            throw new Error('قيم الضريبة يجب أن تكون موجبة');
        }

        return true;
    }

    validateZakatBase(baseData) {
        const requiredFields = [
            'year',
            'period_start',
            'period_end',
            'capital',
            'reserves',
            'retained_earnings'
        ];

        this.validateRequiredFields(baseData, requiredFields);

        if (baseData.capital <= 0) {
            throw new Error('رأس المال يجب أن يكون أكبر من صفر');
        }

        return true;
    }

    validateTaxReturn(returnData) {
        const requiredFields = [
            'type',
            'period_start',
            'period_end',
            'taxable_amount',
            'tax_amount'
        ];

        this.validateRequiredFields(returnData, requiredFields);

        if (returnData.taxable_amount < 0 || returnData.tax_amount < 0) {
            throw new Error('المبالغ يجب أن تكون موجبة');
        }

        return true;
    }

    validateRequiredFields(data, requiredFields) {
        const missingFields = requiredFields.filter(field => !data[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }
        return true;
    }

    /**
     * معالجة الأخطاء
     */
    async handleErrorResponse(response) {
        let error;
        try {
            const errorData = await response.json();
            error = new Error(errorData.message || 'حدث خطأ غير معروف');
            error.code = errorData.code;
            error.details = errorData.details;
        } catch {
            error = new Error(`خطأ في الطلب: ${response.status}`);
        }
        error.status = response.status;
        return error;
    }

    createUserFriendlyError(error) {
        const errorMessages = {
            400: 'البيانات المدخلة غير صحيحة',
            401: 'يرجى تسجيل الدخول مرة أخرى',
            403: 'ليس لديك صلاحية للقيام بهذا الإجراء',
            404: 'لم يتم العثور على البيانات المطلوبة',
            409: 'تعارض في البيانات',
            422: 'البيانات المدخلة غير صالحة',
            500: 'حدث خطأ في النظام'
        };

        return new Error(
            errorMessages[error.status] || 
            error.message || 
            'حدث خطأ غير متوقع'
        );
    }
}