/**
 * مدير قاعدة البيانات - إدارة عمليات قاعدة البيانات لنظام نقاط البيع
 * @module POSDatabase
 * التاريخ: 2025-05-09 02:57:30
 * المستخدم: mostafamohammad7760
 */

export class POSDatabase {
    constructor() {
        this.dbConfig = {
            host: process.env.DB_HOST || 'localhost',
            port: process.env.DB_PORT || 3306,
            database: process.env.DB_NAME || 'pos_system',
            user: process.env.DB_USER || 'root',
            password: process.env.DB_PASSWORD || '',
            connectionLimit: 10
        };

        this.currentUser = 'mostafamohammad7760';
    }

    /**
     * إنشاء اتصال بقاعدة البيانات
     */
    async getConnection() {
        try {
            const connection = await mysql.createConnection(this.dbConfig);
            return connection;
        } catch (error) {
            console.error('Error connecting to database:', error);
            throw new Error('فشل الاتصال بقاعدة البيانات');
        }
    }

    /**
     * الحصول على المنتجات
     * @param {string} categoryId - معرف الفئة (اختياري)
     */
    async getProducts(categoryId = null) {
        const connection = await this.getConnection();
        try {
            let query = `
                SELECT 
                    p.*,
                    pc.name_ar as category_name,
                    u.name_ar as unit_name
                FROM products p
                LEFT JOIN product_categories pc ON p.category_id = pc.category_id
                LEFT JOIN units u ON p.unit_id = u.unit_id
                WHERE p.is_active = 1
            `;

            if (categoryId) {
                query += ' AND p.category_id = ?';
                const [rows] = await connection.execute(query, [categoryId]);
                return rows;
            }

            const [rows] = await connection.execute(query);
            return rows;
        } finally {
            await connection.end();
        }
    }

    /**
     * البحث عن المنتجات
     * @param {string} query - نص البحث
     */
    async searchProducts(query) {
        const connection = await this.getConnection();
        try {
            const searchQuery = `
                SELECT 
                    p.*,
                    pc.name_ar as category_name,
                    u.name_ar as unit_name
                FROM products p
                LEFT JOIN product_categories pc ON p.category_id = pc.category_id
                LEFT JOIN units u ON p.unit_id = u.unit_id
                WHERE p.is_active = 1
                AND (
                    p.barcode LIKE ? OR
                    p.name_ar LIKE ? OR
                    p.name_en LIKE ?
                )
            `;

            const searchTerm = `%${query}%`;
            const [rows] = await connection.execute(searchQuery, [searchTerm, searchTerm, searchTerm]);
            return rows;
        } finally {
            await connection.end();
        }
    }

    /**
     * الحصول على منتج بواسطة الباركود
     * @param {string} barcode - الباركود
     */
    async getProductByBarcode(barcode) {
        const connection = await this.getConnection();
        try {
            const [rows] = await connection.execute(
                'SELECT * FROM products WHERE barcode = ? AND is_active = 1',
                [barcode]
            );
            return rows[0];
        } finally {
            await connection.end();
        }
    }

    /**
     * حفظ عملية بيع جديدة
     * @param {Object} saleData - بيانات عملية البيع
     */
    async saveSale(saleData) {
        const connection = await this.getConnection();
        try {
            await connection.beginTransaction();

            // إنشاء عملية البيع
            const [saleResult] = await connection.execute(`
                INSERT INTO sales (
                    sale_id,
                    invoice_number,
                    customer_id,
                    total_amount,
                    discount_amount,
                    vat_amount,
                    net_amount,
                    payment_method,
                    created_by
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            `, [
                this.generateUUID(),
                await this.generateInvoiceNumber(),
                saleData.customer?.id || null,
                saleData.totals.subtotal,
                saleData.totals.discount,
                saleData.totals.tax,
                saleData.totals.total,
                saleData.payment.method,
                this.currentUser
            ]);

            const saleId = saleResult.insertId;

            // إضافة تفاصيل البيع
            for (const item of saleData.items) {
                await connection.execute(`
                    INSERT INTO sale_items (
                        sale_item_id,
                        sale_id,
                        product_id,
                        quantity,
                        unit_price,
                        discount_amount,
                        vat_amount,
                        net_amount
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                `, [
                    this.generateUUID(),
                    saleId,
                    item.id,
                    item.quantity,
                    item.price,
                    item.discount || 0,
                    item.vat_amount,
                    item.total_with_vat
                ]);
            }

            // إضافة تفاصيل الدفع
            await connection.execute(`
                INSERT INTO payments (
                    payment_id,
                    sale_id,
                    payment_method,
                    amount,
                    reference_number,
                    created_by
                ) VALUES (?, ?, ?, ?, ?, ?)
            `, [
                this.generateUUID(),
                saleId,
                saleData.payment.method,
                saleData.totals.total,
                saleData.payment.reference || null,
                this.currentUser
            ]);

            // تحديث المخزون
            for (const item of saleData.items) {
                await connection.execute(`
                    UPDATE products 
                    SET stock_quantity = stock_quantity - ?
                    WHERE product_id = ?
                `, [item.quantity, item.id]);
            }

            await connection.commit();

            return {
                saleId,
                ...saleData
            };
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            await connection.end();
        }
    }

    /**
     * التحقق من حالة الخزينة
     */
    async getRegisterStatus() {
        const connection = await this.getConnection();
        try {
            const [rows] = await connection.execute(`
                SELECT * FROM cash_register 
                WHERE status = 'open' 
                ORDER BY opening_date DESC 
                LIMIT 1
            `);

            return {
                isOpen: rows.length > 0,
                register: rows[0] || null
            };
        } finally {
            await connection.end();
        }
    }

    /**
     * فتح الخزينة
     * @param {number} openingAmount - المبلغ الافتتاحي
     */
    async openRegister(openingAmount) {
        const connection = await this.getConnection();
        try {
            const registerId = this.generateUUID();
            await connection.execute(`
                INSERT INTO cash_register (
                    register_id,
                    opening_amount,
                    opened_by,
                    status
                ) VALUES (?, ?, ?, 'open')
            `, [registerId, openingAmount, this.currentUser]);

            return registerId;
        } finally {
            await connection.end();
        }
    }

    /**
     * إغلاق الخزينة
     * @param {string} registerId - معرف الخزينة
     * @param {number} closingAmount - المبلغ النهائي
     */
    async closeRegister(registerId, closingAmount) {
        const connection = await this.getConnection();
        try {
            await connection.execute(`
                UPDATE cash_register 
                SET 
                    closing_amount = ?,
                    closing_date = CURRENT_TIMESTAMP,
                    closed_by = ?,
                    status = 'closed'
                WHERE register_id = ?
            `, [closingAmount, this.currentUser, registerId]);
        } finally {
            await connection.end();
        }
    }

    /**
     * توليد رقم فاتورة جديد
     */
    async generateInvoiceNumber() {
        const connection = await this.getConnection();
        try {
            const [rows] = await connection.execute(`
                SELECT MAX(CAST(SUBSTRING(invoice_number, 5) AS UNSIGNED)) as last_number 
                FROM sales 
                WHERE invoice_number LIKE 'INV-%'
            `);

            const lastNumber = rows[0].last_number || 0;
            return `INV-${String(lastNumber + 1).padStart(6, '0')}`;
        } finally {
            await connection.end();
        }
    }

    /**
     * توليد معرف فريد
     */
    generateUUID() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            const r = Math.random() * 16 | 0;
            const v = c == 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }
}