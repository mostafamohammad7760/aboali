/**
 * خدمة API للحسابات المدينة والدائنة
 * @class AccountsAPI
 */
export class AccountsAPI {
    constructor() {
        this.baseUrl = '/api/v1/accounts';
        this.defaultHeaders = {
            'Content-Type': 'application/json',
            'X-User-Id': 'mostafamohammad7760',
            'X-Timestamp': new Date().toISOString()
        };
    }

    /**
     * تنفيذ طلب HTTP
     * @private
     */
    async request(endpoint, options = {}) {
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                ...options,
                headers: {
                    ...this.defaultHeaders,
                    ...options.headers
                }
            });

            if (!response.ok) {
                throw await this.handleErrorResponse(response);
            }

            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            throw this.createUserFriendlyError(error);
        }
    }

    /**
     * طلبات الحسابات المدينة
     */
    async getReceivablesSummary(period = 'month') {
        return this.request(`/receivables/summary?period=${period}`);
    }

    async getReceivablesAging() {
        return this.request('/receivables/aging');
    }

    async getCustomerBalance(customerId) {
        return this.request(`/receivables/customers/${customerId}/balance`);
    }

    async getCustomerStatements(customerId, params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/receivables/customers/${customerId}/statements?${queryString}`);
    }

    /**
     * طلبات الحسابات الدائنة
     */
    async getPayablesSummary(period = 'month') {
        return this.request(`/payables/summary?period=${period}`);
    }

    async getPayablesAging() {
        return this.request('/payables/aging');
    }

    async getSupplierBalance(supplierId) {
        return this.request(`/payables/suppliers/${supplierId}/balance`);
    }

    async getSupplierStatements(supplierId, params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/payables/suppliers/${supplierId}/statements?${queryString}`);
    }

    /**
     * طلبات فواتير المبيعات
     */
    async createSalesInvoice(invoiceData) {
        this.validateInvoiceData(invoiceData);
        return this.request('/sales-invoices', {
            method: 'POST',
            body: JSON.stringify(invoiceData)
        });
    }

    async updateSalesInvoice(invoiceId, invoiceData) {
        this.validateInvoiceData(invoiceData);
        return this.request(`/sales-invoices/${invoiceId}`, {
            method: 'PUT',
            body: JSON.stringify(invoiceData)
        });
    }

    async getSalesInvoice(invoiceId) {
        return this.request(`/sales-invoices/${invoiceId}`);
    }

    async getSalesInvoices(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/sales-invoices?${queryString}`);
    }

    async voidSalesInvoice(invoiceId, reason) {
        return this.request(`/sales-invoices/${invoiceId}/void`, {
            method: 'POST',
            body: JSON.stringify({ reason })
        });
    }

    /**
     * طلبات فواتير المشتريات
     */
    async createPurchaseInvoice(invoiceData) {
        this.validateInvoiceData(invoiceData);
        return this.request('/purchase-invoices', {
            method: 'POST',
            body: JSON.stringify(invoiceData)
        });
    }

    async updatePurchaseInvoice(invoiceId, invoiceData) {
        this.validateInvoiceData(invoiceData);
        return this.request(`/purchase-invoices/${invoiceId}`, {
            method: 'PUT',
            body: JSON.stringify(invoiceData)
        });
    }

    async getPurchaseInvoice(invoiceId) {
        return this.request(`/purchase-invoices/${invoiceId}`);
    }

    async getPurchaseInvoices(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/purchase-invoices?${queryString}`);
    }

    async voidPurchaseInvoice(invoiceId, reason) {
        return this.request(`/purchase-invoices/${invoiceId}/void`, {
            method: 'POST',
            body: JSON.stringify({ reason })
        });
    }

    /**
     * طلبات المدفوعات والمقبوضات
     */
    async recordPayment(paymentData) {
        this.validatePaymentData(paymentData);
        return this.request('/payments', {
            method: 'POST',
            body: JSON.stringify(paymentData)
        });
    }

    async recordReceipt(receiptData) {
        this.validatePaymentData(receiptData);
        return this.request('/receipts', {
            method: 'POST',
            body: JSON.stringify(receiptData)
        });
    }

    async getPaymentDetails(paymentId) {
        return this.request(`/payments/${paymentId}`);
    }

    async getReceiptDetails(receiptId) {
        return this.request(`/receipts/${receiptId}`);
    }

    async voidPayment(paymentId, reason) {
        return this.request(`/payments/${paymentId}/void`, {
            method: 'POST',
            body: JSON.stringify({ reason })
        });
    }

    async voidReceipt(receiptId, reason) {
        return this.request(`/receipts/${receiptId}/void`, {
            method: 'POST',
            body: JSON.stringify({ reason })
        });
    }

    /**
     * طلبات الفواتير المستحقة
     */
    async getDueInvoices(type = 'all', params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/due-invoices/${type}?${queryString}`);
    }

    async sendPaymentReminder(invoiceId, reminderData) {
        return this.request(`/invoices/${invoiceId}/reminders`, {
            method: 'POST',
            body: JSON.stringify(reminderData)
        });
    }

    /**
     * التحقق من صحة البيانات
     */
    validateInvoiceData(invoiceData) {
        const requiredFields = [
            'party_id',
            'invoice_date',
            'due_date',
            'items'
        ];
        
        const missingFields = requiredFields.filter(field => !invoiceData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        if (!Array.isArray(invoiceData.items) || invoiceData.items.length === 0) {
            throw new Error('يجب إضافة بند واحد على الأقل للفاتورة');
        }

        return true;
    }

    validatePaymentData(paymentData) {
        const requiredFields = [
            'party_id',
            'amount',
            'payment_date',
            'payment_method'
        ];
        
        const missingFields = requiredFields.filter(field => !paymentData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        if (paymentData.amount <= 0) {
            throw new Error('يجب أن يكون المبلغ أكبر من صفر');
        }

        return true;
    }

    /**
     * معالجة الأخطاء
     */
    async handleErrorResponse(response) {
        let error;
        try {
            const errorData = await response.json();
            error = new Error(errorData.message || 'حدث خطأ غير معروف');
            error.code = errorData.code;
            error.details = errorData.details;
        } catch {
            error = new Error(`خطأ في الطلب: ${response.status}`);
        }
        error.status = response.status;
        return error;
    }

    createUserFriendlyError(error) {
        const errorMessages = {
            400: 'البيانات المدخلة غير صحيحة',
            401: 'يرجى تسجيل الدخول مرة أخرى',
            403: 'ليس لديك صلاحية للقيام بهذا الإجراء',
            404: 'لم يتم العثور على البيانات المطلوبة',
            409: 'تعارض في البيانات',
            422: 'البيانات المدخلة غير صالحة',
            500: 'حدث خطأ في النظام'
        };

        return new Error(
            errorMessages[error.status] || 
            error.message || 
            'حدث خطأ غير متوقع'
        );
    }
}