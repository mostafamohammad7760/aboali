export class CashManagementAPI {
    constructor() {
        this.baseUrl = '/api/v1';
    }

    async request(endpoint, options = {}) {
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                ...options,
                headers: {
                    'Content-Type': 'application/json',
                    ...options.headers
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            return data;
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    }

    // طلبات الصناديق النقدية
    async getCashSummary() {
        return this.request('/cash/summary');
    }

    async getCashRegisters() {
        return this.request('/cash/registers');
    }

    async getCashRegister(registerId) {
        return this.request(`/cash/registers/${registerId}`);
    }

    async createCashRegister(registerData) {
        return this.request('/cash/registers', {
            method: 'POST',
            body: JSON.stringify(registerData)
        });
    }

    async updateCashRegister(registerId, registerData) {
        return this.request(`/cash/registers/${registerId}`, {
            method: 'PUT',
            body: JSON.stringify(registerData)
        });
    }

    // طلبات الحسابات البنكية
    async getBankSummary() {
        return this.request('/bank/summary');
    }

    async getBankAccounts() {
        return this.request('/bank/accounts');
    }

    async getBankAccount(accountId) {
        return this.request(`/bank/accounts/${accountId}`);
    }

    async createBankAccount(accountData) {
        return this.request('/bank/accounts', {
            method: 'POST',
            body: JSON.stringify(accountData)
        });
    }

    async updateBankAccount(accountId, accountData) {
        return this.request(`/bank/accounts/${accountId}`, {
            method: 'PUT',
            body: JSON.stringify(accountData)
        });
    }

    // طلبات الشيكات
    async getChequesSummary() {
        return this.request('/cheques/summary');
    }

    async getIssuedCheques(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/cheques/issued?${queryString}`);
    }

    async getReceivedCheques(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/cheques/received?${queryString}`);
    }

    async createCheque(chequeData) {
        return this.request('/cheques', {
            method: 'POST',
            body: JSON.stringify(chequeData)
        });
    }

    async updateChequeStatus(chequeId, status) {
        return this.request(`/cheques/${chequeId}/status`, {
            method: 'PUT',
            body: JSON.stringify({ status })
        });
    }

    // طلبات المعاملات
    async getCashTransactions(registerId, params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/cash/registers/${registerId}/transactions?${queryString}`);
    }

    async createCashTransaction(registerId, transactionData) {
        return this.request(`/cash/registers/${registerId}/transactions`, {
            method: 'POST',
            body: JSON.stringify(transactionData)
        });
    }

    // طلبات التسويات البنكية
    async getBankReconciliations(accountId) {
        return this.request(`/bank/accounts/${accountId}/reconciliations`);
    }

    async createBankReconciliation(accountId, reconciliationData) {
        return this.request(`/bank/accounts/${accountId}/reconciliations`, {
            method: 'POST',
            body: JSON.stringify(reconciliationData)
        });
    }

    async getReconciliationItems(reconciliationId) {
        return this.request(`/bank/reconciliations/${reconciliationId}/items`);
    }

    async addReconciliationItem(reconciliationId, itemData) {
        return this.request(`/bank/reconciliations/${reconciliationId}/items`, {
            method: 'POST',
            body: JSON.stringify(itemData)
        });
    }

    // طلبات التقارير
    async getCashFlow(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/cash-flow?${queryString}`);
    }

    async getBankStatement(accountId, params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/bank/accounts/${accountId}/statement?${queryString}`);
    }
}