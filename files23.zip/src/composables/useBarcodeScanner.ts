/**
 * مكون مساعد لقارئ الباركود
 * التاريخ: 2025-05-09 03:42:37
 * المستخدم: mostafamohammad7760
 */

import { ref, onMounted, onUnmounted } from 'vue';
import { useStore } from 'vuex';

interface ScannerConfig {
  // الحد الأقصى للوقت بين الأحرف (بالمللي ثانية)
  maxDelayBetweenChars: number;
  // الحد الأدنى لطول الباركود
  minBarcodeLength: number;
  // الحد الأقصى لطول الباركود
  maxBarcodeLength: number;
  // أنماط الباركود المدعومة
  supportedFormats: string[];
  // تفعيل صوت عند المسح
  beepOnScan: boolean;
  // تفعيل اهتزاز عند المسح
  vibrateOnScan: boolean;
}

export function useBarcodeScanner() {
  const store = useStore();
  
  // حالة القارئ
  const isListening = ref(false);
  const lastScanTime = ref<number>(0);
  const buffer = ref<string>('');
  const timeoutId = ref<number | null>(null);

  // الإعدادات الافتراضية
  const defaultConfig: ScannerConfig = {
    maxDelayBetweenChars: 50,
    minBarcodeLength: 3,
    maxBarcodeLength: 48,
    supportedFormats: ['EAN-13', 'EAN-8', 'UPC-A', 'UPC-E', 'CODE-128', 'CODE-39'],
    beepOnScan: true,
    vibrateOnScan: true
  };

  // الحصول على إعدادات القارئ من المتجر
  const config = ref<ScannerConfig>({
    ...defaultConfig,
    ...store.state.pos.settings.scanner
  });

  // معالجة ضغطات المفاتيح
  const handleKeyDown = (event: KeyboardEvent) => {
    // تجاهل المدخلات من حقول النصوص
    if (
      event.target instanceof HTMLInputElement ||
      event.target instanceof HTMLTextAreaElement ||
      event.target instanceof HTMLSelectElement
    ) {
      return;
    }

    const currentTime = Date.now();

    // إذا كان الوقت بين الأحرف أكبر من الحد الأقصى، نبدأ من جديد
    if (currentTime - lastScanTime.value > config.value.maxDelayBetweenChars) {
      buffer.value = '';
    }

    lastScanTime.value = currentTime;

    // إضافة الحرف للمؤقت
    if (event.key !== 'Enter') {
      buffer.value += event.key;

      // إعادة ضبط المؤقت
      if (timeoutId.value) {
        clearTimeout(timeoutId.value);
      }

      timeoutId.value = window.setTimeout(() => {
        buffer.value = '';
      }, config.value.maxDelayBetweenChars);

    } else {
      // عند الضغط على Enter نتحقق من صحة الباركود
      if (
        buffer.value.length >= config.value.minBarcodeLength &&
        buffer.value.length <= config.value.maxBarcodeLength
      ) {
        processBarcode(buffer.value);
      }

      buffer.value = '';
      if (timeoutId.value) {
        clearTimeout(timeoutId.value);
      }
    }
  };

  // معالجة الباركود
  const processBarcode = async (barcode: string) => {
    try {
      // تشغيل الصوت إذا كان مفعلاً
      if (config.value.beepOnScan) {
        playBeep();
      }

      // تشغيل الاهتزاز إذا كان مفعلاً
      if (config.value.vibrateOnScan && navigator.vibrate) {
        navigator.vibrate(100);
      }

      // البحث عن المنتج في المتجر
      const product = await store.dispatch('pos/findProductByBarcode', barcode);

      if (product) {
        // إرسال المنتج إلى المكون الأب
        emit('barcode-scanned', {
          barcode,
          product,
          timestamp: Date.now()
        });
      } else {
        // إرسال إشعار بعدم وجود المنتج
        emit('barcode-not-found', {
          barcode,
          timestamp: Date.now()
        });
      }

    } catch (error) {
      console.error('خطأ في معالجة الباركود:', error);
      emit('barcode-error', {
        barcode,
        error,
        timestamp: Date.now()
      });
    }
  };

  // تشغيل صوت المسح
  const playBeep = () => {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    oscillator.type = 'square';
    oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
    gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);

    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.1);
  };

  // تهيئة القارئ
  const initScanner = (callback?: (data: any) => void) => {
    if (callback) {
      on('barcode-scanned', callback);
    }
    
    if (!isListening.value) {
      window.addEventListener('keydown', handleKeyDown);
      isListening.value = true;
    }
  };

  // إيقاف القارئ
  const stopScanner = () => {
    if (isListening.value) {
      window.removeEventListener('keydown', handleKeyDown);
      isListening.value = false;
    }

    // تنظيف المتغيرات
    buffer.value = '';
    if (timeoutId.value) {
      clearTimeout(timeoutId.value);
    }
  };

  // تحديث إعدادات القارئ
  const updateConfig = (newConfig: Partial<ScannerConfig>) => {
    config.value = {
      ...config.value,
      ...newConfig
    };
  };

  // نظام الأحداث البسيط
  const listeners = new Map<string, Set<(data: any) => void>>();

  const on = (event: string, callback: (data: any) => void) => {
    if (!listeners.has(event)) {
      listeners.set(event, new Set());
    }
    listeners.get(event)!.add(callback);
  };

  const off = (event: string, callback: (data: any) => void) => {
    const eventListeners = listeners.get(event);
    if (eventListeners) {
      eventListeners.delete(callback);
    }
  };

  const emit = (event: string, data: any) => {
    const eventListeners = listeners.get(event);
    if (eventListeners) {
      eventListeners.forEach(callback => callback(data));
    }
  };

  // تنظيف عند إزالة المكون
  onUnmounted(() => {
    stopScanner();
    listeners.clear();
  });

  return {
    isListening,
    config,
    initScanner,
    stopScanner,
    updateConfig,
    on,
    off
  };
}