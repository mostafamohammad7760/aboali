/**
 * مدير المدفوعات - إدارة طرق الدفع والمعاملات المالية في نظام نقاط البيع
 * @module PaymentManager
 * التاريخ: 2025-05-09 03:10:30
 * المستخدم: mostafamohammad7760
 */

export class PaymentManager {
    constructor(database) {
        this.db = database;
        
        // طرق الدفع المدعومة
        this.paymentMethods = {
            CASH: 'cash',
            CARD: 'card',
            BANK_TRANSFER: 'bank_transfer',
            DIGITAL_WALLET: 'digital_wallet',
            CREDIT: 'credit'
        };

        // حالات المعاملات
        this.transactionStatus = {
            PENDING: 'pending',
            COMPLETED: 'completed',
            FAILED: 'failed',
            REFUNDED: 'refunded',
            PARTIALLY_REFUNDED: 'partially_refunded',
            CANCELLED: 'cancelled'
        };
    }

    /**
     * معالجة عملية دفع جديدة
     * @param {Object} paymentData - بيانات عملية الدفع
     */
    async processPayment(paymentData) {
        try {
            // التحقق من البيانات
            this.validatePaymentData(paymentData);

            // التحقق من توفر المبلغ في حالة الدفع بالآجل
            if (paymentData.method === this.paymentMethods.CREDIT) {
                await this.checkCustomerCredit(
                    paymentData.customer_id,
                    paymentData.amount
                );
            }

            const transactionId = this.generateTransactionId();
            
            // بدء المعاملة
            await this.db.beginTransaction();

            // تسجيل المعاملة
            const transaction = await this.createTransaction({
                transaction_id: transactionId,
                ...paymentData
            });

            // معالجة الدفع حسب الطريقة
            const processedPayment = await this.handlePaymentMethod(transaction);

            // تحديث حالة المعاملة
            await this.updateTransactionStatus(
                transactionId,
                this.transactionStatus.COMPLETED,
                processedPayment
            );

            await this.db.commit();

            // إصدار إيصال الدفع
            const receipt = await this.generatePaymentReceipt(transaction);

            return {
                transaction_id: transactionId,
                status: this.transactionStatus.COMPLETED,
                receipt,
                details: processedPayment
            };
        } catch (error) {
            await this.db.rollback();
            console.error('Error processing payment:', error);
            throw new Error('فشل معالجة عملية الدفع');
        }
    }

    /**
     * معالجة طريقة الدفع
     * @param {Object} transaction - بيانات المعاملة
     */
    async handlePaymentMethod(transaction) {
        switch (transaction.method) {
            case this.paymentMethods.CASH:
                return await this.processCashPayment(transaction);

            case this.paymentMethods.CARD:
                return await this.processCardPayment(transaction);

            case this.paymentMethods.BANK_TRANSFER:
                return await this.processBankTransfer(transaction);

            case this.paymentMethods.DIGITAL_WALLET:
                return await this.processDigitalWallet(transaction);

            case this.paymentMethods.CREDIT:
                return await this.processCreditPayment(transaction);

            default:
                throw new Error('طريقة الدفع غير مدعومة');
        }
    }

    /**
     * معالجة الدفع النقدي
     * @param {Object} transaction - بيانات المعاملة
     */
    async processCashPayment(transaction) {
        const change = transaction.received_amount - transaction.amount;
        
        await this.logCashTransaction({
            transaction_id: transaction.transaction_id,
            amount: transaction.amount,
            received: transaction.received_amount,
            change,
            cashier_id: this.currentUser
        });

        return {
            received: transaction.received_amount,
            change,
            status: 'success'
        };
    }

    /**
     * معالجة الدفع بالبطاقة
     * @param {Object} transaction - بيانات المعاملة
     */
    async processCardPayment(transaction) {
        // هنا يمكن إضافة التكامل مع نظام نقاط البيع للبطاقات
        const cardPayment = {
            amount: transaction.amount,
            card_type: transaction.card_type,
            last_digits: transaction.card_number.slice(-4),
            auth_code: this.generateAuthCode(),
            reference: transaction.reference || null
        };

        await this.logCardTransaction({
            transaction_id: transaction.transaction_id,
            ...cardPayment
        });

        return {
            ...cardPayment,
            status: 'success'
        };
    }

    /**
     * معالجة التحويل البنكي
     * @param {Object} transaction - بيانات المعاملة
     */
    async processBankTransfer(transaction) {
        await this.logBankTransfer({
            transaction_id: transaction.transaction_id,
            amount: transaction.amount,
            bank_name: transaction.bank_name,
            reference: transaction.reference,
            account_number: transaction.account_number
        });

        return {
            reference: transaction.reference,
            status: 'success'
        };
    }

    /**
     * معالجة المحفظة الرقمية
     * @param {Object} transaction - بيانات المعاملة
     */
    async processDigitalWallet(transaction) {
        // يمكن إضافة التكامل مع خدمات الدفع الإلكتروني هنا
        await this.logDigitalWalletTransaction({
            transaction_id: transaction.transaction_id,
            amount: transaction.amount,
            wallet_type: transaction.wallet_type,
            reference: transaction.reference
        });

        return {
            reference: transaction.reference,
            status: 'success'
        };
    }

    /**
     * معالجة الدفع الآجل
     * @param {Object} transaction - بيانات المعاملة
     */
    async processCreditPayment(transaction) {
        await this.updateCustomerCredit(
            transaction.customer_id,
            transaction.amount
        );

        await this.logCreditTransaction({
            transaction_id: transaction.transaction_id,
            customer_id: transaction.customer_id,
            amount: transaction.amount,
            due_date: transaction.due_date
        });

        return {
            due_date: transaction.due_date,
            status: 'success'
        };
    }

    /**
     * إنشاء معاملة جديدة
     * @param {Object} data - بيانات المعاملة
     */
    async createTransaction(data) {
        const query = `
            INSERT INTO payment_transactions (
                transaction_id,
                sale_id,
                method,
                amount,
                currency,
                status,
                customer_id,
                created_by,
                reference
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;

        await this.db.executeQuery(query, [
            data.transaction_id,
            data.sale_id,
            data.method,
            data.amount,
            data.currency || 'SAR',
            this.transactionStatus.PENDING,
            data.customer_id,
            this.currentUser,
            data.reference
        ]);

        return data;
    }

    /**
     * تحديث حالة المعاملة
     * @param {string} transactionId - معرف المعاملة
     * @param {string} status - الحالة الجديدة
     * @param {Object} details - تفاصيل إضافية
     */
    async updateTransactionStatus(transactionId, status, details = {}) {
        const query = `
            UPDATE payment_transactions 
            SET 
                status = ?,
                processed_at = CURRENT_TIMESTAMP,
                details = ?,
                updated_by = ?
            WHERE transaction_id = ?
        `;

        await this.db.executeQuery(query, [
            status,
            JSON.stringify(details),
            this.currentUser,
            transactionId
        ]);
    }

    /**
     * التحقق من صحة بيانات الدفع
     * @param {Object} data - بيانات الدفع
     */
    validatePaymentData(data) {
        const errors = [];

        if (!data.amount || data.amount <= 0) {
            errors.push('المبلغ غير صالح');
        }

        if (!this.paymentMethods[data.method]) {
            errors.push('طريقة الدفع غير صالحة');
        }

        if (data.method === this.paymentMethods.CASH && !data.received_amount) {
            errors.push('المبلغ المستلم مطلوب للدفع النقدي');
        }

        if (data.method === this.paymentMethods.CREDIT && !data.customer_id) {
            errors.push('معرف العميل مطلوب للدفع الآجل');
        }

        if (errors.length > 0) {
            throw new Error(errors.join('\n'));
        }
    }

    /**
     * توليد معرف فريد للمعاملة
     */
    generateTransactionId() {
        return 'TRX-' + Date.now().toString(36).toUpperCase();
    }

    /**
     * توليد رمز التفويض
     */
    generateAuthCode() {
        return Math.random().toString(36).substr(2, 6).toUpperCase();
    }
}