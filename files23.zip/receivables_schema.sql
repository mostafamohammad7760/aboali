-- إنشاء جداول الحسابات المدينة

-- جدول العملاء
CREATE TABLE customers (
    customer_id VARCHAR(20) PRIMARY KEY,
    customer_name_ar VARCHAR(200) NOT NULL,
    customer_name_en VARCHAR(200),
    cr_number VARCHAR(50),
    tax_number VARCHAR(50),
    contact_person VARCHAR(100),
    phone VARCHAR(50),
    email VARCHAR(100),
    address TEXT,
    payment_terms INT DEFAULT 30,
    credit_limit DECIMAL(18,2),
    currency_code CHAR(3) NOT NULL,
    status ENUM('active', 'inactive', 'blocked') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50)
);

-- جدول فواتير العملاء
CREATE TABLE customer_invoices (
    invoice_id VARCHAR(20) PRIMARY KEY,
    customer_id VARCHAR(20) NOT NULL,
    invoice_number VARCHAR(50) NOT NULL,
    invoice_date DATE NOT NULL,
    due_date DATE NOT NULL,
    subtotal DECIMAL(18,2) NOT NULL,
    tax_amount DECIMAL(18,2) DEFAULT 0,
    discount_amount DECIMAL(18,2) DEFAULT 0,
    total_amount DECIMAL(18,2) NOT NULL,
    currency_code CHAR(3) NOT NULL,
    exchange_rate DECIMAL(10,6) DEFAULT 1,
    payment_status ENUM('unpaid', 'partially_paid', 'paid', 'cancelled') DEFAULT 'unpaid',
    invoice_type ENUM('standard', 'proforma', 'credit_note', 'debit_note') DEFAULT 'standard',
    description TEXT,
    terms_conditions TEXT,
    reference_number VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

-- جدول بنود الفواتير
CREATE TABLE invoice_items (
    item_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    invoice_id VARCHAR(20) NOT NULL,
    product_code VARCHAR(50),
    description TEXT,
    quantity DECIMAL(10,2) NOT NULL,
    unit_price DECIMAL(18,2) NOT NULL,
    tax_rate DECIMAL(5,2) DEFAULT 0,
    tax_amount DECIMAL(18,2) DEFAULT 0,
    discount_rate DECIMAL(5,2) DEFAULT 0,
    discount_amount DECIMAL(18,2) DEFAULT 0,
    total_amount DECIMAL(18,2) NOT NULL,
    cost_center_id VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (invoice_id) REFERENCES customer_invoices(invoice_id)
);

-- جدول المقبوضات
CREATE TABLE receipts (
    receipt_id VARCHAR(20) PRIMARY KEY,
    customer_id VARCHAR(20) NOT NULL,
    receipt_date DATE NOT NULL,
    amount DECIMAL(18,2) NOT NULL,
    receipt_method ENUM('cash', 'cheque', 'bank_transfer', 'credit_card') NOT NULL,
    reference_number VARCHAR(50),
    description TEXT,
    status ENUM('pending', 'completed', 'cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    completed_at TIMESTAMP NULL,
    completed_by VARCHAR(50),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

-- جدول توزيع المقبوضات على الفواتير
CREATE TABLE receipt_distributions (
    distribution_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    receipt_id VARCHAR(20) NOT NULL,
    invoice_id VARCHAR(20) NOT NULL,
    amount DECIMAL(18,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    FOREIGN KEY (receipt_id) REFERENCES receipts(receipt_id),
    FOREIGN KEY (invoice_id) REFERENCES customer_invoices(invoice_id)
);

-- جدول أعمار الديون
CREATE TABLE receivables_aging (
    aging_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    customer_id VARCHAR(20) NOT NULL,
    invoice_id VARCHAR(20) NOT NULL,
    aging_date DATE NOT NULL,
    current_amount DECIMAL(18,2) DEFAULT 0,
    days_30 DECIMAL(18,2) DEFAULT 0,
    days_60 DECIMAL(18,2) DEFAULT 0,
    days_90 DECIMAL(18,2) DEFAULT 0,
    days_120 DECIMAL(18,2) DEFAULT 0,
    days_over_120 DECIMAL(18,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (invoice_id) REFERENCES customer_invoices(invoice_id)
);

-- جدول خطط التحصيل
CREATE TABLE collection_plans (
    plan_id VARCHAR(20) PRIMARY KEY,
    customer_id VARCHAR(20) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE,
    total_amount DECIMAL(18,2) NOT NULL,
    collected_amount DECIMAL(18,2) DEFAULT 0,
    status ENUM('active', 'completed', 'cancelled') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

-- جدول أقساط خطط التحصيل
CREATE TABLE collection_installments (
    installment_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    plan_id VARCHAR(20) NOT NULL,
    due_date DATE NOT NULL,
    amount DECIMAL(18,2) NOT NULL,
    status ENUM('pending', 'paid', 'overdue', 'cancelled') DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (plan_id) REFERENCES collection_plans(plan_id)
);

-- إجراءات مخزنة

DELIMITER //

-- إجراء تحديث حالة دفع الفاتورة
CREATE PROCEDURE update_invoice_collection_status(
    IN p_invoice_id VARCHAR(20)
)
BEGIN
    DECLARE v_total_amount DECIMAL(18,2);
    DECLARE v_collected_amount DECIMAL(18,2);
    
    -- الحصول على إجمالي الفاتورة
    SELECT total_amount INTO v_total_amount
    FROM customer_invoices
    WHERE invoice_id = p_invoice_id;
    
    -- حساب إجمالي المحصل
    SELECT COALESCE(SUM(amount), 0) INTO v_collected_amount
    FROM receipt_distributions
    WHERE invoice_id = p_invoice_id;
    
    -- تحديث حالة الفاتورة
    UPDATE customer_invoices 
    SET payment_status = CASE
        WHEN v_collected_amount = 0 THEN 'unpaid'
        WHEN v_collected_amount < v_total_amount THEN 'partially_paid'
        ELSE 'paid'
    END
    WHERE invoice_id = p_invoice_id;
END //

-- إجراء تحديث حالة خطة التحصيل
CREATE PROCEDURE update_collection_plan_status(
    IN p_plan_id VARCHAR(20)
)
BEGIN
    DECLARE v_total_amount DECIMAL(18,2);
    DECLARE v_collected_amount DECIMAL(18,2);
    DECLARE v_overdue_count INT;
    
    -- الحصول على إجمالي الخطة والمبلغ المحصل
    SELECT total_amount, collected_amount 
    INTO v_total_amount, v_collected_amount
    FROM collection_plans 
    WHERE plan_id = p_plan_id;
    
    -- حساب عدد الأقساط المتأخرة
    SELECT COUNT(*) INTO v_overdue_count
    FROM collection_installments
    WHERE plan_id = p_plan_id
    AND due_date < CURDATE()
    AND status = 'pending';
    
    -- تحديث حالة الخطة
    UPDATE collection_plans 
    SET status = CASE
        WHEN v_collected_amount >= v_total_amount THEN 'completed'
        WHEN v_overdue_count > 0 THEN 'overdue'
        ELSE 'active'
    END
    WHERE plan_id = p_plan_id;
END //

-- إجراء حساب أعمار الديون
CREATE PROCEDURE calculate_receivables_aging(
    IN p_customer_id VARCHAR(20),
    IN p_date DATE
)
BEGIN
    -- حذف السجلات القديمة
    DELETE FROM receivables_aging 
    WHERE customer_id = p_customer_id 
    AND aging_date = p_date;
    
    -- إدراج السجلات الجديدة
    INSERT INTO receivables_aging (
        customer_id,
        invoice_id,
        aging_date,
        current_amount,
        days_30,
        days_60,
        days_90,
        days_120,
        days_over_120
    )
    SELECT 
        ci.customer_id,
        ci.invoice_id,
        p_date as aging_date,
        CASE WHEN DATEDIFF(p_date, ci.due_date) <= 0 
             THEN (ci.total_amount - COALESCE(rd.paid_amount, 0))
             ELSE 0 END as current_amount,
        CASE WHEN DATEDIFF(p_date, ci.due_date) BETWEEN 1 AND 30
             THEN (ci.total_amount - COALESCE(rd.paid_amount, 0))
             ELSE 0 END as days_30,
        CASE WHEN DATEDIFF(p_date, ci.due_date) BETWEEN 31 AND 60
             THEN (ci.total_amount - COALESCE(rd.paid_amount, 0))
             ELSE 0 END as days_60,
        CASE WHEN DATEDIFF(p_date, ci.due_date) BETWEEN 61 AND 90
             THEN (ci.total_amount - COALESCE(rd.paid_amount, 0))
             ELSE 0 END as days_90,
        CASE WHEN DATEDIFF(p_date, ci.due_date) BETWEEN 91 AND 120
             THEN (ci.total_amount - COALESCE(rd.paid_amount, 0))
             ELSE 0 END as days_120,
        CASE WHEN DATEDIFF(p_date, ci.due_date) > 120
             THEN (ci.total_amount - COALESCE(rd.paid_amount, 0))
             ELSE 0 END as days_over_120
    FROM customer_invoices ci
    LEFT JOIN (
        SELECT invoice_id, SUM(amount) as paid_amount
        FROM receipt_distributions
        GROUP BY invoice_id
    ) rd ON ci.invoice_id = rd.invoice_id
    WHERE ci.customer_id = p_customer_id
    AND ci.payment_status != 'paid'
    AND ci.payment_status != 'cancelled';
END //

DELIMITER ;