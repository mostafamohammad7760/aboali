/**
 * مدير العملاء - إدارة العملاء في نظام نقاط البيع
 * @module CustomerManager
 * التاريخ: 2025-05-09 03:01:38
 * المستخدم: mostafamohammad7760
 */

export class CustomerManager {
    constructor(database) {
        this.db = database;
        this.defaultCustomer = {
            id: 'default',
            name: 'عميل نقدي',
            type: 'cash',
            credit_limit: 0,
            balance: 0
        };
    }

    /**
     * البحث عن العملاء
     * @param {string} query - نص البحث
     * @param {Object} options - خيارات البحث
     */
    async searchCustomers(query, options = {}) {
        try {
            const {
                limit = 10,
                offset = 0,
                sortBy = 'name',
                sortOrder = 'ASC',
                filterActive = true
            } = options;

            const searchQuery = `
                SELECT 
                    customer_id,
                    name,
                    phone,
                    email,
                    tax_number,
                    credit_limit,
                    balance,
                    is_active,
                    created_at
                FROM customers
                WHERE (
                    name LIKE ? OR
                    phone LIKE ? OR
                    email LIKE ? OR
                    tax_number LIKE ?
                )
                ${filterActive ? 'AND is_active = 1' : ''}
                ORDER BY ${sortBy} ${sortOrder}
                LIMIT ? OFFSET ?
            `;

            const searchTerm = `%${query}%`;
            const params = [
                searchTerm,
                searchTerm,
                searchTerm,
                searchTerm,
                limit,
                offset
            ];

            const results = await this.db.executeQuery(searchQuery, params);
            return this.processCustomerResults(results);
        } catch (error) {
            console.error('Error searching customers:', error);
            throw new Error('فشل البحث عن العملاء');
        }
    }

    /**
     * معالجة نتائج البحث عن العملاء
     * @param {Array} results - نتائج البحث
     */
    processCustomerResults(results) {
        return results.map(customer => ({
            ...customer,
            formattedBalance: this.formatCurrency(customer.balance),
            creditStatus: this.calculateCreditStatus(customer),
            lastPurchase: customer.last_purchase_date ? 
                new Date(customer.last_purchase_date).toLocaleDateString('ar-SA') : 
                'لا يوجد'
        }));
    }

    /**
     * حساب حالة الائتمان للعميل
     * @param {Object} customer - بيانات العميل
     */
    calculateCreditStatus(customer) {
        const usedCredit = customer.balance;
        const availableCredit = customer.credit_limit - usedCredit;

        return {
            used: usedCredit,
            available: availableCredit,
            percentage: customer.credit_limit > 0 ? 
                (usedCredit / customer.credit_limit) * 100 : 0,
            status: this.getCreditStatusLabel(usedCredit, customer.credit_limit)
        };
    }

    /**
     * الحصول على تصنيف حالة الائتمان
     * @param {number} used - الرصيد المستخدم
     * @param {number} limit - حد الائتمان
     */
    getCreditStatusLabel(used, limit) {
        if (limit === 0) return 'نقدي';
        const percentage = (used / limit) * 100;
        
        if (percentage >= 90) return 'خطر';
        if (percentage >= 75) return 'تحذير';
        if (percentage >= 50) return 'متوسط';
        return 'جيد';
    }

    /**
     * إضافة عميل جديد
     * @param {Object} customerData - بيانات العميل
     */
    async addCustomer(customerData) {
        try {
            const customerId = this.generateCustomerId();
            
            // التحقق من البيانات
            this.validateCustomerData(customerData);

            const query = `
                INSERT INTO customers (
                    customer_id,
                    name,
                    phone,
                    email,
                    tax_number,
                    address,
                    credit_limit,
                    created_by
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            `;

            const params = [
                customerId,
                customerData.name,
                customerData.phone,
                customerData.email,
                customerData.tax_number,
                customerData.address,
                customerData.credit_limit || 0,
                this.currentUser
            ];

            await this.db.executeQuery(query, params);
            return await this.getCustomer(customerId);
        } catch (error) {
            console.error('Error adding customer:', error);
            throw new Error('فشل إضافة العميل');
        }
    }

    /**
     * التحقق من بيانات العميل
     * @param {Object} data - بيانات العميل
     */
    validateCustomerData(data) {
        const errors = [];

        if (!data.name || data.name.trim().length < 3) {
            errors.push('اسم العميل يجب أن يكون أكثر من 3 أحرف');
        }

        if (data.phone && !this.isValidPhone(data.phone)) {
            errors.push('رقم الهاتف غير صحيح');
        }

        if (data.email && !this.isValidEmail(data.email)) {
            errors.push('البريد الإلكتروني غير صحيح');
        }

        if (data.tax_number && !this.isValidTaxNumber(data.tax_number)) {
            errors.push('الرقم الضريبي غير صحيح');
        }

        if (errors.length > 0) {
            throw new Error(errors.join('\n'));
        }
    }

    /**
     * تحديث بيانات العميل
     * @param {string} customerId - معرف العميل
     * @param {Object} updates - التحديثات
     */
    async updateCustomer(customerId, updates) {
        try {
            // التحقق من وجود العميل
            const customer = await this.getCustomer(customerId);
            if (!customer) {
                throw new Error('العميل غير موجود');
            }

            // التحقق من البيانات المحدثة
            this.validateCustomerData(updates);

            const query = `
                UPDATE customers
                SET
                    name = ?,
                    phone = ?,
                    email = ?,
                    tax_number = ?,
                    address = ?,
                    credit_limit = ?,
                    updated_by = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE customer_id = ?
            `;

            const params = [
                updates.name,
                updates.phone,
                updates.email,
                updates.tax_number,
                updates.address,
                updates.credit_limit,
                this.currentUser,
                customerId
            ];

            await this.db.executeQuery(query, params);
            return await this.getCustomer(customerId);
        } catch (error) {
            console.error('Error updating customer:', error);
            throw new Error('فشل تحديث بيانات العميل');
        }
    }

    /**
     * تحديث رصيد العميل
     * @param {string} customerId - معرف العميل
     * @param {number} amount - المبلغ
     * @param {string} type - نوع العملية (credit/debit)
     */
    async updateCustomerBalance(customerId, amount, type) {
        try {
            const customer = await this.getCustomer(customerId);
            if (!customer) {
                throw new Error('العميل غير موجود');
            }

            const newBalance = type === 'credit' ?
                customer.balance + amount :
                customer.balance - amount;

            // التحقق من حد الائتمان
            if (type === 'credit' && newBalance > customer.credit_limit) {
                throw new Error('تجاوز حد الائتمان المسموح');
            }

            const query = `
                UPDATE customers
                SET balance = ?,
                    updated_by = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE customer_id = ?
            `;

            await this.db.executeQuery(query, [newBalance, this.currentUser, customerId]);

            // تسجيل العملية
            await this.logCustomerTransaction(customerId, amount, type);

            return await this.getCustomer(customerId);
        } catch (error) {
            console.error('Error updating customer balance:', error);
            throw new Error('فشل تحديث رصيد العميل');
        }
    }

    /**
     * تنسيق العملة
     * @param {number} amount - المبلغ
     */
    formatCurrency(amount) {
        return new Intl.NumberFormat('ar-SA', {
            style: 'currency',
            currency: 'SAR'
        }).format(amount);
    }

    /**
     * توليد معرف فريد للعميل
     */
    generateCustomerId() {
        return 'CUST-' + Date.now().toString(36).toUpperCase();
    }

    /**
     * التحقق من صحة رقم الهاتف
     */
    isValidPhone(phone) {
        return /^(009665|9665|\+9665|05|5)(5|0|3|6|4|9|1|8|7)([0-9]{7})$/.test(phone);
    }

    /**
     * التحقق من صحة البريد الإلكتروني
     */
    isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    /**
     * التحقق من صحة الرقم الضريبي
     */
    isValidTaxNumber(taxNumber) {
        return /^\d{15}$/.test(taxNumber);
    }
}