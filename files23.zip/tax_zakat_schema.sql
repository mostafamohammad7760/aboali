-- إنشاء جداول الضرائب والزكاة

-- جدول تعريفات الضرائب
CREATE TABLE tax_definitions (
    tax_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    tax_type ENUM('vat', 'income', 'withholding', 'other') NOT NULL,
    rate DECIMAL(5,2) NOT NULL,
    is_compound BOOLEAN DEFAULT FALSE,
    applies_to ENUM('sales', 'purchases', 'both') NOT NULL,
    effective_from DATE NOT NULL,
    effective_to DATE,
    status ENUM('active', 'inactive') DEFAULT 'active',
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50)
);

-- جدول الإقرارات الضريبية
CREATE TABLE tax_returns (
    return_id VARCHAR(20) PRIMARY KEY,
    return_number VARCHAR(20) UNIQUE NOT NULL,
    tax_id VARCHAR(20) NOT NULL,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    filing_due_date DATE NOT NULL,
    filing_date DATE,
    tax_amount DECIMAL(18,2) NOT NULL,
    adjustments_amount DECIMAL(18,2) DEFAULT 0,
    penalties_amount DECIMAL(18,2) DEFAULT 0,
    total_amount DECIMAL(18,2) NOT NULL,
    status ENUM('draft', 'submitted', 'approved', 'rejected', 'amended') DEFAULT 'draft',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (tax_id) REFERENCES tax_definitions(tax_id)
);

-- جدول وعاء الزكاة
CREATE TABLE zakat_base (
    base_id VARCHAR(20) PRIMARY KEY,
    year INT NOT NULL,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    currency_code VARCHAR(3) NOT NULL,
    exchange_rate DECIMAL(18,6) NOT NULL DEFAULT 1,
    
    -- عناصر وعاء الزكاة
    capital DECIMAL(18,2) NOT NULL,
    reserves DECIMAL(18,2) DEFAULT 0,
    retained_earnings DECIMAL(18,2) DEFAULT 0,
    provisions DECIMAL(18,2) DEFAULT 0,
    long_term_loans DECIMAL(18,2) DEFAULT 0,
    net_profit DECIMAL(18,2) DEFAULT 0,
    
    -- الحسومات من وعاء الزكاة
    fixed_assets DECIMAL(18,2) DEFAULT 0,
    investments DECIMAL(18,2) DEFAULT 0,
    accumulated_losses DECIMAL(18,2) DEFAULT 0,
    
    -- النتائج
    zakat_base_amount DECIMAL(18,2) NOT NULL,
    zakat_amount DECIMAL(18,2) NOT NULL,
    
    status ENUM('draft', 'submitted', 'approved', 'rejected', 'amended') DEFAULT 'draft',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (currency_code) REFERENCES currencies(code)
);

-- جدول تعديلات وعاء الزكاة
CREATE TABLE zakat_base_adjustments (
    adjustment_id VARCHAR(20) PRIMARY KEY,
    base_id VARCHAR(20) NOT NULL,
    adjustment_type ENUM('addition', 'deduction') NOT NULL,
    category VARCHAR(100) NOT NULL,
    description TEXT,
    amount DECIMAL(18,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    FOREIGN KEY (base_id) REFERENCES zakat_base(base_id)
);

-- جدول المستندات المؤيدة
CREATE TABLE supporting_documents (
    document_id VARCHAR(20) PRIMARY KEY,
    reference_type ENUM('tax_return', 'zakat_base') NOT NULL,
    reference_id VARCHAR(20) NOT NULL,
    document_type VARCHAR(50) NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(1000) NOT NULL,
    file_size INT NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    uploaded_by VARCHAR(50)
);

-- جدول سجل التغييرات
CREATE TABLE change_log (
    log_id VARCHAR(20) PRIMARY KEY,
    reference_type ENUM('tax_return', 'zakat_base') NOT NULL,
    reference_id VARCHAR(20) NOT NULL,
    change_type VARCHAR(50) NOT NULL,
    old_value TEXT,
    new_value TEXT,
    change_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    changed_by VARCHAR(50)
);

-- إجراءات مخزنة

DELIMITER //

-- إجراء حساب وعاء الزكاة
CREATE PROCEDURE calculate_zakat_base(
    IN p_base_id VARCHAR(20)
)
BEGIN
    DECLARE v_base_amount DECIMAL(18,2);
    DECLARE v_zakat_amount DECIMAL(18,2);
    
    -- حساب إجمالي الإضافات
    SELECT 
        capital + 
        IFNULL(reserves, 0) + 
        IFNULL(retained_earnings, 0) + 
        IFNULL(provisions, 0) + 
        IFNULL(long_term_loans, 0) + 
        IFNULL(net_profit, 0)
    INTO v_base_amount
    FROM zakat_base
    WHERE base_id = p_base_id;
    
    -- طرح الحسومات
    SELECT 
        v_base_amount - (
            IFNULL(fixed_assets, 0) + 
            IFNULL(investments, 0) + 
            IFNULL(accumulated_losses, 0)
        )
    INTO v_base_amount
    FROM zakat_base
    WHERE base_id = p_base_id;
    
    -- إضافة التعديلات
    SELECT 
        v_base_amount + 
        COALESCE(
            (
                SELECT SUM(
                    CASE 
                        WHEN adjustment_type = 'addition' THEN amount
                        ELSE -amount
                    END
                )
                FROM zakat_base_adjustments
                WHERE base_id = p_base_id
            ),
            0
        )
    INTO v_base_amount;
    
    -- حساب مبلغ الزكاة (2.5% من وعاء الزكاة)
    SET v_zakat_amount = v_base_amount * 0.025;
    
    -- تحديث وعاء الزكاة
    UPDATE zakat_base
    SET 
        zakat_base_amount = v_base_amount,
        zakat_amount = v_zakat_amount,
        updated_at = CURRENT_TIMESTAMP,
        updated_by = 'mostafamohammad7760'
    WHERE base_id = p_base_id;
END //

-- إجراء إنشاء إقرار ضريبي
CREATE PROCEDURE create_tax_return(
    IN p_tax_id VARCHAR(20),
    IN p_period_start DATE,
    IN p_period_end DATE
)
BEGIN
    DECLARE v_return_number VARCHAR(20);
    
    -- توليد رقم الإقرار
    SELECT CONCAT('TAX-', LPAD(COALESCE(MAX(SUBSTRING(return_number, 5)) + 1, 1), 6, '0'))
    INTO v_return_number
    FROM tax_returns;
    
    -- إدراج الإقرار
    INSERT INTO tax_returns (
        return_id,
        return_number,
        tax_id,
        period_start,
        period_end,
        filing_due_date,
        created_by
    )
    VALUES (
        UUID(),
        v_return_number,
        p_tax_id,
        p_period_start,
        p_period_end,
        DATE_ADD(p_period_end, INTERVAL 1 MONTH), -- تاريخ استحقاق التقديم بعد شهر من نهاية الفترة
        'mostafamohammad7760'
    );
END //

DELIMITER ;

-- المؤشرات
CREATE INDEX idx_tax_definitions_type ON tax_definitions(tax_type);
CREATE INDEX idx_tax_definitions_status ON tax_definitions(status);
CREATE INDEX idx_tax_returns_dates ON tax_returns(period_start, period_end);
CREATE INDEX idx_tax_returns_status ON tax_returns(status);
CREATE INDEX idx_zakat_base_year ON zakat_base(year);
CREATE INDEX idx_zakat_base_status ON zakat_base(status);
CREATE INDEX idx_supporting_documents_ref ON supporting_documents(reference_type, reference_id);
CREATE INDEX idx_change_log_ref ON change_log(reference_type, reference_id);