/**
 * مدير برنامج الولاء - إدارة نقاط العملاء والمكافآت في نظام نقاط البيع
 * @module LoyaltyManager
 * التاريخ: 2025-05-09 03:13:07
 * المستخدم: mostafamohammad7760
 */

export class LoyaltyManager {
    constructor(database) {
        this.db = database;
        
        // معدلات كسب النقاط
        this.pointsRate = {
            DEFAULT: 1, // نقطة لكل ريال
            SILVER: 1.5,
            GOLD: 2,
            PLATINUM: 3
        };

        // مستويات العضوية
        this.membershipLevels = {
            BASIC: {
                name: 'عضوية أساسية',
                minPoints: 0,
                discount: 0
            },
            SILVER: {
                name: 'عضوية فضية',
                minPoints: 1000,
                discount: 5
            },
            GOLD: {
                name: 'عضوية ذهبية',
                minPoints: 5000,
                discount: 10
            },
            PLATINUM: {
                name: 'عضوية بلاتينية',
                minPoints: 10000,
                discount: 15
            }
        };

        // أنواع المكافآت
        this.rewardTypes = {
            POINTS: 'points',
            DISCOUNT: 'discount',
            FREE_PRODUCT: 'free_product',
            VOUCHER: 'voucher'
        };
    }

    /**
     * حساب النقاط لعملية شراء
     * @param {Object} sale - بيانات عملية البيع
     * @param {Object} customer - بيانات العميل
     */
    async calculatePoints(sale, customer) {
        try {
            const membershipLevel = await this.getMembershipLevel(customer.customer_id);
            const pointsRate = this.pointsRate[membershipLevel] || this.pointsRate.DEFAULT;

            // حساب النقاط الأساسية
            let basePoints = Math.floor(sale.totals.subtotal * pointsRate);

            // نقاط إضافية للمنتجات المميزة
            const bonusPoints = await this.calculateBonusPoints(sale.items);

            // نقاط إضافية للمناسبات الخاصة
            const specialPoints = await this.calculateSpecialPoints(sale, customer);

            const totalPoints = basePoints + bonusPoints + specialPoints;

            return {
                basePoints,
                bonusPoints,
                specialPoints,
                totalPoints,
                membershipLevel,
                pointsRate
            };
        } catch (error) {
            console.error('Error calculating points:', error);
            throw new Error('فشل حساب النقاط');
        }
    }

    /**
     * حساب النقاط الإضافية للمنتجات
     * @param {Array} items - قائمة المنتجات
     */
    async calculateBonusPoints(items) {
        let bonusPoints = 0;

        for (const item of items) {
            const product = await this.getProduct(item.product_id);
            if (product.bonus_points) {
                bonusPoints += product.bonus_points * item.quantity;
            }
        }

        return bonusPoints;
    }

    /**
     * حساب النقاط الإضافية للمناسبات الخاصة
     * @param {Object} sale - بيانات عملية البيع
     * @param {Object} customer - بيانات العميل
     */
    async calculateSpecialPoints(sale, customer) {
        let specialPoints = 0;

        // نقاط عيد الميلاد
        if (await this.isBirthday(customer)) {
            specialPoints += Math.floor(sale.totals.subtotal * 0.5);
        }

        // نقاط المناسبات الموسمية
        const seasonalBonus = await this.getSeasonalBonus();
        if (seasonalBonus) {
            specialPoints += Math.floor(sale.totals.subtotal * seasonalBonus.rate);
        }

        return specialPoints;
    }

    /**
     * إضافة نقاط لحساب العميل
     * @param {string} customerId - معرف العميل
     * @param {number} points - عدد النقاط
     * @param {string} source - مصدر النقاط
     */
    async addPoints(customerId, points, source) {
        try {
            await this.db.beginTransaction();

            // تحديث رصيد النقاط
            await this.updateCustomerPoints(customerId, points, 'add');

            // تسجيل عملية إضافة النقاط
            await this.logPointsTransaction({
                customer_id: customerId,
                points,
                type: 'credit',
                source,
                balance: await this.getCustomerPoints(customerId)
            });

            // التحقق من ترقية مستوى العضوية
            await this.checkMembershipUpgrade(customerId);

            await this.db.commit();
        } catch (error) {
            await this.db.rollback();
            console.error('Error adding points:', error);
            throw new Error('فشل إضافة النقاط');
        }
    }

    /**
     * خصم نقاط من حساب العميل
     * @param {string} customerId - معرف العميل
     * @param {number} points - عدد النقاط
     * @param {string} reason - سبب الخصم
     */
    async deductPoints(customerId, points, reason) {
        try {
            const currentPoints = await this.getCustomerPoints(customerId);
            if (currentPoints < points) {
                throw new Error('رصيد النقاط غير كافٍ');
            }

            await this.db.beginTransaction();

            // تحديث رصيد النقاط
            await this.updateCustomerPoints(customerId, points, 'deduct');

            // تسجيل عملية خصم النقاط
            await this.logPointsTransaction({
                customer_id: customerId,
                points,
                type: 'debit',
                source: reason,
                balance: currentPoints - points
            });

            // التحقق من تخفيض مستوى العضوية
            await this.checkMembershipDowngrade(customerId);

            await this.db.commit();
        } catch (error) {
            await this.db.rollback();
            console.error('Error deducting points:', error);
            throw new Error('فشل خصم النقاط');
        }
    }

    /**
     * التحقق من ترقية مستوى العضوية
     * @param {string} customerId - معرف العميل
     */
    async checkMembershipUpgrade(customerId) {
        const totalPoints = await this.getCustomerPoints(customerId);
        let newLevel = null;

        // تحديد المستوى الجديد
        for (const [level, details] of Object.entries(this.membershipLevels)) {
            if (totalPoints >= details.minPoints) {
                newLevel = level;
            }
        }

        if (newLevel) {
            const currentLevel = await this.getMembershipLevel(customerId);
            if (newLevel !== currentLevel) {
                await this.updateMembershipLevel(customerId, newLevel);
                await this.notifyMembershipUpgrade(customerId, newLevel);
            }
        }
    }

    /**
     * استبدال النقاط بمكافأة
     * @param {string} customerId - معرف العميل
     * @param {Object} reward - بيانات المكافأة
     */
    async redeemPoints(customerId, reward) {
        try {
            // التحقق من صلاحية المكافأة
            await this.validateReward(reward);

            // التحقق من رصيد النقاط
            const currentPoints = await this.getCustomerPoints(customerId);
            if (currentPoints < reward.points_required) {
                throw new Error('رصيد النقاط غير كافٍ');
            }

            await this.db.beginTransaction();

            // خصم النقاط
            await this.deductPoints(
                customerId,
                reward.points_required,
                `استبدال: ${reward.name}`
            );

            // إنشاء المكافأة
            const redemption = await this.createRedemption(customerId, reward);

            // إرسال المكافأة للعميل
            await this.deliverReward(redemption);

            await this.db.commit();

            return redemption;
        } catch (error) {
            await this.db.rollback();
            console.error('Error redeeming points:', error);
            throw new Error('فشل استبدال النقاط');
        }
    }

    /**
     * إنشاء مكافأة
     * @param {string} customerId - معرف العميل
     * @param {Object} reward - بيانات المكافأة
     */
    async createRedemption(customerId, reward) {
        const redemptionId = this.generateRedemptionId();
        
        await this.db.executeQuery(`
            INSERT INTO reward_redemptions (
                redemption_id,
                customer_id,
                reward_id,
                points_used,
                status,
                expiry_date,
                created_by
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
        `, [
            redemptionId,
            customerId,
            reward.reward_id,
            reward.points_required,
            'active',
            this.calculateExpiryDate(reward),
            this.currentUser
        ]);

        return {
            redemption_id: redemptionId,
            ...reward,
            customer_id: customerId,
            created_at: new Date()
        };
    }

    /**
     * توليد معرف فريد للاستبدال
     */
    generateRedemptionId() {
        return 'RDM-' + Date.now().toString(36).toUpperCase();
    }

    /**
     * حساب تاريخ انتهاء المكافأة
     * @param {Object} reward - بيانات المكافأة
     */
    calculateExpiryDate(reward) {
        const date = new Date();
        date.setDate(date.getDate() + (reward.validity_days || 30));
        return date;
    }
}