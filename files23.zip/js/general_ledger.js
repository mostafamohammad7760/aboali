import { AccountingAPI } from './api.js';

class GeneralLedger {
    constructor() {
        this.api = new AccountingAPI();
        this.currentUser = 'mostafamohammad7760';
        this.initializeComponents();
        this.attachEventListeners();
        this.loadInitialData();
    }

    initializeComponents() {
        // عناصر شجرة الحسابات
        this.accountTreeView = document.getElementById('accountTreeView');
        this.accountSearch = document.getElementById('accountSearch');
        this.accountTypeFilter = document.getElementById('accountTypeFilter');

        // عناصر نموذج القيد
        this.journalEntryForm = document.getElementById('journalEntryForm');
        this.entryDetailsTable = document.getElementById('entryDetailsTable');
        this.entryLineTemplate = document.getElementById('entryLineTemplate');

        // أزرار التحكم
        this.addAccountBtn = document.getElementById('addAccountBtn');
        this.newEntryBtn = document.getElementById('newEntryBtn');
        this.addLineBtn = document.getElementById('addLineBtn');
        
        this.updateDateTime();
        setInterval(() => this.updateDateTime(), 1000);
    }

    attachEventListeners() {
        // مستمعات شجرة الحسابات
        this.accountSearch.addEventListener('input', () => this.filterAccounts());
        this.accountTypeFilter.addEventListener('change', () => this.filterAccounts());
        this.addAccountBtn.addEventListener('click', () => this.showAddAccountModal());

        // مستمعات القيود
        this.journalEntryForm.addEventListener('submit', (e) => this.handleEntrySubmit(e));
        this.addLineBtn.addEventListener('click', () => this.addEntryLine());
        this.newEntryBtn.addEventListener('click', () => this.showNewEntryForm());

        // مستمعات الجدول
        this.entryDetailsTable.addEventListener('input', (e) => {
            if (e.target.classList.contains('debit-amount') || 
                e.target.classList.contains('credit-amount')) {
                this.updateTotals();
            }
        });
    }

    async loadInitialData() {
        try {
            // تحميل شجرة الحسابات
            const accounts = await this.api.getAccountTree();
            this.renderAccountTree(accounts);

            // تحميل مراكز التكلفة
            const costCenters = await this.api.getCostCenters();
            this.populateCostCenters(costCenters);

            // تحميل آخر رقم قيد
            const lastEntryNumber = await this.api.getLastEntryNumber();
            this.setNextEntryNumber(lastEntryNumber);
        } catch (error) {
            this.showError('خطأ في تحميل البيانات الأولية');
            console.error(error);
        }
    }

    updateDateTime() {
        const now = new Date();
        document.getElementById('currentDateTime').textContent = 
            now.toISOString().replace('T', ' ').slice(0, 19);
    }

    renderAccountTree(accounts) {
        this.accountTreeView.innerHTML = '';
        const tree = this.buildTreeStructure(accounts);
        this.accountTreeView.appendChild(this.createTreeNodes(tree));
    }

    buildTreeStructure(accounts) {
        const tree = {};
        accounts.forEach(account => {
            if (!account.parent_id) {
                tree[account.account_id] = { ...account, children: {} };
            } else {
                let parent = this.findParentNode(tree, account.parent_id);
                if (parent) {
                    parent.children[account.account_id] = { ...account, children: {} };
                }
            }
        });
        return tree;
    }

    createTreeNodes(tree) {
        const ul = document.createElement('ul');
        ul.className = 'account-tree';

        Object.values(tree).forEach(account => {
            const li = document.createElement('li');
            
            const accountInfo = document.createElement('div');
            accountInfo.className = 'account-info';
            accountInfo.innerHTML = `
                <span class="account-id">${account.account_id}</span>
                <span class="account-name">${account.account_name_ar}</span>
                <span class="account-type">${this.translateAccountType(account.account_type)}</span>
            `;

            li.appendChild(accountInfo);

            if (Object.keys(account.children).length > 0) {
                li.appendChild(this.createTreeNodes(account.children));
            }

            ul.appendChild(li);
        });

        return ul;
    }

    translateAccountType(type) {
        const types = {
            asset: 'أصول',
            liability: 'التزامات',
            equity: 'حقوق ملكية',
            revenue: 'إيرادات',
            expense: 'مصروفات'
        };
        return types[type] || type;
    }

    addEntryLine() {
        const tbody = this.entryDetailsTable.querySelector('tbody');
        const clone = this.entryLineTemplate.content.cloneNode(true);
        
        // إضافة مستمعات الأحداث للسطر الجديد
        const removeBtn = clone.querySelector('.remove-line');
        removeBtn.addEventListener('click', (e) => {
            e.target.closest('tr').remove();
            this.updateTotals();
        });

        tbody.appendChild(clone);
        this.updateTotals();
    }

    updateTotals() {
        let totalDebit = 0;
        let totalCredit = 0;

        const rows = this.entryDetailsTable.querySelector('tbody').rows;
        for (let row of rows) {
            totalDebit += Number(row.querySelector('.debit-amount').value) || 0;
            totalCredit += Number(row.querySelector('.credit-amount').value) || 0;
        }

        document.getElementById('totalDebit').textContent = totalDebit.toFixed(2);
        document.getElementById('totalCredit').textContent = totalCredit.toFixed(2);

        // التحقق من توازن القيد
        const isBalanced = Math.abs(totalDebit - totalCredit) < 0.01;
        this.journalEntryForm.querySelector('button[type="submit"]').disabled = !isBalanced;
    }

    async handleEntrySubmit(e) {
        e.preventDefault();
        
        try {
            const entryData = this.collectEntryData();
            if (!this.validateEntryData(entryData)) {
                return;
            }

            const response = await this.api.createJournalEntry(entryData);
            if (response.success) {
                this.showSuccess('تم حفظ القيد بنجاح');
                this.resetEntryForm();
            } else {
                this.showError(response.message);
            }
        } catch (error) {
            this.showError('حدث خطأ أثناء حفظ القيد');
            console.error(error);
        }
    }

    collectEntryData() {
        const rows = this.entryDetailsTable.querySelector('tbody').rows;
        const details = [];

        for (let row of rows) {
            details.push({
                account_id: row.querySelector('.account-select').value,
                cost_center_id: row.querySelector('.cost-center-select').value,
                debit_amount: Number(row.querySelector('.debit-amount').value) || 0,
                credit_amount: Number(row.querySelector('.credit-amount').value) || 0,
                description: row.querySelector('.line-description').value
            });
        }

        return {
            entry_date: document.getElementById('entryDate').value,
            description: document.getElementById('entryDescription').value,
            details: details
        };
    }

    validateEntryData(data) {
        if (!data.entry_date) {
            this.showError('يرجى تحديد تاريخ القيد');
            return false;
        }

        if (!data.details.length) {
            this.showError('يجب إضافة تفاصيل القيد');
            return false;
        }

        const totalDebit = data.details.reduce((sum, detail) => sum + detail.debit_amount, 0);
        const totalCredit = data.details.reduce((sum, detail) => sum + detail.credit_amount, 0);

        if (Math.abs(totalDebit - totalCredit) >= 0.01) {
            this.showError('القيد غير متوازن');
            return false;
        }

        return true;
    }

    showError(message) {
        // تنفيذ عرض رسالة الخطأ
        alert(message); // يمكن استبدالها بطريقة عرض أفضل
    }

    showSuccess(message) {
        // تنفيذ عرض رسالة النجاح
        alert(message); // يمكن استبدالها بطريقة عرض أفضل
    }
}

// تهيئة التطبيق
document.addEventListener('DOMContentLoaded', () => {
    new GeneralLedger();
});