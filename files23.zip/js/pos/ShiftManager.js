/**
 * مدير الورديات - إدارة الورديات والخزينة في نظام نقاط البيع
 * @module ShiftManager
 * التاريخ: 2025-05-09 03:07:35
 * المستخدم: mostafamohammad7760
 */

export class ShiftManager {
    constructor(database) {
        this.db = database;
        this.currentShift = null;
        
        // أنواع العمليات النقدية
        this.cashOperationTypes = {
            CASH_IN: 'cash_in',
            CASH_OUT: 'cash_out',
            SALE: 'sale',
            RETURN: 'return',
            EXPENSE: 'expense'
        };
    }

    /**
     * بدء وردية جديدة
     * @param {Object} shiftData - بيانات الوردية
     */
    async startShift(shiftData) {
        try {
            // التحقق من عدم وجود وردية مفتوحة
            const activeShift = await this.getActiveShift();
            if (activeShift) {
                throw new Error('يوجد وردية مفتوحة بالفعل');
            }

            // التحقق من البيانات
            this.validateShiftData(shiftData);

            const shiftId = this.generateShiftId();
            
            // إنشاء الوردية
            const query = `
                INSERT INTO shifts (
                    shift_id,
                    cashier_id,
                    register_id,
                    opening_amount,
                    opening_note,
                    created_by
                ) VALUES (?, ?, ?, ?, ?, ?)
            `;

            await this.db.executeQuery(query, [
                shiftId,
                shiftData.cashier_id,
                shiftData.register_id,
                shiftData.opening_amount,
                shiftData.opening_note,
                this.currentUser
            ]);

            // تسجيل عملية الافتتاح
            await this.logCashOperation({
                shift_id: shiftId,
                type: this.cashOperationTypes.CASH_IN,
                amount: shiftData.opening_amount,
                notes: 'رصيد افتتاح الوردية'
            });

            this.currentShift = await this.getShift(shiftId);
            return this.currentShift;
        } catch (error) {
            console.error('Error starting shift:', error);
            throw new Error('فشل بدء الوردية');
        }
    }

    /**
     * إغلاق الوردية الحالية
     * @param {Object} closeData - بيانات الإغلاق
     */
    async closeShift(closeData) {
        try {
            // التحقق من وجود وردية مفتوحة
            const activeShift = await this.getActiveShift();
            if (!activeShift) {
                throw new Error('لا يوجد وردية مفتوحة');
            }

            // حساب الإجماليات
            const totals = await this.calculateShiftTotals(activeShift.shift_id);
            
            // التحقق من الفرق
            const difference = closeData.counted_amount - totals.expected_amount;

            // تحديث بيانات الإغلاق
            const query = `
                UPDATE shifts 
                SET 
                    closing_amount = ?,
                    counted_amount = ?,
                    difference_amount = ?,
                    closing_note = ?,
                    closed_by = ?,
                    closed_at = CURRENT_TIMESTAMP,
                    status = 'closed'
                WHERE shift_id = ?
            `;

            await this.db.executeQuery(query, [
                totals.expected_amount,
                closeData.counted_amount,
                difference,
                closeData.closing_note,
                this.currentUser,
                activeShift.shift_id
            ]);

            // تسجيل عملية الإغلاق
            await this.logCashOperation({
                shift_id: activeShift.shift_id,
                type: this.cashOperationTypes.CASH_OUT,
                amount: closeData.counted_amount,
                notes: 'رصيد إغلاق الوردية'
            });

            // إنشاء تقرير الإغلاق
            const closeReport = {
                ...totals,
                counted_amount: closeData.counted_amount,
                difference_amount: difference,
                closing_note: closeData.closing_note
            };

            this.currentShift = null;
            return closeReport;
        } catch (error) {
            console.error('Error closing shift:', error);
            throw new Error('فشل إغلاق الوردية');
        }
    }

    /**
     * حساب إجماليات الوردية
     * @param {string} shiftId - معرف الوردية
     */
    async calculateShiftTotals(shiftId) {
        // جلب جميع العمليات النقدية في الوردية
        const operations = await this.db.executeQuery(`
            SELECT 
                type,
                amount,
                payment_method
            FROM cash_operations
            WHERE shift_id = ?
            ORDER BY created_at
        `, [shiftId]);

        const totals = {
            opening_amount: 0,
            cash_sales: 0,
            card_sales: 0,
            returns: 0,
            expenses: 0,
            cash_in: 0,
            cash_out: 0,
            expected_amount: 0,
            total_transactions: operations.length
        };

        // حساب الإجماليات حسب نوع العملية
        for (const op of operations) {
            switch (op.type) {
                case this.cashOperationTypes.CASH_IN:
                    if (!totals.opening_amount) {
                        totals.opening_amount = op.amount;
                    } else {
                        totals.cash_in += op.amount;
                    }
                    break;

                case this.cashOperationTypes.CASH_OUT:
                    totals.cash_out += op.amount;
                    break;

                case this.cashOperationTypes.SALE:
                    if (op.payment_method === 'cash') {
                        totals.cash_sales += op.amount;
                    } else if (op.payment_method === 'card') {
                        totals.card_sales += op.amount;
                    }
                    break;

                case this.cashOperationTypes.RETURN:
                    totals.returns += op.amount;
                    break;

                case this.cashOperationTypes.EXPENSE:
                    totals.expenses += op.amount;
                    break;
            }
        }

        // حساب الرصيد المتوقع
        totals.expected_amount = totals.opening_amount +
            totals.cash_sales +
            totals.cash_in -
            totals.returns -
            totals.expenses -
            totals.cash_out;

        return totals;
    }

    /**
     * تسجيل عملية نقدية
     * @param {Object} operation - بيانات العملية
     */
    async logCashOperation(operation) {
        const query = `
            INSERT INTO cash_operations (
                operation_id,
                shift_id,
                type,
                amount,
                payment_method,
                reference_id,
                notes,
                created_by
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `;

        await this.db.executeQuery(query, [
            this.generateOperationId(),
            operation.shift_id,
            operation.type,
            operation.amount,
            operation.payment_method || 'cash',
            operation.reference_id || null,
            operation.notes,
            this.currentUser
        ]);
    }

    /**
     * التحقق من صحة بيانات الوردية
     * @param {Object} data - بيانات الوردية
     */
    validateShiftData(data) {
        const errors = [];

        if (!data.cashier_id) {
            errors.push('معرف الكاشير مطلوب');
        }

        if (!data.register_id) {
            errors.push('معرف الخزينة مطلوب');
        }

        if (typeof data.opening_amount !== 'number' || data.opening_amount < 0) {
            errors.push('الرصيد الافتتاحي يجب أن يكون رقماً موجباً');
        }

        if (errors.length > 0) {
            throw new Error(errors.join('\n'));
        }
    }

    /**
     * الحصول على الوردية النشطة
     */
    async getActiveShift() {
        const [shift] = await this.db.executeQuery(`
            SELECT 
                s.*,
                u1.username as cashier_name,
                u2.username as created_by_name
            FROM shifts s
            JOIN users u1 ON s.cashier_id = u1.user_id
            JOIN users u2 ON s.created_by = u2.user_id
            WHERE s.status = 'active'
            LIMIT 1
        `);

        return shift;
    }

    /**
     * توليد معرف فريد للوردية
     */
    generateShiftId() {
        return 'SHF-' + Date.now().toString(36).toUpperCase();
    }

    /**
     * توليد معرف فريد للعملية
     */
    generateOperationId() {
        return 'OPS-' + Date.now().toString(36).toUpperCase();
    }
}