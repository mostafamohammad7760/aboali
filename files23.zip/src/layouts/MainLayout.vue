<!-- تحديث التعليق -->
/**
 * الواجهة الرئيسية للنظام المحاسبي الشامل مع نظام نقاط البيع
 * التاريخ: 2025-05-09 04:09:05 
 * المستخدم: mostafamohammad7760
 */

<!-- نفس التمبلت السابق مع إضافة قسم نقاط البيع في القائمة الجانبية -->
<template>
  <!-- ... الكود السابق ... -->

  <!-- تحديث القائمة الجانبية لتشمل نقاط البيع -->
  <aside class="main-sidebar">
    <nav class="sidebar-nav">
      <div class="nav-section">
        <div class="section-title">العمليات السريعة</div>
        <ul class="nav-items">
          <!-- نقاط البيع -->
          <li class="nav-item">
            <router-link to="/pos" class="nav-link featured-link">
              <i class="fas fa-cash-register"></i>
              <span>نقاط البيع</span>
            </router-link>
          </li>
        </ul>
      </div>

      <!-- الوحدات الرئيسية -->
      <div class="nav-section">
        <div class="section-title">الوحدات الرئيسية</div>
        <ul class="nav-items">
          <!-- لوحة التحكم -->
          <li class="nav-item">
            <router-link to="/dashboard" class="nav-link">
              <i class="fas fa-tachometer-alt"></i>
              <span>لوحة التحكم</span>
            </router-link>
          </li>

          <!-- نقاط البيع - القائمة الفرعية -->
          <li class="nav-item has-submenu">
            <button class="nav-link" @click="toggleSubmenu('pos')">
              <i class="fas fa-cash-register"></i>
              <span>نقاط البيع</span>
              <i class="fas fa-chevron-down submenu-arrow"></i>
            </button>
            <ul class="submenu" v-show="openSubmenus.includes('pos')">
              <li>
                <router-link to="/pos/new-sale">عملية بيع جديدة</router-link>
              </li>
              <li>
                <router-link to="/pos/transactions">سجل المعاملات</router-link>
              </li>
              <li>
                <router-link to="/pos/shifts">إدارة الورديات</router-link>
              </li>
              <li>
                <router-link to="/pos/cash-drawer">درج النقدية</router-link>
              </li>
              <li>
                <router-link to="/pos/discounts">إدارة الخصومات</router-link>
              </li>
              <li>
                <router-link to="/pos/loyalty">نقاط الولاء</router-link>
              </li>
            </ul>
          </li>

          <!-- باقي الوحدات كما هي -->
          <!-- ... -->
        </ul>
      </div>

      <!-- إضافة قسم جديد للتقارير السريعة -->
      <div class="nav-section">
        <div class="section-title">التقارير السريعة</div>
        <ul class="nav-items">
          <li class="nav-item">
            <router-link to="/quick-reports/daily-sales" class="nav-link">
              <i class="fas fa-chart-line"></i>
              <span>مبيعات اليوم</span>
            </router-link>
          </li>
          <li class="nav-item">
            <router-link to="/quick-reports/inventory-alerts" class="nav-link">
              <i class="fas fa-exclamation-triangle"></i>
              <span>تنبيهات المخزون</span>
            </router-link>
          </li>
        </ul>
      </div>
    </nav>
  </aside>

  <!-- تحديث المحتوى الرئيسي -->
  <main class="main-content">
    <!-- شريط التنبيهات السريعة -->
    <div v-if="hasAlerts" class="quick-alerts">
      <div v-if="lowStockAlert" class="alert warning">
        <i class="fas fa-exclamation-triangle"></i>
        يوجد {{ lowStockCount }} صنف تحت حد الطلب
      </div>
      <div v-if="pendingOrdersAlert" class="alert info">
        <i class="fas fa-clock"></i>
        يوجد {{ pendingOrdersCount }} طلب معلق
      </div>
    </div>

    <!-- باقي المحتوى كما هو -->
    <!-- ... -->
  </main>
</template>

<script lang="ts">
import { defineComponent, ref, computed } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useStore } from 'vuex';

export default defineComponent({
  name: 'MainLayout',

  setup() {
    const store = useStore();
    const route = useRoute();
    const router = useRouter();

    // إضافة حالة التنبيهات
    const hasAlerts = computed(() => lowStockAlert.value || pendingOrdersAlert.value);
    const lowStockAlert = computed(() => store.state.inventory.lowStockCount > 0);
    const lowStockCount = computed(() => store.state.inventory.lowStockCount);
    const pendingOrdersAlert = computed(() => store.state.sales.pendingOrdersCount > 0);
    const pendingOrdersCount = computed(() => store.state.sales.pendingOrdersCount);

    // التحقق من صلاحيات المستخدم
    const userPermissions = computed(() => store.state.auth.permissions);
    const canAccessPOS = computed(() => userPermissions.value.includes('pos.access'));

    // الوردية الحالية
    const currentShift = computed(() => store.state.pos.currentShift);

    // باقي الكود كما هو
    // ...

    return {
      // إضافة المتغيرات الجديدة
      hasAlerts,
      lowStockAlert,
      lowStockCount,
      pendingOrdersAlert,
      pendingOrdersCount,
      canAccessPOS,
      currentShift,
      // باقي المتغيرات كما هي
      // ...
    };
  }
});
</script>

<style lang="scss">
// إضافة تنسيقات جديدة

// تنسيق رابط نقاط البيع المميز
.featured-link {
  background: var(--primary-color);
  color: var(--primary-contrast) !important;
  border-radius: var(--border-radius);
  margin: 0 1rem;
  
  &:hover {
    background: var(--primary-dark) !important;
  }

  i {
    color: var(--primary-contrast) !important;
  }
}

// تنسيق التنبيهات السريعة
.quick-alerts {
  margin-bottom: 1.5rem;

  .alert {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 1rem;
    border-radius: var(--border-radius);
    margin-bottom: 0.5rem;

    i {
      font-size: 1.25rem;
    }

    &.warning {
      background: #fff3e0;
      color: #e65100;
    }

    &.info {
      background: #e3f2fd;
      color: #0d47a1;
    }
  }
}

// تحديث تنسيق القائمة الجانبية لتمييز قسم نقاط البيع
.nav-section {
  &:first-child {
    .nav-items {
      padding: 0.5rem 0;
    }
  }
}

// باقي التنسيقات كما هي
// ...
</style>