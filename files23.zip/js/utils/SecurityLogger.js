/**
 * مسجل الأحداث الأمنية
 * @module SecurityLogger
 * التاريخ: 2025-05-09 02:44:42
 * المستخدم: mostafamohammad7760
 */

export class SecurityLogger {
    constructor() {
        this.baseUrl = '/api/v1/security/logs';
        this.logQueue = [];
        this.batchSize = 50;
        this.flushInterval = 5000; // 5 ثوان
        this.currentUser = 'mostafamohammad7760';

        // بدء دورة تفريغ السجلات
        this.startFlushCycle();
    }

    /**
     * أنواع الأحداث الأمنية
     */
    static EVENT_TYPES = {
        AUTH: {
            LOGIN_SUCCESS: 'auth.login.success',
            LOGIN_FAILURE: 'auth.login.failure',
            LOGOUT: 'auth.logout',
            PASSWORD_CHANGE: 'auth.password.change',
            PASSWORD_RESET: 'auth.password.reset',
            MFA_ENABLED: 'auth.mfa.enabled',
            MFA_DISABLED: 'auth.mfa.disabled',
            MFA_CHALLENGE: 'auth.mfa.challenge'
        },
        ACCESS: {
            PERMISSION_DENIED: 'access.permission.denied',
            RESOURCE_ACCESS: 'access.resource.attempt',
            SUSPICIOUS_ACTIVITY: 'access.suspicious',
            IP_BLOCKED: 'access.ip.blocked'
        },
        USER: {
            CREATED: 'user.created',
            MODIFIED: 'user.modified',
            DELETED: 'user.deleted',
            ROLE_CHANGED: 'user.role.changed',
            STATUS_CHANGED: 'user.status.changed'
        },
        SYSTEM: {
            CONFIG_CHANGED: 'system.config.changed',
            BACKUP_CREATED: 'system.backup.created',
            BACKUP_RESTORED: 'system.backup.restored',
            ERROR: 'system.error'
        }
    };

    /**
     * مستويات الخطورة
     */
    static SEVERITY_LEVELS = {
        INFO: 'info',
        WARNING: 'warning',
        ERROR: 'error',
        CRITICAL: 'critical'
    };

    /**
     * تسجيل حدث أمني
     * @param {string} eventType - نوع الحدث
     * @param {Object} data - بيانات الحدث
     * @param {string} severity - مستوى الخطورة
     */
    async logSecurityEvent(eventType, data, severity = SecurityLogger.SEVERITY_LEVELS.INFO) {
        const logEntry = {
            eventId: this.generateEventId(),
            timestamp: new Date().toISOString(),
            eventType,
            severity,
            user: this.currentUser,
            data,
            metadata: {
                userAgent: navigator.userAgent,
                ipAddress: await this.getClientIP(),
                platform: navigator.platform,
                location: window.location.href
            }
        };

        this.logQueue.push(logEntry);

        // إذا وصل حجم القائمة للحد الأقصى، نقوم بتفريغها
        if (this.logQueue.length >= this.batchSize) {
            this.flushLogs();
        }

        // تنبيه فوري للأحداث الحرجة
        if (severity === SecurityLogger.SEVERITY_LEVELS.CRITICAL) {
            this.alertCriticalEvent(logEntry);
        }

        return logEntry;
    }

    /**
     * تفريغ السجلات المخزنة مؤقتاً
     */
    async flushLogs() {
        if (this.logQueue.length === 0) return;

        const logsToSend = [...this.logQueue];
        this.logQueue = [];

        try {
            await fetch(this.baseUrl + '/batch', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-User-Id': this.currentUser,
                    'X-Timestamp': new Date().toISOString()
                },
                body: JSON.stringify({
                    logs: logsToSend,
                    metadata: {
                        batchId: this.generateBatchId(),
                        timestamp: new Date().toISOString()
                    }
                })
            });
        } catch (error) {
            console.error('Error flushing security logs:', error);
            // إعادة السجلات إلى القائمة في حالة الفشل
            this.logQueue = [...logsToSend, ...this.logQueue];
        }
    }

    /**
     * بدء دورة تفريغ السجلات
     */
    startFlushCycle() {
        setInterval(() => {
            this.flushLogs();
        }, this.flushInterval);
    }

    /**
     * تنبيه للأحداث الحرجة
     * @param {Object} logEntry - بيانات الحدث
     */
    async alertCriticalEvent(logEntry) {
        try {
            await fetch(this.baseUrl + '/alert', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Priority': 'high'
                },
                body: JSON.stringify({
                    alert: {
                        type: 'CRITICAL_SECURITY_EVENT',
                        eventData: logEntry,
                        timestamp: new Date().toISOString()
                    }
                })
            });
        } catch (error) {
            console.error('Error sending critical alert:', error);
        }
    }

    /**
     * تسجيل محاولة تسجيل الدخول
     * @param {Object} data - بيانات محاولة تسجيل الدخول
     */
    async logLoginAttempt(data) {
        const eventType = data.success ? 
            SecurityLogger.EVENT_TYPES.AUTH.LOGIN_SUCCESS : 
            SecurityLogger.EVENT_TYPES.AUTH.LOGIN_FAILURE;

        const severity = data.success ? 
            SecurityLogger.SEVERITY_LEVELS.INFO : 
            SecurityLogger.SEVERITY_LEVELS.WARNING;

        await this.logSecurityEvent(eventType, {
            username: data.username,
            success: data.success,
            failureReason: data.failureReason,
            attemptNumber: data.attemptNumber
        }, severity);
    }

    /**
     * تسجيل تغيير في الصلاحيات
     * @param {Object} data - بيانات تغيير الصلاحيات
     */
    async logPermissionChange(data) {
        await this.logSecurityEvent(SecurityLogger.EVENT_TYPES.USER.ROLE_CHANGED, {
            userId: data.userId,
            oldRoles: data.oldRoles,
            newRoles: data.newRoles,
            changedBy: data.changedBy
        }, SecurityLogger.SEVERITY_LEVELS.WARNING);
    }

    /**
     * الحصول على عنوان IP العميل
     * @returns {Promise<string>} عنوان IP
     */
    async getClientIP() {
        try {
            const response = await fetch('https://api.ipify.org?format=json');
            const data = await response.json();
            return data.ip;
        } catch (error) {
            return 'unknown';
        }
    }

    /**
     * توليد معرف فريد للحدث
     * @returns {string} معرف الحدث
     */
    generateEventId() {
        return 'evt_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    /**
     * توليد معرف فريد للدفعة
     * @returns {string} معرف الدفعة
     */
    generateBatchId() {
        return 'batch_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }
}

// تصدير نسخة واحدة من المسجل
export const securityLogger = new SecurityLogger();