/**
 * مدير المستخدمين - إدارة المستخدمين والصلاحيات في نظام نقاط البيع
 * @module UserManager
 * التاريخ: 2025-05-09 03:03:11
 * المستخدم: mostafamohammad7760
 */

export class UserManager {
    constructor(database) {
        this.db = database;
        this.currentUser = null;
        this.sessionTimeout = 30 * 60 * 1000; // 30 دقيقة
        this.permissions = {
            MANAGE_SALES: 'manage_sales',
            MANAGE_RETURNS: 'manage_returns',
            MANAGE_DISCOUNTS: 'manage_discounts',
            MANAGE_CUSTOMERS: 'manage_customers',
            MANAGE_PRODUCTS: 'manage_products',
            MANAGE_INVENTORY: 'manage_inventory',
            MANAGE_REPORTS: 'manage_reports',
            MANAGE_USERS: 'manage_users',
            MANAGE_SETTINGS: 'manage_settings',
            VIEW_REPORTS: 'view_reports'
        };
    }

    /**
     * تسجيل دخول المستخدم
     * @param {string} username - اسم المستخدم
     * @param {string} password - كلمة المرور
     */
    async login(username, password) {
        try {
            // التحقق من بيانات الدخول
            const user = await this.validateCredentials(username, password);
            if (!user) {
                throw new Error('بيانات الدخول غير صحيحة');
            }

            // التحقق من حالة الحساب
            if (!user.is_active) {
                throw new Error('الحساب معطل');
            }

            // إنشاء جلسة جديدة
            const session = await this.createSession(user);
            
            this.currentUser = {
                ...user,
                sessionId: session.session_id,
                permissions: await this.getUserPermissions(user.user_id)
            };

            // تسجيل عملية الدخول
            await this.logUserActivity(user.user_id, 'login', {
                ip: this.getClientIP(),
                userAgent: this.getUserAgent()
            });

            return this.currentUser;
        } catch (error) {
            console.error('Error during login:', error);
            throw new Error('فشل تسجيل الدخول');
        }
    }

    /**
     * التحقق من بيانات الدخول
     * @param {string} username - اسم المستخدم
     * @param {string} password - كلمة المرور
     */
    async validateCredentials(username, password) {
        const query = `
            SELECT 
                u.user_id,
                u.username,
                u.full_name,
                u.email,
                u.role_id,
                u.is_active,
                r.role_name
            FROM users u
            JOIN roles r ON u.role_id = r.role_id
            WHERE u.username = ? 
            AND u.password = ?
            AND u.is_active = 1
        `;

        const hashedPassword = await this.hashPassword(password);
        const [user] = await this.db.executeQuery(query, [username, hashedPassword]);
        return user;
    }

    /**
     * إنشاء جلسة جديدة
     * @param {Object} user - بيانات المستخدم
     */
    async createSession(user) {
        const sessionId = this.generateSessionId();
        const expiresAt = new Date(Date.now() + this.sessionTimeout);

        const query = `
            INSERT INTO user_sessions (
                session_id,
                user_id,
                ip_address,
                user_agent,
                expires_at
            ) VALUES (?, ?, ?, ?, ?)
        `;

        await this.db.executeQuery(query, [
            sessionId,
            user.user_id,
            this.getClientIP(),
            this.getUserAgent(),
            expiresAt
        ]);

        return {
            session_id: sessionId,
            expires_at: expiresAt
        };
    }

    /**
     * الحصول على صلاحيات المستخدم
     * @param {string} userId - معرف المستخدم
     */
    async getUserPermissions(userId) {
        const query = `
            SELECT 
                p.permission_code,
                p.permission_name,
                p.description
            FROM user_permissions up
            JOIN permissions p ON up.permission_id = p.permission_id
            WHERE up.user_id = ?
        `;

        const permissions = await this.db.executeQuery(query, [userId]);
        return permissions.reduce((acc, perm) => {
            acc[perm.permission_code] = true;
            return acc;
        }, {});
    }

    /**
     * التحقق من صلاحية المستخدم
     * @param {string} permission - الصلاحية المطلوبة
     */
    hasPermission(permission) {
        if (!this.currentUser || !this.currentUser.permissions) {
            return false;
        }
        return this.currentUser.permissions[permission] === true;
    }

    /**
     * تسجيل خروج المستخدم
     */
    async logout() {
        try {
            if (!this.currentUser) {
                return;
            }

            // إنهاء الجلسة
            await this.endSession(this.currentUser.sessionId);

            // تسجيل عملية الخروج
            await this.logUserActivity(this.currentUser.user_id, 'logout');

            this.currentUser = null;
            return true;
        } catch (error) {
            console.error('Error during logout:', error);
            throw new Error('فشل تسجيل الخروج');
        }
    }

    /**
     * إنهاء جلسة
     * @param {string} sessionId - معرف الجلسة
     */
    async endSession(sessionId) {
        const query = `
            UPDATE user_sessions 
            SET ended_at = CURRENT_TIMESTAMP
            WHERE session_id = ?
        `;
        await this.db.executeQuery(query, [sessionId]);
    }

    /**
     * تغيير كلمة المرور
     * @param {string} userId - معرف المستخدم
     * @param {string} currentPassword - كلمة المرور الحالية
     * @param {string} newPassword - كلمة المرور الجديدة
     */
    async changePassword(userId, currentPassword, newPassword) {
        try {
            // التحقق من كلمة المرور الحالية
            const user = await this.validateCredentials(
                this.currentUser.username,
                currentPassword
            );

            if (!user) {
                throw new Error('كلمة المرور الحالية غير صحيحة');
            }

            // التحقق من قوة كلمة المرور الجديدة
            if (!this.isStrongPassword(newPassword)) {
                throw new Error('كلمة المرور الجديدة ضعيفة');
            }

            // تحديث كلمة المرور
            const hashedPassword = await this.hashPassword(newPassword);
            const query = `
                UPDATE users 
                SET 
                    password = ?,
                    updated_by = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE user_id = ?
            `;

            await this.db.executeQuery(query, [
                hashedPassword,
                this.currentUser.user_id,
                userId
            ]);

            // تسجيل العملية
            await this.logUserActivity(userId, 'password_change');

            return true;
        } catch (error) {
            console.error('Error changing password:', error);
            throw new Error('فشل تغيير كلمة المرور');
        }
    }

    /**
     * التحقق من قوة كلمة المرور
     * @param {string} password - كلمة المرور
     */
    isStrongPassword(password) {
        const minLength = 8;
        const hasUpperCase = /[A-Z]/.test(password);
        const hasLowerCase = /[a-z]/.test(password);
        const hasNumbers = /\d/.test(password);
        const hasSpecialChars = /[!@#$%^&*(),.?":{}|<>]/.test(password);

        return password.length >= minLength &&
            hasUpperCase &&
            hasLowerCase &&
            hasNumbers &&
            hasSpecialChars;
    }

    /**
     * تشفير كلمة المرور
     * @param {string} password - كلمة المرور
     */
    async hashPassword(password) {
        // في التطبيق الفعلي، استخدم خوارزمية تشفير قوية مثل bcrypt
        return crypto.createHash('sha256').update(password).digest('hex');
    }

    /**
     * تسجيل نشاط المستخدم
     * @param {string} userId - معرف المستخدم
     * @param {string} action - نوع النشاط
     * @param {Object} details - تفاصيل إضافية
     */
    async logUserActivity(userId, action, details = {}) {
        const query = `
            INSERT INTO user_activity_log (
                user_id,
                action,
                details,
                ip_address,
                user_agent
            ) VALUES (?, ?, ?, ?, ?)
        `;

        await this.db.executeQuery(query, [
            userId,
            action,
            JSON.stringify(details),
            this.getClientIP(),
            this.getUserAgent()
        ]);
    }

    /**
     * توليد معرف جلسة فريد
     */
    generateSessionId() {
        return 'sess_' + Date.now().toString(36) + Math.random().toString(36).substr(2);
    }

    /**
     * الحصول على عنوان IP للمستخدم
     */
    getClientIP() {
        // في التطبيق الفعلي، احصل على IP من طلب HTTP
        return '127.0.0.1';
    }

    /**
     * الحصول على معلومات متصفح المستخدم
     */
    getUserAgent() {
        // في التطبيق الفعلي، احصل على User Agent من طلب HTTP
        return 'Mozilla/5.0';
    }
}