import Chart from 'chart.js/auto';

export class ChartManager {
    constructor() {
        this.charts = new Map();
        this.initializeDefaults();
    }

    initializeDefaults() {
        // تعريف الخيارات الافتراضية للرسوم البيانية
        this.defaultOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    rtl: true,
                    labels: {
                        font: {
                            family: 'Arial'
                        }
                    }
                },
                tooltip: {
                    rtl: true,
                    titleFont: {
                        family: 'Arial'
                    },
                    bodyFont: {
                        family: 'Arial'
                    }
                }
            }
        };
    }

    initializeAgingChart(canvasId, initialData) {
        const ctx = document.getElementById(canvasId)?.getContext('2d');
        if (!ctx) return;

        const chart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: initialData.labels,
                datasets: [{
                    data: initialData.datasets[0].data,
                    backgroundColor: initialData.datasets[0].backgroundColor
                }]
            },
            options: {
                ...this.defaultOptions,
                plugins: {
                    ...this.defaultOptions.plugins,
                    title: {
                        display: true,
                        text: 'توزيع الذمم الدائنة حسب العمر',
                        font: {
                            size: 16,
                            family: 'Arial'
                        }
                    }
                }
            }
        });

        this.charts.set(canvasId, chart);
    }

    initializePaymentsChart(canvasId, initialData) {
        const ctx = document.getElementById(canvasId)?.getContext('2d');
        if (!ctx) return;

        const chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: initialData.labels,
                datasets: [{
                    label: 'المدفوعات الشهرية',
                    data: initialData.datasets[0].data,
                    borderColor: initialData.datasets[0].borderColor,
                    fill: false,
                    tension: 0.4
                }]
            },
            options: {
                ...this.defaultOptions,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            font: {
                                family: 'Arial'
                            },
                            callback: function(value) {
                                return new Intl.NumberFormat('ar-SA', {
                                    style: 'currency',
                                    currency: 'SAR',
                                    notation: 'compact'
                                }).format(value);
                            }
                        }
                    },
                    x: {
                        ticks: {
                            font: {
                                family: 'Arial'
                            }
                        }
                    }
                },
                plugins: {
                    ...this.defaultOptions.plugins,
                    title: {
                        display: true,
                        text: 'حركة المدفوعات الشهرية',
                        font: {
                            size: 16,
                            family: 'Arial'
                        }
                    }
                }
            }
        });

        this.charts.set(canvasId, chart);
    }

    updateAgingChart(chartId, newData) {
        const chart = this.charts.get(chartId);
        if (!chart) return;

        chart.data.datasets[0].data = newData.data;
        chart.update();
    }

    updatePaymentsChart(chartId, newData) {
        const chart = this.charts.get(chartId);
        if (!chart) return;

        chart.data.labels = newData.labels;
        chart.data.datasets[0].data = newData.data;
        chart.update();
    }

    // دالة لإنشاء رسم بياني مخصص
    createCustomChart(canvasId, type, data, options = {}) {
        const ctx = document.getElementById(canvasId)?.getContext('2d');
        if (!ctx) return;

        const chartOptions = {
            ...this.defaultOptions,
            ...options
        };

        const chart = new Chart(ctx, {
            type,
            data,
            options: chartOptions
        });

        this.charts.set(canvasId, chart);
        return chart;
    }

    // دالة لتحديث رسم بياني مخصص
    updateCustomChart(chartId, newData, config = {}) {
        const chart = this.charts.get(chartId);
        if (!chart) return;

        if (newData.labels) {
            chart.data.labels = newData.labels;
        }

        if (newData.datasets) {
            chart.data.datasets = newData.datasets;
        }

        if (config.options) {
            chart.options = {
                ...chart.options,
                ...config.options
            };
        }

        chart.update();
    }

    // دالة لتدمير رسم بياني
    destroyChart(chartId) {
        const chart = this.charts.get(chartId);
        if (chart) {
            chart.destroy();
            this.charts.delete(chartId);
        }
    }

    // دالة لتغيير حجم جميع الرسوم البيانية
    resizeAllCharts() {
        this.charts.forEach(chart => {
            chart.resize();
        });
    }

    // دالة لتصدير الرسم البياني كصورة
    exportChart(chartId, format = 'png') {
        const chart = this.charts.get(chartId);
        if (!chart) return null;

        return chart.toBase64Image(format);
    }
}