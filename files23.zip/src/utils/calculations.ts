/**
 * وظائف العمليات الحسابية والمبيعات
 * التاريخ: 2025-05-09 03:47:02
 * المستخدم: mostafamohammad7760
 */

// حساب المجموع الفرعي
export const calculateSubtotal = (items: Array<{ price: number; quantity: number }>): number => {
  return items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
};

// حساب الضريبة
export const calculateTax = (
  amount: number,
  taxRate: number = 0.15, // نسبة ضريبة القيمة المضافة 15%
  options: { 
    includeTax?: boolean;
    round?: boolean;
    precision?: number;
  } = {}
): {
  taxAmount: number;
  totalWithTax: number;
  totalWithoutTax: number;
} => {
  const {
    includeTax = false,
    round = true,
    precision = 2
  } = options;

  let totalWithoutTax: number;
  let taxAmount: number;

  if (includeTax) {
    // إذا كان المبلغ شاملاً للضريبة
    totalWithoutTax = amount / (1 + taxRate);
    taxAmount = amount - totalWithoutTax;
  } else {
    // إذا كان المبلغ غير شامل للضريبة
    totalWithoutTax = amount;
    taxAmount = amount * taxRate;
  }

  if (round) {
    const multiplier = Math.pow(10, precision);
    totalWithoutTax = Math.round(totalWithoutTax * multiplier) / multiplier;
    taxAmount = Math.round(taxAmount * multiplier) / multiplier;
  }

  return {
    taxAmount,
    totalWithTax: totalWithoutTax + taxAmount,
    totalWithoutTax
  };
};

// حساب الخصم
export const calculateDiscount = (
  amount: number,
  discount: number | { type: 'percentage' | 'fixed'; value: number },
  options: {
    maxDiscount?: number;
    round?: boolean;
    precision?: number;
  } = {}
): {
  discountAmount: number;
  totalAfterDiscount: number;
} => {
  const {
    maxDiscount,
    round = true,
    precision = 2
  } = options;

  let discountAmount: number;

  if (typeof discount === 'number') {
    // إذا كان الخصم نسبة مئوية
    discountAmount = amount * (discount / 100);
  } else {
    // إذا كان الخصم قيمة ثابتة أو نسبة
    discountAmount = discount.type === 'percentage'
      ? amount * (discount.value / 100)
      : discount.value;
  }

  // التحقق من الحد الأقصى للخصم
  if (maxDiscount !== undefined) {
    discountAmount = Math.min(discountAmount, maxDiscount);
  }

  // التقريب إذا كان مطلوباً
  if (round) {
    const multiplier = Math.pow(10, precision);
    discountAmount = Math.round(discountAmount * multiplier) / multiplier;
  }

  return {
    discountAmount,
    totalAfterDiscount: amount - discountAmount
  };
};

// حساب نقاط الولاء
export const calculateLoyaltyPoints = (
  amount: number,
  config: {
    pointsPerUnit: number;
    minimumAmount?: number;
    maximumPoints?: number;
    roundingMethod?: 'floor' | 'ceil' | 'round';
  }
): number => {
  const {
    pointsPerUnit,
    minimumAmount = 0,
    maximumPoints,
    roundingMethod = 'floor'
  } = config;

  if (amount < minimumAmount) {
    return 0;
  }

  let points: number;

  switch (roundingMethod) {
    case 'ceil':
      points = Math.ceil(amount * pointsPerUnit);
      break;
    case 'round':
      points = Math.round(amount * pointsPerUnit);
      break;
    default:
      points = Math.floor(amount * pointsPerUnit);
  }

  if (maximumPoints !== undefined) {
    points = Math.min(points, maximumPoints);
  }

  return points;
};

// حساب القيمة النقدية للنقاط
export const calculatePointsValue = (
  points: number,
  config: {
    valuePerPoint: number;
    minimumPoints?: number;
    maximumValue?: number;
  }
): number => {
  const {
    valuePerPoint,
    minimumPoints = 0,
    maximumValue
  } = config;

  if (points < minimumPoints) {
    return 0;
  }

  let value = points * valuePerPoint;

  if (maximumValue !== undefined) {
    value = Math.min(value, maximumValue);
  }

  return value;
};

// حساب الباقي
export const calculateChange = (
  totalAmount: number,
  receivedAmount: number,
  options: {
    allowNegative?: boolean;
    round?: boolean;
    precision?: number;
  } = {}
): {
  change: number;
  isShort: boolean;
  shortageAmount?: number;
} => {
  const {
    allowNegative = false,
    round = true,
    precision = 2
  } = options;

  let change = receivedAmount - totalAmount;
  
  if (!allowNegative && change < 0) {
    return {
      change: 0,
      isShort: true,
      shortageAmount: Math.abs(change)
    };
  }

  if (round) {
    const multiplier = Math.pow(10, precision);
    change = Math.round(change * multiplier) / multiplier;
  }

  return {
    change,
    isShort: change < 0,
    shortageAmount: change < 0 ? Math.abs(change) : undefined
  };
};

// حساب التكلفة والربح
export const calculateProfitability = (
  item: {
    sellingPrice: number;
    costPrice: number;
    quantity: number;
    overhead?: number;
  }
): {
  revenue: number;
  totalCost: number;
  grossProfit: number;
  netProfit: number;
  profitMargin: number;
  roi: number;
} => {
  const revenue = item.sellingPrice * item.quantity;
  const directCost = item.costPrice * item.quantity;
  const overhead = item.overhead || 0;
  const totalCost = directCost + overhead;
  const grossProfit = revenue - directCost;
  const netProfit = grossProfit - overhead;
  const profitMargin = (netProfit / revenue) * 100;
  const roi = (netProfit / totalCost) * 100;

  return {
    revenue,
    totalCost,
    grossProfit,
    netProfit,
    profitMargin,
    roi
  };
};

// حساب المتوسط المتحرك للمبيعات
export const calculateMovingAverage = (
  sales: Array<number>,
  period: number = 7
): Array<number> => {
  const result: number[] = [];
  
  for (let i = 0; i < sales.length; i++) {
    if (i < period - 1) {
      result.push(NaN);
      continue;
    }

    const sum = sales.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
    result.push(sum / period);
  }

  return result;
};