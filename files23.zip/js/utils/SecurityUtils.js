/**
 * أدوات مساعدة للأمان
 * @module SecurityUtils
 * التاريخ: 2025-05-09 02:42:17
 * المستخدم: mostafamohammad7760
 */

export class SecurityUtils {
    /**
     * توليد كلمة مرور عشوائية قوية
     * @param {number} length - طول كلمة المرور
     * @returns {string} كلمة المرور المولدة
     */
    static generateStrongPassword(length = 12) {
        const lowercase = 'abcdefghijklmnopqrstuvwxyz';
        const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const numbers = '0123456789';
        const special = '!@#$%^&*()_+-=[]{}|;:,.<>?';
        
        let password = '';
        const allChars = lowercase + uppercase + numbers + special;

        // ضمان وجود حرف من كل نوع
        password += lowercase[Math.floor(Math.random() * lowercase.length)];
        password += uppercase[Math.floor(Math.random() * uppercase.length)];
        password += numbers[Math.floor(Math.random() * numbers.length)];
        password += special[Math.floor(Math.random() * special.length)];

        // إكمال باقي الأحرف عشوائياً
        for (let i = password.length; i < length; i++) {
            password += allChars[Math.floor(Math.random() * allChars.length)];
        }

        // خلط الأحرف
        return password.split('').sort(() => Math.random() - 0.5).join('');
    }

    /**
     * قياس قوة كلمة المرور
     * @param {string} password - كلمة المرور
     * @returns {Object} تقييم قوة كلمة المرور
     */
    static measurePasswordStrength(password) {
        let score = 0;
        let feedback = [];

        // التحقق من الطول
        if (password.length < 8) {
            feedback.push('كلمة المرور قصيرة جداً');
        } else if (password.length >= 12) {
            score += 2;
        } else {
            score += 1;
        }

        // التحقق من تنوع الأحرف
        if (/[a-z]/.test(password)) score += 1;
        if (/[A-Z]/.test(password)) score += 1;
        if (/[0-9]/.test(password)) score += 1;
        if (/[^A-Za-z0-9]/.test(password)) score += 1;

        // التحقق من التكرار
        const repeatingChars = password.match(/(.)\1{2,}/g);
        if (repeatingChars) {
            score -= repeatingChars.length;
            feedback.push('تجنب تكرار الأحرف');
        }

        // التحقق من التسلسل
        const sequences = ['123', 'abc', 'qwerty'];
        for (const seq of sequences) {
            if (password.toLowerCase().includes(seq)) {
                score -= 1;
                feedback.push('تجنب التسلسلات المعروفة');
                break;
            }
        }

        // تحديد مستوى القوة
        let strength = 'ضعيفة';
        if (score >= 5) strength = 'قوية جداً';
        else if (score >= 4) strength = 'قوية';
        else if (score >= 3) strength = 'متوسطة';

        return {
            score,
            strength,
            feedback
        };
    }

    /**
     * توليد رمز التحقق الثنائي
     * @param {number} length - طول الرمز
     * @returns {string} رمز التحقق
     */
    static generateTwoFactorCode(length = 6) {
        return Array.from({ length }, () => 
            Math.floor(Math.random() * 10)
        ).join('');
    }

    /**
     * تشفير البيانات الحساسة
     * @param {string} data - البيانات المراد تشفيرها
     * @returns {string} البيانات المشفرة
     */
    static encryptSensitiveData(data) {
        // استخدام خوارزمية تشفير قوية
        const encoder = new TextEncoder();
        const dataBuffer = encoder.encode(data);
        return btoa(String.fromCharCode(...new Uint8Array(dataBuffer)));
    }

    /**
     * فك تشفير البيانات
     * @param {string} encryptedData - البيانات المشفرة
     * @returns {string} البيانات الأصلية
     */
    static decryptSensitiveData(encryptedData) {
        const decoder = new TextDecoder();
        const byteArray = Uint8Array.from(atob(encryptedData), c => c.charCodeAt(0));
        return decoder.decode(byteArray);
    }

    /**
     * التحقق من صحة البريد الإلكتروني
     * @param {string} email - البريد الإلكتروني
     * @returns {boolean} نتيجة التحقق
     */
    static validateEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    /**
     * توليد رقم تعريف فريد
     * @returns {string} رقم التعريف
     */
    static generateUUID() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            const r = Math.random() * 16 | 0;
            const v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    /**
     * تنظيف البيانات المدخلة
     * @param {string} input - النص المدخل
     * @returns {string} النص المنظف
     */
    static sanitizeInput(input) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return input.replace(/[&<>"']/g, m => map[m]);
    }

    /**
     * التحقق من صلاحية التوكن
     * @param {string} token - التوكن
     * @returns {boolean} نتيجة التحقق
     */
    static isValidToken(token) {
        try {
            const [header, payload, signature] = token.split('.');
            if (!header || !payload || !signature) return false;

            const decodedPayload = JSON.parse(atob(payload));
            const expirationTime = decodedPayload.exp * 1000;
            
            return Date.now() < expirationTime;
        } catch {
            return false;
        }
    }

    /**
     * تسجيل أحداث الأمان
     * @param {string} event - الحدث
     * @param {Object} details - التفاصيل
     */
    static logSecurityEvent(event, details) {
        const logEntry = {
            timestamp: new Date().toISOString(),
            event,
            details,
            user: 'mostafamohammad7760',
            userAgent: navigator.userAgent
        };

        // إرسال إلى خدمة تسجيل الأحداث
        console.log('Security Event:', logEntry);
        return logEntry;
    }
}