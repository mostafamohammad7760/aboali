/**
 * منطق شاشة المبيعات
 * التاريخ: 2025-05-09 03:29:16
 * المستخدم: mostafamohammad7760
 */

import { ref, computed, onMounted, onUnmounted } from 'vue';
import { useStore } from 'vuex';
import { useNotifications } from '@/composables/useNotifications';
import { usePrinter } from '@/composables/usePrinter';
import { useBarcodeScanner } from '@/composables/useBarcodeScanner';
import CustomerSelector from '@/components/pos/CustomerSelector.vue';
import AddCustomerModal from '@/components/pos/AddCustomerModal.vue';
import DiscountModal from '@/components/pos/DiscountModal.vue';
import PaymentModal from '@/components/pos/PaymentModal.vue';

export default {
  name: 'SalesScreen',

  components: {
    CustomerSelector,
    AddCustomerModal,
    DiscountModal,
    PaymentModal
  },

  setup() {
    const store = useStore();
    const { showNotification } = useNotifications();
    const { printReceipt } = usePrinter();
    const { initScanner, stopScanner } = useBarcodeScanner();

    // الحالة
    const searchQuery = ref('');
    const selectedCategory = ref(null);
    const selectedCustomer = ref(null);
    const cartItems = ref([]);
    const discount = ref(null);
    const showAddCustomer = ref(false);
    const showDiscount = ref(false);
    const showPayment = ref(false);

    // القيم المحسوبة
    const categories = computed(() => store.state.pos.categories);
    const products = computed(() => store.state.pos.products);
    
    const filteredProducts = computed(() => {
      let result = products.value;

      // تصفية حسب الفئة
      if (selectedCategory.value) {
        result = result.filter(p => p.category_id === selectedCategory.value);
      }

      // تصفية حسب البحث
      if (searchQuery.value) {
        const query = searchQuery.value.toLowerCase();
        result = result.filter(p => 
          p.name.toLowerCase().includes(query) ||
          p.barcode?.includes(query)
        );
      }

      return result;
    });

    // حسابات السلة
    const subtotal = computed(() => {
      return cartItems.value.reduce((sum, item) => 
        sum + (item.price * item.quantity), 0
      );
    });

    const taxRate = computed(() => store.state.pos.settings.taxRate || 15);

    const taxAmount = computed(() => {
      return (subtotal.value - (discount.value?.amount || 0)) * (taxRate.value / 100);
    });

    const discountAmount = computed(() => discount.value?.amount || 0);

    const total = computed(() => {
      return subtotal.value + taxAmount.value - discountAmount.value;
    });

    const canCheckout = computed(() => {
      return cartItems.value.length > 0 && total.value > 0;
    });

    // دورة حياة المكون
    onMounted(() => {
      initializeScreen();
      initScanner(handleBarcodeScan);
    });

    onUnmounted(() => {
      stopScanner();
    });

    // الوظائف
    const initializeScreen = async () => {
      try {
        await Promise.all([
          store.dispatch('pos/loadProducts'),
          store.dispatch('pos/loadCategories')
        ]);
      } catch (error) {
        showNotification({
          type: 'error',
          message: 'فشل تحميل البيانات: ' + error.message
        });
      }
    };

    const handleBarcodeScan = (barcode) => {
      const product = products.value.find(p => p.barcode === barcode);
      if (product) {
        addToCart(product);
      } else {
        showNotification({
          type: 'warning',
          message: 'المنتج غير موجود'
        });
      }
    };

    const addToCart = (product) => {
      if (product.stock_quantity <= 0) {
        showNotification({
          type: 'warning',
          message: 'المنتج غير متوفر في المخزون'
        });
        return;
      }

      const existingItem = cartItems.value.find(item => 
        item.product_id === product.id
      );

      if (existingItem) {
        if (existingItem.quantity < product.stock_quantity) {
          existingItem.quantity++;
        } else {
          showNotification({
            type: 'warning',
            message: 'تجاوزت الكمية المتوفرة في المخزون'
          });
        }
      } else {
        cartItems.value.push({
          product_id: product.id,
          name: product.name,
          price: product.price,
          quantity: 1,
          max_quantity: product.stock_quantity
        });
      }
    };

    const updateQuantity = (item) => {
      if (item.quantity <= 0) {
        removeItem(item);
      } else if (item.quantity > item.max_quantity) {
        item.quantity = item.max_quantity;
        showNotification({
          type: 'warning',
          message: 'تجاوزت الكمية المتوفرة في المخزون'
        });
      }
    };

    const removeItem = (item) => {
      const index = cartItems.value.indexOf(item);
      if (index > -1) {
        cartItems.value.splice(index, 1);
      }
    };

    const clearCart = () => {
      cartItems.value = [];
      discount.value = null;
      selectedCustomer.value = null;
    };

    const applyDiscount = (discountData) => {
      discount.value = discountData;
      showDiscount.value = false;
    };

    const proceedToPayment = () => {
      if (!canCheckout.value) return;
      showPayment.value = true;
    };

    const completePayment = async (paymentData) => {
      try {
        const saleData = {
          customer_id: selectedCustomer.value?.id,
          items: cartItems.value,
          subtotal: subtotal.value,
          tax_amount: taxAmount.value,
          discount_amount: discountAmount.value,
          total_amount: total.value,
          payment: paymentData
        };

        const result = await store.dispatch('pos/createSale', saleData);
        
        await printReceipt(result);
        
        showNotification({
          type: 'success',
          message: 'تمت العملية بنجاح'
        });

        clearCart();
        showPayment.value = false;

      } catch (error) {
        showNotification({
          type: 'error',
          message: 'فشلت العملية: ' + error.message
        });
      }
    };

    return {
      // الحالة
      searchQuery,
      selectedCategory,
      selectedCustomer,
      cartItems,
      discount,
      showAddCustomer,
      showDiscount,
      showPayment,

      // القيم المحسوبة
      categories,
      filteredProducts,
      subtotal,
      taxRate,
      taxAmount,
      discountAmount,
      total,
      canCheckout,

      // الوظائف
      addToCart,
      updateQuantity,
      removeItem,
      clearCart,
      applyDiscount,
      proceedToPayment,
      completePayment,

      // المساعدون
      formatCurrency: (amount) => new Intl.NumberFormat('ar-SA', {
        style: 'currency',
        currency: 'SAR'
      }).format(amount),

      getStockStatusClass: (quantity) => {
        if (quantity <= 0) return 'out-of-stock';
        if (quantity < 10) return 'low-stock';
        return 'in-stock';
      }
    };
  }
};