/**
 * خدمة نقاط البيع
 * التاريخ: 2025-05-09 04:24:12
 * المستخدم: mostafamohammad7760
 */

import { Transaction } from 'sequelize';
import { POSShift, POSTransaction, Sale, Contact, LoyaltyPoints } from '../models';
import { SalesService } from './SalesService';
import { PaymentService } from './PaymentService';

interface POSPaymentMethod {
  type: 'cash' | 'card' | 'bank' | 'points';
  amount: number;
  reference?: string;
}

interface POSSaleItem {
  productId: number;
  quantity: number;
  price: number;
  discount?: {
    type: 'percentage' | 'fixed';
    value: number;
  };
}

interface POSSaleData {
  shiftId: number;
  customerId?: number;
  items: POSSaleItem[];
  payments: POSPaymentMethod[];
  usePoints?: boolean;
  notes?: string;
}

export class POSService {
  private salesService: SalesService;
  private paymentService: PaymentService;

  constructor() {
    this.salesService = new SalesService();
    this.paymentService = new PaymentService();
  }

  /**
   * فتح وردية جديدة
   */
  public async openShift(data: {
    userId: number;
    branchId: number;
    startBalance: number;
    notes?: string;
  }): Promise<POSShift> {
    const t = await POSShift.sequelize!.transaction();

    try {
      // التحقق من عدم وجود وردية مفتوحة للمستخدم
      const activeShift = await POSShift.findOne({
        where: {
          userId: data.userId,
          status: 'open'
        },
        transaction: t
      });

      if (activeShift) {
        throw new Error('يوجد وردية مفتوحة بالفعل لهذا المستخدم');
      }

      // إنشاء رقم الوردية
      const shiftNumber = await this.generateShiftNumber(data.branchId);

      // إنشاء الوردية
      const shift = await POSShift.create({
        number: shiftNumber,
        userId: data.userId,
        branchId: data.branchId,
        startBalance: data.startBalance,
        status: 'open',
        startedAt: new Date(),
        notes: data.notes
      }, { transaction: t });

      // تسجيل عملية الإيداع الأولي
      await POSTransaction.create({
        shiftId: shift.id,
        type: 'deposit',
        amount: data.startBalance,
        paymentMethod: 'cash',
        notes: 'رصيد بداية الوردية'
      }, { transaction: t });

      await t.commit();
      return shift;

    } catch (error) {
      await t.rollback();
      throw error;
    }
  }

  /**
   * إغلاق الوردية
   */
  public async closeShift(data: {
    shiftId: number;
    actualBalance: number;
    notes?: string;
  }): Promise<POSShift> {
    const t = await POSShift.sequelize!.transaction();

    try {
      const shift = await POSShift.findByPk(data.shiftId, {
        transaction: t
      });

      if (!shift) {
        throw new Error('الوردية غير موجودة');
      }

      if (shift.status === 'closed') {
        throw new Error('الوردية مغلقة بالفعل');
      }

      // حساب الرصيد المتوقع
      const transactions = await POSTransaction.findAll({
        where: { shiftId: shift.id },
        transaction: t
      });

      const expectedBalance = transactions.reduce((balance, trans) => {
        if (trans.type === 'sale' || trans.type === 'deposit') {
          return balance + trans.amount;
        } else if (trans.type === 'return' || trans.type === 'withdrawal') {
          return balance - trans.amount;
        }
        return balance;
      }, 0);

      // تحديث بيانات الوردية
      await shift.update({
        endBalance: expectedBalance,
        actualBalance: data.actualBalance,
        status: 'closed',
        endedAt: new Date(),
        notes: data.notes
      }, { transaction: t });

      await t.commit();
      return shift;

    } catch (error) {
      await t.rollback();
      throw error;
    }
  }

  /**
   * إنشاء عملية بيع جديدة
   */
  public async createSale(data: POSSaleData): Promise<Sale> {
    const t = await POSShift.sequelize!.transaction();

    try {
      const shift = await POSShift.findByPk(data.shiftId, {
        transaction: t
      });

      if (!shift || shift.status !== 'open') {
        throw new Error('الوردية غير صالحة');
      }

      // إنشاء فاتورة المبيعات
      const sale = await this.salesService.createSale({
        customerId: data.customerId,
        warehouseId: shift.branchId, // افتراض أن كل فرع له مستودع رئيسي
        userId: shift.userId,
        items: data.items.map(item => ({
          productId: item.productId,
          quantity: item.quantity,
          unitPrice: item.price,
          discountType: item.discount?.type,
          discountValue: item.discount?.value
        })),
        transaction: t
      });

      // معالجة نقاط الولاء
      if (data.customerId) {
        if (data.usePoints) {
          await this.processLoyaltyPointsRedemption(
            data.customerId,
            sale.id,
            sale.total,
            t
          );
        } else {
          await this.addLoyaltyPoints(
            data.customerId,
            sale.id,
            sale.total,
            t
          );
        }
      }

      // معالجة المدفوعات
      for (const payment of data.payments) {
        await POSTransaction.create({
          shiftId: data.shiftId,
          saleId: sale.id,
          type: 'sale',
          amount: payment.amount,
          paymentMethod: payment.type,
          reference: payment.reference
        }, { transaction: t });

        // تسجيل المدفوعات في نظام المحاسبة
        await this.paymentService.createPayment({
          type: 'receipt',
          contactId: data.customerId,
          amount: payment.amount,
          paymentMethod: payment.type,
          reference: payment.reference,
          saleId: sale.id,
          transaction: t
        });
      }

      await t.commit();
      return sale;

    } catch (error) {
      await t.rollback();
      throw error;
    }
  }

  /**
   * إضافة نقاط ولاء
   */
  private async addLoyaltyPoints(
    customerId: number,
    saleId: number,
    amount: number,
    transaction: Transaction
  ): Promise<void> {
    const pointsRate = 0.01; // نقطة لكل ريال
    const points = Math.floor(amount * pointsRate);

    if (points > 0) {
      await LoyaltyPoints.create({
        customerId,
        referenceType: 'sale',
        referenceId: saleId,
        points,
        type: 'earn',
        notes: `نقاط مكتسبة من المبيعات ${saleId}`
      }, { transaction });

      // تحديث رصيد نقاط العميل
      await Contact.increment('loyaltyPoints', {
        by: points,
        where: { id: customerId },
        transaction
      });
    }
  }

  /**
   * استخدام نقاط الولاء
   */
  private async processLoyaltyPointsRedemption(
    customerId: number,
    saleId: number,
    amount: number,
    transaction: Transaction
  ): Promise<void> {
    const customer = await Contact.findByPk(customerId, { transaction });
    if (!customer) {
      throw new Error('العميل غير موجود');
    }

    const pointValue = 0.5; // قيمة النقطة بالريال
    const maxPointsValue = amount * 0.2; // 20% كحد أقصى من قيمة الفاتورة
    const availablePointsValue = customer.loyaltyPoints * pointValue;
    
    const pointsToUse = Math.min(
      customer.loyaltyPoints,
      Math.floor(maxPointsValue / pointValue)
    );

    if (pointsToUse > 0) {
      await LoyaltyPoints.create({
        customerId,
        referenceType: 'sale',
        referenceId: saleId,
        points: -pointsToUse,
        type: 'redeem',
        notes: `نقاط مستخدمة في المبيعات ${saleId}`
      }, { transaction });

      await customer.decrement('loyaltyPoints', {
        by: pointsToUse,
        transaction
      });
    }
  }

  /**
   * توليد رقم وردية جديد
   */
  private async generateShiftNumber(branchId: number): Promise<string> {
    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    
    const lastShift = await POSShift.findOne({
      where: {
        number: {
          [Op.like]: `SH${year}${month}${branchId}%`
        }
      },
      order: [['number', 'DESC']]
    });

    const sequence = lastShift
      ? parseInt(lastShift.number.slice(-4)) + 1
      : 1;

    return `SH${year}${month}${branchId}${String(sequence).padStart(4, '0')}`;
  }
}