-- إنشاء جداول المخزون

-- جدول المستودعات
CREATE TABLE warehouses (
    warehouse_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    location TEXT,
    manager_id VARCHAR(50),
    is_main BOOLEAN DEFAULT FALSE,
    status ENUM('active', 'inactive') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50)
);

-- جدول مجموعات الأصناف
CREATE TABLE item_categories (
    category_id VARCHAR(20) PRIMARY KEY,
    parent_id VARCHAR(20),
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (parent_id) REFERENCES item_categories(category_id)
);

-- جدول الوحدات
CREATE TABLE units (
    unit_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    symbol VARCHAR(10),
    is_base BOOLEAN DEFAULT FALSE,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50)
);

-- جدول تحويلات الوحدات
CREATE TABLE unit_conversions (
    conversion_id VARCHAR(20) PRIMARY KEY,
    from_unit_id VARCHAR(20) NOT NULL,
    to_unit_id VARCHAR(20) NOT NULL,
    conversion_factor DECIMAL(18,6) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (from_unit_id) REFERENCES units(unit_id),
    FOREIGN KEY (to_unit_id) REFERENCES units(unit_id),
    UNIQUE KEY unique_conversion (from_unit_id, to_unit_id)
);

-- جدول الأصناف
CREATE TABLE items (
    item_id VARCHAR(20) PRIMARY KEY,
    category_id VARCHAR(20) NOT NULL,
    code VARCHAR(20) UNIQUE NOT NULL,
    barcode VARCHAR(50),
    name VARCHAR(200) NOT NULL,
    description TEXT,
    base_unit_id VARCHAR(20) NOT NULL,
    purchase_unit_id VARCHAR(20),
    sales_unit_id VARCHAR(20),
    min_quantity DECIMAL(18,3) DEFAULT 0,
    max_quantity DECIMAL(18,3),
    reorder_point DECIMAL(18,3),
    reorder_quantity DECIMAL(18,3),
    purchase_price DECIMAL(18,2) DEFAULT 0,
    sales_price DECIMAL(18,2) DEFAULT 0,
    last_purchase_price DECIMAL(18,2),
    last_sales_price DECIMAL(18,2),
    is_active BOOLEAN DEFAULT TRUE,
    is_service BOOLEAN DEFAULT FALSE,
    weight DECIMAL(18,3),
    volume DECIMAL(18,3),
    brand VARCHAR(100),
    model VARCHAR(100),
    status ENUM('active', 'inactive', 'discontinued') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (category_id) REFERENCES item_categories(category_id),
    FOREIGN KEY (base_unit_id) REFERENCES units(unit_id),
    FOREIGN KEY (purchase_unit_id) REFERENCES units(unit_id),
    FOREIGN KEY (sales_unit_id) REFERENCES units(unit_id)
);

-- جدول أرصدة المخزون
CREATE TABLE inventory_balances (
    balance_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    warehouse_id VARCHAR(20) NOT NULL,
    item_id VARCHAR(20) NOT NULL,
    quantity DECIMAL(18,3) NOT NULL DEFAULT 0,
    reserved_quantity DECIMAL(18,3) NOT NULL DEFAULT 0,
    available_quantity DECIMAL(18,3) NOT NULL DEFAULT 0,
    last_transaction_date DATETIME,
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id),
    FOREIGN KEY (item_id) REFERENCES items(item_id),
    UNIQUE KEY unique_item_warehouse (warehouse_id, item_id)
);

-- جدول حركات المخزون
CREATE TABLE inventory_transactions (
    transaction_id VARCHAR(20) PRIMARY KEY,
    transaction_number VARCHAR(20) UNIQUE NOT NULL,
    transaction_date DATETIME NOT NULL,
    warehouse_id VARCHAR(20) NOT NULL,
    transaction_type ENUM(
        'initial_balance',
        'purchase',
        'sales',
        'transfer_in',
        'transfer_out',
        'adjustment_in',
        'adjustment_out',
        'return_in',
        'return_out'
    ) NOT NULL,
    reference_type VARCHAR(50),
    reference_id VARCHAR(20),
    description TEXT,
    status ENUM('draft', 'posted', 'cancelled') DEFAULT 'draft',
    posting_date DATETIME,
    cancellation_date DATETIME,
    cancellation_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id)
);

-- جدول تفاصيل حركات المخزون
CREATE TABLE inventory_transaction_details (
    detail_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    transaction_id VARCHAR(20) NOT NULL,
    item_id VARCHAR(20) NOT NULL,
    unit_id VARCHAR(20) NOT NULL,
    quantity DECIMAL(18,3) NOT NULL,
    unit_price DECIMAL(18,2),
    total_price DECIMAL(18,2),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (transaction_id) REFERENCES inventory_transactions(transaction_id),
    FOREIGN KEY (item_id) REFERENCES items(item_id),
    FOREIGN KEY (unit_id) REFERENCES units(unit_id)
);

-- جدول التحويلات بين المستودعات
CREATE TABLE warehouse_transfers (
    transfer_id VARCHAR(20) PRIMARY KEY,
    transfer_number VARCHAR(20) UNIQUE NOT NULL,
    transfer_date DATETIME NOT NULL,
    from_warehouse_id VARCHAR(20) NOT NULL,
    to_warehouse_id VARCHAR(20) NOT NULL,
    description TEXT,
    status ENUM('draft', 'in_transit', 'received', 'cancelled') DEFAULT 'draft',
    shipping_date DATETIME,
    receiving_date DATETIME,
    cancellation_date DATETIME,
    cancellation_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (from_warehouse_id) REFERENCES warehouses(warehouse_id),
    FOREIGN KEY (to_warehouse_id) REFERENCES warehouses(warehouse_id)
);

-- جدول تفاصيل التحويلات بين المستودعات
CREATE TABLE warehouse_transfer_details (
    detail_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    transfer_id VARCHAR(20) NOT NULL,
    item_id VARCHAR(20) NOT NULL,
    unit_id VARCHAR(20) NOT NULL,
    quantity DECIMAL(18,3) NOT NULL,
    received_quantity DECIMAL(18,3),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (transfer_id) REFERENCES warehouse_transfers(transfer_id),
    FOREIGN KEY (item_id) REFERENCES items(item_id),
    FOREIGN KEY (unit_id) REFERENCES units(unit_id)
);

-- جدول الجرد
CREATE TABLE inventory_count (
    count_id VARCHAR(20) PRIMARY KEY,
    count_number VARCHAR(20) UNIQUE NOT NULL,
    warehouse_id VARCHAR(20) NOT NULL,
    count_date DATETIME NOT NULL,
    description TEXT,
    status ENUM('draft', 'in_progress', 'completed', 'cancelled') DEFAULT 'draft',
    completion_date DATETIME,
    cancellation_date DATETIME,
    cancellation_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id)
);

-- جدول تفاصيل الجرد
CREATE TABLE inventory_count_details (
    detail_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    count_id VARCHAR(20) NOT NULL,
    item_id VARCHAR(20) NOT NULL,
    unit_id VARCHAR(20) NOT NULL,
    system_quantity DECIMAL(18,3) NOT NULL,
    actual_quantity DECIMAL(18,3),
    difference DECIMAL(18,3),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (count_id) REFERENCES inventory_count(count_id),
    FOREIGN KEY (item_id) REFERENCES items(item_id),
    FOREIGN KEY (unit_id) REFERENCES units(unit_id)
);

-- إجراءات مخزنة

DELIMITER //

-- إجراء تحديث رصيد المخزون
CREATE PROCEDURE update_inventory_balance(
    IN p_warehouse_id VARCHAR(20),
    IN p_item_id VARCHAR(20),
    IN p_quantity DECIMAL(18,3),
    IN p_transaction_type VARCHAR(50)
)
BEGIN
    DECLARE v_current_quantity DECIMAL(18,3);
    DECLARE v_new_quantity DECIMAL(18,3);
    
    -- الحصول على الكمية الحالية
    SELECT COALESCE(quantity, 0)
    INTO v_current_quantity
    FROM inventory_balances
    WHERE warehouse_id = p_warehouse_id
    AND item_id = p_item_id;
    
    -- حساب الكمية الجديدة
    SET v_new_quantity = CASE
        WHEN p_transaction_type IN ('initial_balance', 'purchase', 'transfer_in', 'adjustment_in', 'return_in')
            THEN v_current_quantity + p_quantity
        WHEN p_transaction_type IN ('sales', 'transfer_out', 'adjustment_out', 'return_out')
            THEN v_current_quantity - p_quantity
        ELSE v_current_quantity
    END;
    
    -- تحديث أو إدراج الرصيد
    INSERT INTO inventory_balances (
        warehouse_id,
        item_id,
        quantity,
        available_quantity,
        last_transaction_date
    ) VALUES (
        p_warehouse_id,
        p_item_id,
        v_new_quantity,
        v_new_quantity - COALESCE((
            SELECT reserved_quantity 
            FROM inventory_balances 
            WHERE warehouse_id = p_warehouse_id 
            AND item_id = p_item_id
        ), 0),
        NOW()
    ) ON DUPLICATE KEY UPDATE
        quantity = v_new_quantity,
        available_quantity = v_new_quantity - reserved_quantity,
        last_transaction_date = NOW();
END //

-- إجراء ترحيل حركة مخزنية
CREATE PROCEDURE post_inventory_transaction(
    IN p_transaction_id VARCHAR(20),
    IN p_posted_by VARCHAR(50)
)
BEGIN
    DECLARE v_warehouse_id VARCHAR(20);
    DECLARE v_transaction_type VARCHAR(50);
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_item_id VARCHAR(20);
    DECLARE v_quantity DECIMAL(18,3);
    
    -- تعريف Cursor للتفاصيل
    DECLARE cur_details CURSOR FOR
        SELECT item_id, quantity
        FROM inventory_transaction_details
        WHERE transaction_id = p_transaction_id;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    -- الحصول على بيانات الحركة
    SELECT warehouse_id, transaction_type
    INTO v_warehouse_id, v_transaction_type
    FROM inventory_transactions
    WHERE transaction_id = p_transaction_id
    AND status = 'draft';
    
    -- التحقق من وجود الحركة
    IF v_warehouse_id IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'الحركة غير موجودة أو تم ترحيلها مسبقاً';
    END IF;
    
    -- بدء المعاملة
    START TRANSACTION;
    
    -- تحديث أرصدة المخزون
    OPEN cur_details;
    
    read_loop: LOOP
        FETCH cur_details INTO v_item_id, v_quantity;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        -- تحديث رصيد المخزون
        CALL update_inventory_balance(
            v_warehouse_id,
            v_item_id,
            v_quantity,
            v_transaction_type
        );
    END LOOP;
    
    CLOSE cur_details;
    
    -- تحديث حالة الحركة
    UPDATE inventory_transactions
    SET 
        status = 'posted',
        posting_date = NOW(),
        updated_by = p_posted_by,
        updated_at = NOW()
    WHERE transaction_id = p_transaction_id;
    
    COMMIT;
END //

DELIMITER ;

-- المؤشرات
CREATE INDEX idx_inventory_balances_item ON inventory_balances(item_id);
CREATE INDEX idx_inventory_balances_warehouse ON inventory_balances(warehouse_id);
CREATE INDEX idx_transactions_date ON inventory_transactions(transaction_date);
CREATE INDEX idx_transactions_type ON inventory_transactions(transaction_type);
CREATE INDEX idx_transactions_reference ON inventory_transactions(reference_type, reference_id);
CREATE INDEX idx_items_category ON items(category_id);
CREATE INDEX idx_items_status ON items(status);
CREATE INDEX idx_categories_parent ON item_categories(parent_id);
CREATE INDEX idx_transfers_date ON warehouse_transfers(transfer_date);
CREATE INDEX idx_transfers_status ON warehouse_transfers(status);
CREATE INDEX idx_count_warehouse ON inventory_count(warehouse_id);
CREATE INDEX idx_count_status ON inventory_count(status);