/**
 * خدمة المخزون
 * التاريخ: 2025-05-09 04:21:09
 * المستخدم: mostafamohammad7760
 */

import { Transaction } from 'sequelize';
import { Inventory, InventoryTransaction, Product } from '../models';
import { createJournalEntry } from './AccountingService';

interface InventoryUpdateData {
  productId: number;
  warehouseId: number;
  quantity: number;
  cost?: number;
  reference?: {
    type: string;
    id: number;
  };
  notes?: string;
  transaction?: Transaction;
}

export class InventoryService {
  /**
   * تحديث المخزون
   */
  public async updateInventory(data: InventoryUpdateData): Promise<void> {
    const t = data.transaction || await Inventory.sequelize!.transaction();

    try {
      // البحث عن رصيد المخزون الحالي
      let inventory = await Inventory.findOne({
        where: {
          productId: data.productId,
          warehouseId: data.warehouseId
        },
        transaction: t
      });

      // إنشاء رصيد جديد إذا لم يكن موجوداً
      if (!inventory) {
        inventory = await Inventory.create({
          productId: data.productId,
          warehouseId: data.warehouseId,
          quantity: 0
        }, { transaction: t });
      }

      // تحديث الكمية
      const newQuantity = inventory.quantity + data.quantity;
      
      // التحقق من صحة الكمية الجديدة
      if (newQuantity < 0) {
        throw new Error('الكمية غير كافية في المخزون');
      }

      // تحديث رصيد المخزون
      await inventory.update({
        quantity: newQuantity,
        lastCountedAt: new Date()
      }, { transaction: t });

      // تسجيل حركة المخزون
      await InventoryTransaction.create({
        productId: data.productId,
        warehouseId: data.warehouseId,
        quantity: data.quantity,
        balance: newQuantity,
        type: data.quantity > 0 ? 'in' : 'out',
        cost: data.cost,
        referenceType: data.reference?.type,
        referenceId: data.reference?.id,
        notes: data.notes
      }, { transaction: t });

      // إنشاء قيد محاسبي إذا كانت العملية تتضمن تكلفة
      if (data.cost && Math.abs(data.quantity) > 0) {
        const amount = Math.abs(data.quantity) * data.cost;
        
        await createJournalEntry({
          date: new Date(),
          referenceType: 'inventory',
          referenceId: inventory.id,
          items: [
            {
              accountId: 5, // حساب المخزون
              debit: data.quantity > 0 ? amount : 0,
              credit: data.quantity < 0 ? amount : 0
            },
            {
              accountId: 6, // حساب تكلفة البضاعة
              debit: data.quantity < 0 ? amount : 0,
              credit: data.quantity > 0 ? amount : 0
            }
          ],
          transaction: t
        });
      }

      if (!data.transaction) {
        await t.commit();
      }

    } catch (error) {
      if (!data.transaction) {
        await t.rollback();
      }
      throw error;
    }
  }

  /**
   * جرد المخزون
   */
  public async stockTaking(data: {
    warehouseId: number;
    items: Array<{
      productId: number;
      actualQuantity: number;
      notes?: string;
    }>;
    userId: number;
  }): Promise<void> {
    const t = await Inventory.sequelize!.transaction();

    try {
      for (const item of data.items) {
        const inventory = await Inventory.findOne({
          where: {
            productId: item.productId,
            warehouseId: data.warehouseId
          },
          transaction: t
        });

        if (!inventory) {
          throw new Error(`المنتج غير موجود في المخزون: ${item.productId}`);
        }

        const difference = item.actualQuantity - inventory.quantity;

        if (difference !== 0) {
          // تحديث الكمية
          await this.updateInventory({
            productId: item.productId,
            warehouseId: data.warehouseId,
            quantity: difference,
            reference: {
              type: 'stocktaking',
              id: data.userId
            },
            notes: item.notes,
            transaction: t
          });
        }
      }

      await t.commit();

    } catch (error) {
      await t.rollback();
      throw error;
    }
  }

  /**
   * تحويل مخزون بين المستودعات
   */
  public async transferStock(data: {
    fromWarehouseId: number;
    toWarehouseId: number;
    items: Array<{
      productId: number;
      quantity: number;
    }>;
    userId: number;
    notes?: string;
  }): Promise<void> {
    const t = await Inventory.sequelize!.transaction();

    try {
      for (const item of data.items) {
        // تخفيض الكمية من المستودع المصدر
        await this.updateInventory({
          productId: item.productId,
          warehouseId: data.fromWarehouseId,
          quantity: -item.quantity,
          reference: {
            type: 'transfer_out',
            id: data.userId
          },
          notes: data.notes,
          transaction: t
        });

        // إضافة الكمية للمستودع الهدف
        await this.updateInventory({
          productId: item.productId,
          warehouseId: data.toWarehouseId,
          quantity: item.quantity,
          reference: {
            type: 'transfer_in',
            id: data.userId
          },
          notes: data.notes,
          transaction: t
        });
      }

      await t.commit();

    } catch (error) {
      await t.rollback();
      throw error;
    }
  }
}