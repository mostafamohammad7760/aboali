/**
 * مزود التخزين السحابي
 * التاريخ: 2025-05-09 04:35:58
 * المستخدم: mostafamohammad7760
 */

import { S3 } from 'aws-sdk';
import { Storage } from '@google-cloud/storage';
import { BlobServiceClient } from '@azure/storage-blob';

interface CloudStorageConfig {
  provider: 'aws' | 'gcp' | 'azure';
  config: {
    accessKeyId?: string;
    secretAccessKey?: string;
    region?: string;
    bucket: string;
    projectId?: string;
    connectionString?: string;
  };
}

export class CloudStorageProvider {
  private provider: any;
  private bucket: string;

  constructor(config: CloudStorageConfig) {
    this.bucket = config.config.bucket;

    switch (config.provider) {
      case 'aws':
        this.provider = new S3({
          accessKeyId: config.config.accessKeyId,
          secretAccessKey: config.config.secretAccessKey,
          region: config.config.region
        });
        break;

      case 'gcp':
        this.provider = new Storage({
          projectId: config.config.projectId
        });
        break;

      case 'azure':
        this.provider = BlobServiceClient.fromConnectionString(
          config.config.connectionString!
        );
        break;

      default:
        throw new Error('مزود تخزين سحابي غير مدعوم');
    }
  }

  /**
   * رفع ملف
   */
  public async upload(path: string, data: any, options?: {
    metadata?: Record<string, any>;
  }): Promise<void> {
    switch (this.provider.constructor.name) {
      case 'S3':
        await this.provider.upload({
          Bucket: this.bucket,
          Key: path,
          Body: data,
          Metadata: options?.metadata
        }).promise();
        break;

      case 'Storage':
        const bucket = this.provider.bucket(this.bucket);
        const file = bucket.file(path);
        await file.save(data, {
          metadata: options?.metadata
        });
        break;

      case 'BlobServiceClient':
        const containerClient = this.provider.getContainerClient(this.bucket);
        const blockBlobClient = containerClient.getBlockBlobClient(path);
        await blockBlobClient.upload(data, data.length, {
          metadata: options?.metadata
        });
        break;
    }
  }

  /**
   * تحميل ملف
   */
  public async download(path: string): Promise<{
    data: any;
    metadata: Record<string, any>;
  }> {
    switch (this.provider.constructor.name) {
      case 'S3':
        const s3Response = await this.provider.getObject({
          Bucket: this.bucket,
          Key: path
        }).promise();
        return {
          data: s3Response.Body,
          metadata: s3Response.Metadata || {}
        };

      case 'Storage':
        const bucket = this.provider.bucket(this.bucket);
        const file = bucket.file(path);
        const [data, metadata] = await file.download();
        return { data, metadata: metadata || {} };

      case 'BlobServiceClient':
        const containerClient = this.provider.getContainerClient(this.bucket);
        const blockBlobClient = containerClient.getBlockBlobClient(path);
        const downloadResponse = await blockBlobClient.download(0);
        return {
          data: await this.streamToBuffer(downloadResponse.readableStreamBody),
          metadata: downloadResponse.metadata || {}
        };

      default:
        throw new Error('مزود تخزين غير مدعوم');
    }
  }

  /**
   * حذف ملف
   */
  public async delete(path: string): Promise<void> {
    switch (this.provider.constructor.name) {
      case 'S3':
        await this.provider.deleteObject({
          Bucket: this.bucket,
          Key: path
        }).promise();
        break;

      case 'Storage':
        const bucket = this.provider.bucket(this.bucket);
        const file = bucket.file(path);
        await file.delete();
        break;

      case 'BlobServiceClient':
        const containerClient = this.provider.getContainerClient(this.bucket);
        const blockBlobClient = containerClient.getBlockBlobClient(path);
        await blockBlobClient.delete();
        break;
    }
  }

  /**
   * قائمة الملفات
   */
  public async list(prefix: string): Promise<Array<{
    path: string;
    size: number;
    metadata: Record<string, any>;
  }>> {
    switch (this.provider.constructor.name) {
      case 'S3':
        const s3Response = await this.provider.listObjectsV2({
          Bucket: this.bucket,
          Prefix: prefix
        }).promise();
        return s3Response.Contents?.map(item => ({
          path: item.Key!,
          size: item.Size!,
          metadata: {}
        })) || [];

      case 'Storage':
        const [files] = await this.provider
          .bucket(this.bucket)
          .getFiles({ prefix });
        return files.map(file => ({
          path: file.name,
          size: parseInt(file.metadata.size),
          metadata: file.metadata
        }));

      case 'BlobServiceClient':
        const containerClient = this.provider.getContainerClient(this.bucket);
        const blobs = containerClient.listBlobsFlat({ prefix });
        const results = [];
        for await (const blob of blobs) {
          results.push({
            path: blob.name,
            size: blob.properties.contentLength || 0,
            metadata: blob.metadata || {}
          });
        }
        return results;

      default:
        throw new Error('مزود تخزين غير مدعوم');
    }
  }

  /**
   * تحويل Stream إلى Buffer
   */
  private async streamToBuffer(readableStream: NodeJS.ReadableStream): Promise<Buffer> {
    return new Promise((resolve, reject) => {
      const chunks: any[] = [];
      readableStream.on('data', (data) => {
        chunks.push(data instanceof Buffer ? data : Buffer.from(data));
      });
      readableStream.on('end', () => {
        resolve(Buffer.concat(chunks));
      });
      readableStream.on('error', reject);
    });
  }
}