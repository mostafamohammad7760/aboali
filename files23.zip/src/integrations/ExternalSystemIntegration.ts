/**
 * تكامل النظام مع الأنظمة الخارجية
 * التاريخ: 2025-05-09 04:30:01
 * المستخدم: mostafamohammad7760
 */

import axios from 'axios';
import { XMLBuilder, XMLParser } from 'fast-xml-parser';
import { logger } from '../utils/logger';
import { IntegrationError } from '../utils/errors';

export interface ExternalSystemConfig {
  system: 'sage' | 'quickbooks' | 'sap' | 'excel' | 'custom';
  endpoint: string;
  apiKey?: string;
  username?: string;
  password?: string;
  format: 'json' | 'xml';
  options?: Record<string, any>;
}

export class ExternalSystemIntegration {
  private config: ExternalSystemConfig;
  private xmlBuilder: XMLBuilder;
  private xmlParser: XMLParser;

  constructor(config: ExternalSystemConfig) {
    this.config = config;
    this.xmlBuilder = new XMLBuilder({
      ignoreAttributes: false,
      format: true
    });
    this.xmlParser = new XMLParser({
      ignoreAttributes: false,
      parseAttributeValue: true
    });
  }

  /**
   * تصدير القيود المحاسبية
   */
  public async exportJournalEntries(entries: any[]): Promise<void> {
    try {
      const formattedData = this.formatJournalEntries(entries);
      await this.sendToExternalSystem('journal-entries', formattedData);
      logger.info(`تم تصدير ${entries.length} قيد محاسبي بنجاح`);

    } catch (error) {
      logger.error('خطأ في تصدير القيود المحاسبية:', error);
      throw new IntegrationError('فشل تصدير القيود المحاسبية');
    }
  }

  /**
   * تصدير الحسابات
   */
  public async exportChartOfAccounts(accounts: any[]): Promise<void> {
    try {
      const formattedData = this.formatChartOfAccounts(accounts);
      await this.sendToExternalSystem('chart-of-accounts', formattedData);
      logger.info(`تم تصدير ${accounts.length} حساب بنجاح`);

    } catch (error) {
      logger.error('خطأ في تصدير الحسابات:', error);
      throw new IntegrationError('فشل تصدير الحسابات');
    }
  }

  /**
   * تصدير التقارير المالية
   */
  public async exportFinancialStatements(data: any): Promise<void> {
    try {
      const formattedData = this.formatFinancialStatements(data);
      await this.sendToExternalSystem('financial-statements', formattedData);
      logger.info('تم تصدير التقارير المالية بنجاح');

    } catch (error) {
      logger.error('خطأ في تصدير التقارير المالية:', error);
      throw new IntegrationError('فشل تصدير التقارير المالية');
    }
  }

  /**
   * تنسيق القيود المحاسبية حسب النظام الخارجي
   */
  private formatJournalEntries(entries: any[]): any {
    switch (this.config.system) {
      case 'sage':
        return this.formatSageJournalEntries(entries);
      case 'quickbooks':
        return this.formatQuickBooksJournalEntries(entries);
      case 'sap':
        return this.formatSAPJournalEntries(entries);
      case 'excel':
        return this.formatExcelJournalEntries(entries);
      default:
        return entries;
    }
  }

  /**
   * تنسيق القيود لنظام Sage
   */
  private formatSageJournalEntries(entries: any[]): any {
    return {
      JournalEntries: {
        Entry: entries.map(entry => ({
          Header: {
            EntryNumber: entry.number,
            EntryDate: entry.date,
            Reference: entry.reference,
            Notes: entry.notes
          },
          Lines: entry.items.map((item: any) => ({
            AccountCode: item.accountCode,
            Description: item.description,
            Debit: item.debit,
            Credit: item.credit
          }))
        }))
      }
    };
  }

  /**
   * تنسيق القيود لنظام QuickBooks
   */
  private formatQuickBooksJournalEntries(entries: any[]): any {
    return {
      JournalEntries: entries.map(entry => ({
        DocNumber: entry.number,
        TxnDate: entry.date,
        PrivateNote: entry.notes,
        Line: entry.items.map((item: any) => ({
          AccountRef: { value: item.accountId },
          Description: item.description,
          Amount: item.debit > 0 ? item.debit : item.credit,
          JournalEntryLineDetail: {
            PostingType: item.debit > 0 ? 'Debit' : 'Credit'
          }
        }))
      }))
    };
  }

  /**
   * تنسيق القيود لنظام SAP
   */
  private formatSAPJournalEntries(entries: any[]): any {
    return {
      AccountingDocument: {
        DocumentHeader: entries.map(entry => ({
          DocumentDate: entry.date,
          DocumentType: 'SA',
          CompanyCode: this.config.options?.companyCode,
          DocumentNumber: entry.number,
          Reference: entry.reference
        })),
        AccountingDocumentSegment: entries.map(entry => 
          entry.items.map((item: any) => ({
            AccountingDocument: entry.number,
            AccountingDocumentItem: item.lineNumber,
            GLAccount: item.accountCode,
            AmountInDocumentCurrency: item.debit || item.credit,
            DebitCreditCode: item.debit > 0 ? 'D' : 'C',
            DocumentCurrency: this.config.options?.currency || 'SAR',
            PostingKey: item.debit > 0 ? '40' : '50'
          }))
        ).flat()
      }
    };
  }

  /**
   * تنسيق القيود لتصدير Excel
   */
  private formatExcelJournalEntries(entries: any[]): any {
    return entries.map(entry => 
      entry.items.map((item: any) => ({
        'رقم القيد': entry.number,
        'التاريخ': entry.date,
        'رقم الحساب': item.accountCode,
        'اسم الحساب': item.accountName,
        'البيان': item.description,
        'مدين': item.debit,
        'دائن': item.credit,
        'المرجع': entry.reference,
        'الملاحظات': entry.notes
      }))
    ).flat();
  }

  /**
   * إرسال البيانات للنظام الخارجي
   */
  private async sendToExternalSystem(endpoint: string, data: any): Promise<void> {
    const payload = this.config.format === 'xml' 
      ? this.xmlBuilder.build(data)
      : data;

    const headers = {
      'Content-Type': this.config.format === 'xml' 
        ? 'application/xml' 
        : 'application/json',
      'Authorization': this.config.apiKey 
        ? `Bearer ${this.config.apiKey}`
        : `Basic ${Buffer.from(`${this.config.username}:${this.config.password}`).toString('base64')}`
    };

    try {
      const response = await axios({
        method: 'post',
        url: `${this.config.endpoint}/${endpoint}`,
        headers,
        data: payload
      });

      if (response.status !== 200) {
        throw new Error(`فشل الإرسال: ${response.statusText}`);
      }

    } catch (error) {
      logger.error('خطأ في الاتصال بالنظام الخارجي:', error);
      throw new IntegrationError('فشل الاتصال بالنظام الخارجي');
    }
  }
}