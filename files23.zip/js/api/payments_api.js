export class PaymentsAPI {
    constructor() {
        this.baseUrl = '/api/v1/payments';
        this.defaultHeaders = {
            'Content-Type': 'application/json',
            'X-User-Id': 'mostafamohammad7760',
            'X-Timestamp': new Date().toISOString()
        };
    }

    async request(endpoint, options = {}) {
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                ...options,
                headers: {
                    ...this.defaultHeaders,
                    ...options.headers
                }
            });

            if (!response.ok) {
                throw await this.handleErrorResponse(response);
            }

            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            throw this.createUserFriendlyError(error);
        }
    }

    // طلبات لوحة المعلومات
    async getCashStats() {
        return this.request('/dashboard/cash-stats');
    }

    async getBankStats() {
        return this.request('/dashboard/bank-stats');
    }

    async getCheckStats() {
        return this.request('/dashboard/check-stats');
    }

    async getCollectionStats() {
        return this.request('/dashboard/collection-stats');
    }

    async getCashFlowAnalysis(period = 'month') {
        return this.request(`/dashboard/cash-flow-analysis?period=${period}`);
    }

    async getDistributionAnalysis(period = 'month') {
        return this.request(`/dashboard/distribution-analysis?period=${period}`);
    }

    async getUpcomingChecks() {
        return this.request('/dashboard/upcoming-checks');
    }

    // طلبات الحسابات البنكية
    async getBankAccounts(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/bank-accounts?${queryString}`);
    }

    async getBankAccount(accountId) {
        return this.request(`/bank-accounts/${accountId}`);
    }

    async createBankAccount(accountData) {
        this.validateBankAccountData(accountData);
        return this.request('/bank-accounts', {
            method: 'POST',
            body: JSON.stringify(accountData)
        });
    }

    async updateBankAccount(accountId, accountData) {
        this.validateBankAccountData(accountData);
        return this.request(`/bank-accounts/${accountId}`, {
            method: 'PUT',
            body: JSON.stringify(accountData)
        });
    }

    async deleteBankAccount(accountId) {
        return this.request(`/bank-accounts/${accountId}`, {
            method: 'DELETE'
        });
    }

    async getBankAccountStatement(accountId, params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/bank-accounts/${accountId}/statement?${queryString}`);
    }

    // طلبات الصندوق
    async getCashAccounts(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/cash-accounts?${queryString}`);
    }

    async getCashAccount(accountId) {
        return this.request(`/cash-accounts/${accountId}`);
    }

    async createCashAccount(accountData) {
        this.validateCashAccountData(accountData);
        return this.request('/cash-accounts', {
            method: 'POST',
            body: JSON.stringify(accountData)
        });
    }

    async updateCashAccount(accountId, accountData) {
        this.validateCashAccountData(accountData);
        return this.request(`/cash-accounts/${accountId}`, {
            method: 'PUT',
            body: JSON.stringify(accountData)
        });
    }

    async deleteCashAccount(accountId) {
        return this.request(`/cash-accounts/${accountId}`, {
            method: 'DELETE'
        });
    }

    async getCashAccountStatement(accountId, params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/cash-accounts/${accountId}/statement?${queryString}`);
    }

    // طلبات سندات القبض
    async getReceipts(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/receipts?${queryString}`);
    }

    async getReceipt(receiptId) {
        return this.request(`/receipts/${receiptId}`);
    }

    async createReceipt(receiptData) {
        this.validateReceiptData(receiptData);
        return this.request('/receipts', {
            method: 'POST',
            body: JSON.stringify(receiptData)
        });
    }

    async updateReceipt(receiptId, receiptData) {
        this.validateReceiptData(receiptData);
        return this.request(`/receipts/${receiptId}`, {
            method: 'PUT',
            body: JSON.stringify(receiptData)
        });
    }

    async postReceipt(receiptId) {
        return this.request(`/receipts/${receiptId}/post`, {
            method: 'PUT'
        });
    }

    async cancelReceipt(receiptId, reason) {
        return this.request(`/receipts/${receiptId}/cancel`, {
            method: 'PUT',
            body: JSON.stringify({ reason })
        });
    }

    // طلبات سندات الصرف
    async getPayments(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/payments?${queryString}`);
    }

    async getPayment(paymentId) {
        return this.request(`/payments/${paymentId}`);
    }

    async createPayment(paymentData) {
        this.validatePaymentData(paymentData);
        return this.request('/payments', {
            method: 'POST',
            body: JSON.stringify(paymentData)
        });
    }

    async updatePayment(paymentId, paymentData) {
        this.validatePaymentData(paymentData);
        return this.request(`/payments/${paymentId}`, {
            method: 'PUT',
            body: JSON.stringify(paymentData)
        });
    }

    async postPayment(paymentId) {
        return this.request(`/payments/${paymentId}/post`, {
            method: 'PUT'
        });
    }

    async cancelPayment(paymentId, reason) {
        return this.request(`/payments/${paymentId}/cancel`, {
            method: 'PUT',
            body: JSON.stringify({ reason })
        });
    }

    // طلبات الشيكات المؤجلة
    async getDeferredChecks(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/deferred-checks?${queryString}`);
    }

    async getDeferredCheck(checkId) {
        return this.request(`/deferred-checks/${checkId}`);
    }

    async createDeferredCheck(checkData) {
        this.validateCheckData(checkData);
        return this.request('/deferred-checks', {
            method: 'POST',
            body: JSON.stringify(checkData)
        });
    }

    async updateDeferredCheck(checkId, checkData) {
        this.validateCheckData(checkData);
        return this.request(`/deferred-checks/${checkId}`, {
            method: 'PUT',
            body: JSON.stringify(checkData)
        });
    }

    async collectDeferredCheck(checkId) {
        return this.request(`/deferred-checks/${checkId}/collect`, {
            method: 'PUT'
        });
    }

    async bounceDeferredCheck(checkId, reason) {
        return this.request(`/deferred-checks/${checkId}/bounce`, {
            method: 'PUT',
            body: JSON.stringify({ reason })
        });
    }

    // طلبات التحويلات
    async createBankTransfer(transferData) {
        this.validateTransferData(transferData);
        return this.request('/transfers/bank', {
            method: 'POST',
            body: JSON.stringify(transferData)
        });
    }

    async createCashTransfer(transferData) {
        this.validateTransferData(transferData);
        return this.request('/transfers/cash', {
            method: 'POST',
            body: JSON.stringify(transferData)
        });
    }

    // طلبات التقارير
    async getCashFlowReport(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/cash-flow?${queryString}`);
    }

    async getCustomerBalancesReport(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/customer-balances?${queryString}`);
    }

    async getSupplierBalancesReport(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/supplier-balances?${queryString}`);
    }

    async getCheckAgingReport(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/check-aging?${queryString}`);
    }

    // توابع التحقق من صحة البيانات
    validateBankAccountData(accountData) {
        const requiredFields = ['code', 'name', 'bankName', 'accountNumber'];
        
        const missingFields = requiredFields.filter(field => !accountData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        return true;
    }

    validateCashAccountData(accountData) {
        const requiredFields = ['code', 'name'];
        
        const missingFields = requiredFields.filter(field => !accountData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        return true;
    }

    validateReceiptData(receiptData) {
        if (!receiptData.typeId || !receiptData.methodId || !receiptData.amount) {
            throw new Error('نوع السند وطريقة الدفع والمبلغ مطلوبة');
        }

        if (receiptData.amount <= 0) {
            throw new Error('المبلغ يجب أن يكون أكبر من صفر');
        }

        return true;
    }

    validatePaymentData(paymentData) {
        if (!paymentData.typeId || !paymentData.methodId || !paymentData.amount) {
            throw new Error('نوع السند وطريقة الدفع والمبلغ مطلوبة');
        }

        if (paymentData.amount <= 0) {
            throw new Error('المبلغ يجب أن يكون أكبر من صفر');
        }

        return true;
    }

    validateCheckData(checkData) {
        const requiredFields = ['checkNumber', 'bankName', 'amount', 'dueDate'];
        
        const missingFields = requiredFields.filter(field => !checkData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        if (checkData.amount <= 0) {
            throw new Error('مبلغ الشيك يجب أن يكون أكبر من صفر');
        }

        if (new Date(checkData.dueDate) < new Date()) {
            throw new Error('تاريخ استحقاق الشيك يجب أن يكون في المستقبل');
        }

        return true;
    }

    validateTransferData(transferData) {
        if (!transferData.fromAccountId || !transferData.toAccountId || !transferData.amount) {
            throw new Error('الحساب المحول منه والحساب المحول إليه والمبلغ مطلوبة');
        }

        if (transferData.amount <= 0) {
            throw new Error('مبلغ التحويل يجب أن يكون أكبر من صفر');
        }

        if (transferData.fromAccountId === transferData.toAccountId) {
            throw new Error('لا يمكن التحويل لنفس الحساب');
        }

        return true;
    }

    // توابع معالجة الأخطاء
    async handleErrorResponse(response) {
        let error;
        try {
            const errorData = await response.json();
            error = new Error(errorData.message || 'حدث خطأ غير معروف');
            error.code = errorData.code;
            error.details = errorData.details;
        } catch {
            error = new Error(`خطأ في الطلب: ${response.status}`);
        }
        error.status = response.status;
        return error;
    }

    createUserFriendlyError(error) {
        const errorMessages = {
            400: 'البيانات المدخلة غير صحيحة',
            401: 'يرجى تسجيل الدخول مرة أخرى',
            403: 'ليس لديك صلاحية للقيام بهذا الإجراء',
            404: 'لم يتم العثور على البيانات المطلوبة',
            409: 'تعارض في البيانات',
            422: 'البيانات المدخلة غير صالحة',
            500: 'حدث خطأ في النظام'
        };

        return new Error(
            errorMessages[error.status] || 
            error.message || 
            'حدث خطأ غير متوقع'
        );
    }
}