import { CostAccountingAPI } from './api/cost_accounting_api.js';
import { ChartManager } from './chart_manager.js';
import { formatCurrency, formatNumber, formatDate, formatPercentage } from './utils/formatters.js';
import { validateCostCenter, validateCostElement, validateCostOrder } from './utils/validators.js';

class CostAccounting {
    constructor() {
        this.api = new CostAccountingAPI();
        this.charts = new ChartManager();
        this.currentUser = 'mostafamohammad7760';
        
        // تهيئة المكونات والبيانات
        this.initializeComponents();
        this.attachEventListeners();
        this.loadDashboardData();
        
        // تحديث الوقت كل ثانية
        this.updateDateTime();
        setInterval(() => this.updateDateTime(), 1000);
    }

    initializeComponents() {
        // عناصر لوحة المعلومات
        this.dashboardElements = {
            // إحصائيات مراكز التكلفة
            productionCenters: document.getElementById('productionCenters'),
            serviceCenters: document.getElementById('serviceCenters'),
            adminCenters: document.getElementById('adminCenters'),
            
            // إحصائيات التكاليف
            directCosts: document.getElementById('directCosts'),
            indirectCosts: document.getElementById('indirectCosts'),
            totalCosts: document.getElementById('totalCosts'),
            
            // إحصائيات الأوامر
            plannedOrders: document.getElementById('plannedOrders'),
            inProgressOrders: document.getElementById('inProgressOrders'),
            completedOrders: document.getElementById('completedOrders'),
            
            // إحصائيات الانحرافات
            priceVariance: document.getElementById('priceVariance'),
            quantityVariance: document.getElementById('quantityVariance'),
            efficiencyVariance: document.getElementById('efficiencyVariance'),
            
            // الجداول
            latestOrdersTable: document.getElementById('latestOrdersTable')
        };

        // عناصر الفلترة
        this.filterElements = {
            costPeriod: document.getElementById('costPeriod'),
            variancePeriod: document.getElementById('variancePeriod')
        };

        // تهيئة الرسوم البيانية
        this.initializeCharts();
        
        // تهيئة القوالب
        this.orderRowTemplate = document.getElementById('orderRowTemplate');
    }

    async loadDashboardData() {
        try {
            this.showLoading();

            const [
                centerStats,
                costStats,
                orderStats,
                varianceStats,
                costAnalysis,
                varianceAnalysis,
                latestOrders
            ] = await Promise.all([
                this.api.getCostCenterStats(),
                this.api.getCostStats(),
                this.api.getCostOrderStats(),
                this.api.getVarianceStats(),
                this.api.getCostAnalysis(this.filterElements.costPeriod.value),
                this.api.getVarianceAnalysis(this.filterElements.variancePeriod.value),
                this.api.getLatestCostOrders()
            ]);

            this.updateCenterStats(centerStats);
            this.updateCostStats(costStats);
            this.updateOrderStats(orderStats);
            this.updateVarianceStats(varianceStats);
            this.updateCharts(costAnalysis, varianceAnalysis);
            this.renderLatestOrders(latestOrders);

            this.hideLoading();
        } catch (error) {
            this.hideLoading();
            this.showError('حدث خطأ أثناء تحميل البيانات');
            console.error('Dashboard loading error:', error);
        }
    }

    initializeCharts() {
        // تهيئة رسم تحليل التكاليف
        this.charts.initializeLineChart('costChart', {
            labels: [],
            datasets: [
                {
                    label: 'التكاليف المباشرة',
                    data: [],
                    borderColor: '#27ae60',
                    backgroundColor: 'rgba(39, 174, 96, 0.1)',
                    fill: true
                },
                {
                    label: 'التكاليف غير المباشرة',
                    data: [],
                    borderColor: '#f39c12',
                    backgroundColor: 'rgba(243, 156, 18, 0.1)',
                    fill: true
                },
                {
                    label: 'إجمالي التكاليف',
                    data: [],
                    borderColor: '#3498db',
                    backgroundColor: 'rgba(52, 152, 219, 0.1)',
                    fill: true
                }
            ],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => formatCurrency(value)
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: context => formatCurrency(context.parsed.y)
                        }
                    }
                }
            }
        });

        // تهيئة رسم تحليل الانحرافات
        this.charts.initializeBarChart('varianceChart', {
            labels: [],
            datasets: [{
                data: [],
                backgroundColor: [
                    '#2ecc71',
                    '#3498db',
                    '#f1c40f',
                    '#e67e22',
                    '#e74c3c',
                    '#9b59b6'
                ]
            }],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => formatCurrency(value)
                        }
                    }
                },
                plugins: {
                    legend: {
                        position: 'right'
                    },
                    tooltip: {
                        callbacks: {
                            label: context => 
                                `${context.label}: ${formatCurrency(context.parsed.y)}`
                        }
                    }
                }
            }
        });
    }

    updateCenterStats(stats) {
        this.dashboardElements.productionCenters.textContent = stats.production;
        this.dashboardElements.serviceCenters.textContent = stats.service;
        this.dashboardElements.adminCenters.textContent = stats.admin;
    }

    updateCostStats(stats) {
        this.dashboardElements.directCosts.textContent = 
            formatCurrency(stats.direct);
        this.dashboardElements.indirectCosts.textContent = 
            formatCurrency(stats.indirect);
        this.dashboardElements.totalCosts.textContent = 
            formatCurrency(stats.total);
    }

    updateOrderStats(stats) {
        this.dashboardElements.plannedOrders.textContent = stats.planned;
        this.dashboardElements.inProgressOrders.textContent = stats.inProgress;
        this.dashboardElements.completedOrders.textContent = stats.completed;
    }

    updateVarianceStats(stats) {
        this.dashboardElements.priceVariance.textContent = 
            formatCurrency(stats.price);
        this.dashboardElements.quantityVariance.textContent = 
            formatCurrency(stats.quantity);
        this.dashboardElements.efficiencyVariance.textContent = 
            formatCurrency(stats.efficiency);
    }

    updateCharts(costData, varianceData) {
        // تحديث رسم تحليل التكاليف
        this.charts.updateLineChart('costChart', {
            labels: costData.labels,
            datasets: [
                {
                    data: costData.direct,
                    label: 'التكاليف المباشرة'
                },
                {
                    data: costData.indirect,
                    label: 'التكاليف غير المباشرة'
                },
                {
                    data: costData.total,
                    label: 'إجمالي التكاليف'
                }
            ]
        });

        // تحديث رسم تحليل الانحرافات
        this.charts.updateBarChart('varianceChart', {
            labels: varianceData.labels,
            data: varianceData.values
        });
    }

    renderLatestOrders(orders) {
        const tbody = this.dashboardElements.latestOrdersTable;
        tbody.innerHTML = '';

        orders.forEach(order => {
            const tr = this.createOrderRow(order);
            tbody.appendChild(tr);
        });
    }

    createOrderRow(order) {
        const template = this.orderRowTemplate.content.cloneNode(true);
        const tr = template.querySelector('tr');
        
        tr.querySelector('.order-code').textContent = order.code;
        tr.querySelector('.order-description').textContent = order.description;
        tr.querySelector('.cost-unit').textContent = order.costUnit;
        tr.querySelector('.quantity').textContent = 
            formatNumber(order.quantity, 3);
        tr.querySelector('.estimated-cost').textContent = 
            formatCurrency(order.estimatedCost);
        tr.querySelector('.actual-cost').textContent = 
            formatCurrency(order.actualCost);
        
        const progressBar = tr.querySelector('.progress');
        const progressText = tr.querySelector('.progress-text');
        progressBar.style.width = `${order.completionPercentage}%`;
        progressText.textContent = 
            formatPercentage(order.completionPercentage);
        
        const statusCell = tr.querySelector('.order-status');
        statusCell.textContent = this.translateOrderStatus(order.status);
        statusCell.classList.add(order.status.toLowerCase());

        // إضافة مستمعات الأحداث للأزرار
        tr.querySelector('.view-order').addEventListener('click', 
            () => this.viewOrder(order.id));
        
        const editButton = tr.querySelector('.edit-order');
        const completeButton = tr.querySelector('.complete-order');
        
        if (order.status === 'in_progress') {
            editButton.addEventListener('click', 
                () => this.editOrder(order.id));
            completeButton.addEventListener('click', 
                () => this.completeOrder(order.id));
        } else {
            editButton.style.display = 'none';
            completeButton.style.display = 'none';
        }

        return tr;
    }

    attachEventListeners() {
        // مستمعات أحداث الإجراءات السريعة
        document.getElementById('createCostCenter')?.addEventListener('click', 
            () => this.showCostCenterModal());
        document.getElementById('createCostElement')?.addEventListener('click', 
            () => this.showCostElementModal());
        document.getElementById('createCostOrder')?.addEventListener('click', 
            () => this.showCostOrderModal());
        document.getElementById('allocateCosts')?.addEventListener('click', 
            () => this.showCostAllocationModal());

        // مستمعات أحداث الفلترة
        this.filterElements.costPeriod.addEventListener('change', 
            () => this.loadCostAnalysis());
        this.filterElements.variancePeriod.addEventListener('change', 
            () => this.loadVarianceAnalysis());

        // مستمعات أحداث التصدير
        document.getElementById('exportCostChart')?.addEventListener('click', 
            () => this.exportChart('costChart'));
        document.getElementById('exportVarianceChart')?.addEventListener('click', 
            () => this.exportChart('varianceChart'));

        // مستمعات أحداث عرض الكل
        document.getElementById('viewAllOrders')?.addEventListener('click', 
            () => this.navigateToOrders());
    }

    // توابع مساعدة
    translateOrderStatus(status) {
        const statusMap = {
            planned: 'مخطط',
            in_progress: 'قيد التنفيذ',
            completed: 'مكتمل',
            cancelled: 'ملغي'
        };
        return statusMap[status] || status;
    }

    updateDateTime() {
        document.getElementById('currentDateTime').textContent = 
            new Date().toISOString().slice(0, 19).replace('T', ' ');
    }

    showLoading() {
        const loader = document.createElement('div');
        loader.className = 'loading-overlay';
        loader.innerHTML = '<div class="loading-spinner"></div>';
        document.body.appendChild(loader);
    }

    hideLoading() {
        document.querySelector('.loading-overlay')?.remove();
    }

    showError(message) {
        console.error(message);
        // يمكن تحسين هذه الدالة لعرض رسائل خطأ أكثر جاذبية
        alert(message);
    }

    showSuccess(message) {
        // يمكن تحسين هذه الدالة لعرض رسائل نجاح أكثر جاذبية
        alert(message);
    }
}

// تهيئة التطبيق عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    new CostAccounting();
});