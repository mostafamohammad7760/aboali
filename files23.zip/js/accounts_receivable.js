import { AccountsReceivableAPI } from './api/accounts_receivable_api.js';
import { ChartManager } from './chart_manager.js';
import { formatCurrency, formatDate, formatNumber } from './utils/formatters.js';

class AccountsReceivable {
    constructor() {
        this.api = new AccountsReceivableAPI();
        this.charts = new ChartManager();
        this.currentUser = 'mostafamohammad7760';
        
        // تهيئة المكونات والبيانات
        this.initializeComponents();
        this.attachEventListeners();
        this.loadDashboardData();
        
        // تحديث الوقت كل ثانية
        this.updateDateTime();
        setInterval(() => this.updateDateTime(), 1000);
    }

    initializeComponents() {
        // عناصر لوحة المعلومات
        this.dashboardElements = {
            totalReceivables: document.getElementById('totalReceivables'),
            totalInvoices: document.getElementById('totalInvoices'),
            overdueAmount: document.getElementById('overdueAmount'),
            overdueInvoices: document.getElementById('overdueInvoices'),
            monthlyCollections: document.getElementById('monthlyCollections'),
            collectionRate: document.getElementById('collectionRate'),
            activeCustomers: document.getElementById('activeCustomers'),
            totalCustomers: document.getElementById('totalCustomers'),
            expectedCollectionsTable: document.getElementById('expectedCollectionsTable'),
            totalExpectedAmount: document.getElementById('totalExpectedAmount'),
            topCustomersGrid: document.getElementById('topCustomersGrid')
        };

        // تهيئة الرسوم البيانية
        this.initializeCharts();
        
        // تهيئة القوالب
        this.customerCardTemplate = document.getElementById('customerCardTemplate');
    }

    attachEventListeners() {
        // مستمعات أحداث التصدير
        document.getElementById('exportAgingChart')?.addEventListener('click', 
            () => this.exportChart('agingChart'));
        document.getElementById('exportCollectionsChart')?.addEventListener('click', 
            () => this.exportChart('collectionsChart'));
        document.getElementById('exportTopCustomers')?.addEventListener('click', 
            () => this.exportTopCustomers());

        // مستمعات أحداث خطط التحصيل
        document.getElementById('addCollectionPlan')?.addEventListener('click', 
            () => this.showCollectionPlanModal());
        document.getElementById('collectionPlanForm')?.addEventListener('submit', 
            (e) => this.handleCollectionPlanSubmit(e));

        // مستمعات أحداث النوافذ المنبثقة
        document.querySelectorAll('.close-btn').forEach(btn => {
            btn.addEventListener('click', () => this.closeModals());
        });

        // مستمعات أحداث التصفية والبحث
        this.setupFilterListeners();
    }

    async loadDashboardData() {
        try {
            this.showLoading();

            const [
                summary,
                expectedCollections,
                agingData,
                collectionsHistory,
                topCustomers
            ] = await Promise.all([
                this.api.getDashboardSummary(),
                this.api.getExpectedCollections(),
                this.api.getAgingSummary(),
                this.api.getCollectionsHistory(),
                this.api.getTopCustomers()
            ]);

            this.updateDashboardSummary(summary);
            this.renderExpectedCollections(expectedCollections);
            this.updateCharts(agingData, collectionsHistory);
            this.renderTopCustomers(topCustomers);

            this.hideLoading();
        } catch (error) {
            this.hideLoading();
            this.showError('حدث خطأ أثناء تحميل البيانات');
            console.error('Dashboard loading error:', error);
        }
    }

    updateDashboardSummary(summary) {
        // تحديث إحصائيات لوحة المعلومات
        this.dashboardElements.totalReceivables.textContent = 
            formatCurrency(summary.totalReceivables);
        this.dashboardElements.totalInvoices.textContent = 
            formatNumber(summary.totalInvoices);
        this.dashboardElements.overdueAmount.textContent = 
            formatCurrency(summary.overdueAmount);
        this.dashboardElements.overdueInvoices.textContent = 
            formatNumber(summary.overdueInvoices);
        this.dashboardElements.monthlyCollections.textContent = 
            formatCurrency(summary.monthlyCollections);
        this.dashboardElements.collectionRate.textContent = 
            `${summary.collectionRate.toFixed(1)}%`;
        this.dashboardElements.activeCustomers.textContent = 
            formatNumber(summary.activeCustomers);
        this.dashboardElements.totalCustomers.textContent = 
            formatNumber(summary.totalCustomers);
    }

    renderExpectedCollections(collections) {
        const tbody = this.dashboardElements.expectedCollectionsTable;
        tbody.innerHTML = '';
        let totalExpected = 0;

        collections.forEach(collection => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${collection.customerName}</td>
                <td>${collection.invoiceNumber}</td>
                <td>${formatDate(collection.dueDate)}</td>
                <td>${formatCurrency(collection.expectedAmount)}</td>
                <td>
                    <span class="status-badge ${collection.status}">
                        ${this.translateStatus(collection.status)}
                    </span>
                </td>
                <td>
                    <div class="btn-group">
                        <button class="btn btn-sm btn-secondary view-invoice" 
                                data-invoice="${collection.invoiceId}">
                            عرض
                        </button>
                        <button class="btn btn-sm btn-primary add-collection" 
                                data-invoice="${collection.invoiceId}">
                            تحصيل
                        </button>
                    </div>
                </td>
            `;

            totalExpected += collection.expectedAmount;
            tbody.appendChild(tr);

            // إضافة مستمعات الأحداث للأزرار
            tr.querySelector('.view-invoice').addEventListener('click', 
                () => this.viewInvoice(collection.invoiceId));
            tr.querySelector('.add-collection').addEventListener('click', 
                () => this.showCollectionModal(collection));
        });

        this.dashboardElements.totalExpectedAmount.textContent = 
            formatCurrency(totalExpected);
    }

    renderTopCustomers(customers) {
        const grid = this.dashboardElements.topCustomersGrid;
        grid.innerHTML = '';

        customers.forEach(customer => {
            const card = this.createCustomerCard(customer);
            grid.appendChild(card);
        });
    }

    createCustomerCard(customer) {
        const template = this.customerCardTemplate.content.cloneNode(true);
        
        template.querySelector('.customer-name').textContent = customer.customerName;
        template.querySelector('.customer-status').textContent = 
            this.translateStatus(customer.status);
        template.querySelector('.balance').textContent = 
            formatCurrency(customer.balance);
        template.querySelector('.overdue').textContent = 
            formatCurrency(customer.overdueAmount);

        const card = template.querySelector('.customer-card');
        card.dataset.customerId = customer.customerId;

        // إضافة مستمعات الأحداث
        card.querySelector('.view-details').addEventListener('click', 
            () => this.viewCustomerDetails(customer.customerId));
        card.querySelector('.add-collection').addEventListener('click', 
            () => this.showCollectionModal({ customerId: customer.customerId }));

        return card;
    }

    initializeCharts() {
        // تهيئة رسم تعمير الذمم
        this.charts.initializeAgingChart('agingChart', {
            labels: ['حالي', '30 يوم', '60 يوم', '90 يوم', '120 يوم', 'أكثر من 120'],
            datasets: [{
                data: [0, 0, 0, 0, 0, 0],
                backgroundColor: [
                    '#2ecc71',
                    '#3498db',
                    '#f1c40f',
                    '#e67e22',
                    '#e74c3c',
                    '#95a5a6'
                ]
            }]
        });

        // تهيئة رسم التحصيلات
        this.charts.initializeCollectionsChart('collectionsChart', {
            labels: [],
            datasets: [{
                label: 'التحصيلات',
                data: [],
                borderColor: '#2c4d76',
                fill: false
            }]
        });
    }

    updateCharts(agingData, collectionsHistory) {
        // تحديث رسم تعمير الذمم
        this.charts.updateAgingChart('agingChart', {
            data: [
                agingData.current,
                agingData.days30,
                agingData.days60,
                agingData.days90,
                agingData.days120,
                agingData.daysOver120
            ]
        });

        // تحديث رسم التحصيلات
        this.charts.updateCollectionsChart('collectionsChart', {
            labels: collectionsHistory.map(item => item.month),
            data: collectionsHistory.map(item => item.amount)
        });
    }

    // توابع مساعدة
    translateStatus(status) {
        const statusMap = {
            active: 'نشط',
            overdue: 'متأخر',
            pending: 'قيد الانتظار',
            completed: 'مكتمل',
            cancelled: 'ملغي'
        };
        return statusMap[status] || status;
    }

    updateDateTime() {
        document.getElementById('currentDateTime').textContent = 
            new Date().toISOString().slice(0, 19).replace('T', ' ');
    }

    showLoading() {
        const loader = document.createElement('div');
        loader.className = 'loading-overlay';
        loader.innerHTML = '<div class="loading-spinner"></div>';
        document.body.appendChild(loader);
    }

    hideLoading() {
        document.querySelector('.loading-overlay')?.remove();
    }

    showError(message) {
        // يمكن تحسين هذه الدالة لعرض رسائل خطأ أكثر جاذبية
        console.error(message);
        alert(message);
    }

    showSuccess(message) {
        // يمكن تحسين هذه الدالة لعرض رسائل نجاح أكثر جاذبية
        alert(message);
    }
}

// تهيئة التطبيق عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    new AccountsReceivable();
});