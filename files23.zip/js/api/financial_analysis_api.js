export class FinancialAnalysisAPI {
    constructor() {
        this.baseUrl = '/api/v1/financial-analysis';
        this.defaultHeaders = {
            'Content-Type': 'application/json',
            'X-User-Id': 'mostafamohammad7760',
            'X-Timestamp': new Date().toISOString()
        };
    }

    async request(endpoint, options = {}) {
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                ...options,
                headers: {
                    ...this.defaultHeaders,
                    ...options.headers
                }
            });

            if (!response.ok) {
                throw await this.handleErrorResponse(response);
            }

            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            throw this.createUserFriendlyError(error);
        }
    }

    // طلبات المقاييس المالية
    async getFinancialMetrics(period) {
        return this.request(`/metrics?period=${period}`);
    }

    // طلبات النسب المالية
    async getFinancialRatios(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/ratios?${queryString}`);
    }

    async getRatio(ratioId) {
        return this.request(`/ratios/${ratioId}`);
    }

    async calculateRatio(ratioData) {
        this.validateRatioData(ratioData);
        return this.request('/ratios/calculate', {
            method: 'POST',
            body: JSON.stringify(ratioData)
        });
    }

    async updateRatioNotes(ratioId, notes) {
        return this.request(`/ratios/${ratioId}/notes`, {
            method: 'PUT',
            body: JSON.stringify({ notes })
        });
    }

    // طلبات التحليل الأفقي
    async getHorizontalAnalysis(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/horizontal-analysis?${queryString}`);
    }

    async performHorizontalAnalysis(analysisData) {
        this.validateAnalysisData(analysisData);
        return this.request('/horizontal-analysis', {
            method: 'POST',
            body: JSON.stringify(analysisData)
        });
    }

    // طلبات التحليل الرأسي
    async getVerticalAnalysis(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/vertical-analysis?${queryString}`);
    }

    async performVerticalAnalysis(analysisData) {
        this.validateAnalysisData(analysisData);
        return this.request('/vertical-analysis', {
            method: 'POST',
            body: JSON.stringify(analysisData)
        });
    }

    // طلبات تحليل الاتجاهات
    async getTrendAnalysis(period, metric) {
        return this.request(`/trend-analysis?period=${period}&metric=${metric}`);
    }

    async performTrendAnalysis(analysisData) {
        this.validateAnalysisData(analysisData);
        return this.request('/trend-analysis', {
            method: 'POST',
            body: JSON.stringify(analysisData)
        });
    }

    // طلبات نقاط التحليل
    async getAnalysisPoints(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/analysis-points?${queryString}`);
    }

    async createAnalysisPoint(pointData) {
        this.validatePointData(pointData);
        return this.request('/analysis-points', {
            method: 'POST',
            body: JSON.stringify(pointData)
        });
    }

    async updateAnalysisPoint(pointId, pointData) {
        this.validatePointData(pointData);
        return this.request(`/analysis-points/${pointId}`, {
            method: 'PUT',
            body: JSON.stringify(pointData)
        });
    }

    async deleteAnalysisPoint(pointId) {
        return this.request(`/analysis-points/${pointId}`, {
            method: 'DELETE'
        });
    }

    // طلبات المعايير القطاعية
    async getIndustryStandards(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/industry-standards?${queryString}`);
    }

    async updateIndustryStandard(standardId, standardData) {
        this.validateStandardData(standardData);
        return this.request(`/industry-standards/${standardId}`, {
            method: 'PUT',
            body: JSON.stringify(standardData)
        });
    }

    // طلبات التحليل المقارن
    async getIndustryComparison(period, metric) {
        return this.request(`/industry-comparison?period=${period}&metric=${metric}`);
    }

    async performComparativeAnalysis(analysisData) {
        this.validateAnalysisData(analysisData);
        return this.request('/comparative-analysis', {
            method: 'POST',
            body: JSON.stringify(analysisData)
        });
    }

    // طلبات التنبؤات المالية
    async getFinancialForecasts(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/forecasts?${queryString}`);
    }

    async createForecast(forecastData) {
        this.validateForecastData(forecastData);
        return this.request('/forecasts', {
            method: 'POST',
            body: JSON.stringify(forecastData)
        });
    }

    async updateForecast(forecastId, forecastData) {
        this.validateForecastData(forecastData);
        return this.request(`/forecasts/${forecastId}`, {
            method: 'PUT',
            body: JSON.stringify(forecastData)
        });
    }

    // توابع التحقق من صحة البيانات
    validateRatioData(ratioData) {
        const requiredFields = [
            'period_id',
            'ratio_type',
            'numerator_value',
            'denominator_value'
        ];
        
        const missingFields = requiredFields.filter(field => !ratioData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        if (ratioData.denominator_value === 0) {
            throw new Error('لا يمكن أن يكون المقام صفراً');
        }

        return true;
    }

    validateAnalysisData(analysisData) {
        const requiredFields = [
            'account_id',
            'period_id',
            'statement_type'
        ];
        
        const missingFields = requiredFields.filter(field => !analysisData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        return true;
    }

    validatePointData(pointData) {
        const requiredFields = [
            'period_id',
            'analysis_type',
            'category',
            'title',
            'description',
            'impact_level'
        ];
        
        const missingFields = requiredFields.filter(field => !pointData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        return true;
    }

    validateStandardData(standardData) {
        const requiredFields = [
            'industry_code',
            'ratio_code',
            'period_id',
            'average_value',
            'effective_date'
        ];
        
        const missingFields = requiredFields.filter(field => !standardData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        return true;
    }

    validateForecastData(forecastData) {
        const requiredFields = [
            'account_id',
            'period_id',
            'statement_type',
            'forecast_method',
            'historical_value',
            'forecasted_value'
        ];
        
        const missingFields = requiredFields.filter(field => !forecastData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        return true;
    }

    // توابع معالجة الأخطاء
    async handleErrorResponse(response) {
        let error;
        try {
            const errorData = await response.json();
            error = new Error(errorData.message || 'حدث خطأ غير معروف');
            error.code = errorData.code;
            error.details = errorData.details;
        } catch {
            error = new Error(`خطأ في الطلب: ${response.status}`);
        }
        error.status = response.status;
        return error;
    }

    createUserFriendlyError(error) {
        const errorMessages = {
            400: 'البيانات المدخلة غير صحيحة',
            401: 'يرجى تسجيل الدخول مرة أخرى',
            403: 'ليس لديك صلاحية للقيام بهذا الإجراء',
            404: 'لم يتم العثور على البيانات المطلوبة',
            409: 'تعارض في البيانات',
            422: 'البيانات المدخلة غير صالحة',
            500: 'حدث خطأ في النظام'
        };

        return new Error(
            errorMessages[error.status] || 
            error.message || 
            'حدث خطأ غير متوقع'
        );
    }
}