/**
 * مكون مراقبة حالة التكامل
 * التاريخ: 2025-05-09 04:33:50
 * المستخدم: mostafamohammad7760
 */

<template>
  <div class="integration-status">
    <div class="status-header">
      <h3>حالة التكامل</h3>
      <div class="header-actions">
        <BaseButton
          size="sm"
          variant="light"
          icon="fa-sync"
          :loading="refreshing"
          @click="refreshStatus"
        >
          تحديث
        </BaseButton>
      </div>
    </div>

    <div class="status-grid">
      <!-- حالة الاتصال -->
      <div class="status-card">
        <div class="card-header">
          <i class="fas fa-plug"></i>
          <span>حالة الاتصال</span>
        </div>
        <div class="card-content">
          <div 
            class="status-indicator"
            :class="connectionStatus.state"
          >
            {{ connectionStatus.label }}
          </div>
          <p class="status-info">
            {{ connectionStatus.message }}
          </p>
        </div>
      </div>

      <!-- إحصائيات المزامنة -->
      <div class="status-card">
        <div class="card-header">
          <i class="fas fa-sync"></i>
          <span>إحصائيات المزامنة</span>
        </div>
        <div class="card-content">
          <div class="stats-grid">
            <div class="stat-item">
              <span class="label">آخر مزامنة</span>
              <span class="value">
                {{ lastSync ? formatDateTime(lastSync) : 'لم تتم المزامنة بعد' }}
              </span>
            </div>
            <div class="stat-item">
              <span class="label">المزامنة القادمة</span>
              <span class="value">
                {{ nextSync ? formatDateTime(nextSync) : 'غير مجدولة' }}
              </span>
            </div>
            <div class="stat-item">
              <span class="label">معدل النجاح</span>
              <span class="value">{{ successRate }}%</span>
            </div>
            <div class="stat-item">
              <span class="label">وقت الاستجابة</span>
              <span class="value">{{ responseTime }}ms</span>
            </div>
          </div>
        </div>
      </div>

      <!-- حالة التصدير -->
      <div class="status-card">
        <div class="card-header">
          <i class="fas fa-exchange-alt"></i>
          <span>حالة التصدير</span>
        </div>
        <div class="card-content">
          <div class="export-status">
            <div
              v-for="(status, type) in exportStatus"
              :key="type"
              class="export-item"
            >
              <div class="item-header">
                <span class="label">{{ getExportLabel(type) }}</span>
                <span 
                  class="status-badge"
                  :class="status.state"
                >
                  {{ status.label }}
                </span>
              </div>
              <div class="item-stats">
                <small>تم تصدير {{ status.count }} سجل</small>
                <small>آخر تحديث: {{ formatDateTime(status.lastUpdate) }}</small>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- الأخطاء والتحذيرات -->
      <div class="status-card">
        <div class="card-header">
          <i class="fas fa-exclamation-triangle"></i>
          <span>الأخطاء والتحذيرات</span>
        </div>
        <div class="card-content">
          <div class="alerts-list">
            <div
              v-for="alert in alerts"
              :key="alert.id"
              class="alert-item"
              :class="alert.type"
            >
              <div class="alert-icon">
                <i :class="getAlertIcon(alert.type)"></i>
              </div>
              <div class="alert-content">
                <p class="message">{{ alert.message }}</p>
                <small class="timestamp">{{ formatDateTime(alert.timestamp) }}</small>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, onMounted, onUnmounted } from 'vue';
import { formatDateTime } from '@/utils/datetime';

export default defineComponent({
  name: 'IntegrationStatus',

  props: {
    integrationId: {
      type: Number,
      required: true
    }
  },

  setup(props) {
    const refreshing = ref(false);
    const statusInterval = ref<number>();

    // حالة الاتصال
    const connectionStatus = ref({
      state: 'connected',
      label: 'متصل',
      message: 'الاتصال بالنظام الخارجي يعمل بشكل طبيعي'
    });

    // إحصائيات المزامنة
    const lastSync = ref<Date | null>(null);
    const nextSync = ref<Date | null>(null);
    const successRate = ref(100);
    const responseTime = ref(150);

    // حالة التصدير
    const exportStatus = ref({
      journalEntries: {
        state: 'success',
        label: 'مكتمل',
        count: 1250,
        lastUpdate: new Date()
      },
      chartOfAccounts: {
        state: 'pending',
        label: 'قيد المعالجة',
        count: 85,
        lastUpdate: new Date()
      },
      financialStatements: {
        state: 'warning',
        label: 'تحذير',
        count: 12,
        lastUpdate: new Date()
      }
    });

    // الأخطاء والتحذيرات
    const alerts = ref([
      {
        id: 1,
        type: 'error',
        message: 'فشل تصدير التقرير المالي للفترة Q1',
        timestamp: new Date()
      },
      {
        type: 'warning',
        message: 'تأخر في مزامنة القيود المحاسبية',
        timestamp: new Date()
      }
    ]);

    // تحديث الحالة
    const refreshStatus = async () => {
      refreshing.value = true;
      try {
        // هنا يتم جلب بيانات الحالة من الخادم
        await new Promise(resolve => setTimeout(resolve, 1000));
        
      } catch (error) {
        console.error('خطأ في تحديث الحالة:', error);
      } finally {
        refreshing.value = false;
      }
    };

    // التحديث التلقائي
    onMounted(() => {
      refreshStatus();
      statusInterval.value = setInterval(refreshStatus, 60000) as unknown as number;
    });

    onUnmounted(() => {
      if (statusInterval.value) {
        clearInterval(statusInterval.value);
      }
    });

    // وظائف مساعدة
    const getExportLabel = (type: string) => {
      const labels: Record<string, string> = {
        journalEntries: 'القيود المحاسبية',
        chartOfAccounts: 'شجرة الحسابات',
        financialStatements: 'التقارير المالية'
      };
      return labels[type] || type;
    };

    const getAlertIcon = (type: string) => {
      return {
        error: 'fas fa-times-circle',
        warning: 'fas fa-exclamation-circle',
        info: 'fas fa-info-circle'
      }[type] || 'fas fa-info-circle';
    };

    return {
      refreshing,
      connectionStatus,
      lastSync,
      nextSync,
      successRate,
      responseTime,
      exportStatus,
      alerts,
      refreshStatus,
      formatDateTime,
      getExportLabel,
      getAlertIcon
    };
  }
});
</script>

<style lang="scss" scoped>
.integration-status {
  .status-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;

    h3 {
      margin: 0;
    }
  }

  .status-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 1.5rem;
  }

  .status-card {
    background: var(--bg-primary);
    border: 1px solid var(--border-color);
    border-radius: var(--border-radius);
    overflow: hidden;

    .card-header {
      padding: 1rem;
      background: var(--bg-secondary);
      border-bottom: 1px solid var(--border-color);
      display: flex;
      align-items: center;
      gap: 0.5rem;

      i {
        color: var(--primary-color);
      }
    }

    .card-content {
      padding: 1rem;
    }
  }

  .status-indicator {
    display: inline-flex;
    align-items: center;
    padding: 0.5rem 1rem;
    border-radius: var(--border-radius);
    font-weight: 500;

    &.connected {
      background: var(--success-light);
      color: var(--success-dark);
    }

    &.disconnected {
      background: var(--danger-light);
      color: var(--danger-dark);
    }

    &.unstable {
      background: var(--warning-light);
      color: var(--warning-dark);
    }
  }

  .stats-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 1rem;

    .stat-item {
      display: flex;
      flex-direction: column;
      gap: 0.25rem;

      .label {
        font-size: 0.875rem;
        color: var(--text-secondary);
      }

      .value {
        font-weight: 500;
      }
    }
  }

  .export-status {
    display: flex;
    flex-direction: column;
    gap: 1rem;

    .export-item {
      .item-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0.5rem;

        .status-badge {
          padding: 0.25rem 0.5rem;
          border-radius: 1rem;
          font-size: 0.75rem;

          &.success {
            background: var(--success-light);
            color: var(--success-dark);
          }

          &.pending {
            background: var(--warning-light);
            color: var(--warning-dark);
          }

          &.error {
            background: var(--danger-light);
            color: var(--danger-dark);
          }
        }
      }

      .item-stats {
        display: flex;
        justify-content: space-between;
        font-size: 0.875rem;
        color: var(--text-secondary);
      }
    }
  }

  .alerts-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;

    .alert-item {
      display: flex;
      gap: 1rem;
      padding: 0.75rem;
      border-radius: var(--border-radius);

      &.error {
        background: var(--danger-light);
        color: var(--danger-dark);
      }

      &.warning {
        background: var(--warning-light);
        color: var(--warning-dark);
      }

      &.info {
        background: var(--info-light);
        color: var(--info-dark);
      }

      .alert-content {
        flex: 1;

        .message {
          margin: 0 0 0.25rem;
        }

        .timestamp {
          color: inherit;
          opacity: 0.8;
        }
      }
    }
  }
}
</style>