<!-- 
مكون اختيار العميل
التاريخ: 2025-05-09 03:32:13
المستخدم: mostafamohammad7760
-->

<template>
  <div class="customer-selector">
    <!-- زر إضافة عميل جديد -->
    <button class="add-customer-btn" @click="$emit('add-customer')" v-if="!modelValue">
      <i class="fas fa-user-plus"></i>
      <span>إضافة عميل جديد</span>
    </button>

    <!-- بحث عن عميل -->
    <div class="search-container" v-if="!modelValue">
      <div class="search-input">
        <i class="fas fa-search"></i>
        <input
          type="text"
          v-model="searchQuery"
          placeholder="بحث عن عميل..."
          @focus="showResults = true"
          @input="searchCustomers"
        >
      </div>

      <!-- نتائج البحث -->
      <div class="search-results" v-if="showResults && searchResults.length > 0">
        <div
          v-for="customer in searchResults"
          :key="customer.id"
          class="customer-item"
          @click="selectCustomer(customer)"
        >
          <div class="customer-info">
            <h4>{{ customer.name }}</h4>
            <p>{{ customer.phone }}</p>
          </div>
          <div class="customer-points" v-if="customer.points > 0">
            {{ customer.points }} نقطة
          </div>
        </div>
      </div>

      <!-- رسالة عدم وجود نتائج -->
      <div class="no-results" v-if="showResults && searchQuery && searchResults.length === 0">
        لا توجد نتائج
      </div>
    </div>

    <!-- تفاصيل العميل المحدد -->
    <div class="selected-customer" v-if="modelValue">
      <div class="customer-details">
        <div class="avatar">
          {{ getInitials(modelValue.name) }}
        </div>
        <div class="info">
          <h3>{{ modelValue.name }}</h3>
          <p>{{ modelValue.phone }}</p>
          <div class="badges">
            <span class="membership-badge" :class="modelValue.membership_level">
              {{ getMembershipLabel(modelValue.membership_level) }}
            </span>
            <span class="points-badge" v-if="modelValue.points > 0">
              {{ modelValue.points }} نقطة
            </span>
          </div>
        </div>
      </div>
      <button class="remove-btn" @click="removeCustomer">
        <i class="fas fa-times"></i>
      </button>
    </div>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue';
import { useStore } from 'vuex';
import debounce from 'lodash/debounce';

export default {
  name: 'CustomerSelector',

  props: {
    modelValue: {
      type: Object,
      default: null
    }
  },

  emits: ['update:modelValue', 'add-customer'],

  setup(props, { emit }) {
    const store = useStore();
    const searchQuery = ref('');
    const searchResults = ref([]);
    const showResults = ref(false);

    // البحث عن العملاء مع تأخير
    const searchCustomers = debounce(async () => {
      if (searchQuery.value.length < 2) {
        searchResults.value = [];
        return;
      }

      try {
        const results = await store.dispatch('customers/searchCustomers', {
          query: searchQuery.value,
          limit: 5
        });
        searchResults.value = results;
      } catch (error) {
        console.error('فشل البحث عن العملاء:', error);
        searchResults.value = [];
      }
    }, 300);

    // اختيار عميل
    const selectCustomer = (customer) => {
      emit('update:modelValue', customer);
      searchQuery.value = '';
      showResults.value = false;
    };

    // إزالة العميل المحدد
    const removeCustomer = () => {
      emit('update:modelValue', null);
    };

    // الحصول على الأحرف الأولى من الاسم
    const getInitials = (name) => {
      return name
        .split(' ')
        .map(word => word[0])
        .join('')
        .toUpperCase()
        .slice(0, 2);
    };

    // الحصول على تسمية مستوى العضوية
    const getMembershipLabel = (level) => {
      const labels = {
        basic: 'عادي',
        silver: 'فضي',
        gold: 'ذهبي',
        platinum: 'بلاتيني'
      };
      return labels[level] || level;
    };

    // إغلاق نتائج البحث عند النقر خارج المكون
    onMounted(() => {
      document.addEventListener('click', (e) => {
        if (!e.target.closest('.customer-selector')) {
          showResults.value = false;
        }
      });
    });

    return {
      searchQuery,
      searchResults,
      showResults,
      searchCustomers,
      selectCustomer,
      removeCustomer,
      getInitials,
      getMembershipLabel
    };
  }
};
</script>

<style lang="scss" scoped>
.customer-selector {
  position: relative;

  .add-customer-btn {
    width: 100%;
    padding: 0.75rem;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    background: var(--bg-secondary);
    border: 1px dashed var(--border-color);
    border-radius: var(--border-radius);
    cursor: pointer;
    transition: all 0.2s;

    &:hover {
      background: var(--primary-color);
      color: white;
    }
  }

  .search-container {
    margin-top: 0.5rem;

    .search-input {
      position: relative;

      i {
        position: absolute;
        right: 0.75rem;
        top: 50%;
        transform: translateY(-50%);
        color: var(--text-secondary);
      }

      input {
        width: 100%;
        padding: 0.75rem 2.25rem 0.75rem 0.75rem;
        border: 1px solid var(--border-color);
        border-radius: var(--border-radius);
        font-size: 1rem;

        &:focus {
          outline: none;
          border-color: var(--primary-color);
        }
      }
    }

    .search-results {
      position: absolute;
      top: 100%;
      left: 0;
      right: 0;
      background: white;
      border: 1px solid var(--border-color);
      border-radius: var(--border-radius);
      box-shadow: var(--box-shadow);
      z-index: 1000;
      max-height: 300px;
      overflow-y: auto;

      .customer-item {
        padding: 0.75rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
        cursor: pointer;
        border-bottom: 1px solid var(--border-color);

        &:last-child {
          border-bottom: none;
        }

        &:hover {
          background: var(--bg-secondary);
        }

        .customer-info {
          h4 {
            margin: 0;
            font-size: 1rem;
          }

          p {
            margin: 0.25rem 0 0;
            color: var(--text-secondary);
            font-size: 0.9rem;
          }
        }

        .customer-points {
          padding: 0.25rem 0.5rem;
          background: rgba(var(--primary-color), 0.1);
          color: var(--primary-color);
          border-radius: 12px;
          font-size: 0.8rem;
        }
      }
    }

    .no-results {
      padding: 1rem;
      text-align: center;
      color: var(--text-secondary);
    }
  }

  .selected-customer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.75rem;
    background: var(--bg-secondary);
    border-radius: var(--border-radius);

    .customer-details {
      display: flex;
      align-items: center;
      gap: 1rem;

      .avatar {
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: var(--primary-color);
        color: white;
        border-radius: 50%;
        font-weight: bold;
      }

      .info {
        h3 {
          margin: 0;
          font-size: 1rem;
        }

        p {
          margin: 0.25rem 0;
          color: var(--text-secondary);
          font-size: 0.9rem;
        }

        .badges {
          display: flex;
          gap: 0.5rem;
          margin-top: 0.25rem;

          span {
            padding: 0.25rem 0.5rem;
            border-radius: 12px;
            font-size: 0.8rem;

            &.membership-badge {
              &.basic {
                background: rgba(var(--text-secondary), 0.1);
                color: var(--text-secondary);
              }
              &.silver {
                background: rgba(158, 158, 158, 0.1);
                color: #757575;
              }
              &.gold {
                background: rgba(255, 193, 7, 0.1);
                color: #ffc107;
              }
              &.platinum {
                background: rgba(0, 150, 136, 0.1);
                color: #009688;
              }
            }

            &.points-badge {
              background: rgba(var(--primary-color), 0.1);
              color: var(--primary-color);
            }
          }
        }
      }
    }

    .remove-btn {
      padding: 0.5rem;
      background: none;
      border: none;
      color: var(--danger-color);
      cursor: pointer;
      opacity: 0.7;

      &:hover {
        opacity: 1;
      }
    }
  }
}
</style>