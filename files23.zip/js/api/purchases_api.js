export class PurchasesAPI {
    constructor() {
        this.baseUrl = '/api/v1/purchases';
        this.defaultHeaders = {
            'Content-Type': 'application/json',
            'X-User-Id': 'mostafamohammad7760',
            'X-Timestamp': new Date().toISOString()
        };
    }

    async request(endpoint, options = {}) {
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                ...options,
                headers: {
                    ...this.defaultHeaders,
                    ...options.headers
                }
            });

            if (!response.ok) {
                throw await this.handleErrorResponse(response);
            }

            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            throw this.createUserFriendlyError(error);
        }
    }

    // طلبات لوحة المعلومات
    async getPurchasesStats() {
        return this.request('/dashboard/purchases-stats');
    }

    async getOrderStats() {
        return this.request('/dashboard/order-stats');
    }

    async getQuotationStats() {
        return this.request('/dashboard/quotation-stats');
    }

    async getPayablesStats() {
        return this.request('/dashboard/payables-stats');
    }

    async getPurchasesAnalysis(period = 'month') {
        return this.request(`/dashboard/purchases-analysis?period=${period}`);
    }

    async getTopItems(period = 'month') {
        return this.request(`/dashboard/top-items?period=${period}`);
    }

    async getLatestRequests() {
        return this.request('/dashboard/latest-requests');
    }

    // طلبات الموردين
    async getSuppliers(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/suppliers?${queryString}`);
    }

    async getSupplier(supplierId) {
        return this.request(`/suppliers/${supplierId}`);
    }

    async createSupplier(supplierData) {
        this.validateSupplierData(supplierData);
        return this.request('/suppliers', {
            method: 'POST',
            body: JSON.stringify(supplierData)
        });
    }

    async updateSupplier(supplierId, supplierData) {
        this.validateSupplierData(supplierData);
        return this.request(`/suppliers/${supplierId}`, {
            method: 'PUT',
            body: JSON.stringify(supplierData)
        });
    }

    async deleteSupplier(supplierId) {
        return this.request(`/suppliers/${supplierId}`, {
            method: 'DELETE'
        });
    }

    // طلبات طلبات الشراء
    async getPurchaseRequests(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/requests?${queryString}`);
    }

    async getPurchaseRequest(requestId) {
        return this.request(`/requests/${requestId}`);
    }

    async createPurchaseRequest(requestData) {
        this.validateRequestData(requestData);
        return this.request('/requests', {
            method: 'POST',
            body: JSON.stringify(requestData)
        });
    }

    async updatePurchaseRequest(requestId, requestData) {
        this.validateRequestData(requestData);
        return this.request(`/requests/${requestId}`, {
            method: 'PUT',
            body: JSON.stringify(requestData)
        });
    }

    async approvePurchaseRequest(requestId) {
        return this.request(`/requests/${requestId}/approve`, {
            method: 'PUT'
        });
    }

    async rejectPurchaseRequest(requestId, reason) {
        return this.request(`/requests/${requestId}/reject`, {
            method: 'PUT',
            body: JSON.stringify({ reason })
        });
    }

    async cancelPurchaseRequest(requestId, reason) {
        return this.request(`/requests/${requestId}/cancel`, {
            method: 'PUT',
            body: JSON.stringify({ reason })
        });
    }

    // طلبات عروض أسعار الموردين
    async getSupplierQuotations(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/quotations?${queryString}`);
    }

    async getSupplierQuotation(quotationId) {
        return this.request(`/quotations/${quotationId}`);
    }

    async createSupplierQuotation(quotationData) {
        this.validateQuotationData(quotationData);
        return this.request('/quotations', {
            method: 'POST',
            body: JSON.stringify(quotationData)
        });
    }

    async updateSupplierQuotation(quotationId, quotationData) {
        this.validateQuotationData(quotationData);
        return this.request(`/quotations/${quotationId}`, {
            method: 'PUT',
            body: JSON.stringify(quotationData)
        });
    }

    async acceptSupplierQuotation(quotationId) {
        return this.request(`/quotations/${quotationId}/accept`, {
            method: 'PUT'
        });
    }

    async rejectSupplierQuotation(quotationId, reason) {
        return this.request(`/quotations/${quotationId}/reject`, {
            method: 'PUT',
            body: JSON.stringify({ reason })
        });
    }

    // طلبات أوامر الشراء
    async getPurchaseOrders(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/orders?${queryString}`);
    }

    async getPurchaseOrder(orderId) {
        return this.request(`/orders/${orderId}`);
    }

    async createPurchaseOrder(orderData) {
        this.validateOrderData(orderData);
        return this.request('/orders', {
            method: 'POST',
            body: JSON.stringify(orderData)
        });
    }

    async updatePurchaseOrder(orderId, orderData) {
        this.validateOrderData(orderData);
        return this.request(`/orders/${orderId}`, {
            method: 'PUT',
            body: JSON.stringify(orderData)
        });
    }

    async confirmPurchaseOrder(orderId) {
        return this.request(`/orders/${orderId}/confirm`, {
            method: 'PUT'
        });
    }

    async receivePurchaseOrder(orderId, receivingData) {
        return this.request(`/orders/${orderId}/receive`, {
            method: 'PUT',
            body: JSON.stringify(receivingData)
        });
    }

    async cancelPurchaseOrder(orderId, reason) {
        return this.request(`/orders/${orderId}/cancel`, {
            method: 'PUT',
            body: JSON.stringify({ reason })
        });
    }

    // طلبات فواتير المشتريات
    async getPurchaseInvoices(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/invoices?${queryString}`);
    }

    async getPurchaseInvoice(invoiceId) {
        return this.request(`/invoices/${invoiceId}`);
    }

    async createPurchaseInvoice(invoiceData) {
        this.validateInvoiceData(invoiceData);
        return this.request('/invoices', {
            method: 'POST',
            body: JSON.stringify(invoiceData)
        });
    }

    async updatePurchaseInvoice(invoiceId, invoiceData) {
        this.validateInvoiceData(invoiceData);
        return this.request(`/invoices/${invoiceId}`, {
            method: 'PUT',
            body: JSON.stringify(invoiceData)
        });
    }

    async postPurchaseInvoice(invoiceId) {
        return this.request(`/invoices/${invoiceId}/post`, {
            method: 'PUT'
        });
    }

    async makePayment(invoiceId, paymentData) {
        this.validatePaymentData(paymentData);
        return this.request(`/invoices/${invoiceId}/pay`, {
            method: 'PUT',
            body: JSON.stringify(paymentData)
        });
    }

    async cancelPurchaseInvoice(invoiceId, reason) {
        return this.request(`/invoices/${invoiceId}/cancel`, {
            method: 'PUT',
            body: JSON.stringify({ reason })
        });
    }

    // طلبات مرتجعات المشتريات
    async getPurchaseReturns(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/returns?${queryString}`);
    }

    async getPurchaseReturn(returnId) {
        return this.request(`/returns/${returnId}`);
    }

    async createPurchaseReturn(returnData) {
        this.validateReturnData(returnData);
        return this.request('/returns', {
            method: 'POST',
            body: JSON.stringify(returnData)
        });
    }

    async updatePurchaseReturn(returnId, returnData) {
        this.validateReturnData(returnData);
        return this.request(`/returns/${returnId}`, {
            method: 'PUT',
            body: JSON.stringify(returnData)
        });
    }

    async postPurchaseReturn(returnId) {
        return this.request(`/returns/${returnId}/post`, {
            method: 'PUT'
        });
    }

    async cancelPurchaseReturn(returnId, reason) {
        return this.request(`/returns/${returnId}/cancel`, {
            method: 'PUT',
            body: JSON.stringify({ reason })
        });
    }

    // طلبات التقارير
    async getPurchasesReport(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/purchases?${queryString}`);
    }

    async getSupplierStatement(supplierId, params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/supplier-statement/${supplierId}?${queryString}`);
    }

    async getItemPurchasesReport(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/item-purchases?${queryString}`);
    }

    async getPurchasesBySupplierReport(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/purchases-by-supplier?${queryString}`);
    }

    // توابع التحقق من صحة البيانات
    validateSupplierData(supplierData) {
        const requiredFields = ['code', 'name'];
        
        const missingFields = requiredFields.filter(field => !supplierData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        if (supplierData.email && !this.isValidEmail(supplierData.email)) {
            throw new Error('البريد الإلكتروني غير صالح');
        }

        return true;
    }

    validateRequestData(requestData) {
        if (!requestData.departmentId || !requestData.items?.length) {
            throw new Error('القسم والأصناف مطلوبة');
        }

        requestData.items.forEach((item, index) => {
            if (!item.itemId || !item.quantity) {
                throw new Error(`البند رقم ${index + 1} يحتوي على بيانات ناقصة`);
            }
        });

        return true;
    }

    validateQuotationData(quotationData) {
        if (!quotationData.supplierId || !quotationData.items?.length) {
            throw new Error('المورد والأصناف مطلوبة');
        }

        quotationData.items.forEach((item, index) => {
            if (!item.itemId || !item.quantity || !item.unitPrice) {
                throw new Error(`البند رقم ${index + 1} يحتوي على بيانات ناقصة`);
            }
        });

        return true;
    }

    validateOrderData(orderData) {
        if (!orderData.supplierId || !orderData.items?.length) {
            throw new Error('المورد والأصناف مطلوبة');
        }

        orderData.items.forEach((item, index) => {
            if (!item.itemId || !item.quantity || !item.unitPrice) {
                throw new Error(`البند رقم ${index + 1} يحتوي على بيانات ناقصة`);
            }
        });

        return true;
    }

    validateInvoiceData(invoiceData) {
        if (!invoiceData.supplierId || !invoiceData.items?.length) {
            throw new Error('المورد والأصناف مطلوبة');
        }

        invoiceData.items.forEach((item, index) => {
            if (!item.itemId || !item.quantity || !item.unitPrice) {
                throw new Error(`البند رقم ${index + 1} يحتوي على بيانات ناقصة`);
            }
        });

        return true;
    }

    validateReturnData(returnData) {
        if (!returnData.supplierId || !returnData.items?.length) {
            throw new Error('المورد والأصناف مطلوبة');
        }

        returnData.items.forEach((item, index) => {
            if (!item.itemId || !item.quantity || !item.unitPrice) {
                throw new Error(`البند رقم ${index + 1} يحتوي على بيانات ناقصة`);
            }
        });

        if (!returnData.reason) {
            throw new Error('سبب المرتجع مطلوب');
        }

        return true;
    }

    validatePaymentData(paymentData) {
        if (!paymentData.amount || paymentData.amount <= 0) {
            throw new Error('مبلغ الدفعة غير صالح');
        }

        if (!paymentData.paymentMethod) {
            throw new Error('طريقة الدفع مطلوبة');
        }

        return true;
    }

    // توابع مساعدة
    isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    // توابع معالجة الأخطاء
    async handleErrorResponse(response) {
        let error;
        try {
            const errorData = await response.json();
            error = new Error(errorData.message || 'حدث خطأ غير معروف');
            error.code = errorData.code;
            error.details = errorData.details;
        } catch {
            error = new Error(`خطأ في الطلب: ${response.status}`);
        }
        error.status = response.status;
        return error;
    }

    createUserFriendlyError(error) {
        const errorMessages = {
            400: 'البيانات المدخلة غير صحيحة',
            401: 'يرجى تسجيل الدخول مرة أخرى',
            403: 'ليس لديك صلاحية للقيام بهذا الإجراء',
            404: 'لم يتم العثور على البيانات المطلوبة',
            409: 'تعارض في البيانات',
            422: 'البيانات المدخلة غير صالحة',
            500: 'حدث خطأ في النظام'
        };

        return new Error(
            errorMessages[error.status] || 
            error.message || 
            'حدث خطأ غير متوقع'
        );
    }
}