/**
 * واجهة نقطة البيع الرئيسية
 * التاريخ: 2025-05-09 04:11:08
 * المستخدم: mostafamohammad7760
 */

<template>
  <div class="pos-main">
    <!-- الشريط العلوي -->
    <div class="pos-header">
      <div class="header-info">
        <div class="user-info">
          <i class="fas fa-user-circle"></i>
          <span>{{ currentUser.name }}</span>
          <span class="separator">|</span>
          <span>الوردية: {{ currentShift.name }}</span>
        </div>
        <div class="date-time">
          <i class="fas fa-clock"></i>
          <span>{{ currentDateTime }}</span>
        </div>
      </div>
      <div class="header-actions">
        <BaseButton
          icon="fa-calculator"
          variant="light"
          @click="openCalculator"
        >
          الحاسبة
        </BaseButton>
        <BaseButton
          icon="fa-keyboard"
          variant="light"
          @click="toggleNumpad"
        >
          لوحة الأرقام
        </BaseButton>
        <BaseButton
          icon="fa-cash-drawer"
          variant="warning"
          @click="openCashDrawer"
        >
          درج النقدية
        </BaseButton>
        <BaseButton
          icon="fa-sign-out-alt"
          variant="danger"
          @click="closeShift"
        >
          إغلاق الوردية
        </BaseButton>
      </div>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="pos-content">
      <!-- القائمة اليمنى - تفاصيل المبيعات -->
      <div class="sales-panel">
        <!-- معلومات العميل -->
        <div class="customer-section">
          <div class="section-header">
            <h3>العميل</h3>
            <BaseButton
              size="sm"
              variant="primary"
              icon="fa-plus"
              @click="addNewCustomer"
            >
              عميل جديد
            </BaseButton>
          </div>
          <BaseSelect
            v-model="selectedCustomer"
            :options="customers"
            labelKey="name"
            valueKey="id"
            searchable
            placeholder="اختر العميل..."
            class="customer-select"
          >
            <template #option="{ option }">
              <div class="customer-option">
                <span>{{ option.name }}</span>
                <small>{{ option.phone }}</small>
              </div>
            </template>
          </BaseSelect>

          <!-- معلومات نقاط الولاء -->
          <div v-if="selectedCustomer" class="loyalty-info">
            <div class="points">
              <i class="fas fa-star"></i>
              النقاط المتاحة: {{ selectedCustomer.loyaltyPoints }}
            </div>
            <div class="balance">
              <i class="fas fa-wallet"></i>
              الرصيد: {{ formatCurrency(selectedCustomer.balance) }}
            </div>
          </div>
        </div>

        <!-- قائمة المنتجات المختارة -->
        <div class="cart-section">
          <div class="section-header">
            <h3>المنتجات المختارة</h3>
            <BaseButton
              size="sm"
              variant="danger"
              icon="fa-trash"
              @click="clearCart"
              :disabled="!cartItems.length"
            >
              مسح الكل
            </BaseButton>
          </div>
          
          <div class="cart-items" ref="cartItemsList">
            <div
              v-for="item in cartItems"
              :key="item.id"
              class="cart-item"
            >
              <div class="item-info">
                <h4>{{ item.name }}</h4>
                <p class="item-details">
                  <span>{{ formatCurrency(item.price) }}</span>
                  <span>×</span>
                  <span>{{ item.quantity }}</span>
                </p>
              </div>
              <div class="item-total">
                {{ formatCurrency(item.total) }}
              </div>
              <div class="item-actions">
                <button @click="decreaseQuantity(item)">
                  <i class="fas fa-minus"></i>
                </button>
                <button @click="increaseQuantity(item)">
                  <i class="fas fa-plus"></i>
                </button>
                <button @click="removeItem(item)">
                  <i class="fas fa-trash"></i>
                </button>
              </div>
            </div>
          </div>

          <!-- ملخص الفاتورة -->
          <div class="cart-summary">
            <div class="summary-row">
              <span>المجموع</span>
              <span>{{ formatCurrency(subtotal) }}</span>
            </div>
            <div class="summary-row">
              <span>الخصم</span>
              <div class="discount-input">
                <BaseInput
                  v-model="discountValue"
                  type="number"
                  size="sm"
                />
                <BaseSelect
                  v-model="discountType"
                  :options="[
                    { label: '%', value: 'percentage' },
                    { label: 'ريال', value: 'fixed' }
                  ]"
                  size="sm"
                />
              </div>
            </div>
            <div class="summary-row">
              <span>الضريبة ({{ taxRate }}%)</span>
              <span>{{ formatCurrency(taxAmount) }}</span>
            </div>
            <div class="summary-row total">
              <span>الإجمالي</span>
              <span>{{ formatCurrency(total) }}</span>
            </div>
          </div>

          <!-- أزرار العمليات -->
          <div class="cart-actions">
            <BaseButton
              block
              size="lg"
              variant="success"
              icon="fa-money-bill-wave"
              :disabled="!cartItems.length"
              @click="showPaymentModal"
            >
              دفع ({{ formatCurrency(total) }})
            </BaseButton>
            <div class="secondary-actions">
              <BaseButton
                variant="info"
                icon="fa-save"
                :disabled="!cartItems.length"
                @click="saveAsDraft"
              >
                حفظ كمسودة
              </BaseButton>
              <BaseButton
                variant="warning"
                icon="fa-pause"
                :disabled="!cartItems.length"
                @click="holdTransaction"
              >
                تعليق العملية
              </BaseButton>
              <BaseButton
                variant="light"
                icon="fa-print"
                :disabled="!cartItems.length"
                @click="printPreview"
              >
                معاينة الطباعة
              </BaseButton>
            </div>
          </div>
        </div>
      </div>

      <!-- القائمة اليسرى - المنتجات -->
      <div class="products-panel">
        <!-- شريط البحث -->
        <div class="search-section">
          <BaseInput
            v-model="searchQuery"
            placeholder="بحث عن منتج..."
            :clearable="true"
          >
            <template #prefix>
              <i class="fas fa-search"></i>
            </template>
          </BaseInput>
          <BaseInput
            v-model="barcodeInput"
            placeholder="مسح/إدخال الباركود..."
            @keyup.enter="handleBarcode"
          >
            <template #prefix>
              <i class="fas fa-barcode"></i>
            </template>
          </BaseInput>
        </div>

        <!-- تصفية المنتجات -->
        <div class="filters-section">
          <BaseSelect
            v-model="selectedCategory"
            :options="categories"
            placeholder="جميع الفئات"
            clearable
          />
          <div class="view-options">
            <button
              :class="{ active: viewMode === 'grid' }"
              @click="viewMode = 'grid'"
            >
              <i class="fas fa-th"></i>
            </button>
            <button
              :class="{ active: viewMode === 'list' }"
              @click="viewMode = 'list'"
            >
              <i class="fas fa-list"></i>
            </button>
          </div>
        </div>

        <!-- عرض المنتجات -->
        <div
          :class="[
            'products-grid',
            `view-${viewMode}`,
            { 'is-loading': loading }
          ]"
        >
          <div
            v-for="product in filteredProducts"
            :key="product.id"
            class="product-card"
            @click="addToCart(product)"
          >
            <div class="product-image">
              <img :src="product.image" :alt="product.name">
              <span v-if="product.quantity <= 0" class="out-of-stock">
                نفذت الكمية
              </span>
            </div>
            <div class="product-info">
              <h4>{{ product.name }}</h4>
              <p class="product-price">
                {{ formatCurrency(product.price) }}
              </p>
              <small class="product-stock">
                المتوفر: {{ product.quantity }}
              </small>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- نافذة الدفع -->
    <PaymentModal
      v-if="showPayment"
      :amount="total"
      :customer="selectedCustomer"
      @close="showPayment = false"
      @complete="completeTransaction"
    />

    <!-- لوحة الأرقام -->
    <NumpadPanel
      v-if="showNumpad"
      v-model="numpadValue"
      @close="showNumpad = false"
    />
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, computed, onMounted, onUnmounted } from 'vue';
import { useStore } from 'vuex';
import { useRouter } from 'vue-router';
import { formatCurrency } from '@/utils/currency';
import PaymentModal from '@/components/pos/PaymentModal.vue';
import NumpadPanel from '@/components/pos/NumpadPanel.vue';

export default defineComponent({
  name: 'POSMain',

  components: {
    PaymentModal,
    NumpadPanel
  },

  setup() {
    const store = useStore();
    const router = useRouter();

    // الحالة
    const searchQuery = ref('');
    const barcodeInput = ref('');
    const selectedCategory = ref(null);
    const selectedCustomer = ref(null);
    const viewMode = ref('grid');
    const loading = ref(false);
    const showPayment = ref(false);
    const showNumpad = ref(false);
    const numpadValue = ref('');
    const discountValue = ref(0);
    const discountType = ref('percentage');

    // البيانات المحسوبة
    const currentUser = computed(() => store.state.auth.user);
    const currentShift = computed(() => store.state.pos.currentShift);
    const currentDateTime = computed(() => {
      return new Date().toLocaleString('ar-SA');
    });

    const cartItems = computed(() => store.state.pos.cartItems);
    const customers = computed(() => store.state.customers.list);
    const categories = computed(() => store.state.products.categories);
    const products = computed(() => store.state.products.list);

    const filteredProducts = computed(() => {
      let filtered = [...products.value];
      
      if (searchQuery.value) {
        filtered = filtered.filter(product => 
          product.name.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
          product.barcode.includes(searchQuery.value)
        );
      }

      if (selectedCategory.value) {
        filtered = filtered.filter(product => 
          product.categoryId === selectedCategory.value
        );
      }

      return filtered;
    });

    // حسابات الفاتورة
    const subtotal = computed(() => {
      return cartItems.value.reduce((sum, item) => sum + item.total, 0);
    });

    const taxRate = computed(() => store.state.settings.taxRate);

    const discountAmount = computed(() => {
      if (discountType.value === 'percentage') {
        return subtotal.value * (discountValue.value / 100);
      }
      return discountValue.value;
    });

    const taxAmount = computed(() => {
      return (subtotal.value - discountAmount.value) * (taxRate.value / 100);
    });

    const total = computed(() => {
      return subtotal.value - discountAmount.value + taxAmount.value;
    });

    // الوظائف
    const addToCart = (product: any) => {
      if (product.quantity <= 0) return;
      
      store.dispatch('pos/addToCart', product);
    };

    const removeItem = (item: any) => {
      store.dispatch('pos/removeFromCart', item);
    };

    const increaseQuantity = (item: any) => {
      store.dispatch('pos/updateCartItemQuantity', {
        id: item.id,
        quantity: item.quantity + 1
      });
    };

    const decreaseQuantity = (item: any) => {
      if (item.quantity > 1) {
        store.dispatch('pos/updateCartItemQuantity', {
          id: item.id,
          quantity: item.quantity - 1
        });
      }
    };

    const clearCart = () => {
      store.dispatch('pos/clearCart');
    };

    const handleBarcode = () => {
      if (!barcodeInput.value) return;

      const product = products.value.find(p => p.barcode === barcodeInput.value);
      if (product) {
        addToCart(product);
      }
      
      barcodeInput.value = '';
    };

    const completeTransaction = async (paymentDetails: any) => {
      try {
        loading.value = true;
        await store.dispatch('pos/completeTransaction', {
          items: cartItems.value,
          customer: selectedCustomer.value,
          payment: paymentDetails,
          discount: {
            value: discountValue.value,
            type: discountType.value
          },
          tax: taxAmount.value
        });

        // إعادة تعيين الحالة
        clearCart();
        selectedCustomer.value = null;
        discountValue.value = 0;
        showPayment.value = false;

      } catch (error) {
        console.error('خطأ في إتمام العملية:', error);
      } finally {
        loading.value = false;
      }
    };

    // تحميل البيانات الأولية
    onMounted(async () => {
      loading.value = true;
      try {
        await Promise.all([
          store.dispatch('customers/fetchCustomers'),
          store.dispatch('products/fetchProducts'),
          store.dispatch('products/fetchCategories')
        ]);
      } catch (error) {
        console.error('خطأ في تحميل البيانات:', error);
      } finally {
        loading.value = false;
      }
    });

    return {
      // الحالة
      searchQuery,
      barcodeInput,
      selectedCategory,
      selectedCustomer,
      viewMode,
      loading,
      showPayment,
      showNumpad,
      numpadValue,
      discountValue,
      discountType,

      // البيانات المحسوبة
      currentUser,
      currentShift,
      currentDateTime,
      cartItems,
      customers,
      categories,
      filteredProducts,
      subtotal,
      taxRate,
      taxAmount,
      total,

      // الوظائف
      formatCurrency,
      addToCart,
      removeItem,
      increaseQuantity,
      decreaseQuantity,
      clearCart,
      handleBarcode,
      completeTransaction
    };
  }
});
</script>

<style lang="scss" scoped>
.pos-main {
  display: flex;
  flex-direction: column;
  height: 100%;
  background: var(--bg-secondary);

  // تنسيقات الشريط العلوي
  .pos-header {
    background: var(--bg-primary);
    padding: 1rem;
    border-bottom: 1px solid var(--border-color);
    display: flex;
    justify-content: space-between;
    align-items: center;
    
    .header-info {
      display: flex;
      gap: 2rem;
      
      .user-info,
      .date-time {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        
        i {
          color: var(--primary-color);
        }
        
        .separator {
          color: var(--border-color);
        }
      }
    }
    
    .header-actions {
      display: flex;
      gap: 0.5rem;
    }
  }

  // تنسيقات المحتوى الرئيسي
  .pos-content {
    flex: 1;
    display: grid;
    grid-template-columns: 1fr 400px;
    gap: 1rem;
    padding: 1rem;
    height: calc(100vh - 64px);
    overflow: hidden;
  }

  // تنسيقات قائمة المبيعات
  .sales-panel {
    background: var(--bg-primary);
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
    display: flex;
    flex-direction: column;
    
    .section-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem;
      border-bottom: 1px solid var(--border-color);
      
      h3 {
        margin: 0;
        font-size: 1.125rem;
      }
    }
    
    .customer-section {
      padding: 1rem;
      
      .loyalty-info {
        margin-top: 0.5rem;
        display: flex;
        gap: 1rem;
        font-size: 0.875rem;
        
        > div {
          display: flex;
          align-items: center;
          gap: 0.25rem;
          
          i {
            color: var(--primary-color);
          }
        }
      }
    }
    
    .cart-section {
      flex: 1;
      display: flex;
      flex-direction: column;
      
      .cart-items {
        flex: 1;
        overflow-y: auto;
        padding: 1rem;
        
        .cart-item {
          display: flex;
          align-items: center;
          gap: 1rem;
          padding: 0.5rem;
          border-bottom: 1px solid var(--border-color);
          
          &:last-child {
            border-bottom: none;
          }
          
          .item-info {
            flex: 1;
            
            h4 {
              margin: 0;
              font-size: 1rem;
            }
            
            .item-details {
              margin: 0.25rem 0 0;
              font-size: 0.875rem;
              color: var(--text-secondary);
            }
          }
          
          .item-total {
            font-weight: 500;
          }
          
          .item-actions {
            display: flex;
            gap: 0.25rem;
            
            button {
              padding: 0.25rem;
              border: none;
              background: none;
              color: var(--text-secondary);
              cursor: pointer;
              
              &:hover {
                color: var(--primary-color);
              }
            }
          }
        }
      }
      
      .cart-summary {
        padding: 1rem;
        background: var(--bg-secondary);
        
        .summary-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 0.5rem 0;
          
          &.total {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--primary-color);
            border-top: 1px solid var(--border-color);
            margin-top: 0.5rem;
            padding-top: 1rem;
          }
          
          .discount-input {
            display: flex;
            gap: 0.5rem;
            width: 150px;
          }
        }
      }
      
      .cart-actions {
        padding: 1rem;
        
        .secondary-actions {
          display: flex;
          gap: 0.5rem;
          margin-top: 0.5rem;
        }
      }
    }
  }

  // تنسيقات قائمة المنتجات
  .products-panel {
    background: var(--bg-primary);
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
    display: flex;
    flex-direction: column;
    
    .search-section {
      padding: 1rem;
      display: flex;
      gap: 0.5rem;
    }
    
    .filters-section {
      padding: 0 1rem 1rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      
      .view-options {
        display: flex;
        gap: 0.25rem;
        
        button {
          padding: 0.5rem;
          border: 1px solid var(--border-color);
          background: var(--bg-primary);
          color: var(--text-secondary);
          cursor: pointer;
          
          &.active {
            background: var(--primary-color);
            color: var(--primary-contrast);
            border-color: var(--primary-color);
          }
        }
      }
    }
    
    .products-grid {
      flex: 1;
      overflow-y: auto;
      padding: 1rem;
      display: grid;
      gap: 1rem;
      
      &.view-grid {
        grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
        
        .product-card {
          display: flex;
          flex-direction: column;
          
          .product-image {
            aspect-ratio: 1;
            
            img {
              width: 100%;
              height: 100%;
              object-fit: cover;
            }
          }
        }
      }
      
      &.view-list {
        grid-template-columns: 1fr;
        
        .product-card {
          display: flex;
          gap: 1rem;
          
          .product-image {
            width: 80px;
            height: 80px;
            
            img {
              width: 100%;
              height: 100%;
              object-fit: cover;
            }
          }
        }
      }
      
      .product-card {
        background: var(--bg-primary);
        border: 1px solid var(--border-color);
        border-radius: var(--border-radius);
        overflow: hidden;
        cursor: pointer;
        transition: all 0.2s ease;
        
        &:hover {
          border-color: var(--primary-color);
          transform: translateY(-2px);
        }
        
        .product-image {
          position: relative;
          
          .out-of-stock {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.7);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.875rem;
          }
        }
        
        .product-info {
          padding: 0.75rem;
          
          h4 {
            margin: 0;
            font-size: 1rem;
          }
          
          .product-price {
            margin: 0.25rem 0;
            font-weight: 500;
            color: var(--primary-color);
          }
          
          .product-stock {
            color: var(--text-secondary);
            font-size: 0.75rem;
          }
        }
      }
    }
  }
}
</style>