/**
 * مكون القائمة المنسدلة الأساسي
 * التاريخ: 2025-05-09 03:53:55
 * المستخدم: mostafamohammad7760
 */

<template>
  <div 
    :class="[
      'base-select',
      {
        'is-open': isOpen,
        'has-error': error,
        'is-disabled': disabled,
        'is-loading': loading,
        'is-multiple': multiple
      }
    ]"
    @click.stop="toggleDropdown"
    v-click-outside="closeDropdown"
  >
    <!-- التسمية -->
    <label v-if="label" :for="selectId" class="select-label">
      {{ label }}
      <span v-if="required" class="required-mark">*</span>
    </label>

    <div class="select-wrapper">
      <!-- منطقة العرض -->
      <div class="select-display" :tabindex="disabled ? -1 : 0">
        <!-- القيمة المحددة -->
        <div class="selected-value" v-if="!multiple">
          <template v-if="selectedOption">
            <slot name="option" :option="selectedOption">
              {{ getOptionLabel(selectedOption) }}
            </slot>
          </template>
          <span v-else class="placeholder">{{ placeholder }}</span>
        </div>

        <!-- القيم المتعددة المحددة -->
        <div v-else class="selected-tags">
          <template v-if="selectedOptions.length">
            <div
              v-for="option in selectedOptions"
              :key="getOptionValue(option)"
              class="selected-tag"
            >
              <slot name="tag" :option="option">
                {{ getOptionLabel(option) }}
              </slot>
              <button
                type="button"
                class="remove-tag"
                @click.stop="removeOption(option)"
              >
                <i class="fas fa-times"></i>
              </button>
            </div>
          </template>
          <span v-else class="placeholder">{{ placeholder }}</span>
        </div>

        <!-- أيقونات الحالة -->
        <div class="select-icons">
          <i v-if="loading" class="loading-icon fas fa-spinner fa-spin"></i>
          <i v-else-if="clearable && hasValue" 
             class="clear-icon fas fa-times"
             @click.stop="clearSelection"
          ></i>
          <i v-else class="dropdown-icon fas fa-chevron-down"
             :class="{ 'is-open': isOpen }"
          ></i>
        </div>
      </div>

      <!-- قائمة الخيارات -->
      <transition name="fade">
        <div v-if="isOpen" class="select-dropdown">
          <!-- شريط البحث -->
          <div v-if="searchable" class="search-box">
            <input
              ref="searchInput"
              v-model="searchQuery"
              type="text"
              :placeholder="searchPlaceholder"
              @click.stop
              @input="handleSearch"
            >
          </div>

          <!-- قائمة الخيارات -->
          <div class="options-list" ref="optionsList">
            <template v-if="filteredOptions.length">
              <div
                v-for="option in filteredOptions"
                :key="getOptionValue(option)"
                class="option-item"
                :class="{
                  'is-selected': isOptionSelected(option),
                  'is-focused': focusedOptionIndex === getOptionIndex(option)
                }"
                @click.stop="selectOption(option)"
                @mouseover="focusedOptionIndex = getOptionIndex(option)"
              >
                <slot name="option" :option="option">
                  {{ getOptionLabel(option) }}
                </slot>
              </div>
            </template>
            
            <!-- رسالة عدم وجود نتائج -->
            <div v-else class="no-results">
              {{ noResultsText }}
            </div>
          </div>
        </div>
      </transition>
    </div>

    <!-- رسالة الخطأ -->
    <div v-if="error" class="error-message">
      {{ error }}
    </div>

    <!-- نص المساعدة -->
    <div v-if="hint && !error" class="hint-text">
      {{ hint }}
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, computed, watch, nextTick, PropType } from 'vue';
import { vClickOutside } from '@/directives/click-outside';

export default defineComponent({
  name: 'BaseSelect',

  directives: {
    clickOutside: vClickOutside
  },

  props: {
    // القيمة المحددة
    modelValue: {
      type: [String, Number, Object, Array],
      default: null
    },
    // الخيارات
    options: {
      type: Array,
      required: true
    },
    // التسمية
    label: {
      type: String,
      default: ''
    },
    // النص التلميحي
    placeholder: {
      type: String,
      default: 'اختر...'
    },
    // مفتاح التسمية
    labelKey: {
      type: String,
      default: 'label'
    },
    // مفتاح القيمة
    valueKey: {
      type: String,
      default: 'value'
    },
    // إلزامي
    required: {
      type: Boolean,
      default: false
    },
    // معطل
    disabled: {
      type: Boolean,
      default: false
    },
    // متعدد الاختيار
    multiple: {
      type: Boolean,
      default: false
    },
    // قابل للبحث
    searchable: {
      type: Boolean,
      default: false
    },
    // نص البحث التلميحي
    searchPlaceholder: {
      type: String,
      default: 'ابحث...'
    },
    // قابل للمسح
    clearable: {
      type: Boolean,
      default: false
    },
    // جاري التحميل
    loading: {
      type: Boolean,
      default: false
    },
    // رسالة الخطأ
    error: {
      type: String,
      default: ''
    },
    // نص المساعدة
    hint: {
      type: String,
      default: ''
    },
    // نص عدم وجود نتائج
    noResultsText: {
      type: String,
      default: 'لا توجد نتائج'
    }
  },

  emits: [
    'update:modelValue',
    'change',
    'search',
    'open',
    'close',
    'clear'
  ],

  setup(props, { emit }) {
    const isOpen = ref(false);
    const searchQuery = ref('');
    const focusedOptionIndex = ref(-1);
    const selectId = ref(`select-${Date.now()}`);
    const searchInput = ref<HTMLInputElement | null>(null);
    const optionsList = ref<HTMLElement | null>(null);

    // الخيارات المفلترة
    const filteredOptions = computed(() => {
      if (!searchQuery.value) return props.options;

      return props.options.filter(option => {
        const label = getOptionLabel(option).toLowerCase();
        return label.includes(searchQuery.value.toLowerCase());
      });
    });

    // القيمة المحددة
    const selectedOption = computed(() => {
      if (!props.modelValue) return null;
      return props.options.find(option => 
        getOptionValue(option) === props.modelValue
      );
    });

    // القيم المتعددة المحددة
    const selectedOptions = computed(() => {
      if (!props.multiple || !Array.isArray(props.modelValue)) return [];
      return props.options.filter(option =>
        props.modelValue.includes(getOptionValue(option))
      );
    });

    // التحقق من وجود قيمة
    const hasValue = computed(() => {
      return props.multiple 
        ? selectedOptions.value.length > 0
        : selectedOption.value !== null;
    });

    // الحصول على تسمية الخيار
    const getOptionLabel = (option: any): string => {
      if (typeof option === 'string') return option;
      return option[props.labelKey] || '';
    };

    // الحصول على قيمة الخيار
    const getOptionValue = (option: any): any => {
      if (typeof option === 'string') return option;
      return option[props.valueKey];
    };

    // الحصول على مؤشر الخيار
    const getOptionIndex = (option: any): number => {
      return filteredOptions.value.indexOf(option);
    };

    // التحقق من اختيار الخيار
    const isOptionSelected = (option: any): boolean => {
      const value = getOptionValue(option);
      return props.multiple
        ? Array.isArray(props.modelValue) && props.modelValue.includes(value)
        : props.modelValue === value;
    };

    // اختيار خيار
    const selectOption = (option: any) => {
      if (props.disabled) return;

      const value = getOptionValue(option);

      if (props.multiple) {
        const newValue = Array.isArray(props.modelValue) ? [...props.modelValue] : [];
        const index = newValue.indexOf(value);

        if (index === -1) {
          newValue.push(value);
        } else {
          newValue.splice(index, 1);
        }

        emit('update:modelValue', newValue);
      } else {
        emit('update:modelValue', value);
        closeDropdown();
      }

      emit('change', props.multiple ? selectedOptions.value : selectedOption.value);
    };

    // إزالة خيار
    const removeOption = (option: any) => {
      if (props.disabled || !props.multiple) return;

      const value = getOptionValue(option);
      const newValue = (props.modelValue as any[]).filter(v => v !== value);
      emit('update:modelValue', newValue);
      emit('change', selectedOptions.value);
    };

    // مسح الاختيار
    const clearSelection = () => {
      if (props.disabled) return;

      emit('update:modelValue', props.multiple ? [] : null);
      emit('clear');
      closeDropdown();
    };

    // فتح/إغلاق القائمة
    const toggleDropdown = () => {
      if (props.disabled) return;
      isOpen.value ? closeDropdown() : openDropdown();
    };

    const openDropdown = () => {
      isOpen.value = true;
      focusedOptionIndex.value = -1;
      emit('open');

      nextTick(() => {
        if (props.searchable && searchInput.value) {
          searchInput.value.focus();
        }
      });
    };

    const closeDropdown = () => {
      isOpen.value = false;
      searchQuery.value = '';
      emit('close');
    };

    // معالجة البحث
    const handleSearch = () => {
      emit('search', searchQuery.value);
    };

    // معالجة الضغط على المفاتيح
    const handleKeydown = (event: KeyboardEvent) => {
      if (!isOpen.value) {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          openDropdown();
        }
        return;
      }

      switch (event.key) {
        case 'Escape':
          closeDropdown();
          break;
        case 'ArrowDown':
          event.preventDefault();
          focusedOptionIndex.value = Math.min(
            focusedOptionIndex.value + 1,
            filteredOptions.value.length - 1
          );
          scrollToFocusedOption();
          break;
        case 'ArrowUp':
          event.preventDefault();
          focusedOptionIndex.value = Math.max(focusedOptionIndex.value - 1, 0);
          scrollToFocusedOption();
          break;
        case 'Enter':
          event.preventDefault();
          if (focusedOptionIndex.value >= 0) {
            selectOption(filteredOptions.value[focusedOptionIndex.value]);
          }
          break;
      }
    };

    // تمرير إلى الخيار المحدد
    const scrollToFocusedOption = () => {
      nextTick(() => {
        const focusedEl = optionsList.value?.children[focusedOptionIndex.value] as HTMLElement;
        if (focusedEl && optionsList.value) {
          const scrollTop = optionsList.value.scrollTop;
          const offsetTop = focusedEl.offsetTop;
          const offsetHeight = focusedEl.offsetHeight;
          
          if (offsetTop < scrollTop) {
            optionsList.value.scrollTop = offsetTop;
          } else if (offsetTop + offsetHeight > scrollTop + optionsList.value.clientHeight) {
            optionsList.value.scrollTop = offsetTop + offsetHeight - optionsList.value.clientHeight;
          }
        }
      });
    };

    // إضافة مستمعي الأحداث
    onMounted(() => {
      window.addEventListener('keydown', handleKeydown);
    });

    onUnmounted(() => {
      window.removeEventListener('keydown', handleKeydown);
    });

    return {
      isOpen,
      searchQuery,
      focusedOptionIndex,
      selectId,
      searchInput,
      optionsList,
      filteredOptions,
      selectedOption,
      selectedOptions,
      hasValue,
      getOptionLabel,
      getOptionValue,
      getOptionIndex,
      isOptionSelected,
      selectOption,
      removeOption,
      clearSelection,
      toggleDropdown,
      closeDropdown,
      handleSearch
    };
  }
});
</script>

<style lang="scss" scoped>
.base-select {
  position: relative;
  width: 100%;

  // التسمية
  .select-label {
    display: block;
    margin-bottom: 0.25rem;
    font-weight: 500;
    font-size: 0.875rem;
    color: var(--text-color);

    .required-mark {
      color: var(--danger-color);
      margin-right: 0.25rem;
    }
  }

  // الغلاف
  .select-wrapper {
    position: relative;
  }

  // منطقة العرض
  .select-display {
    display: flex;
    align-items: center;
    justify-content: space-between;
    min-height: 2.5rem;
    padding: 0.5rem;
    background: var(--input-bg);
    border: 1px solid var(--border-color);
    border-radius: var(--border-radius);
    cursor: pointer;
    transition: all 0.2s ease;

    &:focus {
      outline: none;
      border-color: var(--primary-color);
      box-shadow: 0 0 0 3px rgba(var(--primary-color-rgb), 0.1);
    }
  }

  // القيمة المحددة
  .selected-value {
    flex: 1;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  // القيم المتعددة
  .selected-tags {
    display: flex;
    flex-wrap: wrap;
    gap: 0.25rem;
    min-height: 1.5rem;

    .selected-tag {
      display: inline-flex;
      align-items: center;
      gap: 0.25rem;
      padding: 0.25rem 0.5rem;
      background: var(--bg-secondary);
      border-radius: var(--border-radius-sm);
      font-size: 0.875rem;

      .remove-tag {
        padding: 0;
        background: none;
        border: none;
        color: var(--text-secondary);
        cursor: pointer;
        opacity: 0.7;

        &:hover {
          opacity: 1;
        }
      }
    }
  }

  // النص التلميحي
  .placeholder {
    color: var(--text-secondary);
  }

  // أيقونات الحالة
  .select-icons {
    display: flex;
    align-items: center;
    margin-right: 0.5rem;
    color: var(--text-secondary);

    .dropdown-icon {
      transition: transform 0.2s ease;

      &.is-open {
        transform: rotate(180deg);
      }
    }
  }

  // قائمة الخيارات
  .select-dropdown {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    margin-top: 0.25rem;
    background: var(--bg-primary);
    border: 1px solid var(--border-color);
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
    z-index: 1000;
    overflow: hidden;

    // شريط البحث
    .search-box {
      padding: 0.5rem;
      border-bottom: 1px solid var(--border-color);

      input {
        width: 100%;
        padding: 0.5rem;
        border: 1px solid var(--border-color);
        border-radius: var(--border-radius-sm);
        font-size: 0.875rem;

        &:focus {
          outline: none;
          border-color: var(--primary-color);
        }
      }
    }

    // قائمة الخيارات
    .options-list {
      max-height: 200px;
      overflow-y: auto;

      .option-item {
        padding: 0.5rem 1rem;
        cursor: pointer;
        transition: all 0.2s ease;

        &:hover,
        &.is-focused {
          background: var(--bg-hover);
        }

        &.is-selected {
          background: var(--primary-color);
          color: var(--primary-contrast);
        }
      }

      .no-results {
        padding: 1rem;
        text-align: center;
        color: var(--text-secondary);
      }
    }
  }

  // رسالة الخطأ
  .error-message {
    margin-top: 0.25rem;
    font-size: 0.75rem;
    color: var(--danger-color);
  }

  // نص المساعدة
  .hint-text {
    margin-top: 0.25rem;
    font-size: 0.75rem;
    color: var(--text-secondary);
  }

  // الحالات
  &.is-disabled {
    opacity: 0.6;
    pointer-events: none;
  }

  &.has-error {
    .select-display {
      border-color: var(--danger-color);

      &:focus {
        box-shadow: 0 0 0 3px rgba(var(--danger-color-rgb), 0.1);
      }
    }
  }
}

// الرسوم المتحركة
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.2s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>