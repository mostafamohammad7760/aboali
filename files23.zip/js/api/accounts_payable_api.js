export class AccountsPayableAPI {
    constructor() {
        this.baseUrl = '/api/v1/accounts-payable';
        this.defaultHeaders = {
            'Content-Type': 'application/json',
            'X-User-Id': 'mostafamohammad7760'
        };
    }

    async request(endpoint, options = {}) {
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                ...options,
                headers: {
                    ...this.defaultHeaders,
                    ...options.headers
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    }

    // طلبات لوحة المعلومات
    async getDashboardSummary() {
        return this.request('/dashboard/summary');
    }

    async getUpcomingPayments(days = 7) {
        return this.request(`/dashboard/upcoming-payments?days=${days}`);
    }

    async getAgingSummary() {
        return this.request('/dashboard/aging-summary');
    }

    async getPaymentsHistory(months = 12) {
        return this.request(`/dashboard/payments-history?months=${months}`);
    }

    // طلبات الموردين
    async getVendors(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/vendors?${queryString}`);
    }

    async getVendor(vendorId) {
        return this.request(`/vendors/${vendorId}`);
    }

    async createVendor(vendorData) {
        return this.request('/vendors', {
            method: 'POST',
            body: JSON.stringify(vendorData)
        });
    }

    async updateVendor(vendorId, vendorData) {
        return this.request(`/vendors/${vendorId}`, {
            method: 'PUT',
            body: JSON.stringify(vendorData)
        });
    }

    // طلبات الفواتير
    async getInvoices(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/invoices?${queryString}`);
    }

    async getInvoice(invoiceId) {
        return this.request(`/invoices/${invoiceId}`);
    }

    async createInvoice(invoiceData) {
        return this.request('/invoices', {
            method: 'POST',
            body: JSON.stringify(invoiceData)
        });
    }

    async updateInvoiceStatus(invoiceId, status) {
        return this.request(`/invoices/${invoiceId}/status`, {
            method: 'PUT',
            body: JSON.stringify({ status })
        });
    }

    // طلبات المدفوعات
    async getPayments(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/payments?${queryString}`);
    }

    async createPayment(paymentData) {
        return this.request('/payments', {
            method: 'POST',
            body: JSON.stringify(paymentData)
        });
    }

    async getPaymentDetails(paymentId) {
        return this.request(`/payments/${paymentId}/details`);
    }

    // طلبات تعمير الذمم
    async getAgingReport(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/aging?${queryString}`);
    }

    async getVendorAging(vendorId) {
        return this.request(`/vendors/${vendorId}/aging`);
    }

    // طلبات التقارير
    async getPayablesSummary(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/payables-summary?${queryString}`);
    }

    async getVendorStatement(vendorId, params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/vendors/${vendorId}/statement?${queryString}`);
    }

    async exportReport(reportType, params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/export/${reportType}?${queryString}`, {
            responseType: 'blob'
        });
    }

    // طلبات الإحصائيات
    async getVendorStatistics(vendorId) {
        return this.request(`/vendors/${vendorId}/statistics`);
    }

    async getPaymentStatistics(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/statistics/payments?${queryString}`);
    }
}