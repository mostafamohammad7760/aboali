import { FixedAssetsAPI } from './api/fixed_assets_api.js';
import { ChartManager } from './chart_manager.js';
import { formatCurrency, formatDate, formatNumber } from './utils/formatters.js';

class FixedAssets {
    constructor() {
        this.api = new FixedAssetsAPI();
        this.charts = new ChartManager();
        this.currentUser = 'mostafamohammad7760';
        
        // تهيئة المكونات والبيانات
        this.initializeComponents();
        this.attachEventListeners();
        this.loadDashboardData();
        
        // تحديث الوقت كل ثانية
        this.updateDateTime();
        setInterval(() => this.updateDateTime(), 1000);
    }

    initializeComponents() {
        // عناصر لوحة المعلومات
        this.dashboardElements = {
            totalAssetsValue: document.getElementById('totalAssetsValue'),
            activeAssetsCount: document.getElementById('activeAssetsCount'),
            annualDepreciation: document.getElementById('annualDepreciation'),
            accumulatedDepreciation: document.getElementById('accumulatedDepreciation'),
            maintenanceCost: document.getElementById('maintenanceCost'),
            maintenanceCount: document.getElementById('maintenanceCount'),
            sparePartsValue: document.getElementById('sparePartsValue'),
            sparePartsCount: document.getElementById('sparePartsCount'),
            maintenanceTable: document.getElementById('maintenanceTable'),
            expiringAssetsGrid: document.getElementById('expiringAssetsGrid')
        };

        // تهيئة الرسوم البيانية
        this.initializeCharts();
        
        // تهيئة القوالب
        this.assetCardTemplate = document.getElementById('assetCardTemplate');
    }

    attachEventListeners() {
        // مستمعات أحداث التصدير
        document.getElementById('exportAssetsDistribution')?.addEventListener('click', 
            () => this.exportChart('assetsDistributionChart'));
        document.getElementById('exportDepreciationChart')?.addEventListener('click', 
            () => this.exportChart('monthlyDepreciationChart'));
        document.getElementById('exportExpiringAssets')?.addEventListener('click', 
            () => this.exportExpiringAssets());

        // مستمعات أحداث النماذج
        document.getElementById('addMaintenance')?.addEventListener('click', 
            () => this.showMaintenanceModal());
        document.getElementById('assetForm')?.addEventListener('submit', 
            (e) => this.handleAssetFormSubmit(e));

        // مستمعات أحداث النوافذ المنبثقة
        document.querySelectorAll('.close-btn').forEach(btn => {
            btn.addEventListener('click', () => this.closeModals());
        });

        // مستمعات أحداث التصفية والبحث
        this.setupFilterListeners();
    }

    async loadDashboardData() {
        try {
            this.showLoading();

            const [
                summary,
                maintenanceRecords,
                assetsDistribution,
                depreciationData,
                expiringAssets
            ] = await Promise.all([
                this.api.getDashboardSummary(),
                this.api.getLatestMaintenance(),
                this.api.getAssetsDistribution(),
                this.api.getMonthlyDepreciation(),
                this.api.getExpiringAssets()
            ]);

            this.updateDashboardSummary(summary);
            this.renderMaintenanceRecords(maintenanceRecords);
            this.updateCharts(assetsDistribution, depreciationData);
            this.renderExpiringAssets(expiringAssets);

            this.hideLoading();
        } catch (error) {
            this.hideLoading();
            this.showError('حدث خطأ أثناء تحميل البيانات');
            console.error('Dashboard loading error:', error);
        }
    }

    updateDashboardSummary(summary) {
        this.dashboardElements.totalAssetsValue.textContent = 
            formatCurrency(summary.totalAssetsValue);
        this.dashboardElements.activeAssetsCount.textContent = 
            formatNumber(summary.activeAssetsCount);
        this.dashboardElements.annualDepreciation.textContent = 
            formatCurrency(summary.annualDepreciation);
        this.dashboardElements.accumulatedDepreciation.textContent = 
            formatCurrency(summary.accumulatedDepreciation);
        this.dashboardElements.maintenanceCost.textContent = 
            formatCurrency(summary.maintenanceCost);
        this.dashboardElements.maintenanceCount.textContent = 
            formatNumber(summary.maintenanceCount);
        this.dashboardElements.sparePartsValue.textContent = 
            formatCurrency(summary.sparePartsValue);
        this.dashboardElements.sparePartsCount.textContent = 
            formatNumber(summary.sparePartsCount);
    }

    renderMaintenanceRecords(records) {
        const tbody = this.dashboardElements.maintenanceTable;
        tbody.innerHTML = '';

        records.forEach(record => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${record.maintenanceId}</td>
                <td>${record.assetName}</td>
                <td>${this.translateMaintenanceType(record.maintenanceType)}</td>
                <td>${formatDate(record.maintenanceDate)}</td>
                <td>${formatCurrency(record.cost)}</td>
                <td>
                    <span class="status-badge ${record.status}">
                        ${this.translateStatus(record.status)}
                    </span>
                </td>
                <td>
                    <div class="btn-group">
                        <button class="btn btn-sm btn-secondary view-maintenance" 
                                data-id="${record.maintenanceId}">
                            عرض
                        </button>
                        <button class="btn btn-sm btn-primary update-maintenance" 
                                data-id="${record.maintenanceId}"
                                ${record.status === 'completed' ? 'disabled' : ''}>
                            تحديث
                        </button>
                    </div>
                </td>
            `;

            tbody.appendChild(tr);

            // إضافة مستمعات الأحداث للأزرار
            tr.querySelector('.view-maintenance').addEventListener('click', 
                () => this.viewMaintenance(record.maintenanceId));
            tr.querySelector('.update-maintenance').addEventListener('click', 
                () => this.showMaintenanceModal(record.maintenanceId));
        });
    }

    renderExpiringAssets(assets) {
        const grid = this.dashboardElements.expiringAssetsGrid;
        grid.innerHTML = '';

        assets.forEach(asset => {
            const card = this.createAssetCard(asset);
            grid.appendChild(card);
        });
    }

    createAssetCard(asset) {
        const template = this.assetCardTemplate.content.cloneNode(true);
        
        template.querySelector('.asset-name').textContent = asset.assetName;
        template.querySelector('.asset-status').textContent = 
            this.translateStatus(asset.status);
        template.querySelector('.current-value').textContent = 
            formatCurrency(asset.currentValue);
        template.querySelector('.remaining-life').textContent = 
            this.formatRemainingLife(asset.remainingLife);

        const card = template.querySelector('.asset-card');
        card.dataset.assetId = asset.assetId;

        // إضافة مستمعات الأحداث
        card.querySelector('.view-details').addEventListener('click', 
            () => this.viewAssetDetails(asset.assetId));
        card.querySelector('.request-maintenance').addEventListener('click', 
            () => this.showMaintenanceModal(null, asset.assetId));

        return card;
    }

    initializeCharts() {
        // تهيئة رسم توزيع الأصول
        this.charts.initializeAssetsDistributionChart('assetsDistributionChart', {
            labels: [],
            datasets: [{
                data: [],
                backgroundColor: [
                    '#2ecc71',
                    '#3498db',
                    '#f1c40f',
                    '#e67e22',
                    '#e74c3c',
                    '#95a5a6'
                ]
            }]
        });

        // تهيئة رسم الإهلاك الشهري
        this.charts.initializeDepreciationChart('monthlyDepreciationChart', {
            labels: [],
            datasets: [{
                label: 'الإهلاك الشهري',
                data: [],
                borderColor: '#2c4d76',
                fill: false
            }]
        });
    }

    updateCharts(assetsDistribution, depreciationData) {
        // تحديث رسم توزيع الأصول
        this.charts.updateAssetsDistributionChart('assetsDistributionChart', {
            labels: assetsDistribution.map(item => item.groupName),
            data: assetsDistribution.map(item => item.totalValue)
        });

        // تحديث رسم الإهلاك
        this.charts.updateDepreciationChart('monthlyDepreciationChart', {
            labels: depreciationData.map(item => item.month),
            data: depreciationData.map(item => item.amount)
        });
    }

    // توابع مساعدة
    translateMaintenanceType(type) {
        const typeMap = {
            preventive: 'وقائية',
            corrective: 'تصحيحية',
            scheduled: 'مجدولة'
        };
        return typeMap[type] || type;
    }

    translateStatus(status) {
        const statusMap = {
            active: 'نشط',
            inactive: 'غير نشط',
            maintenance: 'في الصيانة',
            disposed: 'مستبعد',
            planned: 'مخطط',
            in_progress: 'قيد التنفيذ',
            completed: 'مكتمل',
            cancelled: 'ملغي'
        };
        return statusMap[status] || status;
    }

    formatRemainingLife(months) {
        const years = Math.floor(months / 12);
        const remainingMonths = months % 12;
        
        if (years === 0) {
            return `${remainingMonths} شهر`;
        } else if (remainingMonths === 0) {
            return `${years} سنة`;
        } else {
            return `${years} سنة و ${remainingMonths} شهر`;
        }
    }

    updateDateTime() {
        document.getElementById('currentDateTime').textContent = 
            new Date().toISOString().slice(0, 19).replace('T', ' ');
    }

    showLoading() {
        const loader = document.createElement('div');
        loader.className = 'loading-overlay';
        loader.innerHTML = '<div class="loading-spinner"></div>';
        document.body.appendChild(loader);
    }

    hideLoading() {
        document.querySelector('.loading-overlay')?.remove();
    }

    showError(message) {
        console.error(message);
        // يمكن تحسين هذه الدالة لعرض رسائل خطأ أكثر جاذبية
        alert(message);
    }

    showSuccess(message) {
        // يمكن تحسين هذه الدالة لعرض رسائل نجاح أكثر جاذبية
        alert(message);
    }
}

// تهيئة التطبيق عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    new FixedAssets();
});