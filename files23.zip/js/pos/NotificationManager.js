/**
 * مدير الإشعارات - إدارة الإشعارات والتنبيهات في نظام نقاط البيع
 * @module NotificationManager
 * التاريخ: 2025-05-09 03:14:50
 * المستخدم: mostafamohammad7760
 */

export class NotificationManager {
    constructor(database) {
        this.db = database;
        
        // أنواع الإشعارات
        this.notificationTypes = {
            SYSTEM: 'system',
            INVENTORY: 'inventory',
            SALES: 'sales',
            CUSTOMER: 'customer',
            LOYALTY: 'loyalty',
            MAINTENANCE: 'maintenance',
            SECURITY: 'security'
        };

        // مستويات الأولوية
        this.priorityLevels = {
            LOW: 'low',
            MEDIUM: 'medium',
            HIGH: 'high',
            CRITICAL: 'critical'
        };

        // قنوات الإشعارات
        this.channels = {
            INTERNAL: 'internal',    // داخل النظام
            EMAIL: 'email',          // بريد إلكتروني
            SMS: 'sms',              // رسائل نصية
            PUSH: 'push',            // إشعارات متصفح
            PRINT: 'print'           // طباعة
        };
    }

    /**
     * إرسال إشعار جديد
     * @param {Object} notification - بيانات الإشعار
     */
    async sendNotification(notification) {
        try {
            // التحقق من صحة البيانات
            this.validateNotification(notification);

            const notificationId = this.generateNotificationId();
            
            // تخزين الإشعار
            await this.storeNotification({
                notification_id: notificationId,
                ...notification
            });

            // إرسال الإشعار عبر القنوات المحددة
            await this.dispatchNotification(notification);

            return {
                notification_id: notificationId,
                status: 'sent',
                sent_at: new Date()
            };
        } catch (error) {
            console.error('Error sending notification:', error);
            throw new Error('فشل إرسال الإشعار');
        }
    }

    /**
     * تخزين الإشعار في قاعدة البيانات
     * @param {Object} notification - بيانات الإشعار
     */
    async storeNotification(notification) {
        const query = `
            INSERT INTO notifications (
                notification_id,
                type,
                priority,
                title,
                message,
                recipient_type,
                recipient_id,
                channels,
                metadata,
                created_by
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;

        await this.db.executeQuery(query, [
            notification.notification_id,
            notification.type,
            notification.priority,
            notification.title,
            notification.message,
            notification.recipient_type,
            notification.recipient_id,
            JSON.stringify(notification.channels),
            JSON.stringify(notification.metadata || {}),
            this.currentUser
        ]);
    }

    /**
     * إرسال الإشعار عبر القنوات المحددة
     * @param {Object} notification - بيانات الإشعار
     */
    async dispatchNotification(notification) {
        const dispatches = [];

        for (const channel of notification.channels) {
            switch (channel) {
                case this.channels.INTERNAL:
                    dispatches.push(this.sendInternalNotification(notification));
                    break;

                case this.channels.EMAIL:
                    dispatches.push(this.sendEmailNotification(notification));
                    break;

                case this.channels.SMS:
                    dispatches.push(this.sendSMSNotification(notification));
                    break;

                case this.channels.PUSH:
                    dispatches.push(this.sendPushNotification(notification));
                    break;

                case this.channels.PRINT:
                    dispatches.push(this.printNotification(notification));
                    break;
            }
        }

        await Promise.all(dispatches);
    }

    /**
     * إرسال إشعار داخلي
     * @param {Object} notification - بيانات الإشعار
     */
    async sendInternalNotification(notification) {
        // إضافة الإشعار إلى قائمة إشعارات المستخدم
        await this.db.executeQuery(`
            INSERT INTO user_notifications (
                user_id,
                notification_id,
                is_read,
                created_at
            ) VALUES (?, ?, ?, CURRENT_TIMESTAMP)
        `, [
            notification.recipient_id,
            notification.notification_id,
            false
        ]);
    }

    /**
     * إرسال إشعار بريد إلكتروني
     * @param {Object} notification - بيانات الإشعار
     */
    async sendEmailNotification(notification) {
        try {
            const template = await this.getEmailTemplate(notification.type);
            const recipient = await this.getRecipientEmail(notification.recipient_id);
            
            const emailData = {
                to: recipient,
                subject: notification.title,
                template,
                context: {
                    ...notification,
                    company: await this.getCompanyInfo()
                }
            };

            await this.emailService.send(emailData);
            
            await this.logNotificationDelivery({
                notification_id: notification.notification_id,
                channel: this.channels.EMAIL,
                recipient: recipient,
                status: 'delivered'
            });
        } catch (error) {
            console.error('Error sending email notification:', error);
            await this.logNotificationDelivery({
                notification_id: notification.notification_id,
                channel: this.channels.EMAIL,
                recipient: recipient,
                status: 'failed',
                error: error.message
            });
        }
    }

    /**
     * إرسال إشعار رسالة نصية
     * @param {Object} notification - بيانات الإشعار
     */
    async sendSMSNotification(notification) {
        try {
            const phoneNumber = await this.getRecipientPhone(notification.recipient_id);
            const message = this.formatSMSMessage(notification);

            await this.smsService.send({
                to: phoneNumber,
                message
            });

            await this.logNotificationDelivery({
                notification_id: notification.notification_id,
                channel: this.channels.SMS,
                recipient: phoneNumber,
                status: 'delivered'
            });
        } catch (error) {
            console.error('Error sending SMS notification:', error);
            await this.logNotificationDelivery({
                notification_id: notification.notification_id,
                channel: this.channels.SMS,
                recipient: phoneNumber,
                status: 'failed',
                error: error.message
            });
        }
    }

    /**
     * إرسال إشعار متصفح
     * @param {Object} notification - بيانات الإشعار
     */
    async sendPushNotification(notification) {
        try {
            const subscription = await this.getPushSubscription(notification.recipient_id);
            if (!subscription) {
                throw new Error('لا يوجد اشتراك للإشعارات');
            }

            await this.webPushService.send({
                subscription,
                title: notification.title,
                message: notification.message,
                icon: notification.metadata.icon,
                data: {
                    url: notification.metadata.url
                }
            });

            await this.logNotificationDelivery({
                notification_id: notification.notification_id,
                channel: this.channels.PUSH,
                recipient: notification.recipient_id,
                status: 'delivered'
            });
        } catch (error) {
            console.error('Error sending push notification:', error);
            await this.logNotificationDelivery({
                notification_id: notification.notification_id,
                channel: this.channels.PUSH,
                recipient: notification.recipient_id,
                status: 'failed',
                error: error.message
            });
        }
    }

    /**
     * طباعة الإشعار
     * @param {Object} notification - بيانات الإشعار
     */
    async printNotification(notification) {
        try {
            const printer = this.getPrinterForNotification(notification);
            const content = this.formatPrintContent(notification);

            await printer.print(content);

            await this.logNotificationDelivery({
                notification_id: notification.notification_id,
                channel: this.channels.PRINT,
                recipient: printer.name,
                status: 'delivered'
            });
        } catch (error) {
            console.error('Error printing notification:', error);
            await this.logNotificationDelivery({
                notification_id: notification.notification_id,
                channel: this.channels.PRINT,
                recipient: printer.name,
                status: 'failed',
                error: error.message
            });
        }
    }

    /**
     * التحقق من صحة بيانات الإشعار
     * @param {Object} notification - بيانات الإشعار
     */
    validateNotification(notification) {
        const errors = [];

        if (!this.notificationTypes[notification.type]) {
            errors.push('نوع الإشعار غير صالح');
        }

        if (!this.priorityLevels[notification.priority]) {
            errors.push('مستوى الأولوية غير صالح');
        }

        if (!notification.title || notification.title.trim().length === 0) {
            errors.push('عنوان الإشعار مطلوب');
        }

        if (!notification.message || notification.message.trim().length === 0) {
            errors.push('محتوى الإشعار مطلوب');
        }

        if (!notification.channels || notification.channels.length === 0) {
            errors.push('يجب تحديد قناة واحدة على الأقل');
        }

        if (errors.length > 0) {
            throw new Error(errors.join('\n'));
        }
    }

    /**
     * توليد معرف فريد للإشعار
     */
    generateNotificationId() {
        return 'NOTIF-' + Date.now().toString(36).toUpperCase();
    }
}