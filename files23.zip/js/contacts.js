import { ContactsAPI } from './api/contacts_api.js';
import { ChartManager } from './chart_manager.js';
import { formatCurrency, formatNumber, formatDate, formatDuration } from './utils/formatters.js';
import { validateContact, validateGroup, validateDocument } from './utils/validators.js';

class Contacts {
    constructor() {
        this.api = new ContactsAPI();
        this.charts = new ChartManager();
        this.currentUser = 'mostafamohammad7760';
        
        // تهيئة المكونات والبيانات
        this.initializeComponents();
        this.attachEventListeners();
        this.loadDashboardData();
        
        // تحديث الوقت كل ثانية
        this.updateDateTime();
        setInterval(() => this.updateDateTime(), 1000);
    }

    initializeComponents() {
        // عناصر لوحة المعلومات
        this.dashboardElements = {
            // إحصائيات الموردين
            totalSuppliersCount: document.getElementById('totalSuppliersCount'),
            activeSuppliersCount: document.getElementById('activeSuppliersCount'),
            blockedSuppliersCount: document.getElementById('blockedSuppliersCount'),
            
            // إحصائيات العملاء
            totalCustomersCount: document.getElementById('totalCustomersCount'),
            activeCustomersCount: document.getElementById('activeCustomersCount'),
            blockedCustomersCount: document.getElementById('blockedCustomersCount'),
            
            // المديونيات والائتمان
            suppliersDebt: document.getElementById('suppliersDebt'),
            customersDebt: document.getElementById('customersDebt'),
            averageSupplierCredit: document.getElementById('averageSupplierCredit'),
            averageCustomerCredit: document.getElementById('averageCustomerCredit'),
            
            // الجداول والقوائم
            eventsTimeline: document.getElementById('eventsTimeline'),
            expiredDocumentsTable: document.getElementById('expiredDocumentsTable')
        };

        // عناصر الفلترة
        this.filterElements = {
            suppliersPeriod: document.getElementById('suppliersPeriod'),
            customersPeriod: document.getElementById('customersPeriod')
        };

        // تهيئة الرسوم البيانية
        this.initializeCharts();
        
        // تهيئة القوالب
        this.eventTemplate = document.getElementById('eventTemplate');
    }

    async loadDashboardData() {
        try {
            this.showLoading();

            const [
                suppliersStats,
                customersStats,
                debtsData,
                suppliersAnalysis,
                customersAnalysis,
                latestEvents,
                expiredDocuments
            ] = await Promise.all([
                this.api.getSuppliersStats(),
                this.api.getCustomersStats(),
                this.api.getDebtsData(),
                this.api.getSuppliersAnalysis(this.filterElements.suppliersPeriod.value),
                this.api.getCustomersAnalysis(this.filterElements.customersPeriod.value),
                this.api.getLatestEvents(),
                this.api.getExpiredDocuments()
            ]);

            this.updateStats(suppliersStats, customersStats);
            this.updateDebtsData(debtsData);
            this.updateCharts(suppliersAnalysis, customersAnalysis);
            this.renderEvents(latestEvents);
            this.renderExpiredDocuments(expiredDocuments);

            this.hideLoading();
        } catch (error) {
            this.hideLoading();
            this.showError('حدث خطأ أثناء تحميل البيانات');
            console.error('Dashboard loading error:', error);
        }
    }

    initializeCharts() {
        // تهيئة رسم تحليل الموردين
        this.charts.initializeBarChart('suppliersAnalysisChart', {
            labels: [],
            datasets: [{
                label: 'إجمالي المشتريات',
                data: [],
                backgroundColor: '#2c4d76',
                borderRadius: 6
            }],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => formatCurrency(value)
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: context => formatCurrency(context.parsed.y)
                        }
                    }
                }
            }
        });

        // تهيئة رسم تحليل العملاء
        this.charts.initializeBarChart('customersAnalysisChart', {
            labels: [],
            datasets: [{
                label: 'إجمالي المبيعات',
                data: [],
                backgroundColor: '#27ae60',
                borderRadius: 6
            }],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => formatCurrency(value)
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: context => formatCurrency(context.parsed.y)
                        }
                    }
                }
            }
        });
    }

    updateStats(suppliersStats, customersStats) {
        // تحديث إحصائيات الموردين
        this.dashboardElements.totalSuppliersCount.textContent = 
            formatNumber(suppliersStats.total);
        this.dashboardElements.activeSuppliersCount.textContent = 
            formatNumber(suppliersStats.active);
        this.dashboardElements.blockedSuppliersCount.textContent = 
            formatNumber(suppliersStats.blocked);

        // تحديث إحصائيات العملاء
        this.dashboardElements.totalCustomersCount.textContent = 
            formatNumber(customersStats.total);
        this.dashboardElements.activeCustomersCount.textContent = 
            formatNumber(customersStats.active);
        this.dashboardElements.blockedCustomersCount.textContent = 
            formatNumber(customersStats.blocked);
    }

    updateDebtsData(debtsData) {
        this.dashboardElements.suppliersDebt.textContent = 
            formatCurrency(debtsData.suppliersDebt);
        this.dashboardElements.customersDebt.textContent = 
            formatCurrency(debtsData.customersDebt);
        this.dashboardElements.averageSupplierCredit.textContent = 
            formatCurrency(debtsData.averageSupplierCredit);
        this.dashboardElements.averageCustomerCredit.textContent = 
            formatCurrency(debtsData.averageCustomerCredit);
    }

    updateCharts(suppliersAnalysis, customersAnalysis) {
        // تحديث رسم تحليل الموردين
        this.charts.updateBarChart('suppliersAnalysisChart', {
            labels: suppliersAnalysis.map(item => item.supplierName),
            data: suppliersAnalysis.map(item => item.totalPurchases)
        });

        // تحديث رسم تحليل العملاء
        this.charts.updateBarChart('customersAnalysisChart', {
            labels: customersAnalysis.map(item => item.customerName),
            data: customersAnalysis.map(item => item.totalSales)
        });
    }

    renderEvents(events) {
        const timeline = this.dashboardElements.eventsTimeline;
        timeline.innerHTML = '';

        events.forEach(event => {
            const eventElement = this.createEventElement(event);
            timeline.appendChild(eventElement);
        });
    }

    createEventElement(event) {
        const template = this.eventTemplate.content.cloneNode(true);
        
        // تعيين الأيقونة المناسبة حسب نوع الحدث
        const icon = template.querySelector('.event-icon i');
        icon.className = this.getEventIcon(event.type);
        
        template.querySelector('.event-title').textContent = event.title;
        template.querySelector('.event-description').textContent = event.description;
        template.querySelector('.event-date').textContent = formatDate(event.eventDate);

        return template.firstElementChild;
    }

    renderExpiredDocuments(documents) {
        const tbody = this.dashboardElements.expiredDocumentsTable;
        tbody.innerHTML = '';

        documents.forEach(doc => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${this.translateContactType(doc.contactType)}</td>
                <td>${doc.contactName}</td>
                <td>${doc.name}</td>
                <td>${formatDate(doc.expiryDate)}</td>
                <td>${formatDuration(new Date(doc.expiryDate))}</td>
                <td>
                    <div class="btn-group">
                        <button class="btn btn-sm btn-secondary view-document" 
                                data-id="${doc.documentId}">
                            عرض
                        </button>
                        <button class="btn btn-sm btn-primary update-document" 
                                data-id="${doc.documentId}">
                            تحديث
                        </button>
                    </div>
                </td>
            `;

            tbody.appendChild(tr);

            // إضافة مستمعات الأحداث للأزرار
            tr.querySelector('.view-document').addEventListener('click', 
                () => this.viewDocument(doc.documentId));
            tr.querySelector('.update-document').addEventListener('click', 
                () => this.showDocumentModal(doc));
        });
    }

    attachEventListeners() {
        // مستمعات أحداث الإجراءات السريعة
        document.getElementById('createSupplier')?.addEventListener('click', 
            () => this.showSupplierModal());
        document.getElementById('createCustomer')?.addEventListener('click', 
            () => this.showCustomerModal());
        document.getElementById('createGroup')?.addEventListener('click', 
            () => this.showGroupModal());
        document.getElementById('importContacts')?.addEventListener('click', 
            () => this.showImportModal());

        // مستمعات أحداث الفلترة
        this.filterElements.suppliersPeriod.addEventListener('change', 
            () => this.loadSuppliersAnalysis());
        this.filterElements.customersPeriod.addEventListener('change', 
            () => this.loadCustomersAnalysis());

        // مستمعات أحداث التصدير
        document.getElementById('exportSuppliersChart')?.addEventListener('click', 
            () => this.exportChart('suppliersAnalysisChart'));
        document.getElementById('exportCustomersChart')?.addEventListener('click', 
            () => this.exportChart('customersAnalysisChart'));

        // مستمعات أحداث عرض الكل
        document.getElementById('viewAllEvents')?.addEventListener('click', 
            () => this.navigateToEvents());
        document.getElementById('viewAllDocuments')?.addEventListener('click', 
            () => this.navigateToDocuments());
    }

    // توابع مساعدة
    getEventIcon(type) {
        const iconMap = {
            supplier_created: 'fas fa-truck',
            customer_created: 'fas fa-user-tie',
            document_expired: 'fas fa-file-alt',
            credit_limit_exceeded: 'fas fa-exclamation-triangle',
            status_changed: 'fas fa-sync-alt'
        };
        return iconMap[type] || 'fas fa-info-circle';
    }

    translateContactType(type) {
        return type === 'supplier' ? 'مورد' : 'عميل';
    }

    updateDateTime() {
        document.getElementById('currentDateTime').textContent = 
            new Date().toISOString().slice(0, 19).replace('T', ' ');
    }

    showLoading() {
        const loader = document.createElement('div');
        loader.className = 'loading-overlay';
        loader.innerHTML = '<div class="loading-spinner"></div>';
        document.body.appendChild(loader);
    }

    hideLoading() {
        document.querySelector('.loading-overlay')?.remove();
    }

    showError(message) {
        console.error(message);
        // يمكن تحسين هذه الدالة لعرض رسائل خطأ أكثر جاذبية
        alert(message);
    }

    showSuccess(message) {
        // يمكن تحسين هذه الدالة لعرض رسائل نجاح أكثر جاذبية
        alert(message);
    }
}

// تهيئة التطبيق عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    new Contacts();
});