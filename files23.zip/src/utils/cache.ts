/**
 * وظائف التعامل مع التخزين المؤقت
 * التاريخ: 2025-05-09 03:49:33
 * المستخدم: mostafamohammad7760
 */

interface CacheOptions {
  ttl?: number; // وقت الصلاحية بالثواني
  maxSize?: number; // الحد الأقصى لحجم الذاكرة المؤقتة
  updateAgeOnGet?: boolean; // تحديث وقت آخر استخدام عند القراءة
  namespace?: string; // نطاق التخزين
}

interface CacheItem<T> {
  value: T;
  expires: number;
  lastAccessed: number;
  size: number;
}

class CacheService {
  private cache: Map<string, CacheItem<any>>;
  private currentSize: number;
  private options: Required<CacheOptions>;

  constructor(options: CacheOptions = {}) {
    this.cache = new Map();
    this.currentSize = 0;
    this.options = {
      ttl: 3600, // ساعة واحدة افتراضياً
      maxSize: 5 * 1024 * 1024, // 5 ميجابايت افتراضياً
      updateAgeOnGet: true,
      namespace: 'app_cache',
      ...options
    };

    // بدء عملية التنظيف الدوري
    this.startCleanupInterval();
  }

  /**
   * تخزين قيمة في الذاكرة المؤقتة
   */
  public set<T>(
    key: string,
    value: T,
    options: Partial<CacheOptions> = {}
  ): void {
    const finalKey = this.getNamespacedKey(key);
    const ttl = options.ttl || this.options.ttl;
    const now = Date.now();

    // حساب حجم البيانات
    const size = this.calculateSize(value);

    // التحقق من مساحة التخزين المتاحة
    if (size > this.options.maxSize) {
      console.warn(`القيمة أكبر من الحد الأقصى المسموح به للتخزين: ${key}`);
      return;
    }

    // إزالة العناصر القديمة إذا لزم الأمر
    while (this.currentSize + size > this.options.maxSize) {
      this.evictOldest();
    }

    const item: CacheItem<T> = {
      value,
      expires: now + (ttl * 1000),
      lastAccessed: now,
      size
    };

    this.cache.set(finalKey, item);
    this.currentSize += size;
  }

  /**
   * استرجاع قيمة من الذاكرة المؤقتة
   */
  public get<T>(key: string): T | null {
    const finalKey = this.getNamespacedKey(key);
    const item = this.cache.get(finalKey);

    if (!item) {
      return null;
    }

    const now = Date.now();

    // التحقق من انتهاء الصلاحية
    if (now > item.expires) {
      this.delete(key);
      return null;
    }

    // تحديث وقت آخر استخدام
    if (this.options.updateAgeOnGet) {
      item.lastAccessed = now;
    }

    return item.value;
  }

  /**
   * حذف قيمة من الذاكرة المؤقتة
   */
  public delete(key: string): boolean {
    const finalKey = this.getNamespacedKey(key);
    const item = this.cache.get(finalKey);

    if (item) {
      this.currentSize -= item.size;
      return this.cache.delete(finalKey);
    }

    return false;
  }

  /**
   * مسح كل البيانات المخزنة مؤقتاً
   */
  public clear(): void {
    this.cache.clear();
    this.currentSize = 0;
  }

  /**
   * التحقق من وجود مفتاح
   */
  public has(key: string): boolean {
    const finalKey = this.getNamespacedKey(key);
    const item = this.cache.get(finalKey);

    if (!item) {
      return false;
    }

    // التحقق من انتهاء الصلاحية
    if (Date.now() > item.expires) {
      this.delete(key);
      return false;
    }

    return true;
  }

  /**
   * الحصول على حجم الذاكرة المؤقتة الحالي
   */
  public size(): number {
    return this.currentSize;
  }

  /**
   * الحصول على عدد العناصر المخزنة
   */
  public count(): number {
    return this.cache.size;
  }

  /**
   * تحديث وقت انتهاء صلاحية عنصر
   */
  public touch(key: string): boolean {
    const finalKey = this.getNamespacedKey(key);
    const item = this.cache.get(finalKey);

    if (item) {
      const now = Date.now();
      item.expires = now + (this.options.ttl * 1000);
      item.lastAccessed = now;
      return true;
    }

    return false;
  }

  /**
   * حفظ الذاكرة المؤقتة في التخزين المحلي
   */
  public persist(): void {
    try {
      const serialized = JSON.stringify(Array.from(this.cache.entries()));
      localStorage.setItem(this.options.namespace, serialized);
    } catch (error) {
      console.error('خطأ في حفظ الذاكرة المؤقتة:', error);
    }
  }

  /**
   * استرجاع الذاكرة المؤقتة من التخزين المحلي
   */
  public restore(): void {
    try {
      const serialized = localStorage.getItem(this.options.namespace);
      if (serialized) {
        const entries = JSON.parse(serialized);
        this.cache = new Map(entries);
        this.currentSize = this.calculateTotalSize();
      }
    } catch (error) {
      console.error('خطأ في استرجاع الذاكرة المؤقتة:', error);
    }
  }

  // وظائف مساعدة خاصة

  private getNamespacedKey(key: string): string {
    return `${this.options.namespace}:${key}`;
  }

  private calculateSize(value: any): number {
    try {
      const serialized = JSON.stringify(value);
      return serialized.length * 2; // تقريبي: كل حرف يأخذ 2 بايت
    } catch {
      return 0;
    }
  }

  private calculateTotalSize(): number {
    let total = 0;
    for (const item of this.cache.values()) {
      total += item.size;
    }
    return total;
  }

  private evictOldest(): void {
    let oldest: [string, CacheItem<any>] | null = null;

    for (const entry of this.cache.entries()) {
      if (!oldest || entry[1].lastAccessed < oldest[1].lastAccessed) {
        oldest = entry;
      }
    }

    if (oldest) {
      this.delete(oldest[0].split(':')[1]); // حذف البادئة من المفتاح
    }
  }

  private startCleanupInterval(): void {
    setInterval(() => {
      const now = Date.now();
      for (const [key, item] of this.cache.entries()) {
        if (now > item.expires) {
          this.cache.delete(key);
          this.currentSize -= item.size;
        }
      }
    }, 60000); // تنظيف كل دقيقة
  }
}

// تصدير نسخة واحدة من الخدمة
export const cache = new CacheService();