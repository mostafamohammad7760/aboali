/**
 * خدمة المشتريات
 * التاريخ: 2025-05-09 04:21:09
 * المستخدم: mostafamohammad7760
 */

import { Transaction } from 'sequelize';
import { Purchase, Product, Inventory } from '../models';
import { createJournalEntry } from './AccountingService';
import { updateInventory } from './InventoryService';

interface PurchaseItem {
  productId: number;
  quantity: number;
  unitPrice: number;
  discountType?: 'percentage' | 'fixed';
  discountValue?: number;
  taxRate?: number;
}

interface PurchaseData {
  supplierId: number;
  warehouseId: number;
  userId: number;
  items: PurchaseItem[];
  discountType?: 'percentage' | 'fixed';
  discountValue?: number;
  notes?: string;
}

export class PurchaseService {
  /**
   * إنشاء عملية شراء جديدة
   */
  public async createPurchase(data: PurchaseData, transaction?: Transaction): Promise<Purchase> {
    const t = transaction || await Purchase.sequelize!.transaction();

    try {
      // إنشاء رقم أمر الشراء
      const purchaseNumber = await this.generatePurchaseNumber();

      // حساب المبالغ
      let subtotal = 0;
      let totalTax = 0;
      
      // معالجة المنتجات
      for (const item of data.items) {
        const product = await Product.findByPk(item.productId);
        if (!product) {
          throw new Error(`المنتج غير موجود: ${item.productId}`);
        }

        // حساب قيمة المنتج
        const itemTotal = item.quantity * item.unitPrice;
        const itemDiscount = this.calculateDiscount(itemTotal, item.discountType, item.discountValue);
        const itemTax = (itemTotal - itemDiscount) * (item.taxRate || 0) / 100;

        subtotal += itemTotal;
        totalTax += itemTax;

        // تحديث المخزون
        await updateInventory({
          productId: item.productId,
          warehouseId: data.warehouseId,
          quantity: item.quantity,
          transaction: t,
          cost: item.unitPrice
        });
      }

      // حساب الخصم الإجمالي
      const totalDiscount = this.calculateDiscount(subtotal, data.discountType, data.discountValue);

      // حساب الإجمالي النهائي
      const total = subtotal - totalDiscount + totalTax;

      // إنشاء أمر الشراء
      const purchase = await Purchase.create({
        number: purchaseNumber,
        date: new Date(),
        supplierId: data.supplierId,
        warehouseId: data.warehouseId,
        userId: data.userId,
        subtotal,
        discountType: data.discountType,
        discountValue: data.discountValue,
        taxAmount: totalTax,
        total,
        status: 'draft',
        notes: data.notes
      }, { transaction: t });

      // إنشاء قيد محاسبي
      await createJournalEntry({
        date: new Date(),
        referenceType: 'purchase',
        referenceId: purchase.id,
        items: [
          {
            accountId: 3, // حساب المشتريات
            debit: total,
            credit: 0
          },
          {
            accountId: 4, // حساب الموردين
            debit: 0,
            credit: total
          }
        ],
        transaction: t
      });

      if (!transaction) {
        await t.commit();
      }

      return purchase;

    } catch (error) {
      if (!transaction) {
        await t.rollback();
      }
      throw error;
    }
  }

  /**
   * حساب قيمة الخصم
   */
  private calculateDiscount(amount: number, type?: 'percentage' | 'fixed', value?: number): number {
    if (!value) return 0;
    
    if (type === 'percentage') {
      return amount * (value / 100);
    }
    
    return Math.min(value, amount);
  }

  /**
   * توليد رقم أمر شراء جديد
   */
  private async generatePurchaseNumber(): Promise<string> {
    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    
    const lastPurchase = await Purchase.findOne({
      where: {
        number: {
          [Op.like]: `PO${year}${month}%`
        }
      },
      order: [['number', 'DESC']]
    });

    const sequence = lastPurchase
      ? parseInt(lastPurchase.number.slice(-4)) + 1
      : 1;

    return `PO${year}${month}${String(sequence).padStart(4, '0')}`;
  }
}