-- إنشاء جداول طبقة المصادقة والأمان

-- جدول المستخدمين
CREATE TABLE users (
    user_id VARCHAR(36) PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    employee_number VARCHAR(20) UNIQUE,
    department VARCHAR(100),
    contact_info JSON,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP,
    account_status ENUM('active', 'inactive', 'locked', 'expired') DEFAULT 'active',
    expiry_date DATE,
    password_change_required BOOLEAN DEFAULT true,
    last_password_change TIMESTAMP,
    failed_login_attempts INT DEFAULT 0,
    created_by VARCHAR(36),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(36)
);

-- جدول الأدوار الوظيفية
CREATE TABLE roles (
    role_id VARCHAR(36) PRIMARY KEY,
    role_name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    is_system_role BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(36),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(36)
);

-- جدول ربط المستخدمين بالأدوار
CREATE TABLE user_roles (
    user_id VARCHAR(36),
    role_id VARCHAR(36),
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    assigned_by VARCHAR(36),
    PRIMARY KEY (user_id, role_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (role_id) REFERENCES roles(role_id)
);

-- جدول الصلاحيات
CREATE TABLE permissions (
    permission_id VARCHAR(36) PRIMARY KEY,
    permission_code VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    category VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(36)
);

-- جدول ربط الأدوار بالصلاحيات
CREATE TABLE role_permissions (
    role_id VARCHAR(36),
    permission_id VARCHAR(36),
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    assigned_by VARCHAR(36),
    PRIMARY KEY (role_id, permission_id),
    FOREIGN KEY (role_id) REFERENCES roles(role_id),
    FOREIGN KEY (permission_id) REFERENCES permissions(permission_id)
);

-- جدول إعدادات المصادقة الثنائية
CREATE TABLE two_factor_auth (
    user_id VARCHAR(36) PRIMARY KEY,
    method ENUM('sms', 'email', 'authenticator', 'security_key') NOT NULL,
    secret_key VARCHAR(255),
    backup_codes JSON,
    is_enabled BOOLEAN DEFAULT false,
    last_verified TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- جدول سجل العمليات
CREATE TABLE activity_log (
    log_id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36),
    action_type VARCHAR(50) NOT NULL,
    entity_type VARCHAR(50),
    entity_id VARCHAR(36),
    old_value JSON,
    new_value JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- جدول التنبيهات الأمنية
CREATE TABLE security_alerts (
    alert_id VARCHAR(36) PRIMARY KEY,
    alert_type VARCHAR(50) NOT NULL,
    severity ENUM('low', 'medium', 'high', 'critical') NOT NULL,
    user_id VARCHAR(36),
    description TEXT,
    ip_address VARCHAR(45),
    is_resolved BOOLEAN DEFAULT false,
    resolved_at TIMESTAMP,
    resolved_by VARCHAR(36),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (resolved_by) REFERENCES users(user_id)
);

-- جدول النسخ الاحتياطي
CREATE TABLE backups (
    backup_id VARCHAR(36) PRIMARY KEY,
    backup_type ENUM('full', 'incremental', 'differential') NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    file_size BIGINT,
    checksum VARCHAR(64),
    status ENUM('pending', 'in_progress', 'completed', 'failed') NOT NULL,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    created_by VARCHAR(36),
    FOREIGN KEY (created_by) REFERENCES users(user_id)
);

-- جدول سجل استعادة النسخ الاحتياطي
CREATE TABLE backup_restores (
    restore_id VARCHAR(36) PRIMARY KEY,
    backup_id VARCHAR(36),
    status ENUM('pending', 'in_progress', 'completed', 'failed') NOT NULL,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    restored_by VARCHAR(36),
    notes TEXT,
    FOREIGN KEY (backup_id) REFERENCES backups(backup_id),
    FOREIGN KEY (restored_by) REFERENCES users(user_id)
);

-- جدول سياسات الأمان
CREATE TABLE security_policies (
    policy_id VARCHAR(36) PRIMARY KEY,
    policy_type VARCHAR(50) NOT NULL,
    settings JSON NOT NULL,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(36),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(36),
    FOREIGN KEY (created_by) REFERENCES users(user_id),
    FOREIGN KEY (updated_by) REFERENCES users(user_id)
);

-- جدول الأجهزة الموثوقة
CREATE TABLE trusted_devices (
    device_id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36),
    device_name VARCHAR(100),
    device_type VARCHAR(50),
    device_identifier VARCHAR(255),
    last_used_at TIMESTAMP,
    is_trusted BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- المؤشرات
CREATE INDEX idx_users_status ON users(account_status);
CREATE INDEX idx_users_employee ON users(employee_number);
CREATE INDEX idx_activity_log_date ON activity_log(created_at);
CREATE INDEX idx_security_alerts_type ON security_alerts(alert_type, severity);
CREATE INDEX idx_backups_status ON backups(status, created_at);

-- إجراءات مخزنة

DELIMITER //

-- إجراء تسجيل نشاط المستخدم
CREATE PROCEDURE log_user_activity(
    IN p_user_id VARCHAR(36),
    IN p_action_type VARCHAR(50),
    IN p_entity_type VARCHAR(50),
    IN p_entity_id VARCHAR(36),
    IN p_old_value JSON,
    IN p_new_value JSON,
    IN p_ip_address VARCHAR(45),
    IN p_user_agent TEXT
)
BEGIN
    INSERT INTO activity_log (
        log_id,
        user_id,
        action_type,
        entity_type,
        entity_id,
        old_value,
        new_value,
        ip_address,
        user_agent
    ) VALUES (
        UUID(),
        p_user_id,
        p_action_type,
        p_entity_type,
        p_entity_id,
        p_old_value,
        p_new_value,
        p_ip_address,
        p_user_agent
    );
END //

-- إجراء تحديث حالة المستخدم
CREATE PROCEDURE update_user_status(
    IN p_user_id VARCHAR(36),
    IN p_status VARCHAR(20),
    IN p_updated_by VARCHAR(36)
)
BEGIN
    UPDATE users
    SET 
        account_status = p_status,
        updated_at = CURRENT_TIMESTAMP,
        updated_by = p_updated_by
    WHERE user_id = p_user_id;
    
    -- تسجيل النشاط
    CALL log_user_activity(
        p_updated_by,
        'update_status',
        'user',
        p_user_id,
        JSON_OBJECT('status', (SELECT account_status FROM users WHERE user_id = p_user_id)),
        JSON_OBJECT('status', p_status),
        NULL,
        NULL
    );
END //

DELIMITER ;