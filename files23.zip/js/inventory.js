import { InventoryAPI } from './api/inventory_api.js';
import { ChartManager } from './chart_manager.js';
import { formatCurrency, formatNumber, formatDate } from './utils/formatters.js';
import { validateItem, validateTransaction, validateTransfer } from './utils/validators.js';

class Inventory {
    constructor() {
        this.api = new InventoryAPI();
        this.charts = new ChartManager();
        this.currentUser = 'mostafamohammad7760';
        
        // تهيئة المكونات والبيانات
        this.initializeComponents();
        this.attachEventListeners();
        this.loadDashboardData();
        
        // تحديث الوقت كل ثانية
        this.updateDateTime();
        setInterval(() => this.updateDateTime(), 1000);
    }

    initializeComponents() {
        // عناصر لوحة المعلومات
        this.dashboardElements = {
            // قيمة المخزون
            totalCost: document.getElementById('totalCost'),
            totalSales: document.getElementById('totalSales'),
            profitMargin: document.getElementById('profitMargin'),
            
            // حركة المخزون
            incomingValue: document.getElementById('incomingValue'),
            outgoingValue: document.getElementById('outgoingValue'),
            netMovement: document.getElementById('netMovement'),
            
            // إحصائيات الأصناف
            outOfStock: document.getElementById('outOfStock'),
            lowStock: document.getElementById('lowStock'),
            inStock: document.getElementById('inStock'),
            
            // معلومات الجرد
            activeCount: document.getElementById('activeCount'),
            lastCountDate: document.getElementById('lastCountDate'),
            lastCountDifference: document.getElementById('lastCountDifference'),
            
            // الجداول
            latestTransactionsTable: document.getElementById('latestTransactionsTable')
        };

        // عناصر الفلترة
        this.filterElements = {
            inventoryChartPeriod: document.getElementById('inventoryChartPeriod'),
            warehousesPeriod: document.getElementById('warehousesPeriod')
        };

        // تهيئة الرسوم البيانية
        this.initializeCharts();
        
        // تهيئة القوالب
        this.transactionRowTemplate = document.getElementById('transactionRowTemplate');
    }

    async loadDashboardData() {
        try {
            this.showLoading();

            const [
                inventoryValue,
                inventoryMovement,
                itemsStats,
                countInfo,
                inventoryAnalysis,
                warehousesAnalysis,
                latestTransactions
            ] = await Promise.all([
                this.api.getInventoryValue(),
                this.api.getInventoryMovement(),
                this.api.getItemsStats(),
                this.api.getCountInfo(),
                this.api.getInventoryAnalysis(this.filterElements.inventoryChartPeriod.value),
                this.api.getWarehousesAnalysis(this.filterElements.warehousesPeriod.value),
                this.api.getLatestTransactions()
            ]);

            this.updateInventoryValue(inventoryValue);
            this.updateInventoryMovement(inventoryMovement);
            this.updateItemsStats(itemsStats);
            this.updateCountInfo(countInfo);
            this.updateCharts(inventoryAnalysis, warehousesAnalysis);
            this.renderLatestTransactions(latestTransactions);

            this.hideLoading();
        } catch (error) {
            this.hideLoading();
            this.showError('حدث خطأ أثناء تحميل البيانات');
            console.error('Dashboard loading error:', error);
        }
    }

    initializeCharts() {
        // تهيئة رسم تحليل المخزون
        this.charts.initializeLineChart('inventoryAnalysisChart', {
            labels: [],
            datasets: [
                {
                    label: 'الواردات',
                    data: [],
                    borderColor: '#27ae60',
                    backgroundColor: 'rgba(39, 174, 96, 0.1)',
                    fill: true
                },
                {
                    label: 'الصادرات',
                    data: [],
                    borderColor: '#e74c3c',
                    backgroundColor: 'rgba(231, 76, 60, 0.1)',
                    fill: true
                }
            ],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => formatCurrency(value)
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: context => formatCurrency(context.parsed.y)
                        }
                    }
                }
            }
        });

        // تهيئة رسم تحليل المستودعات
        this.charts.initializePieChart('warehousesAnalysisChart', {
            labels: [],
            datasets: [{
                data: [],
                backgroundColor: [
                    '#2ecc71',
                    '#3498db',
                    '#f1c40f',
                    '#e67e22',
                    '#e74c3c',
                    '#9b59b6',
                    '#34495e',
                    '#16a085'
                ]
            }],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: context => 
                                `${context.label}: ${formatCurrency(context.parsed)}`
                        }
                    }
                }
            }
        });
    }

    updateInventoryValue(data) {
        this.dashboardElements.totalCost.textContent = 
            formatCurrency(data.totalCost);
        this.dashboardElements.totalSales.textContent = 
            formatCurrency(data.totalSales);
        this.dashboardElements.profitMargin.textContent = 
            formatCurrency(data.profitMargin);
    }

    updateInventoryMovement(data) {
        this.dashboardElements.incomingValue.textContent = 
            formatCurrency(data.incoming);
        this.dashboardElements.outgoingValue.textContent = 
            formatCurrency(data.outgoing);
        this.dashboardElements.netMovement.textContent = 
            formatCurrency(data.net);
    }

    updateItemsStats(stats) {
        this.dashboardElements.outOfStock.textContent = 
            formatNumber(stats.outOfStock);
        this.dashboardElements.lowStock.textContent = 
            formatNumber(stats.lowStock);
        this.dashboardElements.inStock.textContent = 
            formatNumber(stats.inStock);
    }

    updateCountInfo(info) {
        this.dashboardElements.activeCount.textContent = 
            formatNumber(info.activeCount);
        this.dashboardElements.lastCountDate.textContent = 
            info.lastCountDate ? formatDate(info.lastCountDate) : '-';
        this.dashboardElements.lastCountDifference.textContent = 
            formatCurrency(info.lastCountDifference);
    }

    updateCharts(inventoryAnalysis, warehousesAnalysis) {
        // تحديث رسم تحليل المخزون
        this.charts.updateLineChart('inventoryAnalysisChart', {
            labels: inventoryAnalysis.labels,
            datasets: [
                {
                    data: inventoryAnalysis.incoming,
                    label: 'الواردات'
                },
                {
                    data: inventoryAnalysis.outgoing,
                    label: 'الصادرات'
                }
            ]
        });

        // تحديث رسم تحليل المستودعات
        this.charts.updatePieChart('warehousesAnalysisChart', {
            labels: warehousesAnalysis.map(item => item.name),
            data: warehousesAnalysis.map(item => item.value)
        });
    }

    renderLatestTransactions(transactions) {
        const tbody = this.dashboardElements.latestTransactionsTable;
        tbody.innerHTML = '';

        transactions.forEach(transaction => {
            const tr = this.createTransactionRow(transaction);
            tbody.appendChild(tr);
        });
    }

    createTransactionRow(transaction) {
        const template = this.transactionRowTemplate.content.cloneNode(true);
        const tr = template.querySelector('tr');
        
        tr.querySelector('.transaction-number').textContent = transaction.number;
        tr.querySelector('.transaction-date').textContent = 
            formatDate(transaction.date);
        tr.querySelector('.warehouse-name').textContent = transaction.warehouse;
        tr.querySelector('.transaction-description').textContent = 
            transaction.description;
        tr.querySelector('.transaction-value').textContent = 
            formatCurrency(transaction.value);
        
        const typeCell = tr.querySelector('.transaction-type');
        typeCell.textContent = this.translateTransactionType(transaction.type);
        typeCell.classList.add(transaction.type.toLowerCase());
        
        const statusCell = tr.querySelector('.transaction-status');
        statusCell.textContent = this.translateTransactionStatus(transaction.status);
        statusCell.classList.add(transaction.status.toLowerCase());

        // إضافة مستمعات الأحداث للأزرار
        tr.querySelector('.view-transaction').addEventListener('click', 
            () => this.viewTransaction(transaction.id));
        
        const postButton = tr.querySelector('.post-transaction');
        if (transaction.status === 'draft') {
            postButton.addEventListener('click', 
                () => this.postTransaction(transaction.id));
        } else {
            postButton.style.display = 'none';
        }

        return tr;
    }

    attachEventListeners() {
        // مستمعات أحداث الإجراءات السريعة
        document.getElementById('createItem')?.addEventListener('click', 
            () => this.showItemModal());
        document.getElementById('createTransaction')?.addEventListener('click', 
            () => this.showTransactionModal());
        document.getElementById('createTransfer')?.addEventListener('click', 
            () => this.showTransferModal());
        document.getElementById('startCount')?.addEventListener('click', 
            () => this.showCountModal());

        // مستمعات أحداث الفلترة
        this.filterElements.inventoryChartPeriod.addEventListener('change', 
            () => this.loadInventoryAnalysis());
        this.filterElements.warehousesPeriod.addEventListener('change', 
            () => this.loadWarehousesAnalysis());

        // مستمعات أحداث التصدير
        document.getElementById('exportInventoryChart')?.addEventListener('click', 
            () => this.exportChart('inventoryAnalysisChart'));
        document.getElementById('exportWarehousesChart')?.addEventListener('click', 
            () => this.exportChart('warehousesAnalysisChart'));

        // مستمعات أحداث عرض الكل
        document.getElementById('viewAllTransactions')?.addEventListener('click', 
            () => this.navigateToTransactions());
    }

    // توابع مساعدة
    translateTransactionType(type) {
        const typeMap = {
            purchase: 'شراء',
            sales: 'مبيعات',
            transfer: 'تحويل',
            adjustment: 'تسوية'
        };
        return typeMap[type] || type;
    }

    translateTransactionStatus(status) {
        const statusMap = {
            draft: 'مسودة',
            posted: 'مرحل',
            cancelled: 'ملغي'
        };
        return statusMap[status] || status;
    }

    updateDateTime() {
        document.getElementById('currentDateTime').textContent = 
            new Date().toISOString().slice(0, 19).replace('T', ' ');
    }

    showLoading() {
        const loader = document.createElement('div');
        loader.className = 'loading-overlay';
        loader.innerHTML = '<div class="loading-spinner"></div>';
        document.body.appendChild(loader);
    }

    hideLoading() {
        document.querySelector('.loading-overlay')?.remove();
    }

    showError(message) {
        console.error(message);
        // يمكن تحسين هذه الدالة لعرض رسائل خطأ أكثر جاذبية
        alert(message);
    }

    showSuccess(message) {
        // يمكن تحسين هذه الدالة لعرض رسائل نجاح أكثر جاذبية
        alert(message);
    }
}

// تهيئة التطبيق عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    new Inventory();
});