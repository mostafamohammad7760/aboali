/**
 * تعريف النماذج الرئيسية
 * التاريخ: 2025-05-09 04:19:20
 * المستخدم: mostafamohammad7760
 */

import { Sequelize, Model, DataTypes } from 'sequelize';
import config from '../config/database';

const sequelize = new Sequelize(
  config.database,
  config.username,
  config.password,
  config as any
);

// نموذج المستخدم
class User extends Model {
  public id!: number;
  public username!: string;
  public password!: string;
  public name!: string;
  public email!: string;
  public phone!: string;
  public roleId!: number;
  public branchId!: number;
  public active!: boolean;
  public readonly createdAt!: Date;
  public readonly updatedAt!: Date;
}

User.init({
  id: {
    type: DataTypes.BIGINT,
    autoIncrement: true,
    primaryKey: true
  },
  username: {
    type: DataTypes.STRING(50),
    allowNull: false,
    unique: true
  },
  password: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  name: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  email: {
    type: DataTypes.STRING(100),
    allowNull: false,
    unique: true
  },
  phone: {
    type: DataTypes.STRING(20)
  },
  roleId: {
    type: DataTypes.BIGINT,
    allowNull: false
  },
  branchId: {
    type: DataTypes.BIGINT,
    allowNull: false
  },
  active: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  }
}, {
  sequelize,
  tableName: 'users'
});

// نموذج المنتج
class Product extends Model {
  public id!: number;
  public name!: string;
  public code!: string;
  public barcode!: string;
  public categoryId!: number;
  public unitId!: number;
  public purchasePrice!: number;
  public salePrice!: number;
  public minQty!: number;
  public maxQty!: number;
  public taxRate!: number;
  public description!: string;
  public imageUrl!: string;
  public active!: boolean;
  public readonly createdAt!: Date;
  public readonly updatedAt!: Date;
}

Product.init({
  id: {
    type: DataTypes.BIGINT,
    autoIncrement: true,
    primaryKey: true
  },
  name: {
    type: DataTypes.STRING(200),
    allowNull: false
  },
  code: {
    type: DataTypes.STRING(50),
    allowNull: false,
    unique: true
  },
  barcode: {
    type: DataTypes.STRING(50),
    unique: true
  },
  categoryId: {
    type: DataTypes.BIGINT,
    allowNull: false
  },
  unitId: {
    type: DataTypes.BIGINT,
    allowNull: false
  },
  purchasePrice: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  },
  salePrice: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  },
  minQty: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0
  },
  maxQty: {
    type: DataTypes.DECIMAL(10, 2)
  },
  taxRate: {
    type: DataTypes.DECIMAL(5, 2),
    defaultValue: 0
  },
  description: {
    type: DataTypes.TEXT
  },
  imageUrl: {
    type: DataTypes.STRING(255)
  },
  active: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  }
}, {
  sequelize,
  tableName: 'products'
});

// نموذج المخزون
class Inventory extends Model {
  public id!: number;
  public productId!: number;
  public warehouseId!: number;
  public quantity!: number;
  public lastCountedAt!: Date;
  public readonly createdAt!: Date;
  public readonly updatedAt!: Date;
}

Inventory.init({
  id: {
    type: DataTypes.BIGINT,
    autoIncrement: true,
    primaryKey: true
  },
  productId: {
    type: DataTypes.BIGINT,
    allowNull: false
  },
  warehouseId: {
    type: DataTypes.BIGINT,
    allowNull: false
  },
  quantity: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0
  },
  lastCountedAt: {
    type: DataTypes.DATE
  }
}, {
  sequelize,
  tableName: 'inventory'
});

// نموذج المبيعات
class Sale extends Model {
  public id!: number;
  public number!: string;
  public date!: Date;
  public customerId!: number;
  public warehouseId!: number;
  public userId!: number;
  public subtotal!: number;
  public discountType!: 'percentage' | 'fixed';
  public discountValue!: number;
  public taxAmount!: number;
  public total!: number;
  public paid!: number;
  public status!: 'draft' | 'confirmed' | 'cancelled';
  public notes!: string;
  public readonly createdAt!: Date;
}

Sale.init({
  id: {
    type: DataTypes.BIGINT,
    autoIncrement: true,
    primaryKey: true
  },
  number: {
    type: DataTypes.STRING(50),
    allowNull: false,
    unique: true
  },
  date: {
    type: DataTypes.DATEONLY,
    allowNull: false
  },
  customerId: {
    type: DataTypes.BIGINT,
    allowNull: false
  },
  warehouseId: {
    type: DataTypes.BIGINT,
    allowNull: false
  },
  userId: {
    type: DataTypes.BIGINT,
    allowNull: false
  },
  subtotal: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  },
  discountType: {
    type: DataTypes.ENUM('percentage', 'fixed'),
    defaultValue: 'fixed'
  },
  discountValue: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0
  },
  taxAmount: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0
  },
  total: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  },
  paid: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0
  },
  status: {
    type: DataTypes.ENUM('draft', 'confirmed', 'cancelled'),
    defaultValue: 'draft'
  },
  notes: {
    type: DataTypes.TEXT
  }
}, {
  sequelize,
  tableName: 'sales'
});

// تصدير النماذج
export {
  sequelize,
  User,
  Product,
  Inventory,
  Sale
};