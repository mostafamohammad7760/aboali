-- إنشاء جداول الإيرادات وفق معايير IFRS 15

-- جدول العقود مع العملاء
CREATE TABLE revenue_contracts (
    contract_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    customer_id VARCHAR(20) NOT NULL,
    contract_date DATE NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE,
    total_amount DECIMAL(18,2) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'SAR',
    status ENUM('draft', 'active', 'completed', 'terminated') DEFAULT 'draft',
    payment_terms TEXT,
    contract_type ENUM('goods', 'services', 'mixed') NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

-- جدول التزامات الأداء
CREATE TABLE performance_obligations (
    obligation_id VARCHAR(20) PRIMARY KEY,
    contract_id VARCHAR(20) NOT NULL,
    code VARCHAR(20) NOT NULL,
    description TEXT NOT NULL,
    amount DECIMAL(18,2) NOT NULL,
    allocation_method ENUM('standalone_price', 'relative_price', 'residual') NOT NULL,
    recognition_method ENUM('point_in_time', 'over_time') NOT NULL,
    recognition_basis ENUM('output', 'input', 'time_based') NOT NULL,
    status ENUM('pending', 'in_progress', 'completed') DEFAULT 'pending',
    completion_percentage DECIMAL(5,2) DEFAULT 0,
    start_date DATE,
    end_date DATE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (contract_id) REFERENCES revenue_contracts(contract_id)
);

-- جدول أسعار المعاملات
CREATE TABLE transaction_prices (
    price_id VARCHAR(20) PRIMARY KEY,
    contract_id VARCHAR(20) NOT NULL,
    base_amount DECIMAL(18,2) NOT NULL,
    variable_amount DECIMAL(18,2) DEFAULT 0,
    variable_constraint DECIMAL(18,2) DEFAULT 0,
    discount_amount DECIMAL(18,2) DEFAULT 0,
    final_amount DECIMAL(18,2) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'SAR',
    calculation_method TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (contract_id) REFERENCES revenue_contracts(contract_id)
);

-- جدول المقابل المتغير
CREATE TABLE variable_consideration (
    consideration_id VARCHAR(20) PRIMARY KEY,
    contract_id VARCHAR(20) NOT NULL,
    type ENUM('bonus', 'penalty', 'rebate', 'refund', 'other') NOT NULL,
    description TEXT NOT NULL,
    estimation_method ENUM('expected_value', 'most_likely') NOT NULL,
    estimated_amount DECIMAL(18,2) NOT NULL,
    constraint_amount DECIMAL(18,2) NOT NULL,
    probability DECIMAL(5,2),
    resolution_date DATE,
    status ENUM('pending', 'resolved', 'cancelled') DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (contract_id) REFERENCES revenue_contracts(contract_id)
);

-- جدول تخصيص سعر المعاملة
CREATE TABLE price_allocations (
    allocation_id VARCHAR(20) PRIMARY KEY,
    contract_id VARCHAR(20) NOT NULL,
    obligation_id VARCHAR(20) NOT NULL,
    amount DECIMAL(18,2) NOT NULL,
    allocation_basis TEXT NOT NULL,
    allocation_date DATE NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (contract_id) REFERENCES revenue_contracts(contract_id),
    FOREIGN KEY (obligation_id) REFERENCES performance_obligations(obligation_id)
);

-- جدول الإيرادات المعترف بها
CREATE TABLE recognized_revenue (
    revenue_id VARCHAR(20) PRIMARY KEY,
    contract_id VARCHAR(20) NOT NULL,
    obligation_id VARCHAR(20) NOT NULL,
    recognition_date DATE NOT NULL,
    amount DECIMAL(18,2) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'SAR',
    period_id VARCHAR(20) NOT NULL,
    recognition_basis TEXT NOT NULL,
    reversal_id VARCHAR(20),
    status ENUM('draft', 'posted', 'reversed') DEFAULT 'draft',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (contract_id) REFERENCES revenue_contracts(contract_id),
    FOREIGN KEY (obligation_id) REFERENCES performance_obligations(obligation_id),
    FOREIGN KEY (period_id) REFERENCES financial_periods(period_id),
    FOREIGN KEY (reversal_id) REFERENCES recognized_revenue(revenue_id)
);

-- جدول أصول العقود
CREATE TABLE contract_assets (
    asset_id VARCHAR(20) PRIMARY KEY,
    contract_id VARCHAR(20) NOT NULL,
    obligation_id VARCHAR(20) NOT NULL,
    amount DECIMAL(18,2) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'SAR',
    recognition_date DATE NOT NULL,
    expected_billing_date DATE,
    status ENUM('active', 'billed', 'impaired') DEFAULT 'active',
    impairment_amount DECIMAL(18,2) DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (contract_id) REFERENCES revenue_contracts(contract_id),
    FOREIGN KEY (obligation_id) REFERENCES performance_obligations(obligation_id)
);

-- جدول التزامات العقود
CREATE TABLE contract_liabilities (
    liability_id VARCHAR(20) PRIMARY KEY,
    contract_id VARCHAR(20) NOT NULL,
    obligation_id VARCHAR(20) NOT NULL,
    amount DECIMAL(18,2) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'SAR',
    recognition_date DATE NOT NULL,
    expected_satisfaction_date DATE,
    status ENUM('active', 'satisfied', 'refunded') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (contract_id) REFERENCES revenue_contracts(contract_id),
    FOREIGN KEY (obligation_id) REFERENCES performance_obligations(obligation_id)
);

-- جدول تكاليف العقود
CREATE TABLE contract_costs (
    cost_id VARCHAR(20) PRIMARY KEY,
    contract_id VARCHAR(20) NOT NULL,
    type ENUM('obtaining', 'fulfillment') NOT NULL,
    description TEXT NOT NULL,
    amount DECIMAL(18,2) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'SAR',
    amortization_method ENUM('straight_line', 'performance_based') NOT NULL,
    amortization_period INT,
    status ENUM('active', 'fully_amortized', 'impaired') DEFAULT 'active',
    impairment_amount DECIMAL(18,2) DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (contract_id) REFERENCES revenue_contracts(contract_id)
);

-- إجراءات مخزنة

DELIMITER //

-- إجراء إنشاء عقد جديد
CREATE PROCEDURE create_revenue_contract(
    IN p_customer_id VARCHAR(20),
    IN p_contract_date DATE,
    IN p_start_date DATE,
    IN p_end_date DATE,
    IN p_total_amount DECIMAL(18,2),
    IN p_contract_type VARCHAR(20),
    IN p_payment_terms TEXT
)
BEGIN
    DECLARE v_contract_id VARCHAR(20);
    DECLARE v_code VARCHAR(20);
    
    -- توليد كود العقد
    SET v_code = CONCAT('CNT', DATE_FORMAT(NOW(), '%Y%m%d%H%i%s'));
    
    -- إنشاء العقد
    INSERT INTO revenue_contracts (
        contract_id,
        code,
        customer_id,
        contract_date,
        start_date,
        end_date,
        total_amount,
        contract_type,
        payment_terms,
        created_by
    )
    VALUES (
        UUID(),
        v_code,
        p_customer_id,
        p_contract_date,
        p_start_date,
        p_end_date,
        p_total_amount,
        p_contract_type,
        p_payment_terms,
        'mostafamohammad7760'
    );
    
    -- استرجاع معرف العقد
    SET v_contract_id = LAST_INSERT_ID();
    
    -- إنشاء سعر المعاملة الأولي
    INSERT INTO transaction_prices (
        price_id,
        contract_id,
        base_amount,
        final_amount,
        created_by
    )
    VALUES (
        UUID(),
        v_contract_id,
        p_total_amount,
        p_total_amount,
        'mostafamohammad7760'
    );
END //

-- إجراء حساب الإيرادات المعترف بها
CREATE PROCEDURE calculate_recognized_revenue(
    IN p_obligation_id VARCHAR(20),
    IN p_recognition_date DATE
)
BEGIN
    DECLARE v_allocated_amount DECIMAL(18,2);
    DECLARE v_completion_percentage DECIMAL(5,2);
    DECLARE v_recognition_amount DECIMAL(18,2);
    DECLARE v_contract_id VARCHAR(20);
    DECLARE v_period_id VARCHAR(20);
    
    -- استرجاع البيانات اللازمة
    SELECT 
        contract_id,
        amount,
        completion_percentage
    INTO 
        v_contract_id,
        v_allocated_amount,
        v_completion_percentage
    FROM performance_obligations
    WHERE obligation_id = p_obligation_id;
    
    -- تحديد الفترة المالية
    SELECT period_id 
    INTO v_period_id
    FROM financial_periods
    WHERE start_date <= p_recognition_date 
    AND end_date >= p_recognition_date
    AND status = 'active'
    LIMIT 1;
    
    -- حساب مبلغ الإيراد المعترف به
    SET v_recognition_amount = v_allocated_amount * (v_completion_percentage / 100);
    
    -- إدراج الإيراد المعترف به
    INSERT INTO recognized_revenue (
        revenue_id,
        contract_id,
        obligation_id,
        recognition_date,
        amount,
        period_id,
        recognition_basis,
        created_by
    )
    VALUES (
        UUID(),
        v_contract_id,
        p_obligation_id,
        p_recognition_date,
        v_recognition_amount,
        v_period_id,
        'Based on completion percentage',
        'mostafamohammad7760'
    );
    
    -- تحديث أصول العقود
    INSERT INTO contract_assets (
        asset_id,
        contract_id,
        obligation_id,
        amount,
        recognition_date,
        created_by
    )
    VALUES (
        UUID(),
        v_contract_id,
        p_obligation_id,
        v_recognition_amount,
        p_recognition_date,
        'mostafamohammad7760'
    );
END //

DELIMITER ;

-- المؤشرات
CREATE INDEX idx_revenue_contracts_dates ON revenue_contracts(contract_date, start_date, end_date);
CREATE INDEX idx_revenue_contracts_status ON revenue_contracts(status);
CREATE INDEX idx_performance_obligations_contract ON performance_obligations(contract_id);
CREATE INDEX idx_performance_obligations_status ON performance_obligations(status);
CREATE INDEX idx_transaction_prices_contract ON transaction_prices(contract_id);
CREATE INDEX idx_variable_consideration_contract ON variable_consideration(contract_id);
CREATE INDEX idx_variable_consideration_status ON variable_consideration(status);
CREATE INDEX idx_price_allocations_contract ON price_allocations(contract_id);
CREATE INDEX idx_recognized_revenue_dates ON recognized_revenue(recognition_date);
CREATE INDEX idx_recognized_revenue_status ON recognized_revenue(status);
CREATE INDEX idx_contract_assets_dates ON contract_assets(recognition_date, expected_billing_date);
CREATE INDEX idx_contract_assets_status ON contract_assets(status);
CREATE INDEX idx_contract_liabilities_dates ON contract_liabilities(recognition_date, expected_satisfaction_date);
CREATE INDEX idx_contract_liabilities_status ON contract_liabilities(status);
CREATE INDEX idx_contract_costs_type ON contract_costs(type);
CREATE INDEX idx_contract_costs_status ON contract_costs(status);