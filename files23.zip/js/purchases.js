import { PurchasesAPI } from './api/purchases_api.js';
import { ChartManager } from './chart_manager.js';
import { formatCurrency, formatNumber, formatDate } from './utils/formatters.js';
import { validateRequest, validateOrder, validateInvoice } from './utils/validators.js';

class Purchases {
    constructor() {
        this.api = new PurchasesAPI();
        this.charts = new ChartManager();
        this.currentUser = 'mostafamohammad7760';
        
        // تهيئة المكونات والبيانات
        this.initializeComponents();
        this.attachEventListeners();
        this.loadDashboardData();
        
        // تحديث الوقت كل ثانية
        this.updateDateTime();
        setInterval(() => this.updateDateTime(), 1000);
    }

    initializeComponents() {
        // عناصر لوحة المعلومات
        this.dashboardElements = {
            // المشتريات
            totalPurchases: document.getElementById('totalPurchases'),
            totalPayments: document.getElementById('totalPayments'),
            totalReturns: document.getElementById('totalReturns'),
            
            // الطلبات
            pendingRequests: document.getElementById('pendingRequests'),
            processingOrders: document.getElementById('processingOrders'),
            receivedOrders: document.getElementById('receivedOrders'),
            
            // عروض الأسعار
            pendingQuotations: document.getElementById('pendingQuotations'),
            acceptedQuotations: document.getElementById('acceptedQuotations'),
            rejectedQuotations: document.getElementById('rejectedQuotations'),
            
            // المدفوعات
            totalPayables: document.getElementById('totalPayables'),
            overduePayables: document.getElementById('overduePayables'),
            lastPayment: document.getElementById('lastPayment'),
            
            // الجداول
            latestRequestsTable: document.getElementById('latestRequestsTable')
        };

        // عناصر الفلترة
        this.filterElements = {
            purchasesChartPeriod: document.getElementById('purchasesChartPeriod'),
            topItemsPeriod: document.getElementById('topItemsPeriod')
        };

        // تهيئة الرسوم البيانية
        this.initializeCharts();
        
        // تهيئة القوالب
        this.requestRowTemplate = document.getElementById('requestRowTemplate');
    }

    async loadDashboardData() {
        try {
            this.showLoading();

            const [
                purchasesStats,
                orderStats,
                quotationStats,
                payablesStats,
                purchasesAnalysis,
                topItems,
                latestRequests
            ] = await Promise.all([
                this.api.getPurchasesStats(),
                this.api.getOrderStats(),
                this.api.getQuotationStats(),
                this.api.getPayablesStats(),
                this.api.getPurchasesAnalysis(this.filterElements.purchasesChartPeriod.value),
                this.api.getTopItems(this.filterElements.topItemsPeriod.value),
                this.api.getLatestRequests()
            ]);

            this.updatePurchasesStats(purchasesStats);
            this.updateOrderStats(orderStats);
            this.updateQuotationStats(quotationStats);
            this.updatePayablesStats(payablesStats);
            this.updateCharts(purchasesAnalysis, topItems);
            this.renderLatestRequests(latestRequests);

            this.hideLoading();
        } catch (error) {
            this.hideLoading();
            this.showError('حدث خطأ أثناء تحميل البيانات');
            console.error('Dashboard loading error:', error);
        }
    }

    initializeCharts() {
        // تهيئة رسم تحليل المشتريات
        this.charts.initializeLineChart('purchasesAnalysisChart', {
            labels: [],
            datasets: [
                {
                    label: 'المشتريات',
                    data: [],
                    borderColor: '#27ae60',
                    backgroundColor: 'rgba(39, 174, 96, 0.1)',
                    fill: true
                },
                {
                    label: 'المرتجعات',
                    data: [],
                    borderColor: '#e74c3c',
                    backgroundColor: 'rgba(231, 76, 60, 0.1)',
                    fill: true
                }
            ],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => formatCurrency(value)
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: context => formatCurrency(context.parsed.y)
                        }
                    }
                }
            }
        });

        // تهيئة رسم أعلى الأصناف طلباً
        this.charts.initializeBarChart('topItemsChart', {
            labels: [],
            datasets: [{
                data: [],
                backgroundColor: [
                    '#2ecc71',
                    '#3498db',
                    '#f1c40f',
                    '#e67e22',
                    '#e74c3c',
                    '#9b59b6',
                    '#34495e',
                    '#16a085',
                    '#2980b9',
                    '#8e44ad'
                ]
            }],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: 'y',
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: context => 
                                `${context.label}: ${formatNumber(context.parsed)} وحدة`
                        }
                    }
                }
            }
        });
    }

    updatePurchasesStats(stats) {
        this.dashboardElements.totalPurchases.textContent = 
            formatCurrency(stats.total);
        this.dashboardElements.totalPayments.textContent = 
            formatCurrency(stats.payments);
        this.dashboardElements.totalReturns.textContent = 
            formatCurrency(stats.returns);
    }

    updateOrderStats(stats) {
        this.dashboardElements.pendingRequests.textContent = 
            formatNumber(stats.pending);
        this.dashboardElements.processingOrders.textContent = 
            formatNumber(stats.processing);
        this.dashboardElements.receivedOrders.textContent = 
            formatNumber(stats.received);
    }

    updateQuotationStats(stats) {
        this.dashboardElements.pendingQuotations.textContent = 
            formatNumber(stats.pending);
        this.dashboardElements.acceptedQuotations.textContent = 
            formatNumber(stats.accepted);
        this.dashboardElements.rejectedQuotations.textContent = 
            formatNumber(stats.rejected);
    }

    updatePayablesStats(stats) {
        this.dashboardElements.totalPayables.textContent = 
            formatCurrency(stats.total);
        this.dashboardElements.overduePayables.textContent = 
            formatCurrency(stats.overdue);
        this.dashboardElements.lastPayment.textContent = 
            stats.lastPayment ? formatDate(stats.lastPayment) : '-';
    }

    updateCharts(purchasesData, itemsData) {
        // تحديث رسم تحليل المشتريات
        this.charts.updateLineChart('purchasesAnalysisChart', {
            labels: purchasesData.labels,
            datasets: [
                {
                    data: purchasesData.purchases,
                    label: 'المشتريات'
                },
                {
                    data: purchasesData.returns,
                    label: 'المرتجعات'
                }
            ]
        });

        // تحديث رسم أعلى الأصناف طلباً
        this.charts.updateBarChart('topItemsChart', {
            labels: itemsData.labels,
            data: itemsData.values
        });
    }

    renderLatestRequests(requests) {
        const tbody = this.dashboardElements.latestRequestsTable;
        tbody.innerHTML = '';

        requests.forEach(request => {
            const tr = this.createRequestRow(request);
            tbody.appendChild(tr);
        });
    }

    createRequestRow(request) {
        const template = this.requestRowTemplate.content.cloneNode(true);
        const tr = template.querySelector('tr');
        
        tr.querySelector('.request-number').textContent = request.number;
        tr.querySelector('.request-date').textContent = 
            formatDate(request.date);
        tr.querySelector('.department-name').textContent = request.department;
        tr.querySelector('.requested-quantity').textContent = 
            formatNumber(request.requestedQuantity);
        tr.querySelector('.received-quantity').textContent = 
            formatNumber(request.receivedQuantity);
        
        const statusCell = tr.querySelector('.request-status');
        statusCell.textContent = this.translateRequestStatus(request.status);
        statusCell.classList.add(request.status.toLowerCase());

        // إضافة مستمعات الأحداث للأزرار
        tr.querySelector('.view-request').addEventListener('click', 
            () => this.viewRequest(request.id));
        
        const approveButton = tr.querySelector('.approve-request');
        const rejectButton = tr.querySelector('.reject-request');
        
        if (request.status === 'pending') {
            approveButton.addEventListener('click', 
                () => this.approveRequest(request.id));
            rejectButton.addEventListener('click', 
                () => this.rejectRequest(request.id));
        } else {
            approveButton.style.display = 'none';
            rejectButton.style.display = 'none';
        }

        return tr;
    }

    attachEventListeners() {
        // مستمعات أحداث الإجراءات السريعة
        document.getElementById('createRequest')?.addEventListener('click', 
            () => this.showRequestModal());
        document.getElementById('createOrder')?.addEventListener('click', 
            () => this.showOrderModal());
        document.getElementById('createInvoice')?.addEventListener('click', 
            () => this.showInvoiceModal());
        document.getElementById('createReturn')?.addEventListener('click', 
            () => this.showReturnModal());

        // مستمعات أحداث الفلترة
        this.filterElements.purchasesChartPeriod.addEventListener('change', 
            () => this.loadPurchasesAnalysis());
        this.filterElements.topItemsPeriod.addEventListener('change', 
            () => this.loadTopItems());

        // مستمعات أحداث التصدير
        document.getElementById('exportPurchasesChart')?.addEventListener('click', 
            () => this.exportChart('purchasesAnalysisChart'));
        document.getElementById('exportTopItemsChart')?.addEventListener('click', 
            () => this.exportChart('topItemsChart'));

        // مستمعات أحداث عرض الكل
        document.getElementById('viewAllRequests')?.addEventListener('click', 
            () => this.navigateToRequests());
    }

    // توابع مساعدة
    translateRequestStatus(status) {
        const statusMap = {
            draft: 'مسودة',
            pending: 'معلق',
            approved: 'معتمد',
            rejected: 'مرفوض',
            cancelled: 'ملغى',
            completed: 'مكتمل'
        };
        return statusMap[status] || status;
    }

    updateDateTime() {
        document.getElementById('currentDateTime').textContent = 
            new Date().toISOString().slice(0, 19).replace('T', ' ');
    }

    showLoading() {
        const loader = document.createElement('div');
        loader.className = 'loading-overlay';
        loader.innerHTML = '<div class="loading-spinner"></div>';
        document.body.appendChild(loader);
    }

    hideLoading() {
        document.querySelector('.loading-overlay')?.remove();
    }

    showError(message) {
        console.error(message);
        // يمكن تحسين هذه الدالة لعرض رسائل خطأ أكثر جاذبية
        alert(message);
    }

    showSuccess(message) {
        // يمكن تحسين هذه الدالة لعرض رسائل نجاح أكثر جاذبية
        alert(message);
    }
}

// تهيئة التطبيق عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    new Purchases();
});