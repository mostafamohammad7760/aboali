/**
 * مزود خدمة Dropbox للتخزين السحابي
 * التاريخ: 2025-05-09 04:40:56
 * المستخدم: mostafamohammad7760
 */

import { Dropbox } from 'dropbox';
import { CloudStorageBase, CloudFile, CloudUploadOptions } from './CloudStorageBase';
import { CloudStorageError } from '../errors/CloudStorageError';

export class DropboxProvider extends CloudStorageBase {
  private client: Dropbox;

  constructor(config: {
    accessToken: string;
    appKey: string;
    appSecret: string;
  }) {
    super();
    this.client = new Dropbox({
      accessToken: config.accessToken
    });
  }

  public async upload(path: string, data: Buffer, options?: CloudUploadOptions): Promise<void> {
    try {
      await this.client.filesUpload({
        path: this.normalizePath(path),
        contents: data,
        mode: { '.tag': 'overwrite' },
        strict_conflict: true
      });

      if (options?.metadata) {
        await this.client.filePropertiesPropertiesAdd({
          path: this.normalizePath(path),
          properties: options.metadata
        });
      }
    } catch (error) {
      throw new CloudStorageError('فشل رفع الملف إلى Dropbox', error);
    }
  }

  public async download(path: string): Promise<CloudFile> {
    try {
      const response = await this.client.filesDownload({
        path: this.normalizePath(path)
      });

      const metadata = await this.client.filePropertiesPropertiesGet({
        path: this.normalizePath(path)
      });

      return {
        data: (response.result as any).fileBinary,
        metadata: metadata.result.properties
      };
    } catch (error) {
      throw new CloudStorageError('فشل تحميل الملف من Dropbox', error);
    }
  }

  public async delete(path: string): Promise<void> {
    try {
      await this.client.filesDeleteV2({
        path: this.normalizePath(path)
      });
    } catch (error) {
      throw new CloudStorageError('فشل حذف الملف من Dropbox', error);
    }
  }

  public async list(prefix: string): Promise<CloudFile[]> {
    try {
      const response = await this.client.filesListFolder({
        path: this.normalizePath(prefix)
      });

      const files = await Promise.all(
        response.result.entries.map(async (entry) => {
          if (entry['.tag'] === 'file') {
            const metadata = await this.client.filePropertiesPropertiesGet({
              path: entry.path_display!
            });

            return {
              path: entry.path_display!,
              size: entry.size!,
              metadata: metadata.result.properties
            };
          }
          return null;
        })
      );

      return files.filter((file): file is CloudFile => file !== null);
    } catch (error) {
      throw new CloudStorageError('فشل قراءة محتويات المجلد من Dropbox', error);
    }
  }

  private normalizePath(path: string): string {
    return path.startsWith('/') ? path : `/${path}`;
  }
}