export class AccountingAPI {
    constructor() {
        this.baseUrl = '/api/v1';
    }

    async request(endpoint, options = {}) {
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                ...options,
                headers: {
                    'Content-Type': 'application/json',
                    ...options.headers
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            return data;
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    }

    // طلبات شجرة الحسابات
    async getAccountTree() {
        return this.request('/accounts/tree');
    }

    async createAccount(accountData) {
        return this.request('/accounts', {
            method: 'POST',
            body: JSON.stringify(accountData)
        });
    }

    async updateAccount(accountId, accountData) {
        return this.request(`/accounts/${accountId}`, {
            method: 'PUT',
            body: JSON.stringify(accountData)
        });
    }

    // طلبات القيود المحاسبية
    async getLastEntryNumber() {
        return this.request('/entries/last-number');
    }

    async createJournalEntry(entryData) {
        return this.request('/entries', {
            method: 'POST',
            body: JSON.stringify(entryData)
        });
    }

    async getJournalEntries(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/entries?${queryString}`);
    }

    async getJournalEntry(entryId) {
        return this.request(`/entries/${entryId}`);
    }

    // طلبات مراكز التكلفة
    async getCostCenters() {
        return this.request('/cost-centers');
    }

    // طلبات التقارير
    async getTrialBalance(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/trial-balance?${queryString}`);
    }

    async getAccountStatement(accountId, params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/account-statement/${accountId}?${queryString}`);
    }

    async getFinancialStatements(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/reports/financial-statements?${queryString}`);
    }

    // طلبات الأرصدة
    async getAccountBalances(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/balances?${queryString}`);
    }

    async updateAccountBalance(accountId, balanceData) {
        return this.request(`/balances/${accountId}`, {
            method: 'PUT',
            body: JSON.stringify(balanceData)
        });
    }
}