<!-- 
مكون نافذة الخصم
التاريخ: 2025-05-09 03:38:22
المستخدم: mostafamohammad7760
-->

<template>
  <div class="discount-modal">
    <div class="modal-overlay" @click="$emit('close')"></div>
    
    <div class="modal-content">
      <div class="modal-header">
        <h2>إضافة خصم</h2>
        <button class="close-btn" @click="$emit('close')">
          <i class="fas fa-times"></i>
        </button>
      </div>

      <div class="modal-body">
        <!-- معلومات المبلغ -->
        <div class="amount-info">
          <div class="info-row">
            <span>المبلغ قبل الخصم:</span>
            <span>{{ formatCurrency(subtotal) }}</span>
          </div>
        </div>

        <!-- نوع الخصم -->
        <div class="discount-type">
          <h3>نوع الخصم</h3>
          <div class="type-selector">
            <button 
              :class="{ active: discountType === 'percentage' }"
              @click="setDiscountType('percentage')"
            >
              <i class="fas fa-percentage"></i>
              نسبة مئوية
            </button>
            <button 
              :class="{ active: discountType === 'fixed' }"
              @click="setDiscountType('fixed')"
            >
              <i class="fas fa-money-bill"></i>
              مبلغ ثابت
            </button>
          </div>
        </div>

        <!-- قيمة الخصم -->
        <div class="discount-value">
          <div class="form-group">
            <label>
              {{ discountType === 'percentage' ? 'نسبة الخصم' : 'قيمة الخصم' }}
              <span v-if="discountType === 'percentage'">(%)</span>
            </label>
            <div class="value-input">
              <input
                type="number"
                v-model="discountValue"
                :min="0"
                :max="discountType === 'percentage' ? 100 : subtotal"
                :step="discountType === 'percentage' ? 1 : 0.5"
                @input="calculateDiscount"
              >
              <!-- أزرار القيم السريعة -->
              <div class="quick-values">
                <button
                  v-for="value in quickValues"
                  :key="value"
                  @click="applyQuickValue(value)"
                >
                  {{ formatQuickValue(value) }}
                </button>
              </div>
            </div>
          </div>

          <!-- عرض النتيجة -->
          <div class="discount-result">
            <div class="result-row">
              <span>قيمة الخصم:</span>
              <span class="discount-amount">
                {{ formatCurrency(calculatedDiscount) }}
              </span>
            </div>
            <div class="result-row total">
              <span>المبلغ بعد الخصم:</span>
              <span>{{ formatCurrency(subtotal - calculatedDiscount) }}</span>
            </div>
          </div>
        </div>

        <!-- سبب الخصم -->
        <div class="discount-reason">
          <div class="form-group">
            <label>سبب الخصم</label>
            <select v-model="discountReason">
              <option value="">-- اختر السبب --</option>
              <option v-for="reason in discountReasons" 
                      :key="reason.id" 
                      :value="reason.id">
                {{ reason.name }}
              </option>
            </select>
          </div>
          <div class="form-group" v-if="discountReason === 'other'">
            <label>سبب آخر</label>
            <input
              type="text"
              v-model="customReason"
              placeholder="اذكر سبب الخصم..."
              maxlength="100"
            >
          </div>
        </div>
      </div>

      <div class="modal-footer">
        <button 
          class="btn btn-light" 
          @click="$emit('close')"
        >
          إلغاء
        </button>
        <button 
          class="btn btn-primary"
          :disabled="!isValid"
          @click="applyDiscount"
        >
          تطبيق الخصم
        </button>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, computed } from 'vue';
import { useStore } from 'vuex';

export default {
  name: 'DiscountModal',

  props: {
    subtotal: {
      type: Number,
      required: true
    }
  },

  emits: ['close', 'apply'],

  setup(props, { emit }) {
    const store = useStore();

    // الحالة
    const discountType = ref('percentage');
    const discountValue = ref('');
    const discountReason = ref('');
    const customReason = ref('');
    const calculatedDiscount = ref(0);

    // القيم السريعة للخصم
    const quickValues = computed(() => {
      if (discountType.value === 'percentage') {
        return [5, 10, 15, 20, 25, 50];
      } else {
        const baseAmount = props.subtotal;
        return [
          Math.round(baseAmount * 0.05),
          Math.round(baseAmount * 0.1),
          Math.round(baseAmount * 0.15),
          Math.round(baseAmount * 0.2)
        ];
      }
    });

    // أسباب الخصم
    const discountReasons = [
      { id: 'loyalty', name: 'عميل مميز' },
      { id: 'damage', name: 'منتج معيب' },
      { id: 'clearance', name: 'تصفية' },
      { id: 'promotion', name: 'عرض ترويجي' },
      { id: 'bulk', name: 'خصم كمية' },
      { id: 'other', name: 'سبب آخر' }
    ];

    // التحقق من صحة البيانات
    const isValid = computed(() => {
      const hasValue = parseFloat(discountValue.value) > 0;
      const isValidPercentage = discountType.value === 'percentage' && 
                               parseFloat(discountValue.value) <= 100;
      const isValidFixed = discountType.value === 'fixed' && 
                          parseFloat(discountValue.value) <= props.subtotal;
      const hasReason = discountReason.value && 
                       (discountReason.value !== 'other' || customReason.value);
      
      return hasValue && (isValidPercentage || isValidFixed) && hasReason;
    });

    // الوظائف
    const setDiscountType = (type) => {
      discountType.value = type;
      discountValue.value = '';
      calculateDiscount();
    };

    const calculateDiscount = () => {
      const value = parseFloat(discountValue.value) || 0;
      
      if (discountType.value === 'percentage') {
        calculatedDiscount.value = (props.subtotal * value) / 100;
      } else {
        calculatedDiscount.value = Math.min(value, props.subtotal);
      }
    };

    const applyQuickValue = (value) => {
      discountValue.value = value;
      calculateDiscount();
    };

    const formatQuickValue = (value) => {
      return discountType.value === 'percentage' 
        ? `${value}%` 
        : new Intl.NumberFormat('ar-SA', {
            style: 'currency',
            currency: 'SAR'
          }).format(value);
    };

    const applyDiscount = () => {
      if (!isValid.value) return;

      emit('apply', {
        type: discountType.value,
        value: parseFloat(discountValue.value),
        amount: calculatedDiscount.value,
        reason: discountReason.value === 'other' ? customReason.value : discountReason.value
      });
    };

    return {
      discountType,
      discountValue,
      discountReason,
      customReason,
      calculatedDiscount,
      quickValues,
      discountReasons,
      isValid,
      setDiscountType,
      calculateDiscount,
      applyQuickValue,
      formatQuickValue,
      applyDiscount,
      formatCurrency: (amount) => new Intl.NumberFormat('ar-SA', {
        style: 'currency',
        currency: 'SAR'
      }).format(amount)
    };
  }
};
</script>

<style lang="scss" scoped>
// التنسيقات في الرسالة التالية...
</style>