-- إنشاء جداول الموارد البشرية

-- جدول الإدارات
CREATE TABLE departments (
    department_id VARCHAR(20) PRIMARY KEY,
    parent_id VARCHAR(20),
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    manager_id VARCHAR(50),
    description TEXT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (parent_id) REFERENCES departments(department_id)
);

-- جدول الوظائف
CREATE TABLE jobs (
    job_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    requirements TEXT,
    min_salary DECIMAL(18,2),
    max_salary DECIMAL(18,2),
    grade_level INT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50)
);

-- جدول الموظفين
CREATE TABLE employees (
    employee_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    gender ENUM('male', 'female') NOT NULL,
    birth_date DATE,
    national_id VARCHAR(20) UNIQUE,
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(20),
    address TEXT,
    department_id VARCHAR(20),
    job_id VARCHAR(20),
    direct_manager_id VARCHAR(20),
    hire_date DATE NOT NULL,
    contract_type ENUM('full_time', 'part_time', 'temporary', 'contract') NOT NULL,
    basic_salary DECIMAL(18,2) NOT NULL,
    status ENUM('active', 'vacation', 'suspended', 'terminated') DEFAULT 'active',
    termination_date DATE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (department_id) REFERENCES departments(department_id),
    FOREIGN KEY (job_id) REFERENCES jobs(job_id),
    FOREIGN KEY (direct_manager_id) REFERENCES employees(employee_id)
);

-- جدول الإجازات
CREATE TABLE vacations (
    vacation_id VARCHAR(20) PRIMARY KEY,
    employee_id VARCHAR(20) NOT NULL,
    vacation_type ENUM(
        'annual', 
        'sick', 
        'unpaid', 
        'emergency',
        'maternity',
        'other'
    ) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    days_count INT NOT NULL,
    reason TEXT,
    attachments TEXT,
    status ENUM('pending', 'approved', 'rejected', 'cancelled') DEFAULT 'pending',
    approved_by VARCHAR(50),
    approval_date DATETIME,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
);

-- جدول رصيد الإجازات
CREATE TABLE vacation_balance (
    balance_id VARCHAR(20) PRIMARY KEY,
    employee_id VARCHAR(20) NOT NULL,
    year INT NOT NULL,
    vacation_type ENUM('annual', 'sick', 'other') NOT NULL,
    total_days INT NOT NULL DEFAULT 0,
    used_days INT NOT NULL DEFAULT 0,
    remaining_days INT NOT NULL DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id),
    UNIQUE KEY unique_balance (employee_id, year, vacation_type)
);

-- جدول الحضور والانصراف
CREATE TABLE attendance (
    attendance_id VARCHAR(20) PRIMARY KEY,
    employee_id VARCHAR(20) NOT NULL,
    attendance_date DATE NOT NULL,
    time_in TIME,
    time_out TIME,
    late_minutes INT DEFAULT 0,
    overtime_minutes INT DEFAULT 0,
    status ENUM('present', 'absent', 'vacation', 'weekend', 'holiday') NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id),
    UNIQUE KEY unique_attendance (employee_id, attendance_date)
);

-- جدول المؤهلات والشهادات
CREATE TABLE qualifications (
    qualification_id VARCHAR(20) PRIMARY KEY,
    employee_id VARCHAR(20) NOT NULL,
    qualification_type ENUM(
        'education',
        'certification',
        'training',
        'skill'
    ) NOT NULL,
    title VARCHAR(200) NOT NULL,
    institution VARCHAR(200),
    major VARCHAR(200),
    grade VARCHAR(50),
    start_date DATE,
    end_date DATE,
    description TEXT,
    attachments TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
);

-- جدول تقييم الأداء
CREATE TABLE performance_reviews (
    review_id VARCHAR(20) PRIMARY KEY,
    employee_id VARCHAR(20) NOT NULL,
    reviewer_id VARCHAR(20) NOT NULL,
    review_period VARCHAR(50) NOT NULL,
    review_date DATE NOT NULL,
    performance_score DECIMAL(5,2),
    strengths TEXT,
    weaknesses TEXT,
    recommendations TEXT,
    goals TEXT,
    status ENUM('draft', 'submitted', 'approved', 'rejected') DEFAULT 'draft',
    approved_by VARCHAR(50),
    approval_date DATETIME,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id),
    FOREIGN KEY (reviewer_id) REFERENCES employees(employee_id)
);

-- إجراءات مخزنة

DELIMITER //

-- إجراء تحديث رصيد الإجازات
CREATE PROCEDURE update_vacation_balance(
    IN p_employee_id VARCHAR(20),
    IN p_year INT,
    IN p_vacation_type VARCHAR(20),
    IN p_days_count INT,
    IN p_operation_type VARCHAR(10)
)
BEGIN
    DECLARE v_total_days INT;
    DECLARE v_used_days INT;
    DECLARE v_remaining_days INT;
    
    -- الحصول على الرصيد الحالي
    SELECT 
        COALESCE(total_days, 0),
        COALESCE(used_days, 0),
        COALESCE(remaining_days, 0)
    INTO 
        v_total_days,
        v_used_days,
        v_remaining_days
    FROM vacation_balance
    WHERE 
        employee_id = p_employee_id
        AND year = p_year
        AND vacation_type = p_vacation_type;
    
    -- تحديث الرصيد
    IF p_operation_type = 'ADD' THEN
        SET v_used_days = v_used_days + p_days_count;
        SET v_remaining_days = v_total_days - v_used_days;
    ELSEIF p_operation_type = 'SUBTRACT' THEN
        SET v_used_days = v_used_days - p_days_count;
        SET v_remaining_days = v_total_days - v_used_days;
    END IF;
    
    -- إدراج أو تحديث الرصيد
    INSERT INTO vacation_balance (
        employee_id,
        year,
        vacation_type,
        total_days,
        used_days,
        remaining_days
    ) VALUES (
        p_employee_id,
        p_year,
        p_vacation_type,
        v_total_days,
        v_used_days,
        v_remaining_days
    ) ON DUPLICATE KEY UPDATE
        used_days = v_used_days,
        remaining_days = v_remaining_days,
        updated_at = NOW();
END //

-- إجراء تسجيل الحضور
CREATE PROCEDURE record_attendance(
    IN p_employee_id VARCHAR(20),
    IN p_attendance_date DATE,
    IN p_time_in TIME,
    IN p_created_by VARCHAR(50)
)
BEGIN
    DECLARE v_schedule_start TIME;
    DECLARE v_late_minutes INT;
    
    -- احتساب التأخير
    SET v_schedule_start = '09:00:00'; -- يمكن تعديلها حسب جدول الموظف
    SET v_late_minutes = TIMESTAMPDIFF(MINUTE, v_schedule_start, p_time_in);
    
    IF v_late_minutes < 0 THEN
        SET v_late_minutes = 0;
    END IF;
    
    -- تسجيل الحضور
    INSERT INTO attendance (
        attendance_id,
        employee_id,
        attendance_date,
        time_in,
        late_minutes,
        status,
        created_by
    ) VALUES (
        UUID(),
        p_employee_id,
        p_attendance_date,
        p_time_in,
        v_late_minutes,
        'present',
        p_created_by
    ) ON DUPLICATE KEY UPDATE
        time_in = p_time_in,
        late_minutes = v_late_minutes,
        updated_at = NOW(),
        updated_by = p_created_by;
END //

DELIMITER ;

-- المؤشرات
CREATE INDEX idx_employees_department ON employees(department_id);
CREATE INDEX idx_employees_job ON employees(job_id);
CREATE INDEX idx_employees_manager ON employees(direct_manager_id);
CREATE INDEX idx_employees_status ON employees(status);
CREATE INDEX idx_departments_parent ON departments(parent_id);
CREATE INDEX idx_vacations_employee ON vacations(employee_id);
CREATE INDEX idx_vacations_dates ON vacations(start_date, end_date);
CREATE INDEX idx_attendance_employee ON attendance(employee_id);
CREATE INDEX idx_attendance_date ON attendance(attendance_date);
CREATE INDEX idx_qualifications_employee ON qualifications(employee_id);
CREATE INDEX idx_performance_employee ON performance_reviews(employee_id);
CREATE INDEX idx_performance_reviewer ON performance_reviews(reviewer_id);