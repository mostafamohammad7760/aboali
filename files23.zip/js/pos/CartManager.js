/**
 * مدير السلة - إدارة عمليات السلة في نظام نقاط البيع
 * @module CartManager
 * التاريخ: 2025-05-09 02:53:24
 * المستخدم: mostafamohammad7760
 */

export class CartManager {
    constructor() {
        this.items = new Map(); // استخدام Map للتخزين الفعال
        this.defaultVatRate = 0.15; // نسبة الضريبة الافتراضية 15%
        
        // حفظ مرجع للسلة المعلقة
        this.heldCarts = new Map();
    }

    /**
     * إضافة منتج للسلة
     * @param {Object} item - تفاصيل المنتج
     */
    addItem(item) {
        const { id, name, price, quantity = 1, vat_rate = this.defaultVatRate } = item;

        if (this.items.has(id)) {
            // تحديث الكمية إذا كان المنتج موجوداً
            const existingItem = this.items.get(id);
            existingItem.quantity += quantity;
            this.items.set(id, existingItem);
        } else {
            // إضافة منتج جديد
            this.items.set(id, {
                id,
                name,
                price,
                quantity,
                vat_rate,
                total: 0 // سيتم حسابه في updateItemTotals
            });
        }

        this.updateItemTotals(id);
        return this.getItems();
    }

    /**
     * تحديث كمية منتج
     * @param {string} itemId - معرف المنتج
     * @param {number} quantity - الكمية الجديدة
     */
    updateQuantity(itemId, quantity) {
        if (!this.items.has(itemId)) {
            throw new Error('المنتج غير موجود في السلة');
        }

        if (quantity <= 0) {
            this.removeItem(itemId);
            return this.getItems();
        }

        const item = this.items.get(itemId);
        item.quantity = quantity;
        this.updateItemTotals(itemId);
        return this.getItems();
    }

    /**
     * حذف منتج من السلة
     * @param {string} itemId - معرف المنتج
     */
    removeItem(itemId) {
        this.items.delete(itemId);
        return this.getItems();
    }

    /**
     * تحديث إجماليات منتج
     * @param {string} itemId - معرف المنتج
     */
    updateItemTotals(itemId) {
        const item = this.items.get(itemId);
        if (!item) return;

        item.total = item.price * item.quantity;
        item.vat_amount = item.total * item.vat_rate;
        item.total_with_vat = item.total + item.vat_amount;
    }

    /**
     * حساب إجماليات السلة
     * @param {Object} options - خيارات الحساب
     */
    calculateTotals(options = {}) {
        const { discountAmount = 0, discountType = 'fixed' } = options;

        let subtotal = 0;
        let totalVat = 0;

        // حساب المجموع الفرعي والضريبة
        for (const item of this.items.values()) {
            subtotal += item.total;
            totalVat += item.vat_amount;
        }

        // حساب الخصم
        let discount = 0;
        if (discountType === 'percentage') {
            discount = (subtotal * discountAmount) / 100;
        } else {
            discount = discountAmount;
        }

        // التأكد من أن الخصم لا يتجاوز المجموع الفرعي
        discount = Math.min(discount, subtotal);

        // حساب المجموع النهائي
        const total = subtotal - discount + totalVat;

        return {
            subtotal,
            discount,
            tax: totalVat,
            total,
            itemCount: this.items.size,
            totalQuantity: this.calculateTotalQuantity()
        };
    }

    /**
     * حساب إجمالي الكميات
     */
    calculateTotalQuantity() {
        let total = 0;
        for (const item of this.items.values()) {
            total += item.quantity;
        }
        return total;
    }

    /**
     * الحصول على محتويات السلة
     */
    getItems() {
        return Array.from(this.items.values());
    }

    /**
     * تعليق السلة الحالية
     * @param {string} reference - مرجع للسلة المعلقة
     */
    holdCart(reference) {
        if (!reference) {
            throw new Error('مطلوب مرجع للسلة المعلقة');
        }

        this.heldCarts.set(reference, {
            items: new Map(this.items),
            timestamp: new Date(),
            totals: this.calculateTotals()
        });

        this.clearCart();
        return reference;
    }

    /**
     * استرجاع سلة معلقة
     * @param {string} reference - مرجع السلة المعلقة
     */
    restoreHeldCart(reference) {
        const heldCart = this.heldCarts.get(reference);
        if (!heldCart) {
            throw new Error('السلة المعلقة غير موجودة');
        }

        this.items = new Map(heldCart.items);
        this.heldCarts.delete(reference);
        return this.getItems();
    }

    /**
     * الحصول على قائمة السلات المعلقة
     */
    getHeldCarts() {
        return Array.from(this.heldCarts.entries()).map(([reference, cart]) => ({
            reference,
            timestamp: cart.timestamp,
            itemCount: cart.items.size,
            totals: cart.totals
        }));
    }

    /**
     * مسح السلة الحالية
     */
    clearCart() {
        this.items.clear();
        return this.getItems();
    }

    /**
     * التحقق من وجود منتج في السلة
     * @param {string} itemId - معرف المنتج
     */
    hasItem(itemId) {
        return this.items.has(itemId);
    }

    /**
     * الحصول على منتج من السلة
     * @param {string} itemId - معرف المنتج
     */
    getItem(itemId) {
        return this.items.get(itemId);
    }

    /**
     * التحقق من وجود تعارض في المخزون
     * @param {Array} inventory - بيانات المخزون
     */
    checkInventoryConflicts(inventory) {
        const conflicts = [];

        for (const [itemId, item] of this.items) {
            const inventoryItem = inventory.find(i => i.id === itemId);
            if (!inventoryItem) {
                conflicts.push({
                    itemId,
                    name: item.name,
                    type: 'not_found',
                    message: 'المنتج غير موجود في المخزون'
                });
                continue;
            }

            if (item.quantity > inventoryItem.stock_quantity) {
                conflicts.push({
                    itemId,
                    name: item.name,
                    type: 'insufficient_stock',
                    requested: item.quantity,
                    available: inventoryItem.stock_quantity,
                    message: 'الكمية المطلوبة غير متوفرة في المخزون'
                });
            }
        }

        return conflicts;
    }
}