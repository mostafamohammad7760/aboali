/**
 * مكون خانة الاختيار الأساسية
 * التاريخ: 2025-05-09 03:56:22
 * المستخدم: mostafamohammad7760
 */

<template>
  <label
    :class="[
      'base-checkbox',
      size,
      {
        'is-checked': modelValue,
        'is-disabled': disabled,
        'is-indeterminate': indeterminate,
        'has-error': error
      }
    ]"
  >
    <!-- خانة الاختيار الأصلية (مخفية) -->
    <input
      type="checkbox"
      :checked="modelValue"
      :name="name"
      :value="value"
      :disabled="disabled"
      :required="required"
      class="checkbox-input"
      @change="handleChange"
    >

    <!-- خانة الاختيار المخصصة -->
    <span class="checkbox-custom">
      <!-- أيقونة علامة الصح -->
      <svg v-if="!indeterminate && modelValue" class="checkbox-icon" viewBox="0 0 24 24">
        <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z" />
      </svg>
      
      <!-- أيقونة الحالة غير المحددة -->
      <svg v-if="indeterminate" class="checkbox-icon" viewBox="0 0 24 24">
        <path d="M19 13H5v-2h14v2z" />
      </svg>
    </span>

    <!-- التسمية -->
    <span class="checkbox-label" v-if="$slots.default">
      <slot></slot>
    </span>
  </label>

  <!-- رسالة الخطأ -->
  <div v-if="error" class="error-message">
    {{ error }}
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue';

export default defineComponent({
  name: 'BaseCheckbox',

  props: {
    // القيمة المحددة
    modelValue: {
      type: Boolean,
      default: false
    },
    // القيمة
    value: {
      type: [String, Number, Boolean, Object],
      default: true
    },
    // الاسم
    name: {
      type: String,
      default: ''
    },
    // الحجم
    size: {
      type: String,
      default: 'md',
      validator: (value: string) => ['sm', 'md', 'lg'].includes(value)
    },
    // معطل
    disabled: {
      type: Boolean,
      default: false
    },
    // إلزامي
    required: {
      type: Boolean,
      default: false
    },
    // حالة غير محددة
    indeterminate: {
      type: Boolean,
      default: false
    },
    // رسالة الخطأ
    error: {
      type: String,
      default: ''
    }
  },

  emits: ['update:modelValue', 'change'],

  setup(props, { emit }) {
    // معالجة التغيير
    const handleChange = (event: Event) => {
      const target = event.target as HTMLInputElement;
      emit('update:modelValue', target.checked);
      emit('change', {
        checked: target.checked,
        value: props.value
      });
    };

    return {
      handleChange
    };
  }
});
</script>

<style lang="scss" scoped>
.base-checkbox {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  cursor: pointer;
  user-select: none;

  // إخفاء خانة الاختيار الأصلية
  .checkbox-input {
    position: absolute;
    opacity: 0;
    width: 0;
    height: 0;
  }

  // خانة الاختيار المخصصة
  .checkbox-custom {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 1.25rem;
    height: 1.25rem;
    background: var(--input-bg);
    border: 2px solid var(--border-color);
    border-radius: var(--border-radius-sm);
    transition: all 0.2s ease;

    // أيقونة علامة الصح
    .checkbox-icon {
      width: 1rem;
      height: 1rem;
      fill: currentColor;
      opacity: 0;
      transform: scale(0.8);
      transition: all 0.2s ease;
    }
  }

  // التسمية
  .checkbox-label {
    font-size: 1rem;
    color: var(--text-color);
  }

  // الأحجام
  &.sm {
    .checkbox-custom {
      width: 1rem;
      height: 1rem;

      .checkbox-icon {
        width: 0.75rem;
        height: 0.75rem;
      }
    }

    .checkbox-label {
      font-size: 0.875rem;
    }
  }

  &.lg {
    .checkbox-custom {
      width: 1.5rem;
      height: 1.5rem;

      .checkbox-icon {
        width: 1.25rem;
        height: 1.25rem;
      }
    }

    .checkbox-label {
      font-size: 1.125rem;
    }
  }

  // الحالة المحددة
  &.is-checked {
    .checkbox-custom {
      background: var(--primary-color);
      border-color: var(--primary-color);
      color: var(--primary-contrast);

      .checkbox-icon {
        opacity: 1;
        transform: scale(1);
      }
    }
  }

  // الحالة غير المحددة
  &.is-indeterminate {
    .checkbox-custom {
      background: var(--primary-color);
      border-color: var(--primary-color);
      color: var(--primary-contrast);

      .checkbox-icon {
        opacity: 1;
        transform: scale(1);
      }
    }
  }

  // الحالة المعطلة
  &.is-disabled {
    cursor: not-allowed;
    opacity: 0.6;

    .checkbox-custom {
      background: var(--disabled-bg);
    }
  }

  // حالة الخطأ
  &.has-error {
    .checkbox-custom {
      border-color: var(--danger-color);
    }
  }

  // التفاعلات
  &:hover:not(.is-disabled) {
    .checkbox-custom {
      border-color: var(--primary-color);
    }
  }

  .checkbox-input:focus-visible + .checkbox-custom {
    box-shadow: 0 0 0 3px rgba(var(--primary-color-rgb), 0.1);
  }
}

// رسالة الخطأ
.error-message {
  margin-top: 0.25rem;
  font-size: 0.75rem;
  color: var(--danger-color);
}
</style>