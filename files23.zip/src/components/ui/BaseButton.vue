/**
 * مكون الزر الأساسي
 * التاريخ: 2025-05-09 03:50:58
 * المستخدم: mostafamohammad7760
 */

<template>
  <button
    :class="[
      'base-button',
      variant,
      size,
      {
        'is-loading': loading,
        'is-block': block,
        'is-disabled': disabled,
        'has-icon': icon,
        'icon-only': iconOnly
      }
    ]"
    :disabled="disabled || loading"
    :type="type"
    @click="handleClick"
  >
    <!-- أيقونة يسار -->
    <i v-if="icon && !iconRight" :class="['button-icon', icon]"></i>

    <!-- محتوى الزر -->
    <span v-if="!iconOnly" class="button-content">
      <slot>{{ text }}</slot>
    </span>

    <!-- أيقونة يمين -->
    <i v-if="icon && iconRight" :class="['button-icon', icon]"></i>

    <!-- مؤشر التحميل -->
    <span v-if="loading" class="loading-spinner">
      <svg viewBox="0 0 24 24">
        <circle
          cx="12"
          cy="12"
          r="10"
          fill="none"
          stroke="currentColor"
          stroke-width="3"
        />
      </svg>
    </span>
  </button>
</template>

<script lang="ts">
import { defineComponent } from 'vue';

export default defineComponent({
  name: 'BaseButton',

  props: {
    // نص الزر
    text: {
      type: String,
      default: ''
    },
    // نوع الزر
    type: {
      type: String as () => 'button' | 'submit' | 'reset',
      default: 'button'
    },
    // نمط الزر
    variant: {
      type: String as () => 'primary' | 'secondary' | 'success' | 'danger' | 'warning' | 'info' | 'light' | 'dark',
      default: 'primary'
    },
    // حجم الزر
    size: {
      type: String as () => 'sm' | 'md' | 'lg',
      default: 'md'
    },
    // الأيقونة
    icon: {
      type: String,
      default: ''
    },
    // موضع الأيقونة (يمين/يسار)
    iconRight: {
      type: Boolean,
      default: false
    },
    // زر أيقونة فقط
    iconOnly: {
      type: Boolean,
      default: false
    },
    // ملء العرض
    block: {
      type: Boolean,
      default: false
    },
    // تعطيل الزر
    disabled: {
      type: Boolean,
      default: false
    },
    // حالة التحميل
    loading: {
      type: Boolean,
      default: false
    }
  },

  emits: ['click'],

  setup(props, { emit }) {
    // معالجة النقر
    const handleClick = (event: MouseEvent) => {
      if (!props.disabled && !props.loading) {
        emit('click', event);
      }
    };

    return {
      handleClick
    };
  }
});
</script>

<style lang="scss" scoped>
.base-button {
  // الخصائص الأساسية
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  padding: 0.625rem 1rem;
  border: 1px solid transparent;
  border-radius: var(--border-radius);
  font-family: inherit;
  font-weight: 500;
  text-align: center;
  white-space: nowrap;
  cursor: pointer;
  transition: all 0.2s ease;
  user-select: none;
  position: relative;
  overflow: hidden;

  // الأحجام
  &.sm {
    padding: 0.375rem 0.75rem;
    font-size: 0.875rem;
    
    .button-icon {
      font-size: 0.875rem;
    }
  }

  &.lg {
    padding: 0.875rem 1.5rem;
    font-size: 1.125rem;

    .button-icon {
      font-size: 1.125rem;
    }
  }

  // الأنماط
  &.primary {
    background: var(--primary-color);
    color: var(--primary-contrast);
    
    &:hover:not(:disabled) {
      background: var(--primary-dark);
    }
  }

  &.secondary {
    background: var(--secondary-color);
    color: var(--secondary-contrast);
    
    &:hover:not(:disabled) {
      background: var(--secondary-dark);
    }
  }

  &.success {
    background: var(--success-color);
    color: var(--success-contrast);
    
    &:hover:not(:disabled) {
      background: var(--success-dark);
    }
  }

  &.danger {
    background: var(--danger-color);
    color: var(--danger-contrast);
    
    &:hover:not(:disabled) {
      background: var(--danger-dark);
    }
  }

  &.warning {
    background: var(--warning-color);
    color: var(--warning-contrast);
    
    &:hover:not(:disabled) {
      background: var(--warning-dark);
    }
  }

  &.info {
    background: var(--info-color);
    color: var(--info-contrast);
    
    &:hover:not(:disabled) {
      background: var(--info-dark);
    }
  }

  &.light {
    background: var(--light-color);
    color: var(--light-contrast);
    border: 1px solid var(--border-color);
    
    &:hover:not(:disabled) {
      background: var(--light-dark);
    }
  }

  &.dark {
    background: var(--dark-color);
    color: var(--dark-contrast);
    
    &:hover:not(:disabled) {
      background: var(--dark-light);
    }
  }

  // الحالات
  &.is-loading {
    color: transparent !important;
    pointer-events: none;

    .loading-spinner {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      
      svg {
        width: 1.5em;
        height: 1.5em;
        animation: spin 1s linear infinite;
        
        circle {
          opacity: 0.25;
          
          &:nth-child(1) {
            opacity: 1;
            stroke-dasharray: 60;
            stroke-dashoffset: 60;
            animation: loading 1s cubic-bezier(0.4, 0, 0.2, 1) infinite;
          }
        }
      }
    }
  }

  &.is-disabled,
  &:disabled {
    opacity: 0.65;
    cursor: not-allowed;
    pointer-events: none;
  }

  &.is-block {
    width: 100%;
  }

  &.icon-only {
    padding: 0.625rem;
    
    &.sm {
      padding: 0.375rem;
    }
    
    &.lg {
      padding: 0.875rem;
    }
  }

  // تأثيرات إضافية
  &:focus {
    outline: none;
    box-shadow: 0 0 0 3px rgba(var(--primary-color-rgb), 0.25);
  }

  &:active:not(:disabled) {
    transform: translateY(1px);
  }
}

// الرسوم المتحركة
@keyframes spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}

@keyframes loading {
  0% {
    stroke-dashoffset: 60;
  }
  50% {
    stroke-dashoffset: 30;
  }
  100% {
    stroke-dashoffset: 0;
  }
}
</style>