/**
 * مسارات API لنظام نقاط البيع
 * التاريخ: 2025-05-09 03:20:03
 * المستخدم: mostafamohammad7760
 */

const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');
const {
    validateSale,
    validateProduct,
    validateCustomer
} = require('../validators/pos');

const SalesController = require('../controllers/SalesController');
const ProductsController = require('../controllers/ProductsController');
const CustomersController = require('../controllers/CustomersController');
const InventoryController = require('../controllers/InventoryController');
const ShiftsController = require('../controllers/ShiftsController');

// مسارات المبيعات
router.post('/sales', 
    authMiddleware.requireAuth,
    validateSale,
    SalesController.createSale
);

router.get('/sales', 
    authMiddleware.requireAuth,
    SalesController.getSales
);

router.get('/sales/:id', 
    authMiddleware.requireAuth,
    SalesController.getSaleById
);

router.put('/sales/:id/void', 
    authMiddleware.requireAuth,
    authMiddleware.requirePermission('void_sale'),
    SalesController.voidSale
);

router.post('/sales/:id/refund', 
    authMiddleware.requireAuth,
    authMiddleware.requirePermission('refund_sale'),
    SalesController.refundSale
);

// مسارات المنتجات
router.get('/products', 
    authMiddleware.requireAuth,
    ProductsController.getProducts
);

router.post('/products', 
    authMiddleware.requireAuth,
    authMiddleware.requirePermission('manage_products'),
    validateProduct,
    ProductsController.createProduct
);

router.put('/products/:id', 
    authMiddleware.requireAuth,
    authMiddleware.requirePermission('manage_products'),
    validateProduct,
    ProductsController.updateProduct
);

router.delete('/products/:id', 
    authMiddleware.requireAuth,
    authMiddleware.requirePermission('manage_products'),
    ProductsController.deleteProduct
);

// مسارات العملاء
router.get('/customers', 
    authMiddleware.requireAuth,
    CustomersController.getCustomers
);

router.post('/customers', 
    authMiddleware.requireAuth,
    validateCustomer,
    CustomersController.createCustomer
);

router.put('/customers/:id', 
    authMiddleware.requireAuth,
    validateCustomer,
    CustomersController.updateCustomer
);

router.get('/customers/:id/history', 
    authMiddleware.requireAuth,
    CustomersController.getCustomerHistory
);

// مسارات المخزون
router.post('/inventory/transactions', 
    authMiddleware.requireAuth,
    authMiddleware.requirePermission('manage_inventory'),
    InventoryController.createTransaction
);

router.get('/inventory/alerts', 
    authMiddleware.requireAuth,
    InventoryController.getAlerts
);

router.post('/inventory/stocktake', 
    authMiddleware.requireAuth,
    authMiddleware.requirePermission('manage_inventory'),
    InventoryController.startStocktake
);

// مسارات الورديات
router.post('/shifts/start', 
    authMiddleware.requireAuth,
    authMiddleware.requirePermission('manage_shifts'),
    ShiftsController.startShift
);

router.post('/shifts/end', 
    authMiddleware.requireAuth,
    authMiddleware.requirePermission('manage_shifts'),
    ShiftsController.endShift
);

router.get('/shifts/current', 
    authMiddleware.requireAuth,
    ShiftsController.getCurrentShift
);

router.get('/shifts/:id/report', 
    authMiddleware.requireAuth,
    ShiftsController.getShiftReport
);

module.exports = router;