/**
 * مكون نافذة الدفع
 * التاريخ: 2025-05-09 04:27:31
 * المستخدم: mostafamohammad7760
 */

<template>
  <BaseModal
    title="دفع الفاتورة"
    :show="true"
    size="lg"
    @close="$emit('close')"
  >
    <div class="payment-modal">
      <!-- تفاصيل المبلغ -->
      <div class="amount-details">
        <div class="total-amount">
          <span>المبلغ المطلوب:</span>
          <span class="amount">{{ formatCurrency(amount) }}</span>
        </div>
        
        <template v-if="customer && customer.loyaltyPoints > 0">
          <div class="loyalty-points">
            <div class="points-info">
              <i class="fas fa-star"></i>
              <span>النقاط المتاحة: {{ customer.loyaltyPoints }}</span>
              <span>({{ formatCurrency(availablePointsValue) }})</span>
            </div>
            <BaseCheckbox
              v-model="usePoints"
              label="استخدام النقاط في الدفع"
              @change="calculateAmounts"
            />
          </div>
        </template>
      </div>

      <!-- طرق الدفع -->
      <div class="payment-methods">
        <h4>طريقة الدفع</h4>
        <div class="methods-grid">
          <button
            v-for="method in paymentMethods"
            :key="method.type"
            class="method-btn"
            :class="{
              'selected': selectedMethod === method.type,
              'disabled': !method.enabled
            }"
            @click="selectMethod(method)"
          >
            <i :class="method.icon"></i>
            <span>{{ method.name }}</span>
          </button>
        </div>
      </div>

      <!-- تفاصيل الدفع -->
      <div class="payment-details" v-if="selectedMethod">
        <!-- الدفع النقدي -->
        <template v-if="selectedMethod === 'cash'">
          <div class="cash-payment">
            <BaseInput
              v-model="cashAmount"
              label="المبلغ المستلم"
              type="number"
              :min="remainingAmount"
              @input="calculateChange"
            />
            <div class="quick-amounts">
              <button
                v-for="amount in quickAmounts"
                :key="amount"
                @click="setCashAmount(amount)"
              >
                {{ formatCurrency(amount) }}
              </button>
            </div>
            <div class="change-amount" v-if="changeAmount > 0">
              <span>المتبقي للعميل:</span>
              <span class="amount">{{ formatCurrency(changeAmount) }}</span>
            </div>
          </div>
        </template>

        <!-- الدفع بالبطاقة -->
        <template v-else-if="selectedMethod === 'card'">
          <div class="card-payment">
            <BaseSelect
              v-model="cardType"
              label="نوع البطاقة"
              :options="cardTypes"
              required
            />
            <BaseInput
              v-model="transactionNumber"
              label="رقم العملية"
              required
            />
          </div>
        </template>

        <!-- التحويل البنكي -->
        <template v-else-if="selectedMethod === 'bank'">
          <div class="bank-payment">
            <BaseSelect
              v-model="bankAccount"
              label="الحساب البنكي"
              :options="bankAccounts"
              required
            />
            <BaseInput
              v-model="transferReference"
              label="رقم الحوالة"
              required
            />
          </div>
        </template>
      </div>

      <!-- ملخص الدفع -->
      <div class="payment-summary">
        <div class="summary-row">
          <span>المبلغ المطلوب:</span>
          <span>{{ formatCurrency(amount) }}</span>
        </div>
        <div class="summary-row" v-if="pointsAmount > 0">
          <span>خصم النقاط:</span>
          <span>- {{ formatCurrency(pointsAmount) }}</span>
        </div>
        <div class="summary-row remaining">
          <span>المبلغ المتبقي:</span>
          <span>{{ formatCurrency(remainingAmount) }}</span>
        </div>
      </div>

      <!-- أزرار التحكم -->
      <div class="modal-actions">
        <BaseButton
          variant="secondary"
          @click="$emit('close')"
        >
          إلغاء
        </BaseButton>
        <BaseButton
          variant="primary"
          :disabled="!isValid"
          @click="completePayment"
        >
          إتمام الدفع
        </BaseButton>
      </div>
    </div>
  </BaseModal>
</template>

<script lang="ts">
import { defineComponent, ref, computed } from 'vue';
import { formatCurrency } from '@/utils/currency';

export default defineComponent({
  name: 'PaymentModal',

  props: {
    amount: {
      type: Number,
      required: true
    },
    customer: {
      type: Object,
      default: null
    }
  },

  emits: ['close', 'complete'],

  setup(props) {
    // حالة النقاط
    const usePoints = ref(false);
    const pointValue = 0.5; // قيمة النقطة بالريال
    const maxPointsPercentage = 0.2; // 20% كحد أقصى من قيمة الفاتورة

    // حالة طرق الدفع
    const selectedMethod = ref('');
    const paymentMethods = [
      {
        type: 'cash',
        name: 'نقدي',
        icon: 'fas fa-money-bill-wave',
        enabled: true
      },
      {
        type: 'card',
        name: 'بطاقة',
        icon: 'fas fa-credit-card',
        enabled: true
      },
      {
        type: 'bank',
        name: 'تحويل بنكي',
        icon: 'fas fa-university',
        enabled: true
      }
    ];

    // حالة الدفع النقدي
    const cashAmount = ref(0);
    const changeAmount = ref(0);
    const quickAmounts = [50, 100, 200, 500];

    // حالة الدفع بالبطاقة
    const cardType = ref('');
    const transactionNumber = ref('');
    const cardTypes = [
      { value: 'visa', label: 'فيزا' },
      { value: 'mastercard', label: 'ماستركارد' },
      { value: 'mada', label: 'مدى' }
    ];

    // حالة التحويل البنكي
    const bankAccount = ref('');
    const transferReference = ref('');
    const bankAccounts = [
      { value: '1', label: 'البنك الأول - 123456789' },
      { value: '2', label: 'البنك الثاني - 987654321' }
    ];

    // حسابات المبالغ
    const availablePointsValue = computed(() => {
      if (!props.customer) return 0;
      return props.customer.loyaltyPoints * pointValue;
    });

    const maxPointsAmount = computed(() => {
      return props.amount * maxPointsPercentage;
    });

    const pointsAmount = computed(() => {
      if (!usePoints.value || !props.customer) return 0;
      return Math.min(availablePointsValue.value, maxPointsAmount.value);
    });

    const remainingAmount = computed(() => {
      return props.amount - pointsAmount.value;
    });

    // التحقق من صحة البيانات
    const isValid = computed(() => {
      if (!selectedMethod.value) return false;

      switch (selectedMethod.value) {
        case 'cash':
          return cashAmount.value >= remainingAmount.value;
        case 'card':
          return cardType.value && transactionNumber.value;
        case 'bank':
          return bankAccount.value && transferReference.value;
        default:
          return false;
      }
    });

    // الوظائف
    const selectMethod = (method: any) => {
      if (!method.enabled) return;
      selectedMethod.value = method.type;
      
      // إعادة تعيين القيم
      cashAmount.value = 0;
      changeAmount.value = 0;
      cardType.value = '';
      transactionNumber.value = '';
      bankAccount.value = '';
      transferReference.value = '';
    };

    const setCashAmount = (amount: number) => {
      cashAmount.value = amount;
      calculateChange();
    };

    const calculateChange = () => {
      changeAmount.value = Math.max(0, cashAmount.value - remainingAmount.value);
    };

    const completePayment = () => {
      const paymentData = {
        usePoints: usePoints.value,
        pointsAmount: pointsAmount.value,
        method: {
          type: selectedMethod.value,
          amount: remainingAmount.value
        }
      };

      switch (selectedMethod.value) {
        case 'cash':
          paymentData.method = {
            ...paymentData.method,
            received: cashAmount.value,
            change: changeAmount.value
          };
          break;
        case 'card':
          paymentData.method = {
            ...paymentData.method,
            cardType: cardType.value,
            transactionNumber: transactionNumber.value
          };
          break;
        case 'bank':
          paymentData.method = {
            ...paymentData.method,
            bankAccount: bankAccount.value,
            reference: transferReference.value
          };
          break;
      }

      emit('complete', paymentData);
    };

    return {
      // الحالة
      usePoints,
      selectedMethod,
      paymentMethods,
      cashAmount,
      changeAmount,
      quickAmounts,
      cardType,
      transactionNumber,
      cardTypes,
      bankAccount,
      transferReference,
      bankAccounts,

      // القيم المحسوبة
      availablePointsValue,
      pointsAmount,
      remainingAmount,
      isValid,

      // الوظائف
      formatCurrency,
      selectMethod,
      setCashAmount,
      calculateChange,
      completePayment
    };
  }
});
</script>

<style lang="scss" scoped>
.payment-modal {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;

  .amount-details {
    text-align: center;

    .total-amount {
      font-size: 1.5rem;
      margin-bottom: 1rem;

      .amount {
        font-weight: 600;
        color: var(--primary-color);
      }
    }

    .loyalty-points {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 0.5rem;
      padding: 1rem;
      background: var(--bg-secondary);
      border-radius: var(--border-radius);

      .points-info {
        display: flex;
        align-items: center;
        gap: 0.5rem;

        i {
          color: #ffc107;
        }
      }
    }
  }

  .payment-methods {
    .methods-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
      gap: 1rem;
      margin-top: 1rem;

      .method-btn {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 0.5rem;
        padding: 1rem;
        border: 2px solid var(--border-color);
        border-radius: var(--border-radius);
        background: none;
        cursor: pointer;
        transition: all 0.2s ease;

        &:hover:not(.disabled) {
          border-color: var(--primary-color);
        }

        &.selected {
          background: var(--primary-color);
          border-color: var(--primary-color);
          color: var(--primary-contrast);
        }

        &.disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }

        i {
          font-size: 1.5rem;
        }
      }
    }
  }

  .payment-details {
    padding: 1rem;
    background: var(--bg-secondary);
    border-radius: var(--border-radius);

    .cash-payment {
      .quick-amounts {
        display: flex;
        flex-wrap: wrap;
        gap: 0.5rem;
        margin: 1rem 0;

        button {
          padding: 0.5rem 1rem;
          border: 1px solid var(--border-color);
          border-radius: var(--border-radius);
          background: var(--bg-primary);
          cursor: pointer;

          &:hover {
            background: var(--bg-hover);
          }
        }
      }

      .change-amount {
        margin-top: 1rem;
        text-align: center;
        font-size: 1.25rem;

        .amount {
          font-weight: 600;
          color: var(--success-color);
        }
      }
    }
  }

  .payment-summary {
    padding: 1rem;
    background: var(--bg-secondary);
    border-radius: var(--border-radius);

    .summary-row {
      display: flex;
      justify-content: space-between;
      padding: 0.5rem 0;

      &.remaining {
        font-size: 1.25rem;
        font-weight: 600;
        color: var(--primary-color);
        border-top: 1px solid var(--border-color);
        margin-top: 0.5rem;
        padding-top: 1rem;
      }
    }
  }

  .modal-actions {
    display: flex;
    justify-content: flex-end;
    gap: 1rem;
    margin-top: 1rem;
  }
}
</style>