/**
 * مكون مفتاح التبديل الأساسي
 * التاريخ: 2025-05-09 03:58:46
 * المستخدم: mostafamohammad7760
 */

<template>
  <label
    :class="[
      'base-switch',
      size,
      {
        'is-checked': modelValue,
        'is-disabled': disabled,
        'has-error': error
      }
    ]"
  >
    <!-- زر التبديل الأصلي (مخفي) -->
    <input
      type="checkbox"
      :checked="modelValue"
      :name="name"
      :disabled="disabled"
      :required="required"
      class="switch-input"
      @change="handleChange"
    >

    <!-- زر التبديل المخصص -->
    <span class="switch-track">
      <span class="switch-thumb">
        <!-- أيقونات الحالة -->
        <span v-if="showIcons" class="switch-icon">
          <i v-if="modelValue" class="fas fa-check"></i>
          <i v-else class="fas fa-times"></i>
        </span>
      </span>
    </span>

    <!-- التسمية -->
    <span v-if="$slots.default" class="switch-label">
      <slot></slot>
    </span>

    <!-- النصوص -->
    <span v-if="labels" class="switch-text">
      {{ modelValue ? labels.checked : labels.unchecked }}
    </span>
  </label>

  <!-- رسالة الخطأ -->
  <div v-if="error" class="error-message">
    {{ error }}
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue';

export default defineComponent({
  name: 'BaseSwitch',

  props: {
    // القيمة المحددة
    modelValue: {
      type: Boolean,
      default: false
    },
    // الاسم
    name: {
      type: String,
      default: ''
    },
    // الحجم
    size: {
      type: String,
      default: 'md',
      validator: (value: string) => ['sm', 'md', 'lg'].includes(value)
    },
    // معطل
    disabled: {
      type: Boolean,
      default: false
    },
    // إلزامي
    required: {
      type: Boolean,
      default: false
    },
    // إظهار الأيقونات
    showIcons: {
      type: Boolean,
      default: false
    },
    // نصوص الحالات
    labels: {
      type: Object as PropType<{
        checked: string;
        unchecked: string;
      }>,
      default: null
    },
    // رسالة الخطأ
    error: {
      type: String,
      default: ''
    }
  },

  emits: ['update:modelValue', 'change'],

  setup(props, { emit }) {
    // معالجة التغيير
    const handleChange = (event: Event) => {
      const target = event.target as HTMLInputElement;
      emit('update:modelValue', target.checked);
      emit('change', target.checked);
    };

    return {
      handleChange
    };
  }
});
</script>

<style lang="scss" scoped>
.base-switch {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  cursor: pointer;
  user-select: none;

  // إخفاء الزر الأصلي
  .switch-input {
    position: absolute;
    opacity: 0;
    width: 0;
    height: 0;
  }

  // المسار
  .switch-track {
    position: relative;
    display: inline-block;
    width: 3rem;
    height: 1.5rem;
    background: var(--border-color);
    border-radius: 999px;
    transition: all 0.2s ease;

    // زر التحريك
    .switch-thumb {
      position: absolute;
      top: 0.125rem;
      left: 0.125rem;
      width: 1.25rem;
      height: 1.25rem;
      background: white;
      border-radius: 50%;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
      justify-content: center;

      // أيقونات الحالة
      .switch-icon {
        font-size: 0.75rem;
        color: var(--text-secondary);
      }
    }
  }

  // التسمية
  .switch-label {
    font-size: 1rem;
    color: var(--text-color);
  }

  // نصوص الحالات
  .switch-text {
    font-size: 0.875rem;
    color: var(--text-secondary);
  }

  // الأحجام
  &.sm {
    .switch-track {
      width: 2.5rem;
      height: 1.25rem;

      .switch-thumb {
        width: 1rem;
        height: 1rem;

        .switch-icon {
          font-size: 0.625rem;
        }
      }
    }

    .switch-label {
      font-size: 0.875rem;
    }
  }

  &.lg {
    .switch-track {
      width: 3.5rem;
      height: 1.75rem;

      .switch-thumb {
        width: 1.5rem;
        height: 1.5rem;

        .switch-icon {
          font-size: 0.875rem;
        }
      }
    }

    .switch-label {
      font-size: 1.125rem;
    }
  }

  // الحالة المفعلة
  &.is-checked {
    .switch-track {
      background: var(--primary-color);

      .switch-thumb {
        left: calc(100% - 1.375rem);

        .switch-icon {
          color: var(--primary-color);
        }
      }
    }
  }

  // الحالة المعطلة
  &.is-disabled {
    cursor: not-allowed;
    opacity: 0.6;

    .switch-track {
      background: var(--disabled-bg);
    }
  }

  // حالة الخطأ
  &.has-error {
    .switch-track {
      background: var(--danger-color);
    }
  }

  // التفاعلات
  &:hover:not(.is-disabled) {
    .switch-track {
      opacity: 0.8;
    }
  }

  .switch-input:focus-visible + .switch-track {
    box-shadow: 0 0 0 3px rgba(var(--primary-color-rgb), 0.1);
  }

  // الرسوم المتحركة
  &.is-checked .switch-thumb {
    transform: translateX(0);
  }

  &:not(.is-checked) .switch-thumb {
    transform: translateX(0);
  }
}

// رسالة الخطأ
.error-message {
  margin-top: 0.25rem;
  font-size: 0.75rem;
  color: var(--danger-color);
}

// التخصيص للغة العربية
[dir="rtl"] {
  .base-switch {
    .switch-thumb {
      right: 0.125rem;
      left: auto;
    }

    &.is-checked {
      .switch-thumb {
        right: calc(100% - 1.375rem);
        left: auto;
      }
    }
  }
}
</style>