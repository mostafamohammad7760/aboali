-- إنشاء جداول المدفوعات والمقبوضات

-- جدول الحسابات البنكية
CREATE TABLE bank_accounts (
    account_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    bank_name VARCHAR(200) NOT NULL,
    account_number VARCHAR(50) NOT NULL,
    iban VARCHAR(50),
    swift_code VARCHAR(20),
    currency VARCHAR(3) NOT NULL DEFAULT 'SAR',
    opening_balance DECIMAL(18,2) DEFAULT 0,
    current_balance DECIMAL(18,2) DEFAULT 0,
    status ENUM('active', 'inactive') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50)
);

-- جدول الصندوق
CREATE TABLE cash_accounts (
    account_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'SAR',
    opening_balance DECIMAL(18,2) DEFAULT 0,
    current_balance DECIMAL(18,2) DEFAULT 0,
    status ENUM('active', 'inactive') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50)
);

-- جدول أنواع المدفوعات والمقبوضات
CREATE TABLE payment_types (
    type_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    category ENUM('payment', 'receipt') NOT NULL,
    status ENUM('active', 'inactive') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50)
);

-- جدول طرق الدفع
CREATE TABLE payment_methods (
    method_id VARCHAR(20) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    requires_bank_account BOOLEAN DEFAULT FALSE,
    requires_reference_number BOOLEAN DEFAULT FALSE,
    requires_due_date BOOLEAN DEFAULT FALSE,
    status ENUM('active', 'inactive') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50)
);

-- جدول سندات القبض
CREATE TABLE receipts (
    receipt_id VARCHAR(20) PRIMARY KEY,
    receipt_number VARCHAR(20) UNIQUE NOT NULL,
    receipt_date DATE NOT NULL,
    type_id VARCHAR(20) NOT NULL,
    customer_id VARCHAR(20),
    method_id VARCHAR(20) NOT NULL,
    bank_account_id VARCHAR(20),
    cash_account_id VARCHAR(20),
    reference_number VARCHAR(50),
    due_date DATE,
    amount DECIMAL(18,2) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'SAR',
    exchange_rate DECIMAL(18,6) DEFAULT 1,
    local_amount DECIMAL(18,2) NOT NULL,
    description TEXT,
    status ENUM('draft', 'posted', 'bounced', 'cancelled') DEFAULT 'draft',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (type_id) REFERENCES payment_types(type_id),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (method_id) REFERENCES payment_methods(method_id),
    FOREIGN KEY (bank_account_id) REFERENCES bank_accounts(account_id),
    FOREIGN KEY (cash_account_id) REFERENCES cash_accounts(account_id)
);

-- جدول تطبيق سندات القبض على الفواتير
CREATE TABLE receipt_applications (
    application_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    receipt_id VARCHAR(20) NOT NULL,
    invoice_id VARCHAR(20) NOT NULL,
    amount DECIMAL(18,2) NOT NULL,
    local_amount DECIMAL(18,2) NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    FOREIGN KEY (receipt_id) REFERENCES receipts(receipt_id),
    FOREIGN KEY (invoice_id) REFERENCES sales_invoices(invoice_id)
);

-- جدول سندات الصرف
CREATE TABLE payments (
    payment_id VARCHAR(20) PRIMARY KEY,
    payment_number VARCHAR(20) UNIQUE NOT NULL,
    payment_date DATE NOT NULL,
    type_id VARCHAR(20) NOT NULL,
    supplier_id VARCHAR(20),
    method_id VARCHAR(20) NOT NULL,
    bank_account_id VARCHAR(20),
    cash_account_id VARCHAR(20),
    reference_number VARCHAR(50),
    due_date DATE,
    amount DECIMAL(18,2) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'SAR',
    exchange_rate DECIMAL(18,6) DEFAULT 1,
    local_amount DECIMAL(18,2) NOT NULL,
    description TEXT,
    status ENUM('draft', 'posted', 'bounced', 'cancelled') DEFAULT 'draft',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (type_id) REFERENCES payment_types(type_id),
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id),
    FOREIGN KEY (method_id) REFERENCES payment_methods(method_id),
    FOREIGN KEY (bank_account_id) REFERENCES bank_accounts(account_id),
    FOREIGN KEY (cash_account_id) REFERENCES cash_accounts(account_id)
);

-- جدول تطبيق سندات الصرف على الفواتير
CREATE TABLE payment_applications (
    application_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    payment_id VARCHAR(20) NOT NULL,
    invoice_id VARCHAR(20) NOT NULL,
    amount DECIMAL(18,2) NOT NULL,
    local_amount DECIMAL(18,2) NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    FOREIGN KEY (payment_id) REFERENCES payments(payment_id),
    FOREIGN KEY (invoice_id) REFERENCES purchase_invoices(invoice_id)
);

-- جدول الشيكات المؤجلة
CREATE TABLE deferred_checks (
    check_id VARCHAR(20) PRIMARY KEY,
    check_number VARCHAR(50) NOT NULL,
    receipt_id VARCHAR(20),
    payment_id VARCHAR(20),
    bank_name VARCHAR(200) NOT NULL,
    bank_branch VARCHAR(200),
    amount DECIMAL(18,2) NOT NULL,
    due_date DATE NOT NULL,
    status ENUM('pending', 'collected', 'bounced', 'cancelled') DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(50),
    FOREIGN KEY (receipt_id) REFERENCES receipts(receipt_id),
    FOREIGN KEY (payment_id) REFERENCES payments(payment_id)
);

-- إجراءات مخزنة

DELIMITER //

-- إجراء تحديث رصيد الحساب البنكي
CREATE PROCEDURE update_bank_account_balance(
    IN p_account_id VARCHAR(20),
    IN p_amount DECIMAL(18,2),
    IN p_operation VARCHAR(1) -- '+' للإضافة، '-' للخصم
)
BEGIN
    IF p_operation = '+' THEN
        UPDATE bank_accounts
        SET current_balance = current_balance + p_amount,
            updated_at = NOW()
        WHERE account_id = p_account_id;
    ELSE
        UPDATE bank_accounts
        SET current_balance = current_balance - p_amount,
            updated_at = NOW()
        WHERE account_id = p_account_id;
    END IF;
END //

-- إجراء تحديث رصيد الصندوق
CREATE PROCEDURE update_cash_account_balance(
    IN p_account_id VARCHAR(20),
    IN p_amount DECIMAL(18,2),
    IN p_operation VARCHAR(1) -- '+' للإضافة، '-' للخصم
)
BEGIN
    IF p_operation = '+' THEN
        UPDATE cash_accounts
        SET current_balance = current_balance + p_amount,
            updated_at = NOW()
        WHERE account_id = p_account_id;
    ELSE
        UPDATE cash_accounts
        SET current_balance = current_balance - p_amount,
            updated_at = NOW()
        WHERE account_id = p_account_id;
    END IF;
END //

-- إجراء تحديث رصيد العميل عند ترحيل سند القبض
CREATE PROCEDURE update_customer_balance_on_receipt(
    IN p_customer_id VARCHAR(20),
    IN p_amount DECIMAL(18,2)
)
BEGIN
    UPDATE customers
    SET balance = balance - p_amount,
        updated_at = NOW()
    WHERE customer_id = p_customer_id;
END //

-- إجراء تحديث رصيد المورد عند ترحيل سند الصرف
CREATE PROCEDURE update_supplier_balance_on_payment(
    IN p_supplier_id VARCHAR(20),
    IN p_amount DECIMAL(18,2)
)
BEGIN
    UPDATE suppliers
    SET balance = balance - p_amount,
        updated_at = NOW()
    WHERE supplier_id = p_supplier_id;
END //

DELIMITER ;

-- المؤشرات
CREATE INDEX idx_bank_accounts_status ON bank_accounts(status);
CREATE INDEX idx_cash_accounts_status ON cash_accounts(status);
CREATE INDEX idx_payment_types_category ON payment_types(category);
CREATE INDEX idx_payment_types_status ON payment_types(status);
CREATE INDEX idx_payment_methods_status ON payment_methods(status);
CREATE INDEX idx_receipts_dates ON receipts(receipt_date);
CREATE INDEX idx_receipts_customer ON receipts(customer_id);
CREATE INDEX idx_receipts_status ON receipts(status);
CREATE INDEX idx_payments_dates ON payments(payment_date);
CREATE INDEX idx_payments_supplier ON payments(supplier_id);
CREATE INDEX idx_payments_status ON payments(status);
CREATE INDEX idx_deferred_checks_dates ON deferred_checks(due_date);
CREATE INDEX idx_deferred_checks_status ON deferred_checks(status);

-- إدخال البيانات الأساسية

-- أنواع المدفوعات والمقبوضات
INSERT INTO payment_types (type_id, code, name, category) VALUES
('RT001', 'CASH_RECEIPT', 'قبض نقدي', 'receipt'),
('RT002', 'CHECK_RECEIPT', 'قبض شيك', 'receipt'),
('RT003', 'TRANSFER_RECEIPT', 'قبض حوالة', 'receipt'),
('RT004', 'CREDIT_CARD_RECEIPT', 'قبض بطاقة ائتمان', 'receipt'),
('PT001', 'CASH_PAYMENT', 'صرف نقدي', 'payment'),
('PT002', 'CHECK_PAYMENT', 'صرف شيك', 'payment'),
('PT003', 'TRANSFER_PAYMENT', 'صرف حوالة', 'payment'),
('PT004', 'CREDIT_CARD_PAYMENT', 'صرف بطاقة ائتمان', 'payment');

-- طرق الدفع
INSERT INTO payment_methods (method_id, code, name, requires_bank_account, requires_reference_number, requires_due_date) VALUES
('PM001', 'CASH', 'نقداً', false, false, false),
('PM002', 'CHECK', 'شيك', true, true, true),
('PM003', 'BANK_TRANSFER', 'حوالة بنكية', true, true, false),
('PM004', 'CREDIT_CARD', 'بطاقة ائتمان', true, true, false);