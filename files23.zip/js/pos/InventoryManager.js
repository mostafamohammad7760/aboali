/**
 * مدير المخزون - إدارة المخزون في نظام نقاط البيع
 * @module InventoryManager
 * التاريخ: 2025-05-09 03:06:04
 * المستخدم: mostafamohammad7760
 */

export class InventoryManager {
    constructor(database) {
        this.db = database;
        this.transactionTypes = {
            PURCHASE: 'purchase',
            SALE: 'sale',
            RETURN: 'return',
            ADJUSTMENT: 'adjustment',
            TRANSFER: 'transfer',
            DAMAGE: 'damage'
        };

        // حدود التنبيه للمخزون
        this.alertThresholds = {
            LOW_STOCK: 'low_stock',
            OUT_OF_STOCK: 'out_of_stock',
            EXPIRING_SOON: 'expiring_soon',
            EXPIRED: 'expired'
        };
    }

    /**
     * إضافة حركة مخزون جديدة 
     * @param {Object} transaction - بيانات الحركة
     */
    async addInventoryTransaction(transaction) {
        try {
            // التحقق من صحة البيانات
            this.validateTransaction(transaction);

            const transactionId = this.generateTransactionId();
            
            await this.db.beginTransaction();

            // إدخال الحركة الرئيسية
            const query = `
                INSERT INTO inventory_transactions (
                    transaction_id,
                    type,
                    reference_id,
                    notes,
                    created_by
                ) VALUES (?, ?, ?, ?, ?)
            `;

            await this.db.executeQuery(query, [
                transactionId,
                transaction.type,
                transaction.reference_id,
                transaction.notes,
                this.currentUser
            ]);

            // إدخال تفاصيل الحركة
            for (const item of transaction.items) {
                await this.addTransactionDetail(transactionId, item);
                
                // تحديث رصيد المخزون
                await this.updateProductStock(
                    item.product_id,
                    item.quantity,
                    transaction.type
                );
            }

            await this.db.commit();

            // التحقق من حدود التنبيه
            await this.checkInventoryAlerts(transaction.items.map(item => item.product_id));

            return await this.getTransaction(transactionId);
        } catch (error) {
            await this.db.rollback();
            console.error('Error adding inventory transaction:', error);
            throw new Error('فشل إضافة حركة المخزون');
        }
    }

    /**
     * إضافة تفاصيل حركة
     * @param {string} transactionId - معرف الحركة
     * @param {Object} item - تفاصيل المنتج
     */
    async addTransactionDetail(transactionId, item) {
        const query = `
            INSERT INTO inventory_transaction_details (
                transaction_id,
                product_id,
                quantity,
                unit_cost,
                unit_price,
                batch_number,
                expiry_date,
                location_id
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `;

        await this.db.executeQuery(query, [
            transactionId,
            item.product_id,
            item.quantity,
            item.unit_cost || null,
            item.unit_price || null,
            item.batch_number || null,
            item.expiry_date || null,
            item.location_id
        ]);
    }

    /**
     * تحديث رصيد المخزون
     * @param {string} productId - معرف المنتج
     * @param {number} quantity - الكمية
     * @param {string} transactionType - نوع الحركة
     */
    async updateProductStock(productId, quantity, transactionType) {
        let updateQuery = 'UPDATE products SET stock_quantity = ';

        switch (transactionType) {
            case this.transactionTypes.PURCHASE:
            case this.transactionTypes.RETURN:
                updateQuery += 'stock_quantity + ?';
                break;

            case this.transactionTypes.SALE:
            case this.transactionTypes.DAMAGE:
                updateQuery += 'stock_quantity - ?';
                break;

            case this.transactionTypes.ADJUSTMENT:
                updateQuery += '?';
                break;

            default:
                throw new Error('نوع الحركة غير صالح');
        }

        updateQuery += ' WHERE product_id = ?';
        await this.db.executeQuery(updateQuery, [quantity, productId]);
    }

    /**
     * التحقق من حدود التنبيه
     * @param {Array} productIds - معرفات المنتجات
     */
    async checkInventoryAlerts(productIds) {
        const alerts = [];

        for (const productId of productIds) {
            const product = await this.getProduct(productId);
            
            // التحقق من نفاد المخزون
            if (product.stock_quantity <= 0) {
                alerts.push({
                    type: this.alertThresholds.OUT_OF_STOCK,
                    product_id: productId,
                    message: `نفاد مخزون ${product.name_ar}`
                });
            }
            // التحقق من المخزون المنخفض
            else if (product.stock_quantity <= product.min_quantity) {
                alerts.push({
                    type: this.alertThresholds.LOW_STOCK,
                    product_id: productId,
                    message: `مخزون منخفض: ${product.name_ar}`
                });
            }

            // التحقق من تاريخ الصلاحية
            if (product.expiry_date) {
                const daysToExpiry = this.calculateDaysToExpiry(product.expiry_date);
                
                if (daysToExpiry <= 0) {
                    alerts.push({
                        type: this.alertThresholds.EXPIRED,
                        product_id: productId,
                        message: `منتج منتهي الصلاحية: ${product.name_ar}`
                    });
                }
                else if (daysToExpiry <= 30) {
                    alerts.push({
                        type: this.alertThresholds.EXPIRING_SOON,
                        product_id: productId,
                        message: `منتج قريب من انتهاء الصلاحية: ${product.name_ar}`
                    });
                }
            }
        }

        if (alerts.length > 0) {
            await this.notifyInventoryAlerts(alerts);
        }

        return alerts;
    }

    /**
     * إرسال تنبيهات المخزون
     * @param {Array} alerts - التنبيهات
     */
    async notifyInventoryAlerts(alerts) {
        for (const alert of alerts) {
            await this.db.executeQuery(`
                INSERT INTO inventory_alerts (
                    alert_type,
                    product_id,
                    message,
                    created_by
                ) VALUES (?, ?, ?, ?)
            `, [
                alert.type,
                alert.product_id,
                alert.message,
                this.currentUser
            ]);
        }

        // يمكن إضافة آليات تنبيه أخرى هنا (بريد إلكتروني، إشعارات، إلخ)
    }

    /**
     * حساب الأيام المتبقية حتى انتهاء الصلاحية
     * @param {Date} expiryDate - تاريخ انتهاء الصلاحية
     */
    calculateDaysToExpiry(expiryDate) {
        const today = new Date();
        const expiry = new Date(expiryDate);
        const diffTime = expiry - today;
        return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    }

    /**
     * التحقق من صحة بيانات الحركة
     * @param {Object} transaction - بيانات الحركة
     */
    validateTransaction(transaction) {
        const errors = [];

        if (!this.transactionTypes[transaction.type]) {
            errors.push('نوع الحركة غير صالح');
        }

        if (!transaction.items || transaction.items.length === 0) {
            errors.push('يجب إضافة منتج واحد على الأقل');
        }

        for (const item of transaction.items || []) {
            if (!item.product_id) {
                errors.push('معرف المنتج مطلوب');
            }

            if (!item.quantity || item.quantity <= 0) {
                errors.push('الكمية يجب أن تكون أكبر من 0');
            }

            if (item.expiry_date && new Date(item.expiry_date) <= new Date()) {
                errors.push('تاريخ الصلاحية يجب أن يكون في المستقبل');
            }
        }

        if (errors.length > 0) {
            throw new Error(errors.join('\n'));
        }
    }

    /**
     * توليد معرف فريد للحركة
     */
    generateTransactionId() {
        return 'TRX-' + Date.now().toString(36).toUpperCase();
    }

    /**
     * الحصول على تفاصيل حركة
     * @param {string} transactionId - معرف الحركة
     */
    async getTransaction(transactionId) {
        const [transaction] = await this.db.executeQuery(`
            SELECT 
                t.*,
                u.username as created_by_user
            FROM inventory_transactions t
            JOIN users u ON t.created_by = u.user_id
            WHERE t.transaction_id = ?
        `, [transactionId]);

        if (!transaction) {
            throw new Error('الحركة غير موجودة');
        }

        // جلب تفاصيل الحركة
        transaction.items = await this.db.executeQuery(`
            SELECT 
                d.*,
                p.name_ar,
                p.name_en,
                p.barcode
            FROM inventory_transaction_details d
            JOIN products p ON d.product_id = p.product_id
            WHERE d.transaction_id = ?
        `, [transactionId]);

        return transaction;
    }
}