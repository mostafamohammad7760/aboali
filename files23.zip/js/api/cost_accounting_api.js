export class CostAccountingAPI {
    constructor() {
        this.baseUrl = '/api/v1/cost-accounting';
        this.defaultHeaders = {
            'Content-Type': 'application/json',
            'X-User-Id': 'mostafamohammad7760',
            'X-Timestamp': new Date().toISOString()
        };
    }

    async request(endpoint, options = {}) {
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                ...options,
                headers: {
                    ...this.defaultHeaders,
                    ...options.headers
                }
            });

            if (!response.ok) {
                throw await this.handleErrorResponse(response);
            }

            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            throw this.createUserFriendlyError(error);
        }
    }

    // طلبات لوحة المعلومات
    async getCostCenterStats() {
        return this.request('/dashboard/center-stats');
    }

    async getCostStats() {
        return this.request('/dashboard/cost-stats');
    }

    async getCostOrderStats() {
        return this.request('/dashboard/order-stats');
    }

    async getVarianceStats() {
        return this.request('/dashboard/variance-stats');
    }

    async getCostAnalysis(period = 'month') {
        return this.request(`/dashboard/cost-analysis?period=${period}`);
    }

    async getVarianceAnalysis(period = 'month') {
        return this.request(`/dashboard/variance-analysis?period=${period}`);
    }

    async getLatestCostOrders() {
        return this.request('/dashboard/latest-orders');
    }

    // طلبات مراكز التكلفة
    async getCostCenters(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/centers?${queryString}`);
    }

    async getCostCenter(centerId) {
        return this.request(`/centers/${centerId}`);
    }

    async createCostCenter(centerData) {
        this.validateCenterData(centerData);
        return this.request('/centers', {
            method: 'POST',
            body: JSON.stringify(centerData)
        });
    }

    async updateCostCenter(centerId, centerData) {
        this.validateCenterData(centerData);
        return this.request(`/centers/${centerId}`, {
            method: 'PUT',
            body: JSON.stringify(centerData)
        });
    }

    async deactivateCostCenter(centerId) {
        return this.request(`/centers/${centerId}/deactivate`, {
            method: 'PUT'
        });
    }

    // طلبات عناصر التكلفة
    async getCostElements(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/elements?${queryString}`);
    }

    async getCostElement(elementId) {
        return this.request(`/elements/${elementId}`);
    }

    async createCostElement(elementData) {
        this.validateElementData(elementData);
        return this.request('/elements', {
            method: 'POST',
            body: JSON.stringify(elementData)
        });
    }

    async updateCostElement(elementId, elementData) {
        this.validateElementData(elementData);
        return this.request(`/elements/${elementId}`, {
            method: 'PUT',
            body: JSON.stringify(elementData)
        });
    }

    // طلبات وحدات التكلفة
    async getCostUnits(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/units?${queryString}`);
    }

    async getCostUnit(unitId) {
        return this.request(`/units/${unitId}`);
    }

    async createCostUnit(unitData) {
        this.validateUnitData(unitData);
        return this.request('/units', {
            method: 'POST',
            body: JSON.stringify(unitData)
        });
    }

    async updateCostUnit(unitId, unitData) {
        this.validateUnitData(unitData);
        return this.request(`/units/${unitId}`, {
            method: 'PUT',
            body: JSON.stringify(unitData)
        });
    }

    // طلبات معايير التكلفة
    async getCostStandards(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/standards?${queryString}`);
    }

    async createCostStandard(standardData) {
        this.validateStandardData(standardData);
        return this.request('/standards', {
            method: 'POST',
            body: JSON.stringify(standardData)
        });
    }

    async updateCostStandard(standardId, standardData) {
        this.validateStandardData(standardData);
        return this.request(`/standards/${standardId}`, {
            method: 'PUT',
            body: JSON.stringify(standardData)
        });
    }

    // طلبات توزيع التكاليف
    async allocateCosts(allocationData) {
        this.validateAllocationData(allocationData);
        return this.request('/allocations', {
            method: 'POST',
            body: JSON.stringify(allocationData)
        });
    }

    async getAllocations(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/allocations?${queryString}`);
    }

    async postAllocation(allocationId) {
        return this.request(`/allocations/${allocationId}/post`, {
            method: 'PUT'
        });
    }

    // طلبات أوامر التكلفة
    async getCostOrders(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/orders?${queryString}`);
    }

    async getCostOrder(orderId) {
        return this.request(`/orders/${orderId}`);
    }

    async createCostOrder(orderData) {
        this.validateOrderData(orderData);
        return this.request('/orders', {
            method: 'POST',
            body: JSON.stringify(orderData)
        });
    }

    async updateCostOrder(orderId, orderData) {
        this.validateOrderData(orderData);
        return this.request(`/orders/${orderId}`, {
            method: 'PUT',
            body: JSON.stringify(orderData)
        });
    }

    async updateOrderCompletion(orderId, completionData) {
        return this.request(`/orders/${orderId}/completion`, {
            method: 'PUT',
            body: JSON.stringify(completionData)
        });
    }

    async cancelOrder(orderId, reason) {
        return this.request(`/orders/${orderId}/cancel`, {
            method: 'PUT',
            body: JSON.stringify({ reason })
        });
    }

    // طلبات تحليل الانحرافات
    async analyzeVariances(analysisData) {
        this.validateAnalysisData(analysisData);
        return this.request('/variances/analyze', {
            method: 'POST',
            body: JSON.stringify(analysisData)
        });
    }

    async getVariances(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/variances?${queryString}`);
    }

    async approveVariance(varianceId) {
        return this.request(`/variances/${varianceId}/approve`, {
            method: 'PUT'
        });
    }

    // توابع التحقق من صحة البيانات
    validateCenterData(centerData) {
        const requiredFields = ['code', 'name', 'type'];
        
        const missingFields = requiredFields.filter(field => !centerData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        return true;
    }

    validateElementData(elementData) {
        const requiredFields = ['code', 'name', 'type', 'nature', 'behavior'];
        
        const missingFields = requiredFields.filter(field => !elementData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        return true;
    }

    validateUnitData(unitData) {
        const requiredFields = ['code', 'name', 'type', 'measurement_unit'];
        
        const missingFields = requiredFields.filter(field => !unitData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        return true;
    }

    validateStandardData(standardData) {
        const requiredFields = [
            'element_id', 
            'unit_id', 
            'quantity', 
            'price', 
            'effective_date'
        ];
        
        const missingFields = requiredFields.filter(field => !standardData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        if (standardData.quantity <= 0 || standardData.price <= 0) {
            throw new Error('الكمية والسعر يجب أن يكونا أكبر من صفر');
        }

        return true;
    }

    validateAllocationData(allocationData) {
        const requiredFields = [
            'period_id',
            'from_center_id',
            'to_center_id',
            'element_id',
            'allocation_basis',
            'allocated_amount'
        ];
        
        const missingFields = requiredFields.filter(field => !allocationData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        if (allocationData.allocated_amount <= 0) {
            throw new Error('المبلغ المخصص يجب أن يكون أكبر من صفر');
        }

        return true;
    }

    validateOrderData(orderData) {
        const requiredFields = [
            'code',
            'description',
            'unit_id',
            'quantity',
            'start_date'
        ];
        
        const missingFields = requiredFields.filter(field => !orderData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        if (orderData.quantity <= 0) {
            throw new Error('الكمية يجب أن تكون أكبر من صفر');
        }

        if (orderData.end_date && 
            new Date(orderData.end_date) <= new Date(orderData.start_date)) {
            throw new Error('تاريخ النهاية يجب أن يكون بعد تاريخ البداية');
        }

        return true;
    }

    validateAnalysisData(analysisData) {
        const requiredFields = [
            'period_id',
            'element_id',
            'unit_id',
            'variance_type',
            'standard_amount',
            'actual_amount'
        ];
        
        const missingFields = requiredFields.filter(field => !analysisData[field]);
        if (missingFields.length > 0) {
            throw new Error(`الحقول التالية مطلوبة: ${missingFields.join(', ')}`);
        }

        return true;
    }

    // توابع معالجة الأخطاء
    async handleErrorResponse(response) {
        let error;
        try {
            const errorData = await response.json();
            error = new Error(errorData.message || 'حدث خطأ غير معروف');
            error.code = errorData.code;
            error.details = errorData.details;
        } catch {
            error = new Error(`خطأ في الطلب: ${response.status}`);
        }
        error.status = response.status;
        return error;
    }

    createUserFriendlyError(error) {
        const errorMessages = {
            400: 'البيانات المدخلة غير صحيحة',
            401: 'يرجى تسجيل الدخول مرة أخرى',
            403: 'ليس لديك صلاحية للقيام بهذا الإجراء',
            404: 'لم يتم العثور على البيانات المطلوبة',
            409: 'تعارض في البيانات',
            422: 'البيانات المدخلة غير صالحة',
            500: 'حدث خطأ في النظام'
        };

        return new Error(
            errorMessages[error.status] || 
            error.message || 
            'حدث خطأ غير متوقع'
        );
    }
}